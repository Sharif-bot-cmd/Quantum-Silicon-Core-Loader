def cmd_footer(args):
    """
    Advanced FOOTER command handler for comprehensive footer block analysis
    Supports multiple footer types, advanced parsing, and forensic analysis
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    print("\n[*] Starting QSLCL Footer Block Analysis...")

    # -----------------------------------------------------
    # Enhanced footer request with multiple types
    # -----------------------------------------------------
    footer_type = getattr(args, 'footer_type', 'STANDARD').upper()
    request_flags = build_footer_request_flags(args)
    
    payload = build_footer_payload(footer_type, request_flags, args)

    # -----------------------------------------------------
    # Multi-strategy dispatch with enhanced detection
    # -----------------------------------------------------
    resp = dispatch_footer_request(dev, footer_type, payload, args)

    if not resp:
        print("[!] No footer response received.")
        return False

    # -----------------------------------------------------
    # Enhanced response processing
    # -----------------------------------------------------
    status = qslcl_decode_rtf(resp)
    print(f"[*] Footer Response: {status['severity']} — {status['name']}")

    data = status.get("extra", b"")
    if not data:
        print("[!] FOOTER block empty or unavailable.")
        return False

    # -----------------------------------------------------
    # Comprehensive footer analysis
    # -----------------------------------------------------
    return analyze_footer_block(dev, data, args, footer_type)

def build_footer_request_flags(args):
    """
    Build comprehensive footer request flags
    """
    flags = 0x00
    
    # Basic flags
    if getattr(args, "raw", False):
        flags |= 0x01  # Raw footer data
    if getattr(args, "extended", False):
        flags |= 0x02  # Extended footer information
    if getattr(args, "verbose", False):
        flags |= 0x04  # Verbose footer data
    if getattr(args, "crc", False):
        flags |= 0x08  # Include CRC verification
    if getattr(args, "metadata", False):
        flags |= 0x10  # Include metadata
    
    # Advanced flags
    if getattr(args, "all", False):
        flags |= 0x80  # Request all available footers
    
    return flags

def build_footer_payload(footer_type, flags, args):
    """
    Build sophisticated footer request payload
    """
    payload = bytearray()
    
    # Footer type identifier
    type_mapping = {
        "STANDARD": b"FOOTER_STD\x00",
        "EXTENDED": b"FOOTER_EXT\x00",
        "SECURITY": b"FOOTER_SEC\x00",
        "BOOT": b"FOOTER_BOOT\x00",
        "LOADER": b"FOOTER_LDR\x00",
        "DEBUG": b"FOOTER_DBG\x00",
        "AUDIT": b"FOOTER_AUD\x00",
        "ALL": b"FOOTER_ALL\x00"
    }
    
    footer_header = type_mapping.get(footer_type, b"FOOTER_REQ\x00")
    payload.extend(footer_header)
    
    # Add flags
    payload.extend(struct.pack("<B", flags))
    
    # Add optional parameters
    if hasattr(args, 'footer_args') and args.footer_args:
        for arg in args.footer_args:
            try:
                if arg.startswith("0x"):
                    payload.extend(struct.pack("<I", int(arg, 16)))
                elif arg.isdigit():
                    payload.extend(struct.pack("<I", int(arg)))
                else:
                    payload.extend(arg.encode() + b"\x00")
            except:
                payload.extend(arg.encode() + b"\x00")
    
    # Add timestamp for request tracking
    timestamp = int(time.time())
    payload.extend(struct.pack("<I", timestamp))
    
    return bytes(payload)

def dispatch_footer_request(dev, footer_type, payload, args):
    """
    Multi-strategy footer request dispatch with fallbacks
    """
    strategies = [
        try_engine_footer_handler,
        try_par_footer_handler,
        try_vm5_footer_handler,
        try_idx_footer_handler,
        try_direct_footer_handler,
        try_generic_footer_handler
    ]
    
    for strategy in strategies:
        resp = strategy(dev, footer_type, payload, args)
        if resp:
            return resp
    
    return None

def try_engine_footer_handler(dev, footer_type, payload, args):
    """Try ENGINE block handler"""
    # Multiple possible opcodes for footer
    footer_opcodes = [0xF0, 0xF1, 0xF2, 0xF3, 0xF4]
    
    for opcode in footer_opcodes:
        if opcode in QSLCLEND_DB:
            print(f"[*] Using ENGINE handler (0x{opcode:02X}) for {footer_type} footer...")
            entry = QSLCLEND_DB[opcode]
            if isinstance(entry, dict):
                entry_data = entry.get("raw", b"")
            else:
                entry_data = entry
            
            pkt = b"QSLCLEND" + entry_data + payload
            resp = qslcl_dispatch(dev, "ENGINE", pkt)
            if resp:
                return resp
    return None

def try_par_footer_handler(dev, footer_type, payload, args):
    """Try QSLCLPAR footer handler"""
    footer_commands = [
        "FOOTER",
        f"FOOTER_{footer_type}",
        "GET_FOOTER",
        "READ_FOOTER"
    ]
    
    for cmd in footer_commands:
        if cmd in QSLCLPAR_DB:
            print(f"[*] Using PARSER handler ({cmd}) for {footer_type} footer...")
            resp = qslcl_dispatch(dev, cmd, payload)
            if resp:
                return resp
    return None

def try_vm5_footer_handler(dev, footer_type, payload, args):
    """Try QSLCLVM5 footer handler"""
    vm5_commands = [
        "FOOTER",
        f"FOOTER_{footer_type}",
        "FOOTER_READ"
    ]
    
    for cmd in vm5_commands:
        if cmd in QSLCLVM5_DB:
            print(f"[*] Using VM5 handler ({cmd}) for {footer_type} footer...")
            raw = QSLCLVM5_DB[cmd]["raw"]
            pkt = b"QSLCLVM5" + raw + payload
            resp = qslcl_dispatch(dev, "NANO", pkt)
            if resp:
                return resp
    return None

def try_idx_footer_handler(dev, footer_type, payload, args):
    """Try QSLCLIDX footer handler"""
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '').upper()
            if any(footer_keyword in entry_name for footer_keyword in ["FOOTER", "FOOT", "END"]):
                idx = entry.get('idx', 0)
                print(f"[*] Using IDX handler ({name}) for footer...")
                pkt = b"QSLCLIDX" + struct.pack("<I", idx) + payload
                resp = qslcl_dispatch(dev, "IDX", pkt)
                if resp:
                    return resp
    return None

def try_direct_footer_handler(dev, footer_type, payload, args):
    """Try direct footer command"""
    print(f"[*] Using direct FOOTER command for {footer_type}...")
    resp = qslcl_dispatch(dev, "FOOTER", payload)
    return resp

def try_generic_footer_handler(dev, footer_type, payload, args):
    """Final fallback handler"""
    print(f"[*] Using generic handler for {footer_type} footer...")
    resp = qslcl_dispatch(dev, footer_type, payload)
    return resp

def analyze_footer_block(dev, data, args, footer_type):
    """
    Comprehensive footer block analysis with multiple output formats
    """
    print(f"\n[*] Analyzing {footer_type} Footer Block ({len(data)} bytes)...")
    
    # -----------------------------------------------------
    # Save footer data if requested
    # -----------------------------------------------------
    if args.save:
        save_footer_data(data, args.save, footer_type)
    
    # -----------------------------------------------------
    # Parse footer structure based on type
    # -----------------------------------------------------
    footer_info = parse_footer_structure(data, footer_type)
    
    # -----------------------------------------------------
    # Display based on output format
    # -----------------------------------------------------
    display_footer_data(data, footer_info, args, footer_type)
    
    # -----------------------------------------------------
    # Additional analysis if verbose mode
    # -----------------------------------------------------
    if getattr(args, "verbose", False):
        perform_advanced_footer_analysis(data, footer_type)
    
    # -----------------------------------------------------
    # Validate footer integrity if requested
    # -----------------------------------------------------
    if getattr(args, "validate", False):
        validate_footer_integrity(data, footer_type)
    
    return True

def parse_footer_structure(data, footer_type):
    """
    Parse footer structure based on type and content
    """
    footer_info = {
        "type": footer_type,
        "size": len(data),
        "timestamp": None,
        "checksum": None,
        "version": None,
        "magic": None,
        "entries": []
    }
    
    # Try to identify footer magic/header
    if len(data) >= 8:
        magic = data[:8]
        footer_info["magic"] = magic.hex()
        
        # Common footer magic values
        magic_patterns = {
            b"QSLCLEND": "QSLCL Standard Footer",
            b"QSLCLFT8": "QSLCL Footer v8",
            b"ANDROID!": "Android Boot Footer",
            b"BOOTLDR!": "Bootloader Footer",
            b"SECUREFT": "Security Footer",
            b"DEBUGREC": "Debug Footer"
        }
        
        for pattern, description in magic_patterns.items():
            if magic.startswith(pattern):
                footer_info["description"] = description
                break
    
    # Try to extract timestamp
    if len(data) >= 12:
        try:
            timestamp = struct.unpack("<I", data[8:12])[0]
            if timestamp > 1577836800:  # Reasonable timestamp (after 2020)
                footer_info["timestamp"] = timestamp
                footer_info["time_string"] = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(timestamp))
        except:
            pass
    
    # Try to extract version information
    if len(data) >= 16:
        try:
            version = struct.unpack("<HH", data[12:16])  # major, minor
            footer_info["version"] = f"{version[0]}.{version[1]}"
        except:
            pass
    
    # Try to extract checksum
    if len(data) >= 20:
        try:
            checksum = struct.unpack("<I", data[16:20])[0]
            footer_info["checksum"] = f"0x{checksum:08X}"
        except:
            pass
    
    return footer_info

def display_footer_data(data, footer_info, args, footer_type):
    """
    Display footer data in various formats based on arguments
    """
    # -----------------------------------------------------
    # Header information
    # -----------------------------------------------------
    print(f"\n{'='*60}")
    print(f"FOOTER ANALYSIS: {footer_type}")
    print(f"{'='*60}")
    
    # Basic footer info
    print(f"Size: {footer_info['size']} bytes")
    if 'description' in footer_info:
        print(f"Type: {footer_info['description']}")
    if footer_info['magic']:
        print(f"Magic: {footer_info['magic']}")
    if footer_info['timestamp']:
        print(f"Timestamp: {footer_info['time_string']} (Unix: {footer_info['timestamp']})")
    if footer_info['version']:
        print(f"Version: {footer_info['version']}")
    if footer_info['checksum']:
        print(f"Checksum: {footer_info['checksum']}")
    
    # -----------------------------------------------------
    # Output format selection
    # -----------------------------------------------------
    if getattr(args, "hex", False):
        display_hex_dump(data, args)
    elif getattr(args, "raw", False):
        display_raw_binary(data)
    elif getattr(args, "structured", False):
        display_structured_footer(data, footer_info)
    elif getattr(args, "json", False):
        display_json_output(data, footer_info, args)
    else:
        display_smart_format(data, footer_info)
    
    print(f"{'='*60}")

def display_hex_dump(data, args):
    """Display hex dump of footer data"""
    print("\nHex Dump:")
    print("-" * 60)
    
    bytes_per_line = 16
    for i in range(0, len(data), bytes_per_line):
        chunk = data[i:i + bytes_per_line]
        hex_part = " ".join(f"{b:02x}" for b in chunk)
        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print(f"{i:08x}: {hex_part:<48} {ascii_part}")

def display_raw_binary(data):
    """Display raw binary data"""
    print("\nRaw Binary:")
    print("-" * 60)
    print(data.hex())

def display_structured_footer(data, footer_info):
    """Display structured footer analysis"""
    print("\nStructured Analysis:")
    print("-" * 60)
    
    # Analyze potential structure
    if len(data) >= 32:
        print("Potential Structure:")
        print(f"  Header (8 bytes): {data[:8].hex()}")
        print(f"  Timestamp (4 bytes): {struct.unpack('<I', data[8:12])[0] if len(data) >= 12 else 'N/A'}")
        print(f"  Version (4 bytes): {data[12:16].hex()}")
        print(f"  Checksum (4 bytes): {data[16:20].hex()}")
        print(f"  Reserved (12 bytes): {data[20:32].hex()}")
        
        if len(data) > 32:
            print(f"  Payload ({len(data)-32} bytes): {data[32:64].hex()}..." if len(data) > 64 else data[32:].hex())

def display_json_output(data, footer_info, args):
    """Display footer data as JSON"""
    import json
    
    json_output = {
        "footer_info": footer_info,
        "data_hex": data.hex(),
        "analysis_timestamp": time.time()
    }
    
    # Add data preview
    if len(data) <= 1024:  # Only include full data for small footers
        json_output["data_raw"] = list(data)
    
    print("\nJSON Output:")
    print("-" * 60)
    print(json.dumps(json_output, indent=2))

def display_smart_format(data, footer_info):
    """Smart format detection for footer display"""
    # Try to decode as text first
    try:
        text = data.decode('utf-8', errors='ignore').strip()
        printable_ratio = len([c for c in text if c.isprintable()]) / len(text) if text else 0
        
        if printable_ratio > 0.8:
            print("\nText Content:")
            print("-" * 60)
            print(text)
            return
    except:
        pass
    
    # Try structured parsing for common footer formats
    if len(data) >= 16 and data[:8] in [b"QSLCLEND", b"ANDROID!", b"BOOTLDR!"]:
        display_structured_footer(data, footer_info)
    else:
        # Fallback to hex dump for binary data
        display_hex_dump(data, None)

def save_footer_data(data, filename, footer_type):
    """Save footer data to file with proper formatting"""
    try:
        # Add footer type to filename if not specified
        if not any(ft in filename.upper() for ft in ["FOOTER", "FOOT"]):
            base, ext = os.path.splitext(filename)
            filename = f"{base}_{footer_type.lower()}{ext}"
        
        with open(filename, "wb") as f:
            f.write(data)
        
        # Also save analysis if verbose
        if getattr(args, "verbose", False):
            analysis_file = f"{os.path.splitext(filename)[0]}_analysis.txt"
            with open(analysis_file, "w") as f:
                f.write(f"Footer Analysis: {footer_type}\n")
                f.write(f"Size: {len(data)} bytes\n")
                f.write(f"Saved: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("="*50 + "\n")
                f.write(data.hex())
        
        print(f"[+] Footer saved → {filename}")
        return True
    except Exception as e:
        print(f"[!] Failed to save footer: {e}")
        return False

def perform_advanced_footer_analysis(data, footer_type):
    """Perform advanced analysis on footer data"""
    print("\n[*] Advanced Footer Analysis:")
    print("-" * 60)
    
    # Entropy analysis
    entropy = calculate_entropy(data)
    print(f"Data Entropy: {entropy:.3f} bits/byte")
    if entropy > 7.5:
        print("  → High entropy: likely encrypted or compressed")
    elif entropy > 6.0:
        print("  → Medium entropy: mixed content")
    else:
        print("  → Low entropy: likely structured data or text")
    
    # Pattern detection
    patterns = detect_common_patterns(data)
    if patterns:
        print("Detected Patterns:")
        for pattern, count in patterns.items():
            print(f"  → {pattern}: {count} occurrences")
    
    # Magic number detection
    magics = detect_magic_numbers(data)
    if magics:
        print("Magic Numbers:")
        for magic, description in magics.items():
            print(f"  → {magic}: {description}")

def calculate_entropy(data):
    """Calculate Shannon entropy of data"""
    if not data:
        return 0
    
    entropy = 0
    for x in range(256):
        p_x = data.count(x) / len(data)
        if p_x > 0:
            entropy += -p_x * math.log2(p_x)
    
    return entropy

def detect_common_patterns(data):
    """Detect common patterns in footer data"""
    patterns = {}
    
    # Common byte patterns
    common_patterns = {
        b"\x00\x00\x00\x00": "Null padding",
        b"\xFF\xFF\xFF\xFF": "Fill bytes", 
        b"\xDE\xAD\xBE\xEF": "Debug marker",
        b"\xCA\xFE\xBA\xBE": "Java marker",
        b"\xFE\xED\xFA\xCE": "Big-endian marker",
        b"\xCE\xFA\xED\xFE": "Little-endian marker"
    }
    
    for pattern, description in common_patterns.items():
        count = data.count(pattern)
        if count > 0:
            patterns[description] = count
    
    return patterns

def detect_magic_numbers(data):
    """Detect magic numbers in footer data"""
    magics = {}
    
    # Common magic numbers at various offsets
    magic_offsets = [0, 4, 8, 16, 32]
    
    for offset in magic_offsets:
        if offset + 4 <= len(data):
            magic = data[offset:offset+4]
            magic_hex = magic.hex()
            
            magic_db = {
                "7f454c46": "ELF Header",
                "464c457f": "ELF Header (BE)",
                "214c4153": "LAS (LiDAR)",
                "89504e47": "PNG Image",
                "474e5089": "PNG Image (BE)",
                "ffd8ffe0": "JPEG Image",
                "504b0304": "ZIP Archive",
                "43443030": "ISO9660 CD",
                "38425053": "PSD Image",
                "49492a00": "TIFF Image",
                "4d4d002a": "TIFF Image (BE)",
            }
            
            if magic_hex in magic_db:
                magics[f"0x{offset:02X}: {magic_hex}"] = magic_db[magic_hex]
    
    return magics

def validate_footer_integrity(data, footer_type):
    """Validate footer integrity and checksums"""
    print("\n[*] Footer Integrity Validation:")
    print("-" * 60)
    
    # Simple checksum validation
    simple_checksum = sum(data) & 0xFFFFFFFF
    print(f"Simple Checksum: 0x{simple_checksum:08X}")
    
    # CRC32 validation if possible
    try:
        import zlib
        crc32 = zlib.crc32(data) & 0xFFFFFFFF
        print(f"CRC32: 0x{crc32:08X}")
    except:
        pass
    
    # Structure validation for known footer types
    if footer_type == "SECURITY" and len(data) >= 32:
        print("Security Footer Structure: Valid" if data[0:4] == b"SEC@" else "Security Footer Structure: Invalid")
    
    print("Integrity: Basic validation completed")

# Update the argument parser in main() function
def update_footer_parser(sub):
    """
    Update the FOOTER command parser with new subcommands
    """
    footer_parser = sub.add_parser("footer", help="Footer block analysis and extraction commands")
    footer_parser.add_argument("--type", dest="footer_type", default="STANDARD", 
                              choices=["STANDARD", "EXTENDED", "SECURITY", "BOOT", "LOADER", "DEBUG", "AUDIT", "ALL"],
                              help="Type of footer to retrieve")
    footer_parser.add_argument("--raw", action="store_true", help="Request raw footer data")
    footer_parser.add_argument("--extended", action="store_true", help="Request extended footer information")
    footer_parser.add_argument("--verbose", action="store_true", help="Verbose footer analysis")
    footer_parser.add_argument("--crc", action="store_true", help="Include CRC verification")
    footer_parser.add_argument("--metadata", action="store_true", help="Include metadata")
    footer_parser.add_argument("--all", action="store_true", help="Request all available footers")
    footer_parser.add_argument("--validate", action="store_true", help="Validate footer integrity")
    footer_parser.add_argument("--hex", action="store_true", help="Display as hex dump")
    footer_parser.add_argument("--structured", action="store_true", help="Display structured analysis")
    footer_parser.add_argument("--json", action="store_true", help="Display as JSON")
    footer_parser.add_argument("--save", metavar="FILE", help="Save footer to file")
    footer_parser.add_argument("footer_args", nargs="*", help="Additional footer parameters")
    footer_parser.set_defaults(func=cmd_footer)