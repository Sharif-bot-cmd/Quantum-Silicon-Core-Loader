def resolve_address_for_peekpoke(dev, target):
    """
    Advanced address resolver for PEEK/POKE operations
    Supports multiple addressing modes with intelligent detection
    """
    # Ensure partitions are scanned
    scan_gpt(dev)
    
    target = target.strip().lower()
    
    # Case 1: Register name (e.g., "r0", "x1", "sp", "pc")
    register_addr = resolve_register_address(target)
    if register_addr is not None:
        return register_addr
    
    # Case 2: Symbolic address (e.g., "kernel_base", "stack_pointer")
    symbolic_addr = resolve_symbolic_address(dev, target)
    if symbolic_addr is not None:
        return symbolic_addr
    
    # Case 3: Partition with offset (e.g., "boot+0x200", "system+512")
    if "+" in target:
        return resolve_partition_offset(dev, target)
    
    # Case 4: Memory region alias (e.g., "ddr_start", "sram_end")
    region_addr = resolve_memory_region(dev, target)
    if region_addr is not None:
        return region_addr
    
    # Case 5: Bare partition name (e.g., "boot", "recovery")
    if target in PARTITIONS:
        addr, size = PARTITIONS[target]
        print(f"[*] Using partition '{target}' base address: 0x{addr:08X}")
        return addr
    
    # Case 6: Raw hex address (e.g., "0x880000", "0x1000")
    if target.startswith("0x"):
        try:
            return int(target, 16)
        except ValueError:
            raise ValueError(f"Invalid hex address: {target}")
    
    # Case 7: Raw decimal address (e.g., "123456", "4096")
    if target.isdigit():
        return int(target)
    
    # Case 8: Mathematical expression (e.g., "0x1000+0x200", "4096*2")
    math_addr = resolve_mathematical_expression(target)
    if math_addr is not None:
        return math_addr
    
    # Case 9: Try to auto-detect as symbol or special address
    auto_addr = auto_detect_address(dev, target)
    if auto_addr is not None:
        return auto_addr
    
    raise ValueError(f"Unknown PEEK/POKE target: {target}\n"
                    "Supported formats:\n"
                    "  • Hex: 0x880000\n"
                    "  • Decimal: 123456\n"
                    "  • Partition: boot, system\n"
                    "  • Partition+offset: boot+0x200, system+512\n"
                    "  • Register: r0, x1, sp, pc, lr\n"
                    "  • Memory region: ddr_start, sram_base\n"
                    "  • Expression: 0x1000+0x200, 4096*2")

def resolve_register_address(register_name):
    """
    Resolve CPU register names to their address or identifier
    """
    register_map = {
        # ARM registers
        'r0': 0x1000, 'r1': 0x1004, 'r2': 0x1008, 'r3': 0x100C,
        'r4': 0x1010, 'r5': 0x1014, 'r6': 0x1018, 'r7': 0x101C,
        'r8': 0x1020, 'r9': 0x1024, 'r10': 0x1028, 'r11': 0x102C,
        'r12': 0x1030, 'sp': 0x1034, 'lr': 0x1038, 'pc': 0x103C,
        'cpsr': 0x1040,
        
        # ARM64 registers
        'x0': 0x1100, 'x1': 0x1108, 'x2': 0x1110, 'x3': 0x1118,
        'x4': 0x1120, 'x5': 0x1128, 'x6': 0x1130, 'x7': 0x1138,
        'x8': 0x1140, 'x9': 0x1148, 'x10': 0x1150, 'x11': 0x1158,
        'x12': 0x1160, 'x13': 0x1168, 'x14': 0x1170, 'x15': 0x1178,
        'x16': 0x1180, 'x17': 0x1188, 'x18': 0x1190, 'x19': 0x1198,
        'x20': 0x11A0, 'x21': 0x11A8, 'x22': 0x11B0, 'x23': 0x11B8,
        'x24': 0x11C0, 'x25': 0x11C8, 'x26': 0x11D0, 'x27': 0x11D8,
        'x28': 0x11E0, 'x29': 0x11E8, 'x30': 0x11F0, 'sp': 0x11F8, 'pc': 0x1200,
        
        # Special registers
        'sctlr': 0x2000, 'ttbr0': 0x2008, 'ttbr1': 0x2010,
        'tcr': 0x2018, 'mair': 0x2020, 'amair': 0x2028,
        'vbar': 0x2030, 'rvbar': 0x2038,
    }
    
    return register_map.get(register_name.lower())

def resolve_symbolic_address(dev, symbol):
    """
    Resolve symbolic addresses to physical addresses
    """
    symbol_map = {
        'kernel_base': 0x80000000,
        'kernel_start': 0x80000000,
        'kernel_end': 0x81000000,
        'ramdisk_start': 0x81000000,
        'ramdisk_end': 0x82000000,
        'device_tree': 0x82000000,
        'dtb_start': 0x82000000,
        'stack_pointer': 0x83000000,
        'stack_base': 0x83000000,
        'stack_top': 0x83100000,
        'heap_start': 0x84000000,
        'heap_end': 0x85000000,
        'vector_table': 0x00000000,
        'exception_vector': 0x00000000,
        'boot_args': 0x00000100,
    }
    
    # Try predefined symbols first
    if symbol in symbol_map:
        return symbol_map[symbol]
    
    # Try to query device for symbol addresses
    try:
        resp = qslcl_dispatch(dev, "SYMBOL", symbol.encode() + b"\x00")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                if len(extra) >= 8:
                    return struct.unpack("<Q", extra[:8])[0]
    except:
        pass
    
    return None

def resolve_partition_offset(dev, target):
    """
    Resolve partition+offset format (e.g., "boot+0x200")
    """
    try:
        part, off = target.split("+", 1)
        part = part.strip()
        off = off.strip()
        
        # Get partition info
        part_addr, part_size = resolve_partition(part)
        
        # Parse offset (supports hex, decimal, and expressions)
        if off.startswith("0x"):
            off_val = int(off, 16)
        elif off.isdigit():
            off_val = int(off)
        else:
            # Try mathematical expression
            off_val = resolve_mathematical_expression(off)
            if off_val is None:
                raise ValueError(f"Invalid offset format: {off}")
        
        # Validate offset range
        if off_val >= part_size:
            raise ValueError(f"Offset 0x{off_val:X} beyond partition '{part}' size (0x{part_size:X})")
        
        result_addr = part_addr + off_val
        print(f"[*] Partition '{part}' + 0x{off_val:X} = 0x{result_addr:08X}")
        return result_addr
        
    except ValueError as e:
        raise ValueError(f"Invalid partition+offset format '{target}': {e}")

def resolve_memory_region(dev, region_name):
    """
    Resolve memory region aliases
    """
    region_map = {
        'ddr_start': 0x80000000,
        'ddr_end': 0xFFFFFFFF,
        'sram_start': 0x00000000,
        'sram_end': 0x00040000,
        'iram_start': 0x00080000,
        'iram_end': 0x000C0000,
        'bootrom_start': 0x00000000,
        'bootrom_end': 0x00010000,
        'peripheral_start': 0x10000000,
        'peripheral_end': 0x1FFFFFFF,
        'mmio_start': 0x10000000,
        'mmio_end': 0x1FFFFFFF,
    }
    
    return region_map.get(region_name.lower())

def resolve_mathematical_expression(expr):
    """
    Resolve mathematical expressions in addresses
    """
    try:
        # Basic expression evaluation (safe)
        expr = expr.strip()
        
        # Replace common hex patterns
        expr = expr.replace('0x', '0x')
        
        # Supported operations
        allowed_chars = set('0123456789abcdefABCDEFxX+-*/() ')
        if not all(c in allowed_chars for c in expr):
            return None
        
        # Evaluate safely
        result = eval(expr, {"__builtins__": {}}, {})
        return int(result)
        
    except:
        return None

def auto_detect_address(dev, target):
    """
    Auto-detect address type for unknown targets
    """
    # Try common patterns
    if target.endswith('_base') or target.endswith('_start'):
        base_name = target[:-5]
        return resolve_symbolic_address(dev, base_name)
    
    elif target.endswith('_end') or target.endswith('_top'):
        base_name = target[:-4] + '_start'
        start_addr = resolve_symbolic_address(dev, base_name)
        if start_addr:
            return start_addr + 0x1000  # Assume 4KB size
    
    # Try as partition with different capitalization
    for part_name in PARTITIONS.keys():
        if part_name.lower() == target.lower():
            addr, size = PARTITIONS[part_name]
            print(f"[*] Auto-detected partition '{part_name}': 0x{addr:08X}")
            return addr
    
    return None

def _decode_and_show_peek(resp, operation, addr, size, data_type, count, origin):
    """
    Enhanced result decoder for PEEK operations with multiple data types
    """
    if not resp:
        print(f"[!] {operation} failed @ 0x{addr:08X} (no response, via {origin})")
        return None
    
    result = decode_runtime_result(resp)
    sev = result.get("severity", "UNKNOWN")
    name = result.get("name", "UNKNOWN")
    
    msg = f"{operation} @ 0x{addr:08X} ({origin}) → {name}"
    
    if sev == "SUCCESS":
        print(f"[✓] {msg}")
        data = result.get("extra", b"")
        return display_peek_data(data, addr, size, data_type, count)
    elif sev == "WARNING":
        print(f"[~] {msg}")
        data = result.get("extra", b"")
        if data:
            return display_peek_data(data, addr, size, data_type, count)
    else:
        print(f"[✗] {msg}")
        return None

def display_peek_data(data, addr, size, data_type, count):
    """
    Display peeked data in multiple formats
    """
    if not data:
        print("[!] Empty response data")
        return None
    
    print(f"\n[*] Memory Dump @ 0x{addr:08X}:")
    print("-" * 60)
    
    # Hex dump
    hex_dump(data, addr)
    
    # Data type interpretation
    print("\n[*] Data Interpretation:")
    interpret_data_types(data, data_type, count)
    
    # ASCII representation
    print("\n[*] ASCII Representation:")
    ascii_dump(data)
    
    return data

def hex_dump(data, base_addr):
    """
    Display hex dump of memory data
    """
    bytes_per_line = 16
    for i in range(0, len(data), bytes_per_line):
        chunk = data[i:i + bytes_per_line]
        hex_str = ' '.join(f'{b:02X}' for b in chunk)
        ascii_str = ''.join(chr(b) if 32 <= b <= 126 else '.' for b in chunk)
        addr_str = f"{base_addr + i:08X}"
        print(f"  {addr_str}: {hex_str:<48} {ascii_str}")

def interpret_data_types(data, data_type, count):
    """
    Interpret data as different types
    """
    interpretations = []
    
    # Auto-detect data type if needed
    if data_type == 'auto':
        data_type = auto_detect_data_type(data)
    
    # Interpret based on data type
    if data_type == 'uint8' and len(data) >= count:
        values = [struct.unpack_from("<B", data, i)[0] for i in range(min(count, len(data)))]
        interpretations.append(f"uint8[{count}]: {values}")
    
    elif data_type == 'uint16' and len(data) >= count * 2:
        values = [struct.unpack_from("<H", data, i*2)[0] for i in range(min(count, len(data)//2))]
        interpretations.append(f"uint16[{count}]: {[hex(v) for v in values]}")
    
    elif data_type == 'uint32' and len(data) >= count * 4:
        values = [struct.unpack_from("<I", data, i*4)[0] for i in range(min(count, len(data)//4))]
        interpretations.append(f"uint32[{count}]: {[hex(v) for v in values]}")
    
    elif data_type == 'uint64' and len(data) >= count * 8:
        values = [struct.unpack_from("<Q", data, i*8)[0] for i in range(min(count, len(data)//8))]
        interpretations.append(f"uint64[{count}]: {[hex(v) for v in values]}")
    
    elif data_type == 'float' and len(data) >= count * 4:
        values = [struct.unpack_from("<f", data, i*4)[0] for i in range(min(count, len(data)//4))]
        interpretations.append(f"float[{count}]: {values}")
    
    elif data_type == 'double' and len(data) >= count * 8:
        values = [struct.unpack_from("<d", data, i*8)[0] for i in range(min(count, len(data)//8))]
        interpretations.append(f"double[{count}]: {values}")
    
    elif data_type == 'string':
        try:
            string_val = data.decode('utf-8', errors='ignore').split('\x00')[0]
            interpretations.append(f"string: \"{string_val}\"")
        except:
            interpretations.append("string: [invalid encoding]")
    
    # Always show raw integer interpretation
    if len(data) >= 4:
        uint32_val = struct.unpack_from("<I", data, 0)[0]
        int32_val = struct.unpack_from("<i", data, 0)[0]
        interpretations.append(f"raw32: 0x{uint32_val:08X} ({int32_val})")
    
    if len(data) >= 8:
        uint64_val = struct.unpack_from("<Q", data, 0)[0]
        int64_val = struct.unpack_from("<q", data, 0)[0]
        interpretations.append(f"raw64: 0x{uint64_val:016X} ({int64_val})")
    
    for interpretation in interpretations:
        print(f"  • {interpretation}")

def auto_detect_data_type(data):
    """
    Auto-detect the most likely data type
    """
    if len(data) < 4:
        return 'uint8'
    
    # Check if it looks like a string
    if all(32 <= b <= 126 or b in [0, 9, 10, 13] for b in data[:16]):
        return 'string'
    
    # Check if it looks like floating point
    if len(data) >= 4:
        try:
            float_val = struct.unpack_from("<f", data, 0)[0]
            if not (math.isnan(float_val) or math.isinf(float_val)):
                if 1e-10 < abs(float_val) < 1e10:
                    return 'float'
        except:
            pass
    
    return 'uint32'

def ascii_dump(data):
    """
    Display ASCII representation of data
    """
    ascii_chars = []
    for byte in data[:64]:  # First 64 bytes only
        if 32 <= byte <= 126:
            ascii_chars.append(chr(byte))
        else:
            ascii_chars.append('.')
    
    ascii_str = ''.join(ascii_chars)
    print(f"  \"{ascii_str}\"")
    
    # Show control character info
    control_chars = sum(1 for b in data[:64] if b < 32 and b != 0)
    if control_chars > 0:
        print(f"  [Contains {control_chars} control characters]")

def parse_poke_value(value_str, data_type, size):
    """
    Parse poke value string into binary data based on data type
    """
    value_str = value_str.strip()
    
    # Auto-detect type if needed
    if data_type == 'auto':
        data_type = auto_detect_value_type(value_str)
    
    # Parse based on type
    if data_type == 'uint8':
        value = int(value_str, 0) & 0xFF
        return struct.pack("<B", value), 'uint8'
    
    elif data_type == 'uint16':
        value = int(value_str, 0) & 0xFFFF
        return struct.pack("<H", value), 'uint16'
    
    elif data_type == 'uint32':
        value = int(value_str, 0) & 0xFFFFFFFF
        return struct.pack("<I", value), 'uint32'
    
    elif data_type == 'uint64':
        value = int(value_str, 0) & 0xFFFFFFFFFFFFFFFF
        return struct.pack("<Q", value), 'uint64'
    
    elif data_type == 'int8':
        value = int(value_str, 0)
        if value < -128 or value > 127:
            raise ValueError("int8 value out of range (-128 to 127)")
        return struct.pack("<b", value), 'int8'
    
    elif data_type == 'int16':
        value = int(value_str, 0)
        if value < -32768 or value > 32767:
            raise ValueError("int16 value out of range (-32768 to 32767)")
        return struct.pack("<h", value), 'int16'
    
    elif data_type == 'int32':
        value = int(value_str, 0)
        return struct.pack("<i", value), 'int32'
    
    elif data_type == 'int64':
        value = int(value_str, 0)
        return struct.pack("<q", value), 'int64'
    
    elif data_type == 'float':
        value = float(value_str)
        return struct.pack("<f", value), 'float'
    
    elif data_type == 'double':
        value = float(value_str)
        return struct.pack("<d", value), 'double'
    
    elif data_type == 'hex':
        # Raw hex string
        if value_str.startswith('0x'):
            value_str = value_str[2:]
        if len(value_str) % 2 != 0:
            value_str = '0' + value_str
        return bytes.fromhex(value_str), 'hex'
    
    elif data_type == 'string':
        # String data (null-terminated)
        return value_str.encode('utf-8') + b'\x00', 'string'
    
    else:
        raise ValueError(f"Unsupported data type: {data_type}")

def auto_detect_value_type(value_str):
    """
    Auto-detect value type from string
    """
    value_str = value_str.strip()
    
    # Check for float
    if '.' in value_str or 'e' in value_str.lower():
        try:
            float(value_str)
            return 'float'
        except:
            pass
    
    # Check for hex
    if value_str.startswith('0x'):
        if len(value_str) > 10:  # More than 32 bits
            return 'uint64'
        else:
            return 'uint32'
    
    # Check for string (contains non-digit characters)
    if not all(c in '0123456789-+' for c in value_str.replace(' ', '')):
        return 'string'
    
    # Default to int32
    return 'int32'

def perform_safety_checks(dev, addr, data):
    """
    Perform safety checks before memory write
    """
    print("[*] Performing safety checks...")
    
    # Check if address is in dangerous ranges
    dangerous_ranges = [
        (0x00000000, 0x00010000, "Boot ROM"),
        (0x10000000, 0x10001000, "Critical MMIO"),
        (0x80000000, 0x80001000, "Kernel Code"),
    ]
    
    for start, end, description in dangerous_ranges:
        if start <= addr < end:
            print(f"[!] WARNING: Writing to {description} region!")
            break
    
    # Check data pattern for suspicious values
    if len(data) >= 4:
        first_word = struct.unpack_from("<I", data, 0)[0]
        if first_word in [0x00000000, 0xFFFFFFFF, 0xDEADBEEF]:
            print(f"[!] WARNING: Writing suspicious pattern: 0x{first_word:08X}")
    
    # Size check
    if len(data) > 1024:
        print(f"[!] WARNING: Large write size: {len(data)} bytes")
    
    # Final confirmation
    print(f"\n[!] WARNING: Direct memory write to 0x{addr:08X}")
    print(f"    Data: {data.hex()}")
    print(f"    Size: {len(data)} bytes")
    
    confirm = input("!! CONFIRM MEMORY WRITE (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Memory write cancelled")
        return False
    
    return True

def _decode_and_show_poke(resp, operation, addr, value_data, origin):
    """
    Enhanced result decoder for POKE operations
    """
    if not resp:
        print(f"[!] {operation} failed @ 0x{addr:08X} (no response, via {origin})")
        return None
    
    result = decode_runtime_result(resp)
    sev = result.get("severity", "UNKNOWN")
    name = result.get("name", "UNKNOWN")
    
    msg = f"{operation} @ 0x{addr:08X} ({origin}) → {name}"
    
    if sev == "SUCCESS":
        print(f"[✓] {msg}")
        return True
    elif sev == "WARNING":
        print(f"[~] {msg}")
        return True
    else:
        print(f"[✗] {msg}")
        return False

def verify_poke_write(dev, addr, expected_data):
    """
    Verify that the poke write was successful
    """
    print("[*] Verifying write...")
    
    # Read back the written data
    payload = struct.pack("<Q I", addr, len(expected_data))
    resp, origin = qslclidx_or_dispatch(dev, "PEEK", payload)
    
    if not resp:
        print("[!] Verification failed: Could not read back data")
        return False
    
    result = decode_runtime_result(resp)
    if result.get("severity") != "SUCCESS":
        print("[!] Verification failed: Readback error")
        return False
    
    actual_data = result.get("extra", b"")
    
    if actual_data == expected_data:
        print("[✓] Write verification: SUCCESS")
        return True
    else:
        print("[!] Write verification: FAILED")
        print(f"    Expected: {expected_data.hex()}")
        print(f"    Actual:   {actual_data.hex()}")
        return False

# Update the argument parsers
def update_peek_poke_parsers(sub):
    """
    Update the PEEK and POKE command parsers with enhanced options
    """
    # PEEK parser
    peek_parser = sub.add_parser("peek", help="Read memory with advanced addressing and data interpretation")
    peek_parser.add_argument("address", help="Memory address (hex, decimal, partition, register, symbol, or expression)")
    peek_parser.add_argument("-s", "--size", type=int, default=4, help="Number of bytes to read (default: 4)")
    peek_parser.add_argument("-t", "--data-type", choices=['auto', 'uint8', 'uint16', 'uint32', 'uint64', 'int8', 'int16', 'int32', 'int64', 'float', 'double', 'string'], default='auto', help="Data type interpretation")
    peek_parser.add_argument("-c", "--count", type=int, default=1, help="Number of elements for array types")
    peek_parser.set_defaults(func=cmd_peek)
    
    # POKE parser
    poke_parser = sub.add_parser("poke", help="Write memory with advanced addressing and data types")
    poke_parser.add_argument("address", help="Memory address (hex, decimal, partition, register, symbol, or expression)")
    poke_parser.add_argument("value", help="Value to write (supports multiple data types)")
    poke_parser.add_argument("-t", "--data-type", choices=['auto', 'uint8', 'uint16', 'uint32', 'uint64', 'int8', 'int16', 'int32', 'int64', 'float', 'double', 'hex', 'string'], default='auto', help="Data type of value")
    poke_parser.add_argument("-s", "--size", type=int, default=4, help="Size of write in bytes (for hex/string types)")
    poke_parser.set_defaults(func=cmd_poke)

def cmd_poke(args):
    """
    Advanced POKE command for memory writing with multiple data types and safety checks
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse address
    try:
        addr = resolve_address_for_peekpoke(dev, args.address)
    except Exception as e:
        return print(f"[!] Address error: {e}")
    
    # Parse value and data type
    value_str = args.value
    data_type = getattr(args, 'data_type', 'auto').lower()
    size = getattr(args, 'size', 4)
    
    # Parse value based on data type
    try:
        value_data, actual_type = parse_poke_value(value_str, data_type, size)
    except Exception as e:
        return print(f"[!] Value parsing error: {e}")
    
    print(f"[*] POKE @ 0x{addr:08X} = {value_str} (as {actual_type}, size: {len(value_data)} bytes)")
    
    # Safety checks
    if not perform_safety_checks(dev, addr, value_data):
        return False
    
    # Build payload
    payload = struct.pack("<Q", addr) + value_data
    resp, origin = qslclidx_or_dispatch(dev, "POKE", payload)
    
    result = _decode_and_show_poke(resp, "POKE", addr, value_data, origin)
    
    # Verify write if successful
    if result:
        verify_poke_write(dev, addr, value_data)
    
    return result


def cmd_peek(args):
    """
    Advanced PEEK command for memory reading with multiple data types and formats
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse address
    try:
        addr = resolve_address_for_peekpoke(dev, args.address)
    except Exception as e:
        return print(f"[!] Address error: {e}")
    
    # Parse size and data type
    size = getattr(args, 'size', 4)  # Default 4 bytes
    data_type = getattr(args, 'data_type', 'auto').lower()
    count = getattr(args, 'count', 1)  # Number of elements for array types
    
    print(f"[*] PEEK @ 0x{addr:08X} (size: {size}, type: {data_type}, count: {count})")
    
    # Build payload with size information
    payload = struct.pack("<Q I I", addr, size, count)
    resp, origin = qslclidx_or_dispatch(dev, "PEEK", payload)
    
    result = _decode_and_show_peek(resp, "PEEK", addr, size, data_type, count, origin)
    return result is not None