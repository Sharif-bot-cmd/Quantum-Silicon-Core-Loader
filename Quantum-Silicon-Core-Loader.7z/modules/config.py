def cmd_config(args):
    """
    Advanced CONFIG command handler for comprehensive system configuration management
    Supports configuration get/set/list/delete/backup/restore operations
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    # Parse CONFIG subcommand
    if not hasattr(args, 'config_subcommand') or not args.config_subcommand:
        return print("[!] CONFIG command requires subcommand (get, set, list, delete, backup, restore, etc.)")
    
    subcmd = args.config_subcommand.upper()
    
    if subcmd == "GET":
        return config_get(dev, args)
    elif subcmd == "SET":
        return config_set(dev, args)
    elif subcmd == "LIST":
        return config_list_keys(dev, args)
    elif subcmd == "DELETE":
        return config_delete(dev, args)
    elif subcmd == "BACKUP":
        return config_backup(dev, args)
    elif subcmd == "RESTORE":
        return config_restore(dev, args)
    elif subcmd == "RESET":
        return config_reset(dev, args)
    elif subcmd == "IMPORT":
        return config_import(dev, args)
    elif subcmd == "EXPORT":
        return config_export(dev, args)
    elif subcmd == "VALIDATE":
        return config_validate(dev, args)
    elif subcmd == "INFO":
        return config_info(dev, args)
    else:
        return handle_config_operation(dev, subcmd, args)

def config_get(dev, args):
    """
    Get configuration value for specified key
    """
    if not hasattr(args, 'config_args') or not args.config_args:
        return print("[!] CONFIG GET requires key name")
    
    key = args.config_args[0].upper()
    
    print(f"[*] Getting configuration: {key}")
    
    # Try different methods to get configuration
    strategies = [
        try_idx_config_get,
        try_par_config_get,
        try_end_config_get,
        try_vm5_config_get,
        try_direct_config_get
    ]
    
    for strategy in strategies:
        value = strategy(dev, key)
        if value is not None:
            display_config_value(key, value)
            return True
    
    print(f"[!] Failed to get configuration for: {key}")
    return False

def try_idx_config_get(dev, key):
    """Try QSLCLIDX config get"""
    idx_entry = qslclidx_get_cmd("CONFIG_GET")
    if idx_entry:
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLIDX" + struct.pack("<I", idx_entry["idx"]) + payload
        resp = qslcl_dispatch(dev, "IDX", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                return status.get("extra", b"")
    return None

def try_par_config_get(dev, key):
    """Try QSLCLPAR config get"""
    if "CONFIG_GET" in QSLCLPAR_DB:
        payload = key.encode("ascii") + b"\x00"
        resp = qslcl_dispatch(dev, "CONFIG_GET", payload)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                return status.get("extra", b"")
    return None

def try_end_config_get(dev, key):
    """Try QSLCLEND config get opcode"""
    CONFIG_GET_OPCODE = 0xC1
    if CONFIG_GET_OPCODE in QSLCLEND_DB:
        entry = QSLCLEND_DB[CONFIG_GET_OPCODE]
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLEND" + entry + payload
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                return status.get("extra", b"")
    return None

def try_vm5_config_get(dev, key):
    """Try QSLCLVM5 config get"""
    if "CONFIG_GET" in QSLCLVM5_DB:
        raw = QSLCLVM5_DB["CONFIG_GET"]["raw"]
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                return status.get("extra", b"")
    return None

def try_direct_config_get(dev, key):
    """Try direct config get"""
    payload = key.encode("ascii") + b"\x00"
    resp = qslcl_dispatch(dev, "CONFIG_GET", payload)
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            return status.get("extra", b"")
    return None

def display_config_value(key, value):
    """
    Display configuration value in appropriate format
    """
    if not value:
        print(f"  {key}: <empty>")
        return
    
    # Try to decode as string first
    try:
        str_value = value.decode('utf-8', errors='ignore').rstrip('\x00')
        if all(c.isprintable() or c in ' \t\n\r' for c in str_value):
            print(f"  {key}: \"{str_value}\"")
            return
    except:
        pass
    
    # Try to interpret as numeric values
    if len(value) == 1:
        print(f"  {key}: {value[0]} (byte) 0x{value[0]:02X}")
    elif len(value) == 2:
        num = struct.unpack("<H", value)[0]
        print(f"  {key}: {num} (word) 0x{num:04X}")
    elif len(value) == 4:
        num = struct.unpack("<I", value)[0]
        print(f"  {key}: {num} (dword) 0x{num:08X}")
    elif len(value) == 8:
        num = struct.unpack("<Q", value)[0]
        print(f"  {key}: {num} (qword) 0x{num:016X}")
    else:
        # Display as hex
        hex_value = value.hex()
        if len(hex_value) > 64:
            hex_value = hex_value[:64] + "..."
        print(f"  {key}: {hex_value} ({len(value)} bytes)")

def config_set(dev, args):
    """
    Set configuration value for specified key
    """
    if not hasattr(args, 'config_args') or len(args.config_args) < 2:
        return print("[!] CONFIG SET requires key and value")
    
    key = args.config_args[0].upper()
    value_str = args.config_args[1]
    
    # Parse value based on format
    value_data = parse_config_value(value_str)
    if value_data is None:
        print("[!] Invalid value format. Use: string, 123, 0x123, true/false, 1.5")
        return False
    
    print(f"[*] Setting configuration: {key} = {value_str}")
    
    # Build payload
    payload = key.encode("ascii") + b"\x00" + value_data
    
    # Safety check for large values
    if len(payload) > 1024:
        print("[!] Configuration value too large, refusing.")
        return False
    
    # Try different methods to set configuration
    strategies = [
        try_idx_config_set,
        try_par_config_set,
        try_end_config_set,
        try_vm5_config_set,
        try_direct_config_set
    ]
    
    for strategy in strategies:
        success = strategy(dev, payload)
        if success is not None:
            if success:
                print(f"[✓] Configuration set successfully: {key}")
                # Verify the setting
                if args.verify:
                    time.sleep(0.5)
                    verify_config_set(dev, key, value_data)
            return success
    
    print(f"[!] Failed to set configuration for: {key}")
    return False

def parse_config_value(value_str):
    """
    Parse configuration value from string to bytes
    """
    # Empty value
    if value_str == "":
        return b""
    
    # Boolean values
    if value_str.lower() in ["true", "yes", "on", "1"]:
        return b"\x01"
    elif value_str.lower() in ["false", "no", "off", "0"]:
        return b"\x00"
    
    # Hex values
    if value_str.startswith("0x"):
        try:
            hex_str = value_str[2:]
            if len(hex_str) % 2 != 0:
                hex_str = "0" + hex_str
            return bytes.fromhex(hex_str)
        except:
            return None
    
    # Numeric values
    if value_str.isdigit() or (value_str.startswith('-') and value_str[1:].isdigit()):
        try:
            num = int(value_str)
            if -128 <= num <= 255:
                return struct.pack("<B", num & 0xFF)
            elif -32768 <= num <= 65535:
                return struct.pack("<H", num & 0xFFFF)
            else:
                return struct.pack("<I", num & 0xFFFFFFFF)
        except:
            return None
    
    # Float values
    try:
        float_val = float(value_str)
        return struct.pack("<f", float_val)
    except:
        pass
    
    # String value (default)
    return value_str.encode("utf-8") + b"\x00"

def try_idx_config_set(dev, payload):
    """Try QSLCLIDX config set"""
    idx_entry = qslclidx_get_cmd("CONFIG_SET")
    if idx_entry:
        pkt = b"QSLCLIDX" + struct.pack("<I", idx_entry["idx"]) + payload
        resp = qslcl_dispatch(dev, "IDX", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_par_config_set(dev, payload):
    """Try QSLCLPAR config set"""
    if "CONFIG_SET" in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, "CONFIG_SET", payload)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_end_config_set(dev, payload):
    """Try QSLCLEND config set opcode"""
    CONFIG_SET_OPCODE = 0xC0
    if CONFIG_SET_OPCODE in QSLCLEND_DB:
        entry = QSLCLEND_DB[CONFIG_SET_OPCODE]
        pkt = b"QSLCLEND" + entry + payload
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_vm5_config_set(dev, payload):
    """Try QSLCLVM5 config set"""
    if "CONFIG_SET" in QSLCLVM5_DB:
        raw = QSLCLVM5_DB["CONFIG_SET"]["raw"]
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_direct_config_set(dev, payload):
    """Try direct config set"""
    resp = qslcl_dispatch(dev, "CONFIG_SET", payload)
    if resp:
        status = decode_runtime_result(resp)
        return status.get("severity") == "SUCCESS"
    return False

def verify_config_set(dev, key, expected_value):
    """
    Verify that configuration was set correctly
    """
    print(f"[*] Verifying configuration: {key}")
    
    current_value = try_idx_config_get(dev, key)
    if current_value is None:
        current_value = try_direct_config_get(dev, key)
    
    if current_value is not None:
        if current_value == expected_value:
            print(f"[✓] Configuration verified: {key}")
        else:
            print(f"[!] Configuration mismatch for: {key}")
            print(f"    Expected: {expected_value.hex()}")
            print(f"    Got: {current_value.hex()}")
    else:
        print(f"[!] Could not verify configuration: {key}")

def config_list_keys(dev, args):
    """
    List all available configuration keys
    """
    print("[*] Retrieving configuration keys...")
    
    # Try to get key list from device
    keys = get_config_key_list(dev)
    
    if not keys:
        # Fallback to common configuration keys
        keys = get_common_config_keys()
    
    # Filter by category if specified
    category_filter = None
    if hasattr(args, 'config_args') and args.config_args:
        category_filter = args.config_args[0].upper()
    
    print(f"\n[*] Available Configuration Keys ({len(keys)} total):")
    print("=" * 60)
    
    categorized_keys = categorize_config_keys(keys)
    
    for category, key_list in categorized_keys.items():
        if category_filter and category != category_filter:
            continue
            
        print(f"\n[{category}]")
        for key in sorted(key_list):
            # Try to get current value for display
            current_value = try_direct_config_get(dev, key)
            if current_value is not None:
                value_preview = format_value_preview(current_value)
                print(f"  • {key}: {value_preview}")
            else:
                print(f"  • {key}")
    
    if category_filter and category_filter not in categorized_keys:
        print(f"[!] No configuration keys found in category: {category_filter}")
    
    return True

def get_config_key_list(dev):
    """
    Get list of configuration keys from device
    """
    keys = []
    
    # Try different methods to get key list
    strategies = [
        try_idx_config_list,
        try_par_config_list,
        try_end_config_list,
        try_vm5_config_list
    ]
    
    for strategy in strategies:
        result = strategy(dev)
        if result:
            keys.extend(result)
    
    # Remove duplicates and return
    return list(set(keys))

def try_idx_config_list(dev):
    """Try QSLCLIDX config list"""
    idx_entry = qslclidx_get_cmd("CONFIG_LIST")
    if idx_entry:
        pkt = b"QSLCLIDX" + struct.pack("<I", idx_entry["idx"])
        resp = qslcl_dispatch(dev, "IDX", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                return parse_key_list(extra)
    return []

def try_par_config_list(dev):
    """Try QSLCLPAR config list"""
    if "CONFIG_LIST" in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, "CONFIG_LIST")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                return parse_key_list(extra)
    return []

def try_end_config_list(dev):
    """Try QSLCLEND config list opcode"""
    CONFIG_LIST_OPCODE = 0xC2
    if CONFIG_LIST_OPCODE in QSLCLEND_DB:
        entry = QSLCLEND_DB[CONFIG_LIST_OPCODE]
        pkt = b"QSLCLEND" + entry
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                return parse_key_list(extra)
    return []

def try_vm5_config_list(dev):
    """Try QSLCLVM5 config list"""
    if "CONFIG_LIST" in QSLCLVM5_DB:
        raw = QSLCLVM5_DB["CONFIG_LIST"]["raw"]
        pkt = b"QSLCLVM5" + raw
        resp = qslcl_dispatch(dev, "NANO", pkt)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                return parse_key_list(extra)
    return []

def parse_key_list(data):
    """
    Parse key list from binary data
    """
    if not data:
        return []
    
    try:
        key_str = data.decode('utf-8', errors='ignore')
        keys = [k.strip() for k in key_str.split('\x00') if k.strip()]
        return keys
    except:
        return []

def get_common_config_keys():
    """
    Return common configuration keys as fallback
    """
    return [
        "BOOT_MODE", "DEBUG_LEVEL", "SECURE_BOOT", "VERIFIED_BOOT",
        "SERIAL_BAUD", "USB_CONFIG", "POWER_MODE", "THERMAL_LIMIT",
        "VOLTAGE_CPU", "VOLTAGE_GPU", "CLOCK_CPU", "CLOCK_GPU",
        "MEMORY_TIMING", "STORAGE_MODE", "NETWORK_MODE", "LOG_LEVEL",
        "WATCHDOG_TIMEOUT", "RESET_DELAY", "BOOT_DELAY", "SLEEP_TIMEOUT",
        "BACKLIGHT_LEVEL", "VIBRATION_STRENGTH", "AUDIO_VOLUME",
        "DISPLAY_BRIGHTNESS", "TOUCH_SENSITIVITY", "CAMERA_QUALITY",
        "GPS_MODE", "BLUETOOTH_MODE", "WIFI_MODE", "CELLULAR_MODE",
        "BATTERY_SAVER", "PERFORMANCE_MODE", "SECURITY_LEVEL"
    ]

def categorize_config_keys(keys):
    """
    Categorize configuration keys for better organization
    """
    categories = {
        "BOOT": [],
        "SECURITY": [],
        "POWER": [],
        "PERFORMANCE": [],
        "HARDWARE": [],
        "NETWORK": [],
        "AUDIO/VIDEO": [],
        "SYSTEM": [],
        "OTHER": []
    }
    
    category_patterns = {
        "BOOT": ["BOOT", "STARTUP", "INIT"],
        "SECURITY": ["SECURE", "VERIF", "AUTH", "LOCK", "ENCRYPT"],
        "POWER": ["POWER", "BATTERY", "VOLTAGE", "CURRENT", "SLEEP"],
        "PERFORMANCE": ["CLOCK", "FREQ", "PERF", "SPEED", "TIMING"],
        "HARDWARE": ["CPU", "GPU", "MEMORY", "STORAGE", "DISPLAY", "TOUCH"],
        "NETWORK": ["WIFI", "BLUETOOTH", "GPS", "CELLULAR", "NETWORK"],
        "AUDIO/VIDEO": ["AUDIO", "VIDEO", "CAMERA", "MIC", "SPEAKER", "DISPLAY"],
        "SYSTEM": ["DEBUG", "LOG", "RESET", "WATCHDOG", "SYSTEM"]
    }
    
    for key in keys:
        matched = False
        key_upper = key.upper()
        
        for category, patterns in category_patterns.items():
            if any(pattern in key_upper for pattern in patterns):
                categories[category].append(key)
                matched = True
                break
        
        if not matched:
            categories["OTHER"].append(key)
    
    # Remove empty categories
    return {k: v for k, v in categories.items() if v}

def format_value_preview(value):
    """
    Create a preview of configuration value
    """
    if not value:
        return "<empty>"
    
    if len(value) == 1:
        return f"0x{value[0]:02X}"
    
    try:
        str_val = value.decode('utf-8', errors='ignore').rstrip('\x00')
        if len(str_val) <= 20 and all(c.isprintable() for c in str_val):
            return f"\"{str_val}\""
    except:
        pass
    
    return f"{len(value)} bytes"

def config_delete(dev, args):
    """
    Delete configuration key
    """
    if not hasattr(args, 'config_args') or not args.config_args:
        return print("[!] CONFIG DELETE requires key name")
    
    key = args.config_args[0].upper()
    
    print(f"[*] Deleting configuration: {key}")
    
    # Safety confirmation for important keys
    important_keys = ["SECURE_BOOT", "BOOT_MODE", "POWER_MODE"]
    if key in important_keys:
        confirm = input(f"!! CONFIRM DELETE {key} (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Configuration delete cancelled")
            return False
    
    # Try different deletion methods
    strategies = [
        try_idx_config_delete,
        try_par_config_delete,
        try_end_config_delete,
        try_vm5_config_delete,
        try_direct_config_delete
    ]
    
    for strategy in strategies:
        success = strategy(dev, key)
        if success is not None:
            if success:
                print(f"[✓] Configuration deleted: {key}")
            return success
    
    print(f"[!] Failed to delete configuration: {key}")
    return False

def try_idx_config_delete(dev, key):
    """Try QSLCLIDX config delete"""
    idx_entry = qslclidx_get_cmd("CONFIG_DELETE")
    if idx_entry:
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLIDX" + struct.pack("<I", idx_entry["idx"]) + payload
        resp = qslcl_dispatch(dev, "IDX", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_par_config_delete(dev, key):
    """Try QSLCLPAR config delete"""
    if "CONFIG_DELETE" in QSLCLPAR_DB:
        payload = key.encode("ascii") + b"\x00"
        resp = qslcl_dispatch(dev, "CONFIG_DELETE", payload)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def config_backup(dev, args):
    """
    Backup all configurations to file
    """
    filename = "config_backup.json"
    if hasattr(args, 'config_args') and args.config_args:
        filename = args.config_args[0]
    
    print(f"[*] Backing up configurations to: {filename}")
    
    # Get all configuration keys
    keys = get_config_key_list(dev)
    if not keys:
        keys = get_common_config_keys()
    
    backup_data = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "device": str(dev),
        "configurations": {}
    }
    
    # Backup each configuration
    backed_up = 0
    for key in keys:
        value = try_direct_config_get(dev, key)
        if value is not None:
            backup_data["configurations"][key] = value.hex()
            backed_up += 1
            print(f"  [✓] Backed up: {key}")
        else:
            print(f"  [!] Failed to backup: {key}")
    
    # Save to file
    try:
        import json
        with open(filename, 'w') as f:
            json.dump(backup_data, f, indent=2)
        print(f"[✓] Configuration backup complete: {backed_up}/{len(keys)} configurations saved to {filename}")
        return True
    except Exception as e:
        print(f"[!] Failed to save backup: {e}")
        return False

def config_restore(dev, args):
    """
    Restore configurations from backup file
    """
    if not hasattr(args, 'config_args') or not args.config_args:
        return print("[!] CONFIG RESTORE requires backup filename")
    
    filename = args.config_args[0]
    
    print(f"[*] Restoring configurations from: {filename}")
    
    try:
        import json
        with open(filename, 'r') as f:
            backup_data = json.load(f)
        
        configurations = backup_data.get("configurations", {})
        
        if not configurations:
            print("[!] No configurations found in backup file")
            return False
        
        print(f"[*] Found {len(configurations)} configurations from {backup_data.get('timestamp', 'unknown')}")
        
        # Safety confirmation
        confirm = input("!! CONFIRM CONFIGURATION RESTORE (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Configuration restore cancelled")
            return False
        
        # Restore each configuration
        restored = 0
        for key, hex_value in configurations.items():
            value_data = bytes.fromhex(hex_value)
            payload = key.encode("ascii") + b"\x00" + value_data
            
            success = try_direct_config_set(dev, payload)
            if success:
                restored += 1
                print(f"  [✓] Restored: {key}")
            else:
                print(f"  [!] Failed to restore: {key}")
        
        print(f"[✓] Configuration restore complete: {restored}/{len(configurations)} configurations restored")
        return restored > 0
        
    except Exception as e:
        print(f"[!] Failed to restore backup: {e}")
        return False

def config_reset(dev, args):
    """
    Reset all configurations to default values
    """
    print("[!] WARNING: This will reset ALL configurations to default values!")
    print("[!] This action cannot be undone!")
    
    confirm = input("!! CONFIRM CONFIGURATION RESET (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Configuration reset cancelled")
        return False
    
    print("[*] Resetting all configurations to defaults...")
    
    # Try configuration reset command
    resp = qslcl_dispatch(dev, "CONFIG_RESET")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] All configurations reset to defaults")
            return True
    
    print("[!] Configuration reset failed")
    return False

def config_import(dev, args):
    """
    Import configurations from file (similar to restore but different format)
    """
    if not hasattr(args, 'config_args') or not args.config_args:
        return print("[!] CONFIG IMPORT requires filename")
    
    filename = args.config_args[0]
    print(f"[*] Importing configurations from: {filename}")
    
    # Implementation similar to restore but for different file formats
    # This is a placeholder for future implementation
    print("[!] Config import not yet implemented")
    return False

def config_export(dev, args):
    """
    Export configurations to file (similar to backup but different format)
    """
    filename = "config_export.txt"
    if hasattr(args, 'config_args') and args.config_args:
        filename = args.config_args[0]
    
    print(f"[*] Exporting configurations to: {filename}")
    
    # Implementation similar to backup but for different file formats
    # This is a placeholder for future implementation
    print("[!] Config export not yet implemented")
    return False

def config_validate(dev, args):
    """
    Validate all configurations for consistency
    """
    print("[*] Validating configuration consistency...")
    
    keys = get_config_key_list(dev)
    if not keys:
        keys = get_common_config_keys()
    
    issues_found = 0
    
    for key in keys:
        value = try_direct_config_get(dev, key)
        if value is not None:
            # Basic validation checks
            if len(value) == 0:
                print(f"  [!] {key}: Empty value")
                issues_found += 1
            elif len(value) > 256:
                print(f"  [!] {key}: Value too large ({len(value)} bytes)")
                issues_found += 1
            else:
                print(f"  [✓] {key}: Valid")
        else:
            print(f"  [?] {key}: Cannot read value")
    
    print(f"\n[*] Configuration validation complete: {issues_found} issues found")
    return issues_found == 0

def config_info(dev, args):
    """
    Display detailed information about configuration system
    """
    print("\n" + "="*60)
    print("[*] CONFIGURATION SYSTEM INFORMATION")
    print("="*60)
    
    # Display capabilities
    print("\n[CAPABILITIES]")
    capabilities = []
    
    if qslclidx_get_cmd("CONFIG_GET"): capabilities.append("GET")
    if qslclidx_get_cmd("CONFIG_SET"): capabilities.append("SET")
    if qslclidx_get_cmd("CONFIG_LIST"): capabilities.append("LIST")
    if qslclidx_get_cmd("CONFIG_DELETE"): capabilities.append("DELETE")
    
    if capabilities:
        print(f"  Supported operations: {', '.join(capabilities)}")
    else:
        print("  No configuration capabilities detected")
    
    # Display statistics
    keys = get_config_key_list(dev)
    if keys:
        print(f"  Total configuration keys: {len(keys)}")
        
        categorized = categorize_config_keys(keys)
        for category, key_list in categorized.items():
            print(f"    {category}: {len(key_list)} keys")
    
    # Display storage information
    print(f"\n[STORAGE]")
    print("  Configuration storage: Device NVRAM/Flash")
    print("  Maximum value size: 1024 bytes")
    print("  Persistence: Survives reboot")
    
    print("\n" + "="*60)
    return True

def handle_config_operation(dev, operation, args):
    """
    Handle other configuration operations
    """
    print(f"[*] Executing configuration operation: {operation}")
    
    # This function can be extended for custom configuration operations
    print(f"[!] Configuration operation '{operation}' not implemented")
    return False

# Placeholder functions for unimplemented strategies
def try_direct_config_delete(dev, key):
    payload = key.encode("ascii") + b"\x00"
    resp = qslcl_dispatch(dev, "CONFIG_DELETE", payload)
    if resp:
        status = decode_runtime_result(resp)
        return status.get("severity") == "SUCCESS"
    return False

def try_end_config_delete(dev, key):
    CONFIG_DELETE_OPCODE = 0xC3
    if CONFIG_DELETE_OPCODE in QSLCLEND_DB:
        entry = QSLCLEND_DB[CONFIG_DELETE_OPCODE]
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLEND" + entry + payload
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def try_vm5_config_delete(dev, key):
    if "CONFIG_DELETE" in QSLCLVM5_DB:
        raw = QSLCLVM5_DB["CONFIG_DELETE"]["raw"]
        payload = key.encode("ascii") + b"\x00"
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity") == "SUCCESS"
    return None

def cmd_config_list(args=None):
    """
    Enhanced configuration capabilities listing
    """
    print("\n" + "="*60)
    print("[*] QSLCL CONFIGURATION SYSTEM CAPABILITIES")
    print("="*60)
    
    # ---------------------
    # QSLCLIDX Configuration Commands
    # ---------------------
    print("\n[QSLCLIDX] Indexed Configuration Commands:")
    config_idx_commands = []
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and any(x in name.upper() for x in ["CONFIG", "SETTING", "PARAM"]):
            config_idx_commands.append((name, entry.get('idx', 0)))
    
    if config_idx_commands:
        for name, idx in sorted(config_idx_commands, key=lambda x: x[1]):
            print(f"   • {name:<20} (idx=0x{idx:02X})")
    else:
        print("   (no indexed configuration commands)")
    
    # ---------------------
    # QSLCLEND Configuration Opcodes
    # ---------------------
    print("\n[QSLCLEND] Configuration Opcodes:")
    config_end_commands = []
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        if any(x in str(entry_name).upper() for x in ["CONFIG", "SETTING"]) or opcode in [0xC0, 0xC1, 0xC2, 0xC3]:
            config_end_commands.append((opcode, entry_name))
    
    if config_end_commands:
        for opcode, name in sorted(config_end_commands):
            name_display = name if name else "CONFIG_OPERATION"
            print(f"   • {name_display:<20} (opcode=0x{opcode:02X})")
    else:
        print("   (no configuration opcodes)")
    
    # ---------------------
    # QSLCLPAR Configuration Blocks
    # ---------------------
    print("\n[QSLCLPAR] Parser Configuration Blocks:")
    config_par_commands = []
    for cmd_name in QSLCLPAR_DB.keys():
        if any(x in cmd_name.upper() for x in ["CONFIG", "SETTING", "PARAM"]):
            config_par_commands.append(cmd_name)
    
    if config_par_commands:
        for cmd in sorted(config_par_commands):
            print(f"   • {cmd}")
    else:
        print("   (no parser configuration blocks)")
    
    # ---------------------
    # QSLCLVM5 Configuration Microservices
    # ---------------------
    print("\n[QSLCLVM5] Configuration Microservices:")
    config_vm5_commands = []
    for cmd_name in QSLCLVM5_DB.keys():
        if any(x in cmd_name.upper() for x in ["CONFIG", "SETTING"]):
            config_vm5_commands.append(cmd_name)
    
    if config_vm5_commands:
        for cmd in sorted(config_vm5_commands):
            print(f"   • {cmd}")
    else:
        print("   (no configuration microservices)")
    
    # ---------------------
    # Available Operations
    # ---------------------
    print("\n[OPERATIONS] Available Configuration Commands:")
    print("   • config get <key>              - Get configuration value")
    print("   • config set <key> <value>      - Set configuration value") 
    print("   • config list [category]        - List configuration keys")
    print("   • config delete <key>           - Delete configuration key")
    print("   • config backup [filename]      - Backup all configurations")
    print("   • config restore <filename>     - Restore configurations")
    print("   • config reset                  - Reset to defaults")
    print("   • config validate               - Validate configurations")
    print("   • config info                   - System information")
    
    # ---------------------
    # Value Formats
    # ---------------------
    print("\n[VALUE FORMATS] Supported Configuration Value Types:")
    print("   • String:    \"hello world\"")
    print("   • Integer:   123 or 0x7B")
    print("   • Boolean:   true/false or 1/0")
    print("   • Float:     3.14")
    print("   • Hex:       0x1234ABCD")
    
    print("\n" + "="*60)

# Update the argument parser in main() function
def update_config_parser(sub):
    """
    Update the CONFIG command parser with new subcommands
    """
    config_parser = sub.add_parser("config", help="Configuration management commands")
    config_parser.add_argument("config_subcommand", help="Config subcommand (get, set, list, delete, backup, restore, reset, import, export, validate, info)")
    config_parser.add_argument("config_args", nargs="*", help="Additional arguments for config command")
    config_parser.add_argument("--verify", action="store_true", help="Verify configuration after setting")
    config_parser.set_defaults(func=cmd_config)