def cmd_mode(args):
    """
    Advanced MODE command handler for triggering device mode changes
    Supports mode switching using QSLCL's internal MODE commands
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse MODE subcommand
    if not hasattr(args, 'mode_subcommand') or not args.mode_subcommand:
        return print("[!] MODE command requires subcommand (check available modes with 'mode list')")
    
    subcmd = args.mode_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_modes(dev)
    else:
        return trigger_device_mode(dev, subcmd, args)

def list_available_modes(dev):
    """
    List all available MODE commands from QSLCL loader
    """
    print("\n" + "="*50)
    print("[*] AVAILABLE QSLCL MODE COMMANDS")
    print("="*50)
    
    modes_found = []
    
    # Check QSLCLPAR for MODE commands
    print("\n[QSLCLPAR] Mode Commands:")
    par_modes = [cmd for cmd in QSLCLPAR_DB.keys() if "MODE" in cmd.upper()]
    for mode_cmd in par_modes:
        print(f"  • {mode_cmd}")
        modes_found.append(mode_cmd)
    
    # Check QSLCLEND for mode-related opcodes
    print("\n[QSLCLEND] Mode Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        if isinstance(entry, dict) and "MODE" in str(entry.get('name', '')).upper():
            print(f"  • Opcode 0x{opcode:02X}: {entry.get('name', 'UNKNOWN')}")
            modes_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for mode microservices
    print("\n[QSLCLVM5] Mode Microservices:")
    vm5_modes = [cmd for cmd in QSLCLVM5_DB.keys() if "MODE" in cmd.upper()]
    for mode_cmd in vm5_modes:
        print(f"  • {mode_cmd}")
        modes_found.append(f"VM5_{mode_cmd}")
    
    # Check QSLCLIDX for mode indices
    print("\n[QSLCLIDX] Mode Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and "MODE" in str(entry.get('name', '')).upper():
            print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
            modes_found.append(f"IDX_{name}")
    
    if not modes_found:
        print("  No mode commands found in loader")
    
    print(f"\n[*] Total mode commands found: {len(modes_found)}")
    print("="*50)
    
    return True

def trigger_device_mode(dev, mode_name, args):
    """
    Trigger specific device mode using QSLCL MODE commands
    """
    print(f"[*] Triggering mode: {mode_name}")
    
    # Build payload from additional arguments
    payload = b""
    if hasattr(args, 'mode_args'):
        for arg in args.mode_args:
            try:
                if arg.startswith("0x"):
                    # Hex value
                    if len(arg) > 4:  # Assume 32-bit value
                        payload += struct.pack("<I", int(arg, 16))
                    else:
                        payload += struct.pack("<B", int(arg, 16))
                elif arg.isdigit():
                    # Decimal value
                    payload += struct.pack("<I", int(arg))
                else:
                    # String argument
                    payload += arg.encode() + b"\x00"
            except:
                payload += arg.encode() + b"\x00"
    
    # Try different MODE command strategies
    strategies = [
        try_direct_mode_command,
        try_par_mode_command,
        try_end_mode_opcode,
        try_vm5_mode_service,
        try_idx_mode_command,
        try_generic_mode_dispatch
    ]
    
    for strategy in strategies:
        success = strategy(dev, mode_name, payload)
        if success is not None:
            return success
    
    print(f"[!] Failed to trigger mode: {mode_name}")
    return False

def try_direct_mode_command(dev, mode_name, payload):
    """
    Try direct MODE command dispatch
    """
    # Try exact mode name match
    resp = qslcl_dispatch(dev, "MODE", mode_name.encode() + b"\x00" + payload)
    status = decode_runtime_result(resp)
    
    if status.get("severity") == "SUCCESS":
        print(f"[✓] Mode '{mode_name}' triggered successfully via direct MODE command")
        return True
    
    return None

def try_par_mode_command(dev, mode_name, payload):
    """
    Try QSLCLPAR mode commands
    """
    # Check for exact match
    if mode_name in QSLCLPAR_DB:
        print(f"[*] Using QSLCLPAR mode command: {mode_name}")
        resp = qslcl_dispatch(dev, mode_name, payload)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLPAR")
            return True
        else:
            print(f"[!] QSLCLPAR mode '{mode_name}' failed: {status}")
            return False
    
    # Check for MODE_ prefixed commands
    mode_prefixed = f"MODE_{mode_name}"
    if mode_prefixed in QSLCLPAR_DB:
        print(f"[*] Using QSLCLPAR mode command: {mode_prefixed}")
        resp = qslcl_dispatch(dev, mode_prefixed, payload)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLPAR {mode_prefixed}")
            return True
        else:
            print(f"[!] QSLCLPAR mode '{mode_prefixed}' failed: {status}")
            return False
    
    return None

def try_end_mode_opcode(dev, mode_name, payload):
    """
    Try QSLCLEND mode opcodes
    """
    # Calculate opcode from mode name
    mode_opcode = sum(mode_name.encode()) & 0xFF
    
    if mode_opcode in QSLCLEND_DB:
        print(f"[*] Using QSLCLEND mode opcode 0x{mode_opcode:02X} for '{mode_name}'")
        entry = QSLCLEND_DB[mode_opcode]
        if isinstance(entry, dict):
            entry_data = entry.get("raw", b"")
        else:
            entry_data = entry
        
        pkt = b"QSLCLEND" + entry_data + payload
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLEND opcode 0x{mode_opcode:02X}")
            return True
        else:
            print(f"[!] QSLCLEND mode opcode 0x{mode_opcode:02X} failed: {status}")
            return False
    
    # Try common mode opcodes
    common_mode_opcodes = {
        "QSLCL": 0xFF
    }
    
    if mode_name in common_mode_opcodes:
        opcode = common_mode_opcodes[mode_name]
        if opcode in QSLCLEND_DB:
            print(f"[*] Using common QSLCLEND mode opcode 0x{opcode:02X} for '{mode_name}'")
            entry = QSLCLEND_DB[opcode]
            if isinstance(entry, dict):
                entry_data = entry.get("raw", b"")
            else:
                entry_data = entry
            
            pkt = b"QSLCLEND" + entry_data + payload
            resp = qslcl_dispatch(dev, "ENGINE", pkt)
            status = decode_runtime_result(resp)
            
            if status.get("severity") == "SUCCESS":
                print(f"[✓] Mode '{mode_name}' triggered successfully via common QSLCLEND opcode 0x{opcode:02X}")
                return True
            else:
                print(f"[!] Common QSLCLEND mode opcode 0x{opcode:02X} failed: {status}")
                return False
    
    return None

def try_vm5_mode_service(dev, mode_name, payload):
    """
    Try QSLCLVM5 mode microservices
    """
    # Check for exact match
    if mode_name in QSLCLVM5_DB:
        print(f"[*] Using QSLCLVM5 mode microservice: {mode_name}")
        raw = QSLCLVM5_DB[mode_name]["raw"]
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLVM5")
            return True
        else:
            print(f"[!] QSLCLVM5 mode '{mode_name}' failed: {status}")
            return False
    
    # Check for MODE_ prefixed VM5 services
    mode_prefixed = f"MODE_{mode_name}"
    if mode_prefixed in QSLCLVM5_DB:
        print(f"[*] Using QSLCLVM5 mode microservice: {mode_prefixed}")
        raw = QSLCLVM5_DB[mode_prefixed]["raw"]
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLVM5 {mode_prefixed}")
            return True
        else:
            print(f"[!] QSLCLVM5 mode '{mode_prefixed}' failed: {status}")
            return False
    
    return None

def try_idx_mode_command(dev, mode_name, payload):
    """
    Try QSLCLIDX mode commands
    """
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if mode_name.upper() == entry_name.upper() or f"MODE_{mode_name}".upper() == entry_name.upper():
                idx = entry.get('idx', 0)
                print(f"[*] Using QSLCLIDX mode command: {name} (idx: 0x{idx:02X})")
                
                pkt = b"QSLCLIDX" + struct.pack("<I", idx) + payload
                resp = qslcl_dispatch(dev, "IDX", pkt)
                status = decode_runtime_result(resp)
                
                if status.get("severity") == "SUCCESS":
                    print(f"[✓] Mode '{mode_name}' triggered successfully via QSLCLIDX {name}")
                    return True
                else:
                    print(f"[!] QSLCLIDX mode '{name}' failed: {status}")
                    return False
    
    return None

def try_generic_mode_dispatch(dev, mode_name, payload):
    """
    Final fallback: try generic mode dispatch
    """
    print(f"[*] Trying generic mode dispatch for '{mode_name}'")
    
    # Try the mode name as a direct command
    resp = qslcl_dispatch(dev, mode_name, payload)
    status = decode_runtime_result(resp)
    
    if status.get("severity") == "SUCCESS":
        print(f"[✓] Mode '{mode_name}' triggered successfully via generic dispatch")
        return True
    else:
        print(f"[!] Generic mode dispatch for '{mode_name}' failed: {status}")
        return False

def get_current_device_mode(dev):
    """
    Get current device mode if supported by loader
    """
    print("[*] Querying current device mode...")
    
    # Try different methods to get current mode
    mode_queries = [
        "GET_MODE",
        "CURRENT_MODE", 
        "MODE_STATUS",
        "STATUS"
    ]
    
    for query in mode_queries:
        # Check QSLCLPAR first
        if query in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, query, b"")
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                mode_data = status.get("extra", b"")
                if mode_data:
                    try:
                        mode_str = mode_data.decode('utf-8', errors='ignore').rstrip('\x00')
                        print(f"[*] Current mode: {mode_str}")
                        return mode_str
                    except:
                        print(f"[*] Current mode (raw): {mode_data.hex()}")
                        return mode_data
    
    # Try generic mode query
    resp = qslcl_dispatch(dev, "MODE", b"QUERY\x00")
    status = decode_runtime_result(resp)
    if status.get("severity") == "SUCCESS":
        mode_data = status.get("extra", b"")
        if mode_data:
            try:
                mode_str = mode_data.decode('utf-8', errors='ignore').rstrip('\x00')
                print(f"[*] Current mode: {mode_str}")
                return mode_str
            except:
                print(f"[*] Current mode (raw): {mode_data.hex()}")
                return mode_data
    
    print("[!] Could not determine current device mode")
    return None

def cmd_mode_status(args):
    """
    Handle 'mode status' command to check current device mode
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    return get_current_device_mode(dev) is not None

def update_mode_parser(sub):
    """
    Update the MODE command parser with new subcommands
    """
    mode_parser = sub.add_parser("mode", help="Device mode commands (trigger mode changes)")
    mode_parser.add_argument("mode_subcommand", help="Mode subcommand (list, status, or mode name)")
    mode_parser.add_argument("mode_args", nargs="*", help="Additional arguments for mode command")
    mode_parser.set_defaults(func=cmd_mode)

    status_parser = sub.add_parser("mode-status", help="Check current device mode")
    status_parser.set_defaults(func=cmd_mode_status)