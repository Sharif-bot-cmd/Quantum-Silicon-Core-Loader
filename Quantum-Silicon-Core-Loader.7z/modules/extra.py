def resolve_target_for_rw(dev, target):
    """
    Enhanced target resolution with advanced partition detection and validation
    target = "boot", "0x880000", "boot+0x1000", "emmc:userdata", "ufs:0:boot"
    Returns (address, size, is_partition, target_info)
    """
    target_info = {
        "type": "unknown",
        "name": target,
        "address": 0,
        "size": 0,
        "validated": False,
        "sector_aligned": False
    }
    
    # Check for partition+offset format (e.g., "boot+0x1000")
    if "+" in target:
        try:
            part_name, offset_str = target.split("+", 1)
            scan_gpt(dev)
            base_addr, part_size = resolve_partition(part_name)
            
            if offset_str.startswith("0x"):
                offset = int(offset_str, 16)
            else:
                offset = int(offset_str)
            
            if offset >= part_size:
                raise ValueError(f"Offset 0x{offset:X} beyond partition {part_name} size 0x{part_size:X}")
            
            addr = base_addr + offset
            target_info.update({
                "type": "partition_offset",
                "name": part_name,
                "base_address": base_addr,
                "offset": offset,
                "address": addr,
                "size": part_size - offset,  # Remaining size from offset
                "validated": True
            })
            return addr, part_size - offset, True, target_info
            
        except Exception as e:
            print(f"[!] Invalid partition+offset format: {e}")
            return None, None, False, target_info
    
    # Check for storage device format (e.g., "emmc:userdata", "ufs:0:boot")
    if ":" in target:
        try:
            storage_type, *parts = target.split(":")
            if storage_type.upper() in ["EMMC", "UFS", "NAND", "SPI"]:
                # FIXED: Implement proper storage target resolution
                if storage_type.upper() == "EMMC" and len(parts) == 1:
                    part_name = parts[0]
                    try:
                        scan_gpt(dev)
                        addr, size = resolve_partition(part_name)
                        target_info.update({
                            "type": "emmc_partition",
                            "storage": "eMMC",
                            "name": part_name,
                            "address": addr,
                            "size": size,
                            "validated": True
                        })
                        return addr, size, True, target_info
                    except:
                        pass
                elif storage_type.upper() == "UFS" and len(parts) == 2:
                    lun, part_name = parts
                    try:
                        scan_gpt(dev)
                        addr, size = resolve_partition(part_name)
                        target_info.update({
                            "type": "ufs_partition",
                            "storage": "UFS",
                            "lun": lun,
                            "name": part_name,
                            "address": addr,
                            "size": size,
                            "validated": True
                        })
                        return addr, size, True, target_info
                    except:
                        pass
        except:
            pass
    
    # Hex raw address
    if target.startswith("0x") or (target.replace('_', '').isalnum() and any(c in 'abcdefABCDEF' for c in target)):
        try:
            addr = int(target, 16) if target.startswith("0x") else int(target, 16)
            target_info.update({
                "type": "raw_address",
                "address": addr,
                "validated": True
            })
            return addr, None, False, target_info
        except:
            pass
    
    # Decimal raw address
    if target.isdigit():
        try:
            addr = int(target)
            target_info.update({
                "type": "raw_address",
                "address": addr,
                "validated": True
            })
            return addr, None, False, target_info
        except:
            pass
    
    # Partition name
    try:
        scan_gpt(dev)
        addr, size = resolve_partition(target)
        target_info.update({
            "type": "partition",
            "name": target,
            "address": addr,
            "size": size,
            "validated": True
        })
        return addr, size, True, target_info
    except:
        # Try common partition aliases
        aliases = {
            "boot": "boot", "kernel": "boot", "recovery": "recovery", "system": "system",
            "vendor": "vendor", "userdata": "userdata", "cache": "cache", "misc": "misc",
            "frp": "frp", "persist": "persist", "modem": "modem", "bootloader": "aboot"
        }
        
        if target.lower() in aliases:
            try:
                actual_name = aliases[target.lower()]
                addr, size = resolve_partition(actual_name)
                target_info.update({
                    "type": "partition_alias",
                    "name": actual_name,
                    "alias": target,
                    "address": addr,
                    "size": size,
                    "validated": True
                })
                return addr, size, True, target_info
            except:
                pass
    
    # Not a known target
    target_info["validated"] = False
    return None, None, False, target_info

def resolve_storage_target(dev, storage_type, parts, target_info):
    """
    Resolve storage device specific targets
    """
    if storage_type.upper() == "EMMC":
        if len(parts) == 1:
            # emmc:userdata format
            part_name = parts[0]
            try:
                addr, size = resolve_partition(part_name)
                target_info.update({
                    "type": "emmc_partition",
                    "storage": "eMMC",
                    "name": part_name,
                    "address": addr,
                    "size": size,
                    "validated": True
                })
                return addr, size, True, target_info
            except:
                pass
    
    elif storage_type.upper() == "UFS":
        if len(parts) == 2:
            # ufs:0:boot format (LUN:partition)
            lun, part_name = parts
            try:
                # UFS specific resolution would go here
                # For now, try regular partition resolution
                addr, size = resolve_partition(part_name)
                target_info.update({
                    "type": "ufs_partition",
                    "storage": "UFS",
                    "lun": lun,
                    "name": part_name,
                    "address": addr,
                    "size": size,
                    "validated": True
                })
                return addr, size, True, target_info
            except:
                pass
    
    return None, None, False, target_info

def detect_file_or_hex(data, max_file_size=1024*1024*1024):  # 1GB max by default
    """
    Enhanced file/hex detection with validation and safety limits
    Return: (type, data, info)
    """
    info = {
        "type": "unknown",
        "size": 0,
        "valid": False,
        "source": data
    }
    
    # Check if it's a file path
    if os.path.exists(data):
        try:
            file_size = os.path.getsize(data)
            if file_size > max_file_size:
                raise ValueError(f"File too large: {file_size} bytes (max: {max_file_size})")
            
            with open(data, "rb") as f:
                file_data = f.read()
            
            info.update({
                "type": "file",
                "size": len(file_data),
                "file_path": data,
                "file_size": file_size,
                "valid": True
            })
            return "file", file_data, info
            
        except Exception as e:
            raise ValueError(f"File error: {e}")
    
    # Check if it's a hex string
    try:
        # Remove common hex prefixes and whitespace
        clean_data = data.replace("0x", "").replace(" ", "").replace(":", "").replace("-", "")
        
        # Validate hex characters
        if all(c in "0123456789ABCDEFabcdef" for c in clean_data):
            # Ensure even length for bytes conversion
            if len(clean_data) % 2 != 0:
                clean_data = "0" + clean_data
            
            hex_data = bytes.fromhex(clean_data)
            
            info.update({
                "type": "hex",
                "size": len(hex_data),
                "hex_length": len(clean_data) // 2,
                "valid": True
            })
            return "hex", hex_data, info
    except:
        pass
    
    # Check if it's a pattern (e.g., "00FF"*100)
    if "*" in data:
        try:
            pattern, repeat_str = data.split("*", 1)
            repeat_count = int(repeat_str)
            
            # Validate pattern as hex
            clean_pattern = pattern.replace("0x", "").replace(" ", "")
            if all(c in "0123456789ABCDEFabcdef" for c in clean_pattern):
                if len(clean_pattern) % 2 != 0:
                    clean_pattern = "0" + clean_pattern
                
                pattern_bytes = bytes.fromhex(clean_pattern)
                pattern_data = pattern_bytes * repeat_count
                
                info.update({
                    "type": "pattern",
                    "size": len(pattern_data),
                    "pattern": clean_pattern,
                    "repeats": repeat_count,
                    "valid": True
                })
                return "pattern", pattern_data, info
        except:
            pass
    
    # Check if it's a fill pattern (e.g., "FF:1024" to fill 1024 bytes with 0xFF)
    if ":" in data and not data.startswith("0x"):
        try:
            fill_byte_str, size_str = data.split(":", 1)
            fill_byte = int(fill_byte_str, 16) & 0xFF
            fill_size = int(size_str)
            
            fill_data = bytes([fill_byte]) * fill_size
            
            info.update({
                "type": "fill",
                "size": fill_size,
                "fill_byte": fill_byte,
                "valid": True
            })
            return "fill", fill_data, info
        except:
            pass
    
    raise ValueError(f"Data source not recognized: {data}")

def validate_read_write_operation(dev, addr, size, operation="read"):
    """
    Validate read/write operation parameters for safety
    """
    warnings = []
    errors = []
    
    # Check address alignment
    sector_size = get_sector_size(dev)
    if addr % sector_size != 0:
        warnings.append(f"Address 0x{addr:X} not sector-aligned (sector size: {sector_size})")
    
    # Check size alignment
    if size % sector_size != 0:
        warnings.append(f"Size 0x{size:X} not sector-aligned (sector size: {sector_size})")
    
    # Check for critical system addresses (read-only protection)
    critical_ranges = [
        (0x00000000, 0x01000000, "Boot ROM/Flash"),
        (0x88000000, 0x89000000, "Kernel/Boot"),
        (0xFFF00000, 0xFFFFFFFF, "Reserved/MMIO")
    ]
    
    for start, end, description in critical_ranges:
        if start <= addr < end:
            if operation == "write":
                errors.append(f"CRITICAL: Writing to {description} region (0x{addr:X}) may brick device!")
            else:
                warnings.append(f"Reading from {description} region (0x{addr:X})")
    
    # Size limits
    max_safe_size = 256 * 1024 * 1024  # 256MB
    if size > max_safe_size:
        warnings.append(f"Large operation: {size} bytes (> {max_safe_size} bytes)")
    
    return warnings, errors

def smart_size_determination(dev, target_info, args, operation="read"):
    """
    Intelligent size determination for read/write operations
    """
    size = None
    size_source = "unknown"
    
    # Priority 1: Explicit size argument
    if hasattr(args, 'size') and args.size:
        size = args.size
        size_source = "explicit_argument"
    
    # Priority 2: Secondary argument (if numeric)
    elif hasattr(args, 'arg2') and args.arg2 and args.arg2.isdigit():
        size = int(args.arg2)
        size_source = "secondary_argument"
    
    # Priority 3: Partition size
    elif target_info.get("type") in ["partition", "partition_alias", "emmc_partition", "ufs_partition"]:
        size = target_info.get("size")
        size_source = "partition_size"
    
    # Priority 4: Smart detection for raw addresses
    elif target_info.get("type") == "raw_address" and operation == "read":
        # For raw address reads, try to detect region size
        detected_size = detect_region_size(dev, target_info["address"])
        if detected_size:
            size = detected_size
            size_source = "auto_detected"
        else:
            # Default safe size for raw reads
            size = 4096
            size_source = "default_safe"
    
    # Priority 5: Data size for writes
    elif operation == "write" and hasattr(args, 'data'):
        try:
            _, data, _ = detect_file_or_hex(args.data)
            size = len(data)
            size_source = "data_size"
        except:
            pass
    
    if size is None:
        raise ValueError(f"Cannot determine size for {operation} operation")
    
    return size, size_source

def detect_region_size(dev, address):
    """
    Attempt to detect the size of a memory region
    """
    # Try to read progressively larger chunks until failure
    test_sizes = [512, 4096, 32768, 131072]  # 512B, 4KB, 32KB, 128KB
    
    for test_size in test_sizes:
        try:
            payload = struct.pack("<Q I", address, test_size)
            resp = qslcl_dispatch(dev, "READ", payload)
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    break
            else:
                break
        except:
            break
    else:
        # If all sizes succeeded, return the largest tested size
        return test_sizes[-1]
    
    # Return the last successful size
    return test_sizes[test_sizes.index(test_size) - 1] if test_sizes.index(test_size) > 0 else 512

def optimized_read_operation(dev, addr, size, chunk_size=None):
    """
    Perform optimized read operation with chunking and progress tracking
    """
    if chunk_size is None:
        chunk_size = min(size, 64 * 1024)  # 64KB chunks by default
    
    total_read = 0
    all_data = bytearray()
    sector_size = get_sector_size(dev)
    
    # Align chunk size to sectors
    chunk_size = align_up(chunk_size, sector_size)
    
    print(f"[*] Reading in {chunk_size // 1024}KB chunks...")
    
    with ProgressBar(total=size, prefix="Reading", suffix="complete", decimals=1) as progress:
        while total_read < size:
            current_chunk = min(chunk_size, size - total_read)
            current_addr = addr + total_read
            
            # Align chunk to sector boundary
            aligned_chunk = align_up(current_chunk, sector_size)
            
            payload = struct.pack("<Q I", current_addr, aligned_chunk)
            resp, origin = qslclidx_or_dispatch(dev, "READ", payload)
            
            if not resp:
                print(f"\n[!] Read failed at 0x{current_addr:X}")
                break
            
            status = decode_runtime_result(resp)
            if status.get("severity") != "SUCCESS":
                print(f"\n[!] Read error at 0x{current_addr:X}: {status.get('name', 'UNKNOWN')}")
                break
            
            chunk_data = status.get("extra", b"")
            if not chunk_data:
                print(f"\n[!] Empty response at 0x{current_addr:X}")
                break
            
            # Take only the requested amount (in case we read more due to alignment)
            actual_data = chunk_data[:current_chunk]
            all_data.extend(actual_data)
            total_read += len(actual_data)
            
            progress.update(len(actual_data))
    
    return bytes(all_data), total_read

def optimized_write_operation(dev, addr, data, chunk_size=None):
    """
    Perform optimized write operation with chunking and progress tracking
    """
    if chunk_size is None:
        chunk_size = min(len(data), 64 * 1024)  # 64KB chunks by default
    
    total_written = 0
    sector_size = get_sector_size(dev)
    total_size = len(data)
    
    # Align chunk size to sectors
    chunk_size = align_up(chunk_size, sector_size)
    
    print(f"[*] Writing in {chunk_size // 1024}KB chunks...")
    
    with ProgressBar(total=total_size, prefix="Writing", suffix="complete", decimals=1) as progress:
        while total_written < total_size:
            current_chunk = min(chunk_size, total_size - total_written)
            current_addr = addr + total_written
            
            # Get chunk data and pad to sector alignment if needed
            chunk_data = data[total_written:total_written + current_chunk]
            if len(chunk_data) % sector_size != 0:
                chunk_data += b"\x00" * (sector_size - (len(chunk_data) % sector_size))
            
            payload = struct.pack("<Q", current_addr) + chunk_data
            resp, origin = qslclidx_or_dispatch(dev, "WRITE", payload)
            
            if not resp:
                print(f"\n[!] Write failed at 0x{current_addr:X}")
                return False
            
            status = decode_runtime_result(resp)
            if status.get("severity") != "SUCCESS":
                print(f"\n[!] Write error at 0x{current_addr:X}: {status.get('name', 'UNKNOWN')}")
                return False
            
            total_written += current_chunk
            progress.update(current_chunk)
    
    return True

def chunked_erase_operation(dev, addr, size, chunk_size=1024*1024):  # 1MB chunks
    """
    Perform erase operation in chunks for large regions
    """
    total_erased = 0
    chunk_size = align_up(chunk_size, get_sector_size(dev))
    
    with ProgressBar(total=size, prefix="Erasing", suffix="complete", decimals=1) as progress:
        while total_erased < size:
            current_chunk = min(chunk_size, size - total_erased)
            current_addr = addr + total_erased
            
            payload = struct.pack("<Q I", current_addr, current_chunk)
            resp, origin = qslclidx_or_dispatch(dev, "ERASE", payload)
            
            if not resp:
                print(f"\n[!] Erase failed at 0x{current_addr:X}")
                return False
            
            status = decode_runtime_result(resp)
            if status.get("severity") != "SUCCESS":
                print(f"\n[!] Erase error at 0x{current_addr:X}: {status.get('name', 'UNKNOWN')}")
                return False
            
            total_erased += current_chunk
            progress.update(current_chunk)
    
    return True

def determine_output_file(args, target, target_info):
    """
    Determine output filename for read operations
    """
    # Priority 1: Explicit output argument
    if hasattr(args, 'output') and args.output:
        return args.output
    
    # Priority 2: Secondary argument (if not numeric)
    if hasattr(args, 'arg2') and args.arg2 and not args.arg2.isdigit():
        return args.arg2
    
    # Priority 3: Smart filename based on target info
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    
    if target_info.get("type") == "partition":
        return f"{target_info['name']}_{timestamp}.bin"
    elif target_info.get("type") == "raw_address":
        return f"memory_0x{target_info['address']:X}_{timestamp}.bin"
    elif target_info.get("type") == "partition_offset":
        return f"{target_info['name']}_0x{target_info['offset']:X}_{timestamp}.bin"
    else:
        return f"{target}_{timestamp}.bin"

# ============================================================
#                      ENHANCED READ
# ============================================================
def cmd_read(args):
    """
    Enhanced READ command with intelligent target resolution and validation
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device detected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Resolve target with enhanced detection
    target = args.target
    addr, psize, is_part, target_info = resolve_target_for_rw(dev, target)
    
    if not target_info.get("validated", False):
        return print(f"[!] Cannot resolve target: {target}")
    
    # Intelligent size determination
    try:
        size, size_source = smart_size_determination(dev, target_info, args, "read")
    except ValueError as e:
        return print(f"[!] {e}")
    
    # Output file determination
    outfile = determine_output_file(args, target, target_info)
    
    # Operation validation
    warnings, errors = validate_read_write_operation(dev, addr, size, "read")
    
    # Display warnings
    for warning in warnings:
        print(f"[~] Warning: {warning}")
    
    # Check for critical errors
    if errors:
        for error in errors:
            print(f"[!] Error: {error}")
        confirm = input("Continue anyway? (y/N): ").strip().lower()
        if confirm != 'y':
            return print("[*] Read operation cancelled.")
    
    # Sector alignment
    sector = get_sector_size(dev)
    aligned_addr = addr & ~(sector - 1)
    aligned_size = align_up(size, sector)
    
    # Display operation info
    print(f"[*] READ Operation Summary:")
    print(f"    Target: {target} ({target_info['type']})")
    print(f"    Address: 0x{addr:X} -> 0x{aligned_addr:X} (aligned)")
    print(f"    Size: 0x{size:X} -> 0x{aligned_size:X} bytes (aligned)")
    print(f"    Size Source: {size_source}")
    print(f"    Output: {outfile}")
    
    if warnings:
        print(f"    Warnings: {len(warnings)}")
    
    # Perform read operation
    print(f"\n[*] Starting read operation...")
    
    try:
        data, bytes_read = optimized_read_operation(dev, aligned_addr, aligned_size)
        
        # Trim to actual requested size
        if bytes_read > size:
            data = data[:size]
        
        # Save to file
        with open(outfile, "wb") as f:
            f.write(data)
        
        # Verify file was written
        if os.path.exists(outfile) and os.path.getsize(outfile) == len(data):
            print(f"[✓] Read completed: {bytes_read} bytes -> {outfile}")
            
            # Additional info
            file_size = os.path.getsize(outfile)
            print(f"[*] File info: {file_size} bytes ({file_size / 1024 / 1024:.2f} MB)")
            
            # Calculate checksum if small enough
            if file_size < 10 * 1024 * 1024:  # 10MB
                import hashlib
                sha256 = hashlib.sha256(data).hexdigest()
                print(f"[*] SHA256: {sha256}")
            
            return True
        else:
            print(f"[!] File write verification failed")
            return False
            
    except Exception as e:
        print(f"[!] Read operation failed: {e}")
        return False

def cmd_write(args):
    """
    Enhanced WRITE command with comprehensive validation and safety checks
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device detected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Resolve target
    target = args.target
    addr, psize, is_part, target_info = resolve_target_for_rw(dev, target)
    
    if not target_info.get("validated", False):
        return print(f"[!] Cannot resolve target: {target}")
    
    # Detect and load data
    try:
        dtype, data, data_info = detect_file_or_hex(args.data)
    except ValueError as e:
        return print(f"[!] {e}")
    
    # Size validation for partitions
    if is_part and psize and len(data) > psize:
        print(f"[!] Warning: Data size ({len(data)} bytes) exceeds partition size ({psize} bytes)")
        confirm = input("Continue with truncated write? (y/N): ").strip().lower()
        if confirm != 'y':
            return print("[*] Write operation cancelled.")
        # Truncate data to partition size
        data = data[:psize]
        print(f"[*] Data truncated to {len(data)} bytes")
    
    # Operation validation
    warnings, errors = validate_read_write_operation(dev, addr, len(data), "write")
    
    # Display critical information
    print(f"[!] WRITE OPERATION WARNING")
    print(f"    Target: {target} ({target_info['type']})")
    print(f"    Address: 0x{addr:X}")
    print(f"    Data Size: {len(data)} bytes")
    print(f"    Data Type: {dtype}")
    
    if data_info.get("file_path"):
        print(f"    Source File: {data_info['file_path']}")
    
    # Display all warnings and errors
    for warning in warnings:
        print(f"    Warning: {warning}")
    
    for error in errors:
        print(f"    CRITICAL: {error}")
    
    # Safety confirmation
    if errors:
        print(f"\n[!] CRITICAL ERRORS DETECTED!")
        confirm = input("TYPE 'YES' TO CONTINUE (THIS MAY BRICK YOUR DEVICE): ").strip().upper()
        if confirm != 'YES':
            return print("[*] Write operation cancelled for safety.")
    else:
        confirm = input("\nConfirm write operation? (yes/NO): ").strip().lower()
        if confirm != 'yes':
            return print("[*] Write operation cancelled.")
    
    # Sector alignment
    sector = get_sector_size(dev)
    aligned_addr = addr & ~(sector - 1)
    aligned_len = align_up(len(data), sector)
    
    # Pad data if necessary
    if len(data) < aligned_len:
        original_size = len(data)
        data += b"\x00" * (aligned_len - len(data))
        print(f"[*] Data padded from {original_size} to {len(data)} bytes for alignment")
    
    # Perform write operation
    print(f"\n[*] Starting write operation...")
    
    try:
        success = optimized_write_operation(dev, aligned_addr, data)
        
        if success:
            print(f"[✓] Write completed: {len(data)} bytes -> 0x{addr:X}")
            
            # Optional verification read
            if len(data) <= 65536:  # Only verify small writes
                verify = input("Verify write? (y/N): ").strip().lower()
                if verify == 'y':
                    print("[*] Verifying write...")
                    verify_data, _ = optimized_read_operation(dev, aligned_addr, min(len(data), 65536))
                    if verify_data == data[:len(verify_data)]:
                        print("[✓] Write verification: SUCCESS")
                    else:
                        print("[!] Write verification: FAILED - data mismatch")
            
            return True
        else:
            print("[!] Write operation failed")
            return False
            
    except Exception as e:
        print(f"[!] Write operation failed: {e}")
        return False

def cmd_erase(args):
    """
    Enhanced ERASE command with safety controls and validation
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device detected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Resolve target
    target = args.target
    addr, psize, is_part, target_info = resolve_target_for_rw(dev, target)
    
    if not target_info.get("validated", False):
        return print(f"[!] Cannot resolve target: {target}")
    
    # Size determination
    try:
        size, size_source = smart_size_determination(dev, target_info, args, "erase")
    except ValueError as e:
        return print(f"[!] {e}")
    
    # Operation validation
    warnings, errors = validate_read_write_operation(dev, addr, size, "erase")
    
    # Display critical information
    print(f"[!] ERASE OPERATION WARNING")
    print(f"    Target: {target} ({target_info['type']})")
    print(f"    Address: 0x{addr:X}")
    print(f"    Size: 0x{size:X} bytes ({size / 1024 / 1024:.2f} MB)")
    print(f"    Size Source: {size_source}")
    
    # Display all warnings and errors
    for warning in warnings:
        print(f"    Warning: {warning}")
    
    for error in errors:
        print(f"    CRITICAL: {error}")
    
    # Safety confirmation
    print(f"\n[!] ERASE WILL DESTROY DATA!")
    if errors:
        confirm = input("TYPE 'ERASE' TO CONTINUE (THIS MAY BRICK YOUR DEVICE): ").strip().upper()
        expected_confirm = "ERASE"
    else:
        confirm = input("TYPE 'YES' TO CONFIRM ERASE: ").strip().upper()
        expected_confirm = "YES"
    
    if confirm != expected_confirm:
        return print("[*] Erase operation cancelled.")
    
    # Sector alignment
    sector = get_sector_size(dev)
    aligned_addr = addr & ~(sector - 1)
    aligned_size = align_up(size, sector)
    
    # Perform erase operation
    print(f"\n[*] Starting erase operation...")
    
    # For large erases, use chunking
    if aligned_size > 1024 * 1024:  # 1MB
        print(f"[*] Large erase detected, using chunked operation...")
        success = chunked_erase_operation(dev, aligned_addr, aligned_size)
    else:
        payload = struct.pack("<Q I", aligned_addr, aligned_size)
        resp, origin = qslclidx_or_dispatch(dev, "ERASE", payload)
        
        if resp:
            status = decode_runtime_result(resp)
            success = status.get("severity") == "SUCCESS"
            if not success:
                print(f"[!] Erase failed: {status.get('name', 'UNKNOWN')}")
        else:
            success = False
            print("[!] No response from erase command")
    
    if success:
        print(f"[✓] Erase completed: 0x{aligned_size:X} bytes at 0x{aligned_addr:X}")
        return True
    else:
        print("[!] Erase operation failed")
        return False

