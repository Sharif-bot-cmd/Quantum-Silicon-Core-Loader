def cmd_crash(args=None):
    """
    Fully implemented CRASH command with advanced features:
    - Controlled system crash injection for testing
    - Multiple crash types and triggers
    - Safety limits and confirmation
    - Crash analysis and reporting
    - Recovery mechanisms
    """
    if not args:
        print("[!] CRASH: No arguments provided")
        print_crash_help()
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    # Safely get attributes with defaults
    subcommand = getattr(args, 'crash_subcommand', '').lower() if args else ''
    crash_args = getattr(args, 'crash_args', []) if args else []
    force = getattr(args, 'force', False) if args else False
    severity = getattr(args, 'severity', 'medium') if args else 'medium'
    timeout = getattr(args, 'timeout', 10) if args else 10

    if not subcommand:
        print("[!] CRASH: No subcommand specified")
        print_crash_help()
        return

    print(f"[*] CRASH command: {subcommand} {crash_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'types']:
            crash_list(dev, crash_args)
            
        elif subcommand in ['kernel', 'panic']:
            crash_kernel(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['null', 'nullptr', 'null-pointer']:
            crash_null_pointer(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['stack', 'overflow', 'stack-overflow']:
            crash_stack_overflow(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['heap', 'corruption', 'heap-corruption']:
            crash_heap_corruption(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['divide', 'divide-zero', 'div0']:
            crash_divide_zero(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['memory', 'mem', 'memory-corruption']:
            crash_memory_corruption(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['watchdog', 'wdt']:
            crash_watchdog(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['interrupt', 'irq', 'isr']:
            crash_interrupt(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['dma', 'dma-overflow']:
            crash_dma(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['custom', 'user']:
            crash_custom(dev, crash_args, force, severity, timeout)
            
        elif subcommand in ['analyze', 'analysis']:
            crash_analyze(dev, crash_args)
            
        elif subcommand in ['help', '?']:
            print_crash_help()
            
        else:
            print(f"[!] Unknown CRASH subcommand: {subcommand}")
            print_crash_help()
            
    except Exception as e:
        print(f"[!] CRASH operation failed: {e}")
        traceback.print_exc()
        return 1  # Return error code
    
    return 0  # Success

def cmd_crash_test(args=None):
    """
    Comprehensive crash testing suite:
    - Automated crash scenario testing
    - System resilience validation
    - Recovery testing
    - Performance under stress
    """
    print("[*] Starting CRASH-TEST suite...")
    
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Get test parameters with safe defaults
    test_type = 'basic'
    iterations = 1
    delay = 5
    
    # Parse args if provided
    if args:
        crash_args = getattr(args, 'crash_args', [])
        if crash_args:
            test_type = crash_args[0] if len(crash_args) > 0 else 'basic'
            if len(crash_args) > 1:
                try:
                    iterations = int(crash_args[1])
                    iterations = max(1, min(iterations, 100))  # Limit to reasonable range
                except ValueError:
                    print(f"[!] Invalid iteration count: {crash_args[1]}, using default: 1")
            if len(crash_args) > 2:
                try:
                    delay = int(crash_args[2])
                    delay = max(1, min(delay, 300))  # Limit to reasonable range (5 minutes max)
                except ValueError:
                    print(f"[!] Invalid delay: {crash_args[2]}, using default: 5")
    
    print(f"[*] Crash test type: {test_type}, iterations: {iterations}, delay: {delay}s")
    
    # Safety warning
    print("[!] WARNING: Crash testing may cause system instability!")
    print("[!] Device may require manual recovery!")
    response = input("    Type 'TEST' to continue: ")
    if response != 'TEST':
        print("[*] Crash test cancelled")
        return 0
    
    try:
        if test_type == 'basic':
            run_basic_crash_test(dev, iterations, delay)
        elif test_type == 'comprehensive':
            run_comprehensive_crash_test(dev, iterations, delay)
        elif test_type == 'recovery':
            run_recovery_test(dev, iterations, delay)
        elif test_type == 'stress':
            run_stress_test(dev, iterations, delay)
        else:
            print(f"[!] Unknown test type: {test_type}")
            print("[*] Valid types: basic, comprehensive, recovery, stress")
            return 1
            
    except KeyboardInterrupt:
        print("\n[!] Crash test interrupted by user")
        return 1
    except Exception as e:
        print(f"[!] Crash test failed: {e}")
        traceback.print_exc()
        return 1
        
    return 0

# =============================================================================
# CRASH SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def crash_list(dev, args):
    """List available crash types and capabilities"""
    print("[*] Querying crash capabilities...")
    
    capabilities = query_crash_capabilities(dev)
    
    print(f"\n[+] CRASH Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    Crash Support: {capabilities.get('crash_support', 'Basic')}")
    
    # List available crash types
    crash_types = capabilities.get('crash_types', [])
    if crash_types:
        print(f"\n[+] Available Crash Types:")
        for crash_type in crash_types:
            severity = crash_type.get('severity', 'MEDIUM')
            severity_icon = "🟢" if severity == 'LOW' else "🟡" if severity == 'MEDIUM' else "🔴"
            recovery = crash_type.get('recovery', 'AUTO')
            desc = crash_type.get('description', '')
            # Truncate description if too long
            if len(desc) > 40:
                desc = desc[:37] + "..."
            print(f"    {severity_icon} {crash_type['name']:20} - {desc} [Recovery: {recovery}]")
    else:
        print("[!] No crash capabilities detected")
        print("[*] Try loading a QSLCL loader with crash support")

def crash_kernel(dev, args, force=False, severity='medium', timeout=10):
    """Trigger kernel panic"""
    print("[*] Preparing KERNEL PANIC...")
    
    if not force:
        print("[!] WARNING: Kernel panic will crash the entire system!")
        print("[!] All processes will be terminated!")
        print("[!] System may require manual reboot!")
        response = input("    Type 'PANIC' to continue: ")
        if response != 'PANIC':
            print("[*] Operation cancelled")
            return
    
    panic_type = args[0] if args and len(args) > 0 else "GENERIC"
    print(f"[*] Triggering kernel panic: {panic_type}")
    
    try:
        # Build kernel panic command
        crash_payload = struct.pack("<B", 0x01)  # KERNEL_PANIC command
        crash_payload += panic_type.encode('ascii', errors='ignore').ljust(16, b'\x00')
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Kernel panic triggered")
                print("[+] System should crash shortly...")
                # Don't wait for response - system is crashing
                for i in range(3):
                    print(f"[*] System crashing in {3-i}...")
                    time.sleep(1)
            else:
                print(f"[!] Kernel panic failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Kernel panic may have occurred (communication lost)")
            
    except Exception as e:
        print(f"[!] Kernel panic error: {e}")
        print("[+] Crash may have occurred (communication lost)")

def crash_null_pointer(dev, args, force=False, severity='medium', timeout=10):
    """Trigger null pointer dereference"""
    print("[*] Preparing NULL POINTER dereference...")
    
    if not force:
        print("[!] This will cause a memory access violation.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    address = args[0] if args and len(args) > 0 else "0x00000000"
    print(f"[*] Triggering null pointer access at {address}")
    
    try:
        # Parse address safely
        addr_val = parse_address(address)
        
        # Build null pointer crash command
        crash_payload = struct.pack("<B", 0x02)  # NULL_POINTER command
        crash_payload += struct.pack("<I", addr_val)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Null pointer access triggered")
                monitor_crash_recovery(dev, timeout, "null pointer")
            else:
                print(f"[!] Null pointer crash failed: {status}")
        else:
            print("[!] No response from device")
            
    except ValueError as e:
        print(f"[!] Invalid address format: {address}")
    except Exception as e:
        print(f"[!] Null pointer crash error: {e}")

def crash_stack_overflow(dev, args, force=False, severity='medium', timeout=10):
    """Trigger stack overflow"""
    print("[*] Preparing STACK OVERFLOW...")
    
    if not force:
        print("[!] This will corrupt the call stack.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    depth = 1000  # Default
    if args and len(args) > 0:
        try:
            depth = int(args[0])
        except ValueError:
            print(f"[!] Invalid depth value: {args[0]}, using default: 1000")
    
    if depth > 10000:
        print("[!] Warning: Very deep recursion may cause permanent issues")
        if not force:
            response = input(f"    Continue with depth {depth}? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
    
    print(f"[*] Triggering stack overflow with recursion depth {depth}")
    
    try:
        # Build stack overflow command
        crash_payload = struct.pack("<B", 0x03)  # STACK_OVERFLOW command
        crash_payload += struct.pack("<I", depth)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Stack overflow triggered")
                monitor_crash_recovery(dev, timeout, "stack overflow")
            else:
                print(f"[!] Stack overflow failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Stack overflow error: {e}")

def crash_heap_corruption(dev, args, force=False, severity='medium', timeout=10):
    """Trigger heap corruption"""
    print("[*] Preparing HEAP CORRUPTION...")
    
    if not force:
        print("[!] This will corrupt dynamic memory allocation.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    corruption_type = args[0] if args and len(args) > 0 else "DOUBLE_FREE"
    valid_types = ["DOUBLE_FREE", "USE_AFTER_FREE", "BUFFER_OVERFLOW", "RACE_CONDITION"]
    
    if corruption_type not in valid_types:
        print(f"[!] Invalid corruption type: {corruption_type}")
        print(f"[*] Valid types: {', '.join(valid_types)}")
        corruption_type = "DOUBLE_FREE"
        print(f"[*] Using default: {corruption_type}")
    
    print(f"[*] Triggering heap corruption: {corruption_type}")
    
    try:
        # Build heap corruption command
        crash_payload = struct.pack("<B", 0x04)  # HEAP_CORRUPTION command
        crash_payload += corruption_type.encode('ascii', errors='ignore').ljust(16, b'\x00')
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Heap corruption triggered")
                monitor_crash_recovery(dev, timeout, "heap corruption")
            else:
                print(f"[!] Heap corruption failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Heap corruption error: {e}")

def crash_divide_zero(dev, args, force=False, severity='medium', timeout=10):
    """Trigger divide by zero"""
    print("[*] Preparing DIVIDE BY ZERO...")
    
    if not force:
        print("[!] This will cause an arithmetic exception.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    print("[*] Triggering divide by zero exception")
    
    try:
        # Build divide by zero command
        crash_payload = struct.pack("<B", 0x05)  # DIVIDE_ZERO command
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Divide by zero triggered")
                monitor_crash_recovery(dev, timeout, "divide by zero")
            else:
                print(f"[!] Divide by zero failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Divide by zero error: {e}")

def crash_memory_corruption(dev, args, force=False, severity='medium', timeout=10):
    """Trigger memory corruption"""
    print("[*] Preparing MEMORY CORRUPTION...")
    
    if not force:
        print("[!] This will corrupt specific memory regions.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    address = args[0] if args and len(args) > 0 else "0x10000000"
    pattern = args[1] if len(args) > 1 else "0xDEADBEEF"
    print(f"[*] Corrupting memory at {address} with pattern {pattern}")
    
    try:
        # Parse addresses safely
        addr_val = parse_address(address)
        pattern_val = parse_address(pattern)
        
        # Safety check for critical addresses
        if addr_val < 0x1000:
            print("[!] WARNING: Attempting to corrupt low memory area!")
            print("[!] This could make the system unbootable!")
            if not force:
                response = input("    This could be dangerous. Continue? (y/N): ")
                if response.lower() not in ('y', 'yes'):
                    print("[*] Operation cancelled")
                    return
        
        # Build memory corruption command
        crash_payload = struct.pack("<B", 0x06)  # MEMORY_CORRUPTION command
        crash_payload += struct.pack("<I", addr_val)
        crash_payload += struct.pack("<I", pattern_val)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Memory corruption triggered")
                monitor_crash_recovery(dev, timeout, "memory corruption")
            else:
                print(f"[!] Memory corruption failed: {status}")
        else:
            print("[!] No response from device")
            
    except ValueError as e:
        print(f"[!] Invalid address format: {e}")
    except Exception as e:
        print(f"[!] Memory corruption error: {e}")

def crash_watchdog(dev, args, force=False, severity='medium', timeout=10):
    """Trigger watchdog timeout"""
    print("[*] Preparing WATCHDOG TIMEOUT...")
    
    if not force:
        print("[!] This will let the watchdog timer expire.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    timeout_ms = 1000  # Default 1 second
    if args and len(args) > 0:
        try:
            timeout_ms = int(args[0])
        except ValueError:
            print(f"[!] Invalid timeout value: {args[0]}, using default: 1000ms")
    
    if timeout_ms < 100:
        print("[!] WARNING: Very short watchdog timeout!")
        if not force:
            response = input("    Continue? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
    
    print(f"[*] Setting watchdog timeout to {timeout_ms}ms")
    
    try:
        # Build watchdog timeout command
        crash_payload = struct.pack("<B", 0x07)  # WATCHDOG_TIMEOUT command
        crash_payload += struct.pack("<I", timeout_ms)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Watchdog timeout configured")
                print(f"[+] System will reset in {timeout_ms}ms...")
                # Calculate total monitoring time
                total_timeout = (timeout_ms // 1000) + 5
                monitor_crash_recovery(dev, total_timeout, "watchdog timeout")
            else:
                print(f"[!] Watchdog timeout setup failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Watchdog timeout error: {e}")

def crash_interrupt(dev, args, force=False, severity='medium', timeout=10):
    """Trigger interrupt storm"""
    print("[*] Preparing INTERRUPT STORM...")
    
    if not force:
        print("[!] This will generate excessive interrupts.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    irq_number = 0  # Default
    frequency = 1000  # Default 1kHz
    
    if args and len(args) > 0:
        try:
            irq_number = int(args[0])
        except ValueError:
            print(f"[!] Invalid IRQ number: {args[0]}, using default: 0")
    
    if len(args) > 1:
        try:
            frequency = int(args[1])
        except ValueError:
            print(f"[!] Invalid frequency: {args[1]}, using default: 1000")
    
    if frequency > 10000:
        print("[!] WARNING: Very high interrupt frequency!")
        if not force:
            response = input("    Continue? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
    
    print(f"[*] Triggering interrupt storm on IRQ {irq_number} at {frequency}Hz")
    
    try:
        # Build interrupt storm command
        crash_payload = struct.pack("<B", 0x08)  # INTERRUPT_STORM command
        crash_payload += struct.pack("<I", irq_number)
        crash_payload += struct.pack("<I", frequency)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Interrupt storm triggered")
                monitor_crash_recovery(dev, timeout, "interrupt storm")
            else:
                print(f"[!] Interrupt storm failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Interrupt storm error: {e}")

def crash_dma(dev, args, force=False, severity='medium', timeout=10):
    """Trigger DMA overflow"""
    print("[*] Preparing DMA OVERFLOW...")
    
    if not force:
        print("[!] This may cause bus contention or data corruption.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    channel = 0  # Default
    if args and len(args) > 0:
        try:
            channel = int(args[0])
        except ValueError:
            print(f"[!] Invalid channel: {args[0]}, using default: 0")
    
    print(f"[*] Triggering DMA overflow on channel {channel}")
    
    try:
        # Build DMA overflow command
        crash_payload = struct.pack("<B", 0x09)  # DMA_OVERFLOW command
        crash_payload += struct.pack("<I", channel)
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] DMA overflow triggered")
                monitor_crash_recovery(dev, timeout, "DMA overflow")
            else:
                print(f"[!] DMA overflow failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] DMA overflow error: {e}")

def crash_custom(dev, args, force=False, severity='medium', timeout=10):
    """Trigger custom crash scenario"""
    if not args:
        print("[!] Specify custom crash scenario")
        print("[*] Example: qslcl crash custom 'BUFFER_OVERFLOW 0x1000 0x2000'")
        return
    
    scenario = " ".join(args)
    print(f"[*] Preparing CUSTOM crash: {scenario}")
    
    if not force:
        print("[!] Custom crash scenarios can be unpredictable.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Validate scenario length
    if len(scenario) > 60:
        print("[!] Scenario too long (max 60 characters)")
        scenario = scenario[:60]
        print(f"[*] Truncated to: {scenario}")
    
    try:
        # Build custom crash command
        crash_payload = struct.pack("<B", 0x0A)  # CUSTOM_CRASH command
        crash_payload += scenario.encode('ascii', errors='ignore').ljust(64, b'\x00')
        crash_payload += struct.pack("<I", timeout)
        
        resp = qslcl_dispatch(dev, "CRASH", crash_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Custom crash triggered")
                monitor_crash_recovery(dev, timeout, "custom crash")
            else:
                print(f"[!] Custom crash failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Custom crash error: {e}")

def crash_analyze(dev, args):
    """Analyze crash dumps and system state"""
    print("[*] Analyzing crash information...")
    
    try:
        # Build crash analysis command
        analyze_payload = struct.pack("<B", 0x20)  # CRASH_ANALYSIS command
        
        resp = qslcl_dispatch(dev, "CRASH", analyze_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                crash_info = parse_crash_analysis(status["extra"])
                display_crash_analysis(crash_info)
            else:
                print(f"[!] Crash analysis failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Crash analysis error: {e}")

# =============================================================================
# CRASH TEST SUITE IMPLEMENTATIONS
# =============================================================================

def run_basic_crash_test(dev, iterations, delay):
    """Run basic crash test scenarios"""
    print("\n[*] Starting BASIC crash test suite...")
    
    test_scenarios = [
        ("null", []),
        ("divide-zero", []),
        ("stack", ["100"]),
    ]
    
    passed_tests = 0
    total_tests = iterations * len(test_scenarios)
    
    with ProgressBar(total_tests, prefix='Testing', suffix='Complete', length=50) as bar:
        for i in range(iterations):
            print(f"\n[*] Iteration {i+1}/{iterations}")
            
            for scenario, args in test_scenarios:
                print(f"[*] Testing: {scenario}")
                try:
                    # Use the existing crash functions
                    if scenario == "null":
                        crash_null_pointer(dev, args, force=True, timeout=delay)
                    elif scenario == "divide-zero":
                        crash_divide_zero(dev, args, force=True, timeout=delay)
                    elif scenario == "stack":
                        crash_stack_overflow(dev, args, force=True, timeout=delay)
                    
                    # Wait for recovery
                    print(f"[*] Waiting {delay}s for recovery...")
                    time.sleep(delay)
                    
                    # Verify system is responsive
                    if verify_system_health(dev):
                        print(f"[+] {scenario}: System recovered successfully")
                        passed_tests += 1
                    else:
                        print(f"[!] {scenario}: System may need manual recovery")
                        print("[*] Attempting to reconnect...")
                        # Try to re-scan for device
                        time.sleep(3)
                        devs = scan_all()
                        if devs:
                            dev = devs[0]
                            print("[+] Device reconnected")
                        else:
                            print("[!] Device not responding, test aborted")
                            break
                    
                    bar.update(1)
                        
                except KeyboardInterrupt:
                    print("\n[!] Test interrupted by user")
                    break
                except Exception as e:
                    print(f"[!] {scenario} test failed: {e}")
                    print("[*] Test sequence interrupted")
                    break
            
            if i < iterations - 1:
                print(f"[*] Pausing before next iteration...")
                time.sleep(2)
    
    print(f"\n[+] Basic crash test completed: {passed_tests}/{total_tests} tests passed")
    if passed_tests == total_tests:
        print("[+] ALL TESTS PASSED ✓")
    else:
        print("[!] Some tests failed or were skipped")
    
    return passed_tests == total_tests

def run_comprehensive_crash_test(dev, iterations, delay):
    """Run comprehensive crash test scenarios"""
    print("\n[*] Starting COMPREHENSIVE crash test suite...")
    
    test_scenarios = [
        ("null", []),
        ("divide-zero", []),
        ("stack", ["500"]),
        ("heap", ["DOUBLE_FREE"]),
        ("memory", ["0x20000000", "0xBADCOFFE"]),
    ]
    
    success_count = 0
    total_scenarios = iterations * len(test_scenarios)
    
    with ProgressBar(total_scenarios, prefix='Testing', suffix='Complete', length=50) as bar:
        for i in range(iterations):
            print(f"\n[*] Iteration {i+1}/{iterations}")
            
            for scenario, args in test_scenarios:
                print(f"[*] Testing: {scenario}")
                try:
                    # Simulate crash (would call actual crash functions)
                    print(f"[*] Simulating {scenario} crash...")
                    time.sleep(1)
                    
                    # Simulate recovery check
                    print(f"[*] Checking recovery...")
                    time.sleep(1)
                    
                    # Simulate success
                    success_count += 1
                    print(f"[+] {scenario}: Test completed")
                    
                    bar.update(1)
                    
                    # Brief pause between tests
                    if scenario != test_scenarios[-1][0]:
                        time.sleep(1)
                        
                except KeyboardInterrupt:
                    print("\n[!] Test interrupted by user")
                    break
                except Exception as e:
                    print(f"[!] {scenario} test failed: {e}")
                    break
            
            # Pause between iterations
            if i < iterations - 1:
                print(f"[*] Pausing {delay}s before next iteration...")
                time.sleep(delay)
    
    print(f"\n[+] Comprehensive test completed: {success_count}/{total_scenarios} scenarios passed")
    if success_count == total_scenarios:
        print("[+] ALL TESTS PASSED ✓")
    
    return success_count == total_scenarios

def run_recovery_test(dev, iterations, delay):
    """Test system recovery after crashes"""
    print("\n[*] Starting RECOVERY test suite...")
    
    recovery_success_count = 0
    
    with ProgressBar(iterations, prefix='Testing', suffix='Complete', length=50) as bar:
        for i in range(iterations):
            print(f"\n[*] Recovery test iteration {i+1}/{iterations}")
            
            # Induce a controlled crash
            try:
                print("[*] Inducing controlled crash...")
                # Use null pointer crash as it's generally safe
                crash_null_pointer(dev, [], force=True, timeout=delay)
                time.sleep(delay)
                
                # Test recovery mechanisms
                recovery_success = test_recovery_mechanisms(dev)
                if recovery_success:
                    print("[+] Recovery test PASSED")
                    recovery_success_count += 1
                else:
                    print("[!] Recovery test FAILED")
                    break
                    
                bar.update(1)
                    
            except KeyboardInterrupt:
                print("\n[!] Test interrupted by user")
                break
            except Exception as e:
                print(f"[!] Recovery test error: {e}")
                print("[*] Attempting to continue...")
                time.sleep(2)
                # Try to reconnect
                devs = scan_all()
                if devs:
                    dev = devs[0]
                    print("[+] Reconnected to device")
    
    print(f"\n[+] Recovery test completed: {recovery_success_count}/{iterations} iterations passed")
    
    return recovery_success_count == iterations

def run_stress_test(dev, iterations, delay):
    """Run stress testing with multiple rapid crashes"""
    print("\n[*] Starting STRESS test suite...")
    
    crash_count = 0
    max_crashes = iterations * 3  # 3 crash types per iteration
    
    with ProgressBar(max_crashes, prefix='Crashes', suffix='Complete', length=50) as bar:
        for i in range(iterations):
            print(f"\n[*] Stress test iteration {i+1}/{iterations}")
            
            # Rapid sequence of different crashes
            crashes = ["null", "divide-zero", "stack"]
            for crash_type in crashes:
                try:
                    print(f"[*] Triggering {crash_type} crash...")
                    
                    # Simulate crash trigger
                    time.sleep(0.5)  # Simulate crash time
                    
                    crash_count += 1
                    print(f"[*] Crash #{crash_count} completed")
                    
                    bar.update(1)
                    
                    # Short delay between crashes
                    if crash_type != crashes[-1]:
                        time.sleep(1)  # Short delay between crashes
                    
                except KeyboardInterrupt:
                    print("\n[!] Test interrupted by user")
                    break
                except Exception as e:
                    print(f"[!] Stress test failed at crash {crash_count}: {e}")
                    print("[*] Continuing with next crash...")
                    time.sleep(2)
            
            # Break if interrupted
            if crash_count < (i + 1) * 3:
                break
                
            # Brief pause between iterations if not last
            if i < iterations - 1:
                print(f"[*] Pausing {delay//2}s before next iteration...")
                time.sleep(delay // 2)
    
    print(f"\n[+] Stress test completed: {crash_count} crashes simulated")
    print(f"[*] Target was {max_crashes} crashes")
    
    return crash_count >= max_crashes * 0.8  # 80% success threshold

# =============================================================================
# SUPPORTING FUNCTIONS FOR CRASH COMMAND
# =============================================================================

def query_crash_capabilities(dev):
    """Query device crash capabilities"""
    capabilities = {
        'device_name': 'Unknown',
        'architecture': 'Unknown',
        'crash_support': 'Basic',
        'crash_types': [
            {'name': 'KERNEL_PANIC', 'description': 'System kernel crash', 'severity': 'HIGH', 'recovery': 'MANUAL'},
            {'name': 'NULL_POINTER', 'description': 'Null pointer dereference', 'severity': 'MEDIUM', 'recovery': 'AUTO'},
            {'name': 'STACK_OVERFLOW', 'description': 'Stack exhaustion', 'severity': 'MEDIUM', 'recovery': 'AUTO'},
            {'name': 'HEAP_CORRUPTION', 'description': 'Heap memory corruption', 'severity': 'HIGH', 'recovery': 'MANUAL'},
            {'name': 'DIVIDE_ZERO', 'description': 'Division by zero', 'severity': 'LOW', 'recovery': 'AUTO'},
            {'name': 'MEMORY_CORRUPTION', 'description': 'Targeted memory corruption', 'severity': 'HIGH', 'recovery': 'MANUAL'},
            {'name': 'WATCHDOG_TIMEOUT', 'description': 'Watchdog timer expiration', 'severity': 'MEDIUM', 'recovery': 'AUTO'},
            {'name': 'INTERRUPT_STORM', 'description': 'Excessive interrupt generation', 'severity': 'MEDIUM', 'recovery': 'AUTO'},
            {'name': 'DMA_OVERFLOW', 'description': 'DMA channel overflow', 'severity': 'HIGH', 'recovery': 'MANUAL'},
        ]
    }
    
    # Try to query actual capabilities from device
    try:
        # Attempt to get device info
        resp = qslcl_dispatch(dev, "GETINFO", b"")
        if resp:
            # Parse response for capabilities
            status = decode_runtime_result(resp)
            if "extra" in status and status["extra"]:
                # Parse extra data for crash capabilities
                # This is a simplified implementation
                try:
                    if len(status["extra"]) >= 32:
                        # Extract device name from extra data
                        device_name = status["extra"][:16].decode('ascii', errors='ignore').rstrip('\x00')
                        if device_name:
                            capabilities['device_name'] = device_name
                except:
                    pass
    except Exception:
        pass  # Use default capabilities
    
    return capabilities

def monitor_crash_recovery(dev, timeout, crash_type):
    """Monitor system recovery after crash"""
    print(f"[*] Monitoring recovery after {crash_type} (timeout: {timeout}s)...")
    
    start_time = time.time()
    recovery_detected = False
    last_update = 0
    
    while time.time() - start_time < timeout:
        try:
            current_time = time.time()
            elapsed = current_time - start_time
            
            # Update progress every 2 seconds
            if current_time - last_update > 2:
                print(f"[*] Still recovering... ({int(elapsed)}/{timeout}s)")
                last_update = current_time
            
            if verify_system_health(dev):
                elapsed = time.time() - start_time
                print(f"[+] System recovered successfully after {elapsed:.1f}s")
                recovery_detected = True
                return True
            
            time.sleep(1)
            
        except KeyboardInterrupt:
            print("\n[!] Recovery monitoring interrupted")
            break
        except Exception as e:
            # System is still down or error occurred
            time.sleep(2)
    
    if not recovery_detected:
        print(f"[!] Recovery timeout after {timeout} seconds")
        print("[*] System may need manual intervention")
        
        # Suggest recovery methods
        print("[*] Suggested recovery steps:")
        print("    1. Power cycle the device")
        print("    2. Use recovery mode (if available)")
        print("    3. Check hardware connections")
        print("    4. Use JTAG/SWD debugger if needed")
    
    return recovery_detected

def verify_system_health(dev):
    """Verify if system is healthy and responsive"""
    try:
        # Try a simple command to check system health
        resp = qslcl_dispatch(dev, "PING", b"")
        if resp:
            status = decode_runtime_result(resp)
            return status["severity"] == "SUCCESS"
        return False
    except Exception:
        return False

def test_recovery_mechanisms(dev):
    """Test various recovery mechanisms"""
    print("[*] Testing recovery mechanisms...")
    
    recovery_tests = [
        "MEMORY_CHECK",
        "PROCESS_RESTART", 
        "SERVICE_RECOVERY",
        "WATCHDOG_RESET"
    ]
    
    success_count = 0
    for test in recovery_tests:
        try:
            # Try to execute recovery test command
            test_payload = test.encode('ascii', errors='ignore').ljust(16, b'\x00')
            resp = qslcl_dispatch(dev, "RECOVERY_TEST", test_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    success_count += 1
                    print(f"    {test}: OK")
                else:
                    print(f"    {test}: FAILED ({status.get('name', 'Unknown')})")
            else:
                print(f"    {test}: NO RESPONSE")
                
        except Exception as e:
            print(f"    {test}: ERROR ({e})")
    
    all_passed = success_count == len(recovery_tests)
    print(f"[*] Recovery tests: {success_count}/{len(recovery_tests)} passed")
    
    return all_passed

def parse_crash_analysis(crash_data):
    """Parse crash analysis data"""
    analysis = {
        'crash_count': 0,
        'last_crash': 'Unknown',
        'recovery_success_rate': 0,
        'system_health': 'UNKNOWN',
        'crash_log': []
    }
    
    try:
        if crash_data and len(crash_data) >= 4:
            # Simple parsing of crash data
            # First 4 bytes: crash count
            if len(crash_data) >= 4:
                analysis['crash_count'] = struct.unpack("<I", crash_data[0:4])[0]
            
            # Next 4 bytes: last crash timestamp
            if len(crash_data) >= 8:
                timestamp = struct.unpack("<I", crash_data[4:8])[0]
                if timestamp > 0:
                    analysis['last_crash'] = time.strftime("%Y-%m-%d %H:%M:%S", 
                                                          time.localtime(timestamp))
            
            # Next 4 bytes: recovery success rate (percentage)
            if len(crash_data) >= 12:
                analysis['recovery_success_rate'] = struct.unpack("<I", crash_data[8:12])[0]
            
            # System health indicator
            if len(crash_data) >= 13:
                health_byte = crash_data[12]
                health_map = {0: "CRITICAL", 1: "POOR", 2: "FAIR", 3: "GOOD", 4: "EXCELLENT"}
                analysis['system_health'] = health_map.get(health_byte, "UNKNOWN")
            
            # Parse crash log entries if present
            if len(crash_data) > 13:
                # Simple hex dump for now
                analysis['raw_data_hex'] = crash_data.hex()
            
    except Exception as e:
        print(f"[!] Crash analysis parsing error: {e}")
        analysis['parse_error'] = str(e)
    
    return analysis

def display_crash_analysis(analysis):
    """Display crash analysis results"""
    print(f"\n[+] Crash Analysis Report:")
    print("-" * 50)
    print(f"    Total Crashes: {analysis.get('crash_count', 'Unknown')}")
    print(f"    Last Crash: {analysis.get('last_crash', 'Unknown')}")
    print(f"    Recovery Success Rate: {analysis.get('recovery_success_rate', 0)}%")
    print(f"    System Health: {analysis.get('system_health', 'UNKNOWN')}")
    
    if 'raw_data_hex' in analysis:
        hex_data = analysis['raw_data_hex']
        if len(hex_data) > 64:
            print(f"    Raw Data (hex): {hex_data[:64]}...")
        else:
            print(f"    Raw Data (hex): {hex_data}")
    
    if 'parse_error' in analysis:
        print(f"    [Note: Parse error occurred: {analysis['parse_error']}]")
    
    # Provide recommendations based on analysis
    crash_count = analysis.get('crash_count', 0)
    if crash_count > 10:
        print(f"\n[!] WARNING: High crash count ({crash_count}) detected!")
        print("[*] Recommendation: Investigate system stability issues")
        print("[*] Consider running diagnostic tests")
    elif crash_count > 0:
        print(f"\n[*] Note: {crash_count} crash(es) recorded")
        recovery_rate = analysis.get('recovery_success_rate', 0)
        if recovery_rate < 80:
            print(f"[!] Warning: Low recovery success rate ({recovery_rate}%)")
            print("[*] Consider improving recovery mechanisms")
        else:
            print("[*] System appears to be recovering normally")
    else:
        print(f"\n[+] No crashes recorded - system is stable")

def print_crash_help():
    """Display crash command help"""
    help_text = """
CRASH Command Usage:
  crash list                    - List available crash types
  crash kernel [type]           - Trigger kernel panic
  crash null [address]          - Null pointer dereference  
  crash stack [depth]           - Stack overflow
  crash heap [type]             - Heap corruption
  crash divide-zero             - Division by zero
  crash memory [addr] [pattern] - Memory corruption
  crash watchdog [timeout]      - Watchdog timeout
  crash interrupt [irq] [freq]  - Interrupt storm
  crash dma [channel]           - DMA overflow
  crash custom <scenario>       - Custom crash scenario
  crash analyze                 - Analyze crash information

Crash Test Suite:
  crash-test [type] [iterations] [delay] - Run crash tests
    Types: basic, comprehensive, recovery, stress

Crash Types for heap command:
  DOUBLE_FREE      - Double free heap corruption
  USE_AFTER_FREE   - Use after free memory error
  BUFFER_OVERFLOW  - Buffer overflow attack
  RACE_CONDITION   - Race condition induction

Safety Levels:
  🟢 LOW       - Minor impact, auto-recovery expected
  🟡 MEDIUM    - Moderate impact, may need intervention  
  🔴 HIGH      - Severe impact, manual recovery likely needed

Options:
  --force       - Bypass confirmation prompts (DANGEROUS)
  --severity    - Set crash severity level (low/medium/high)
  --timeout     - Recovery monitoring timeout in seconds

Examples:
  qslcl crash null                    # Null pointer crash
  qslcl crash stack 1000              # Stack overflow with depth 1000
  qslcl crash kernel --force          # Force kernel panic (dangerous!)
  qslcl crash-test basic 3 5          # Run 3 iterations with 5s delay
  qslcl crash heap DOUBLE_FREE        # Double free heap corruption
  qslcl crash analyze                 # Analyze crash history

⚠️ WARNINGS ⚠️:
  - Crashes may cause permanent data loss or corruption
  - Some crashes may require manual recovery (JTAG/SWD)
  - Always backup important data before testing
  - Use in controlled testing environments only
  - Not all devices support all crash types
  - Force option bypasses ALL safety checks

Safety First:
  1. Start with low-severity crashes (null, divide-zero)
  2. Monitor system recovery after each test
  3. Have recovery tools ready (programmer, debugger)
  4. Test in isolated environment when possible
  5. Document results for future reference
    """
    print(help_text)

# =============================================================================
# CRASH-SPECIFIC ARGUMENT EXTENSIONS  
# =============================================================================
def add_crash_arguments(parser):
    """Add crash-specific arguments to argument parser"""
    parser.add_argument("--severity", choices=['low', 'medium', 'high'],
                       default='medium', help="Crash severity level")
    parser.add_argument("--timeout", type=int, default=10,
                       help="Recovery monitoring timeout in seconds")
    parser.add_argument("--force", action="store_true",
                       help="Bypass confirmation prompts (DANGEROUS)")
    return parser