def cmd_write(args=None):
    """
    Fully implemented WRITE command with advanced features:
    - Multiple data source types (file, hex string, patterns)
    - Partition and address targeting
    - Smart data validation
    - Progress tracking with verification
    - Safety checks and confirmation
    - Error recovery and resume support
    """
    if not args:
        print("[!] WRITE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    target = getattr(args, 'target', '')
    data_source = getattr(args, 'data', '')
    chunk_size = getattr(args, 'chunk_size', 65536)
    max_file_size = getattr(args, 'max_file_size', 1073741824)  # 1GB default
    no_verify = getattr(args, 'no_verify', False)
    force = getattr(args, 'force', False)

    if not target:
        print("[!] WRITE: No target specified")
        return

    if not data_source:
        print("[!] WRITE: No data source specified")
        return

    print(f"[*] WRITE command: target={target}, data={data_source}")

    # =========================================================================
    # 1. TARGET RESOLUTION
    # =========================================================================
    address = 0
    target_size = 0
    partition_info = None
    partitions = load_partitions(dev)

    # Parse target (partition or address)
    if '+' in target:
        # Partition+offset format
        part_name, offset_str = target.split('+', 1)
        for part in partitions:
            if part['name'].lower() == part_name.lower():
                offset = parse_address(offset_str)
                address = part['offset'] + offset
                partition_info = part
                target_size = part['size'] - offset
                print(f"[+] Target: {part_name}+{offset_str} = 0x{address:08X}")
                break
        if not partition_info:
            print(f"[!] Unknown partition: {part_name}")
            return
    else:
        # Check if target is a partition name
        for part in partitions:
            if part['name'].lower() == target.lower():
                partition_info = part
                address = part['offset']
                target_size = part['size']
                print(f"[+] Target is partition: {part['name']} (0x{address:08X}, size: 0x{target_size:08X})")
                break
        
        # If not a partition, parse as raw address
        if not partition_info:
            try:
                address = parse_address(target)
                print(f"[+] Target address: 0x{address:08X}")
                # For raw addresses, we'll determine size from data
            except ValueError as e:
                print(f"[!] Invalid target format: {target} - {e}")
                return

    # =========================================================================
    # 2. DATA SOURCE PROCESSING
    # =========================================================================
    write_data = b""
    data_size = 0
    source_type = "unknown"

    try:
        # Check if data source is a file
        if os.path.exists(data_source):
            source_type = "file"
            file_size = os.path.getsize(data_source)
            
            if file_size > max_file_size:
                print(f"[!] File too large: {file_size} > {max_file_size}")
                if not force:
                    return
            
            with open(data_source, 'rb') as f:
                write_data = f.read()
            data_size = len(write_data)
            print(f"[+] Reading from file: {data_source} ({data_size} bytes)")
            print(f"[+] File SHA256: {hashlib.sha256(write_data).hexdigest()}")

        # Check if it's a hex string
        elif re.match(r'^[0-9A-Fa-f]+$', data_source.replace(' ', '').replace(':', '')):
            source_type = "hex"
            write_data = bytes.fromhex(data_source.replace(' ', '').replace(':', ''))
            data_size = len(write_data)
            print(f"[+] Processing hex data: {data_size} bytes")

        # Check for pattern syntax (e.g., "00FF*100" or "FF:4096")
        elif '*' in data_source or ':' in data_source:
            source_type = "pattern"
            write_data = parse_pattern_data(data_source)
            data_size = len(write_data)
            print(f"[+] Generated pattern data: {data_size} bytes")

        # Check for special commands
        elif data_source.lower() in ['zero', 'zeros', '00']:
            source_type = "pattern"
            if target_size > 0:
                write_data = b'\x00' * target_size
                data_size = target_size
                print(f"[+] Generating zeros: {data_size} bytes")
            else:
                print("[!] Cannot determine size for zero fill on raw address")
                return

        elif data_source.lower() in ['ff', 'ones', 'erase']:
            source_type = "pattern"
            if target_size > 0:
                write_data = b'\xFF' * target_size
                data_size = target_size
                print(f"[+] Generating ones: {data_size} bytes")
            else:
                print("[!] Cannot determine size for ones fill on raw address")
                return

        else:
            # Treat as literal string
            source_type = "string"
            write_data = data_source.encode('utf-8')
            data_size = len(write_data)
            print(f"[+] Using string data: {data_size} bytes")

    except Exception as e:
        print(f"[!] Data processing failed: {e}")
        return

    if data_size == 0:
        print("[!] No data to write")
        return

    # =========================================================================
    # 3. SAFETY CHECKS AND CONFIRMATION
    # =========================================================================
    if partition_info:
        # Check if write fits in partition
        if data_size > target_size:
            print(f"[!] Data too large for partition: {data_size} > {target_size}")
            if not force:
                return
            else:
                print("[!] Force mode: truncating data to partition size")
                write_data = write_data[:target_size]
                data_size = target_size

        # Warn about critical partitions
        critical_partitions = ['boot', 'recovery', 'system', 'bootloader', 'aboot']
        if partition_info['name'].lower() in critical_partitions and not force:
            print(f"[!] WARNING: Writing to critical partition: {partition_info['name']}")
            print(f"[!] This may brick your device!")
            response = input("    Type 'YES' to continue: ")
            if response != 'YES':
                print("[*] Operation cancelled")
                return

    # Show write summary
    print(f"\n[*] WRITE SUMMARY:")
    print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
    print(f"    Data size: 0x{data_size:08X} ({data_size} bytes)")
    print(f"    Source: {source_type}")
    print(f"    Chunk size: 0x{chunk_size:08X}")

    if not force:
        response = input("\n[*] Confirm write operation? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return

    # =========================================================================
    # 4. WRITE OPERATION
    # =========================================================================
    print(f"\n[*] Writing {data_size} bytes to 0x{address:08X}...")
    
    bytes_written = 0
    retry_count = 0
    max_retries = 3
    failed_chunks = []

    try:
        with ProgressBar(data_size, prefix='Writing', suffix='Complete', length=50) as progress:
            while bytes_written < data_size:
                chunk_addr = address + bytes_written
                remaining = data_size - bytes_written
                current_chunk_size = min(chunk_size, remaining)
                chunk_data = write_data[bytes_written:bytes_written + current_chunk_size]
                
                try:
                    # Build WRITE command packet
                    write_header = struct.pack("<II", chunk_addr, current_chunk_size)
                    write_payload = write_header + chunk_data
                    
                    if "WRITE" in QSLCLPAR_DB:
                        resp = qslcl_dispatch(dev, "WRITE", write_payload)
                    else:
                        # Fallback to generic write
                        cmd = f"WRITE 0x{chunk_addr:08X} 0x{current_chunk_size:04X}"
                        full_payload = cmd.encode() + b' ' + chunk_data
                        resp = qslcl_dispatch(dev, "WRITE", full_payload)
                    
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            bytes_written += current_chunk_size
                            progress.update(current_chunk_size)
                            retry_count = 0  # Reset retry counter
                        else:
                            print(f"\n[!] Write error at 0x{chunk_addr:08X}: {status}")
                            failed_chunks.append((chunk_addr, current_chunk_size))
                            retry_count += 1
                    else:
                        print(f"\n[!] No response at 0x{chunk_addr:08X}")
                        failed_chunks.append((chunk_addr, current_chunk_size))
                        retry_count += 1
                    
                    # Handle retries
                    if retry_count >= max_retries:
                        print(f"[!] Max retries exceeded at 0x{chunk_addr:08X}")
                        break
                        
                except Exception as e:
                    print(f"\n[!] Write exception at 0x{chunk_addr:08X}: {e}")
                    failed_chunks.append((chunk_addr, current_chunk_size))
                    retry_count += 1
                    if retry_count >= max_retries:
                        break
                    time.sleep(0.1)  # Brief pause before retry

        # =========================================================================
        # 5. RETRY FAILED CHUNKS
        # =========================================================================
        if failed_chunks and not no_verify:
            print(f"\n[*] Retrying {len(failed_chunks)} failed chunks...")
            for chunk_addr, chunk_size in failed_chunks[:]:  # Copy list for modification
                retry_success = False
                for attempt in range(max_retries):
                    try:
                        chunk_data = write_data[chunk_addr-address:chunk_addr-address + chunk_size]
                        write_header = struct.pack("<II", chunk_addr, chunk_size)
                        write_payload = write_header + chunk_data
                        
                        resp = qslcl_dispatch(dev, "WRITE", write_payload)
                        if resp and decode_runtime_result(resp)["severity"] == "SUCCESS":
                            bytes_written += chunk_size
                            failed_chunks.remove((chunk_addr, chunk_size))
                            retry_success = True
                            print(f"[+] Retry successful for 0x{chunk_addr:08X}")
                            break
                    except Exception as e:
                        print(f"[!] Retry failed for 0x{chunk_addr:08X}: {e}")
                
                if not retry_success:
                    print(f"[!] Permanent failure at 0x{chunk_addr:08X}")

        # =========================================================================
        # 6. VERIFICATION (if enabled)
        # =========================================================================
        if not no_verify and bytes_written > 0:
            print("\n[*] Verifying write operation...")
            verify_success = True
            
            with ProgressBar(bytes_written, prefix='Verify', suffix='Complete', length=50) as progress:
                verify_addr = address
                remaining_verify = bytes_written
                
                while remaining_verify > 0:
                    verify_chunk_size = min(chunk_size, remaining_verify)
                    
                    # Read back for verification
                    read_payload = struct.pack("<II", verify_addr, verify_chunk_size)
                    resp = qslcl_dispatch(dev, "READ", read_payload)
                    
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            read_data = status["extra"]
                            expected_data = write_data[verify_addr-address:verify_addr-address + verify_chunk_size]
                            
                            if read_data == expected_data:
                                progress.update(verify_chunk_size)
                            else:
                                print(f"\n[!] Verify failed at 0x{verify_addr:08X}")
                                verify_success = False
                                break
                        else:
                            print(f"\n[!] Verify read failed at 0x{verify_addr:08X}: {status}")
                            verify_success = False
                            break
                    else:
                        print(f"\n[!] No verify response at 0x{verify_addr:08X}")
                        verify_success = False
                        break
                    
                    verify_addr += verify_chunk_size
                    remaining_verify -= verify_chunk_size

            if verify_success:
                print("\n[+] Verification passed!")
            else:
                print("\n[!] Verification failed!")

        # =========================================================================
        # 7. FINAL SUMMARY
        # =========================================================================
        print(f"\n[+] WRITE operation completed!")
        print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
        print(f"    Data size: 0x{data_size:08X} ({data_size} bytes)")
        print(f"    Written: 0x{bytes_written:08X} ({bytes_written} bytes)")
        print(f"    Success rate: {bytes_written/data_size*100:.1f}%")
        
        if failed_chunks:
            print(f"    Failed chunks: {len(failed_chunks)}")
            for chunk_addr, chunk_size in failed_chunks:
                print(f"      - 0x{chunk_addr:08X} (0x{chunk_size:04X} bytes)")

        if source_type == "file":
            print(f"    Source file: {data_source}")
            print(f"    Source SHA256: {hashlib.sha256(write_data).hexdigest()}")

    except Exception as e:
        print(f"[!] WRITE operation failed: {e}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR WRITE COMMAND
# =============================================================================

def parse_pattern_data(pattern_str):
    """
    Parse pattern data strings:
    - "00FF*100" = 100 repetitions of 0x00FF
    - "FF:4096" = 4096 bytes of 0xFF
    - "AABBCC" = literal hex data
    - "1234*8" = 8 repetitions of 0x1234
    """
    pattern_str = pattern_str.strip()
    
    # Pattern with repetition: "DATA*COUNT"
    if '*' in pattern_str:
        data_part, count_part = pattern_str.split('*', 1)
        try:
            # Parse hex data
            if ':' in data_part:
                # Fill pattern: "VALUE:SIZE"
                value_str, size_str = data_part.split(':', 1)
                value_byte = int(value_str, 16) & 0xFF
                size = int(size_str)
                count = int(count_part)
                return bytes([value_byte] * size * count)
            else:
                # Hex pattern repetition: "AABB*10"
                data_bytes = bytes.fromhex(data_part)
                count = int(count_part)
                return data_bytes * count
        except ValueError as e:
            print(f"[!] Invalid pattern format: {pattern_str} - {e}")
            return b""

    # Fill pattern: "VALUE:SIZE"
    elif ':' in pattern_str:
        value_str, size_str = pattern_str.split(':', 1)
        try:
            value_byte = int(value_str, 16) & 0xFF
            size = int(size_str)
            return bytes([value_byte] * size)
        except ValueError as e:
            print(f"[!] Invalid fill pattern: {pattern_str} - {e}")
            return b""

    # Simple hex string
    else:
        try:
            return bytes.fromhex(pattern_str)
        except ValueError:
            print(f"[!] Invalid hex data: {pattern_str}")
            return b""