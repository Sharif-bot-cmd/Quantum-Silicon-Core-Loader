from typing import Dict, List, Tuple, Optional, Any, Union
import os
import struct
import time
import hashlib
import re
import traceback

# =============================================================================
# PATTERN DATA PARSER - MOVED TO TOP TO AVOID CIRCULAR IMPORTS
# =============================================================================
def parse_pattern_data(pattern_str: str) -> bytes:
    """
    Parse pattern data strings:
    - "00FF*100" = 100 repetitions of 0x00FF
    - "FF:4096" = 4096 bytes of 0xFF
    - "AABBCC" = literal hex data
    - "1234*8" = 8 repetitions of 0x1234
    """
    pattern_str = pattern_str.strip()
    
    # Pattern with repetition: "DATA*COUNT"
    if '*' in pattern_str:
        data_part, count_part = pattern_str.split('*', 1)
        try:
            # Parse hex data
            if ':' in data_part:
                # Fill pattern: "VALUE:SIZE"
                value_str, size_str = data_part.split(':', 1)
                value_byte = int(value_str, 16) & 0xFF
                size = int(size_str)
                count = int(count_part)
                return bytes([value_byte] * size * count)
            else:
                # Hex pattern repetition: "AABB*10"
                data_bytes = bytes.fromhex(data_part)
                count = int(count_part)
                return data_bytes * count
        except ValueError as e:
            print(f"[!] Invalid pattern format: {pattern_str} - {e}")
            return b""

    # Fill pattern: "VALUE:SIZE"
    elif ':' in pattern_str:
        value_str, size_str = pattern_str.split(':', 1)
        try:
            value_byte = int(value_str, 16) & 0xFF
            size = int(size_str)
            return bytes([value_byte] * size)
        except ValueError as e:
            print(f"[!] Invalid fill pattern: {pattern_str} - {e}")
            return b""

    # Simple hex string
    else:
        try:
            return bytes.fromhex(pattern_str)
        except ValueError:
            print(f"[!] Invalid hex data: {pattern_str}")
            return b""

# =============================================================================
# LOCAL PROGRESS BAR (FALLBACK)
# =============================================================================
class ProgressBarLocal:
    def __init__(self, total, prefix='', suffix='', decimals=1, length=50, fill='█'):
        self.total = total
        self.prefix = prefix
        self.suffix = suffix
        self.decimals = decimals
        self.length = length
        self.fill = fill
        self.current = 0
        
    def __enter__(self):
        self.update(0)
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        print()
        
    def update(self, progress):
        if self.total <= 0:
            return
        self.current += progress
        percent = ("{0:." + str(self.decimals) + "f}").format(100 * (self.current / float(self.total)))
        filled_length = int(self.length * self.current // self.total)
        bar = self.fill * filled_length + '-' * (self.length - filled_length)
        print(f'\r{self.prefix} |{bar}| {percent}% {self.suffix}', end='', flush=True)
        if self.current >= self.total:
            print()

# =============================================================================
# PROTECTION SYSTEM FOR WRITE OPERATIONS
# =============================================================================

class WriteProtectionManager:
    """Manages write protection checks and safety verification"""
    
    def __init__(self):
        self.protected_regions = []
        self.load_common_protected_regions()
        self.critical_partitions = ['boot', 'recovery', 'bootloader', 'aboot', 'sbl', 'sbl1', 'xbl', 
                                    'preloader', 'brom', 'llb', 'iboot', 'pbl', 'sbl2', 'rpm']
        self.critical_address_ranges = [
            (0x00000000, 0x00010000, "BootROM/Vector Table - BRICK RISK"),
            (0x00001000, 0x00004000, "LLB/Low-Level Bootloader"),
            (0x00004000, 0x00008000, "iBoot/SBL Region"),
            (0x00010000, 0x00020000, "Secondary Bootloader"),
        ]
    
    def load_common_protected_regions(self):
        """Load database of protected regions"""
        self.protected_regions = [
            # CRITICAL - Absolute NO-GO zones
            {"name": "BOOTROM", "start": 0x00000000, "end": 0x00010000, 
             "reason": "BootROM - PERMANENT BRICK", "severity": "CRITICAL"},
            {"name": "IROM", "start": 0x00000000, "end": 0x00008000, 
             "reason": "Internal ROM - PERMANENT BRICK", "severity": "CRITICAL"},
            {"name": "IVT", "start": 0x00000000, "end": 0x00000400, 
             "reason": "Interrupt Vector Table", "severity": "CRITICAL"},
            {"name": "RESET_VECTOR", "start": 0x00000000, "end": 0x00000020, 
             "reason": "Reset vector", "severity": "CRITICAL"},
            
            # HIGH RISK
            {"name": "NOR_BOOT", "start": 0x00000000, "end": 0x00020000, 
             "reason": "NOR boot sector", "severity": "HIGH"},
            {"name": "PBL", "start": 0x00000000, "end": 0x00004000, 
             "reason": "Primary Boot Loader", "severity": "HIGH"},
            {"name": "SBL1", "start": 0x00004000, "end": 0x00020000, 
             "reason": "Secondary Bootloader 1", "severity": "HIGH"},
        ]
    
    def is_address_protected(self, address, size=1):
        """Check if address range overlaps any protected region"""
        end_addr = address + size
        
        for region in self.protected_regions:
            if (address < region["end"] and end_addr > region["start"]):
                return {
                    "protected": True,
                    "region": region["name"],
                    "reason": region["reason"],
                    "severity": region["severity"],
                    "overlap_start": max(address, region["start"]),
                    "overlap_end": min(end_addr, region["end"])
                }
        
        # Check critical address ranges
        for start, end, reason in self.critical_address_ranges:
            if address < end and end_addr > start:
                return {
                    "protected": True,
                    "region": "CRITICAL_RANGE",
                    "reason": reason,
                    "severity": "CRITICAL",
                    "overlap_start": max(address, start),
                    "overlap_end": min(end_addr, end)
                }
        
        return {"protected": False}
    
    def is_critical_partition(self, partition_name):
        """Check if partition is critical (high brick risk)"""
        return partition_name.lower() in self.critical_partitions
    
    def get_partition_risk_level(self, partition_name):
        """Get risk level for a partition"""
        name_lower = partition_name.lower()
        
        if name_lower in ['bootrom', 'brom', 'irom']:
            return "CRITICAL", "BootROM modification - WILL BRICK DEVICE"
        elif name_lower in ['pbl', 'sbl', 'sbl1', 'aboot', 'xbl']:
            return "CRITICAL", "Primary bootloader modification - HIGH BRICK RISK"
        elif name_lower in ['boot', 'recovery']:
            return "HIGH", "Boot partition modification - May cause boot failure"
        elif name_lower in ['system', 'vendor']:
            return "MEDIUM", "System partition modification - May require reflash"
        else:
            return "LOW", "Standard partition - Lower risk"
    
    def check_alignment(self, address, sector_size, force=False):
        """Check if address is properly aligned"""
        if address % sector_size != 0:
            return {
                "aligned": False,
                "message": f"Unaligned write at 0x{address:X} (sector size {sector_size})",
                "suggested": address - (address % sector_size)
            }
        return {"aligned": True}

# =============================================================================
# WRITE SAFETY FUNCTIONS
# =============================================================================

def check_write_safety(dev, address, size, force=False, protection_manager=None):
    """
    Comprehensive write safety check for protected regions
    Returns (is_safe, warning_message, protection_info)
    """
    if protection_manager is None:
        protection_manager = WriteProtectionManager()
    
    # Step 1: Check protected region database
    protection = protection_manager.is_address_protected(address, size)
    
    if protection["protected"]:
        if protection["severity"] == "CRITICAL":
            return False, f"🚫 CRITICAL: {protection['region']} - {protection['reason']}", protection
        elif not force:
            return False, f"⚠️  Protected: {protection['region']} - {protection['reason']}", protection
        else:
            print(f"[!!!] FORCE ENABLED: Writing to {protection['region']} anyway!")
            return True, f"⚠️ FORCED write to {protection['region']}", protection
    
    # Step 2: Check if we have partition info
    if hasattr(dev, '_current_partition') and dev._current_partition:
        risk_level, risk_reason = protection_manager.get_partition_risk_level(dev._current_partition)
        
        if risk_level == "CRITICAL" and not force:
            return False, f"🚫 {risk_reason}", {"severity": risk_level, "reason": risk_reason}
        elif risk_level == "HIGH" and not force:
            print(f"[!] {risk_reason}")
            return True, f"⚠️ {risk_reason}", {"severity": risk_level, "reason": risk_reason}
    
    # Step 3: Check alignment if sector size known
    try:
        from qslcl import get_sector_size
        sector_size = get_sector_size(dev)
        alignment_check = protection_manager.check_alignment(address, sector_size, force)
        
        if not alignment_check["aligned"] and not force:
            return False, alignment_check["message"], alignment_check
    except:
        pass  # Skip alignment check if can't get sector size
    
    return True, "✓ Safe to write", None

def test_write_verify_readonly(dev, address):
    """
    Test if a region is actually writable by attempting a small write and verify
    Returns True if region is writable, False if read-only
    """
    try:
        # Try to import qslcl functions
        from qslcl import qslcl_dispatch, decode_runtime_result
        
        # Save original value
        read_payload = struct.pack("<II", address, 4)
        original_resp = qslcl_dispatch(dev, "READ", read_payload)
        
        if not original_resp:
            return False
        
        # Try to decode response
        if hasattr(decode_runtime_result, '__call__'):
            original_status = decode_runtime_result(original_resp)
            if len(original_status.get("extra", b"")) < 4:
                return False
            original = original_status["extra"][:4]
        else:
            if len(original_resp) < 4:
                return False
            original = original_resp[:4]
        
        # Generate test pattern (different from original)
        test_value = struct.unpack("<I", original)[0] ^ 0xFFFFFFFF
        test_pattern = struct.pack("<I", test_value)
        
        # Attempt write
        write_payload = struct.pack("<II", address, 4) + test_pattern
        write_resp = qslcl_dispatch(dev, "WRITE", write_payload)
        
        # Read back
        read_back_resp = qslcl_dispatch(dev, "READ", read_payload)
        
        # Restore original
        restore_payload = struct.pack("<II", address, 4) + original
        qslcl_dispatch(dev, "WRITE", restore_payload)
        
        # Check if write succeeded
        if read_back_resp:
            if hasattr(decode_runtime_result, '__call__'):
                read_back_status = decode_runtime_result(read_back_resp)
                read_back_data = read_back_status.get("extra", b"")[:4]
            else:
                read_back_data = read_back_resp[:4]
            
            if read_back_data == test_pattern:
                return True  # Writable
            else:
                return False  # Read-only
        
        return False
        
    except Exception as e:
        print(f"[!] Write test failed: {e}")
        return False

def display_protection_warning(protection_info, force=False):
    """Display formatted protection warning"""
    if not protection_info or not protection_info.get("protected", False):
        return
    
    severity = protection_info.get("severity", "UNKNOWN")
    region = protection_info.get("region", "Unknown")
    reason = protection_info.get("reason", "No reason provided")
    
    if severity == "CRITICAL":
        print("\n" + "=" * 70)
        print(f"💀💀💀 CRITICAL PROTECTION VIOLATION DETECTED 💀💀💀")
        print("=" * 70)
        print(f"Region: {region}")
        print(f"Reason: {reason}")
        print(f"Overlap: 0x{protection_info.get('overlap_start', 0):08X} - 0x{protection_info.get('overlap_end', 0):08X}")
        print("=" * 70)
        if not force:
            print("⚠️  This operation has been BLOCKED to prevent permanent device damage.")
        else:
            print("⚠️  FORCE MODE ACTIVE - Proceeding with EXTREME CAUTION!")
        print("=" * 70 + "\n")
    elif severity == "HIGH":
        print("\n" + "-" * 50)
        print(f"⚠️  HIGH RISK: {region}")
        print(f"   {reason}")
        print("-" * 50 + "\n")

# =============================================================================
# HELPER FUNCTIONS FOR LOCAL USE
# =============================================================================
def parse_address_local(addr_str: str) -> int:
    """
    Local implementation of parse_address to avoid import issues
    """
    addr_str = str(addr_str).strip().lower()
    
    # Remove whitespace
    addr_str = ''.join(addr_str.split())
    
    # Handle common formats
    if addr_str.startswith('0x'):
        return int(addr_str[2:], 16)
    elif addr_str.startswith('$'):
        return int(addr_str[1:], 16)
    elif addr_str.startswith('&h'):
        return int(addr_str[2:], 16)
    elif ':' in addr_str:  # Segment:offset format
        segment, offset = addr_str.split(':', 1)
        return (int(segment, 16) << 4) + int(offset, 16)
    else:
        # Try decimal, then hex
        try:
            return int(addr_str)
        except ValueError:
            return int(addr_str, 16)

def legacy_target_resolution(target: str, partitions: list) -> Tuple[int, int, Optional[dict]]:
    """
    Legacy target resolution for when resolve_target is not available
    """
    address = 0
    target_size = 0
    partition_info = None

    # Parse target (partition or address)
    if '+' in target:
        # Partition+offset format
        part_name, offset_str = target.split('+', 1)
        for part in partitions:
            if part['name'].lower() == part_name.lower():
                offset = parse_address_local(offset_str)
                address = part['offset'] + offset
                partition_info = part
                target_size = part['size'] - offset
                print(f"[+] Target: {part_name}+{offset_str} = 0x{address:08X}")
                break
        if not partition_info:
            print(f"[!] Unknown partition: {part_name}")
            return 0, 0, None
    else:
        # Check if target is a partition name
        for part in partitions:
            if part['name'].lower() == target.lower():
                partition_info = part
                address = part['offset']
                target_size = part['size']
                print(f"[+] Target is partition: {part['name']} (0x{address:08X}, size: 0x{target_size:08X})")
                break
        
        # If not a partition, parse as raw address
        if not partition_info:
            try:
                address = parse_address_local(target)
                target_size = 0x1000  # Default size for raw addresses
                print(f"[+] Target address: 0x{address:08X} (default size: 0x{target_size:08X})")
            except ValueError as e:
                print(f"[!] Invalid target format: {target} - {e}")
                return 0, 0, None

    return address, target_size, partition_info

# =============================================================================
# MAIN WRITE COMMAND FUNCTION - WITH PROTECTION LAYER
# =============================================================================
def cmd_write(args=None):
    """
    Fully implemented WRITE command with advanced protection features:
    - Multiple data source types (file, hex string, patterns)
    - Partition and address targeting
    - Smart data validation
    - Progress tracking with verification
    - Safety checks and confirmation
    - COMPREHENSIVE PROTECTION AGAINST BRICKING
    - Protected region detection
    - Read-only memory verification
    - Error recovery and resume support
    
    UPDATED to match qslcl.py v1.2.5 expectations with protection layer
    """

    if not args:
        print("[!] WRITE: No arguments provided")
        return 1

    # Try to import qslcl functions
    global use_qslcl_functions, scan_all, load_partitions, detect_memory_regions
    global resolve_target, auto_loader_if_needed, qslcl_dispatch, decode_runtime_result
    global ProgressBar, QSLCLCMD_DB
    
    use_qslcl_functions = False
    try:
        from qslcl import (scan_all, load_partitions, detect_memory_regions, 
                          resolve_target, auto_loader_if_needed, qslcl_dispatch, 
                          decode_runtime_result, ProgressBar, QSLCLCMD_DB)
        use_qslcl_functions = True
    except ImportError:
        print("[!] Running in standalone mode (some features limited)")
        
        # Define dummy functions for standalone mode
        def scan_all():
            return []
        def load_partitions(dev):
            return []
        def detect_memory_regions(dev):
            return []
        def auto_loader_if_needed(args, dev):
            pass
        def qslcl_dispatch(dev, cmd, payload):
            return None
        def decode_runtime_result(resp):
            return {"severity": "UNKNOWN", "extra": b""}
        ProgressBar = ProgressBarLocal
        QSLCLCMD_DB = {}

    # Get device
    devs = scan_all()
    
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    
    # Auto-load loader if specified
    if use_qslcl_functions and hasattr(args, 'loader') and args.loader:
        auto_loader_if_needed(args, dev)

    # Parse arguments
    target = getattr(args, 'target', '')
    data_source = getattr(args, 'data', '')
    chunk_size = getattr(args, 'chunk_size', 65536)
    max_file_size = getattr(args, 'max_file_size', 1073741824)  # 1GB default
    no_verify = getattr(args, 'no_verify', False)
    force = getattr(args, 'force', False)
    
    # New protection-related arguments
    protection_level = getattr(args, 'protection', 'normal')
    skip_protection_checks = getattr(args, 'no_protection_checks', False)
    test_readonly = getattr(args, 'test_readonly', False)

    if not target:
        print("[!] WRITE: No target specified")
        return 1

    if not data_source:
        print("[!] WRITE: No data source specified")
        return 1

    print(f"[*] WRITE command: target={target}, data={data_source}")
    
    # Initialize protection manager
    protection_manager = WriteProtectionManager()

    # =========================================================================
    # 0. DISABLE PROTECTION WARNING (if explicitly disabled)
    # =========================================================================
    if skip_protection_checks:
        print("\n" + "=" * 70)
        print("💀💀💀 PROTECTION CHECKS DISABLED 💀💀💀")
        print("=" * 70)
        print("This is EXTREMELY DANGEROUS and can PERMANENTLY BRICK your device!")
        print("You have been warned.")
        print("=" * 70 + "\n")
        
        if not force:
            response = input("Type 'I UNDERSTAND THE RISK' to continue: ")
            if response != "I UNDERSTAND THE RISK":
                print("[*] Operation cancelled")
                return 1

    # =========================================================================
    # 1. TARGET RESOLUTION
    # =========================================================================
    if use_qslcl_functions:
        try:
            partitions = load_partitions(dev)
            memory_regions = detect_memory_regions(dev) if hasattr(detect_memory_regions, '__call__') else []
            
            # Try to use resolve_target if available
            if hasattr(resolve_target, '__call__'):
                target_info = resolve_target(target, partitions, memory_regions, dev)
                
                if not target_info:
                    print(f"[!] Could not resolve target: {target}")
                    return 1
                    
                address = target_info['address']
                target_size = target_info['size']
                partition_info = target_info.get('partition_info')
                region_info = target_info.get('region_info')
                
                # Store partition info for protection checks
                if partition_info:
                    dev._current_partition = partition_info['name']
                    print(f"[+] Target is partition: {partition_info['name']} (0x{address:08X}, size: 0x{target_size:08X})")
                    
                    # Check partition risk level
                    risk_level, risk_reason = protection_manager.get_partition_risk_level(partition_info['name'])
                    if risk_level in ["CRITICAL", "HIGH"] and not force and not skip_protection_checks:
                        print(f"\n[!!!] {risk_reason}")
                        response = input(f"Type 'YES' to write to {partition_info['name']}: ")
                        if response != 'YES':
                            print("[*] Operation cancelled")
                            return 1
                            
                elif region_info:
                    print(f"[+] Target is memory region: {region_info['name']} (0x{address:08X}, size: 0x{target_size:08X})")
                else:
                    print(f"[+] Target address: 0x{address:08X}, using default size: 0x{target_size:08X}")
            else:
                # Fallback to legacy resolution
                address, target_size, partition_info = legacy_target_resolution(target, partitions)
                if address == 0 and target_size == 0:
                    return 1
                if partition_info:
                    dev._current_partition = partition_info['name']
                    
        except Exception as e:
            print(f"[!] Target resolution error: {e}")
            print("[*] Using legacy fallback...")
            partitions = load_partitions(dev) if hasattr(load_partitions, '__call__') else []
            address, target_size, partition_info = legacy_target_resolution(target, partitions)
            if address == 0 and target_size == 0:
                return 1
            if partition_info:
                dev._current_partition = partition_info['name']
    else:
        print("[!] Cannot resolve target without qslcl functions")
        return 1

    # =========================================================================
    # 2. DATA SOURCE PROCESSING
    # =========================================================================
    write_data = b""
    data_size = 0
    source_type = "unknown"

    try:
        # Check if data source is a file
        if os.path.exists(data_source):
            source_type = "file"
            file_size = os.path.getsize(data_source)
            
            if file_size > max_file_size:
                print(f"[!] File too large: {file_size} > {max_file_size}")
                if not force:
                    return 1
            
            with open(data_source, 'rb') as f:
                write_data = f.read()
            data_size = len(write_data)
            print(f"[+] Reading from file: {data_source} ({data_size} bytes)")
            print(f"[+] File SHA256: {hashlib.sha256(write_data).hexdigest()}")

        # Check if it's a hex string
        elif re.match(r'^[0-9A-Fa-f]+$', data_source.replace(' ', '').replace(':', '')):
            source_type = "hex"
            write_data = bytes.fromhex(data_source.replace(' ', '').replace(':', ''))
            data_size = len(write_data)
            print(f"[+] Processing hex data: {data_size} bytes")

        # Check for pattern syntax (e.g., "00FF*100" or "FF:4096")
        elif '*' in data_source or ':' in data_source:
            source_type = "pattern"
            write_data = parse_pattern_data(data_source)
            data_size = len(write_data)
            print(f"[+] Generated pattern data: {data_size} bytes")

        # Check for special commands
        elif data_source.lower() in ['zero', 'zeros', '00']:
            source_type = "pattern"
            if target_size > 0:
                write_data = b'\x00' * target_size
                data_size = target_size
                print(f"[+] Generating zeros: {data_size} bytes")
            else:
                print("[!] Cannot determine size for zero fill on raw address")
                return 1

        elif data_source.lower() in ['ff', 'ones', 'erase']:
            source_type = "pattern"
            if target_size > 0:
                write_data = b'\xFF' * target_size
                data_size = target_size
                print(f"[+] Generating ones: {data_size} bytes")
            else:
                print("[!] Cannot determine size for ones fill on raw address")
                return 1

        else:
            # Treat as literal string
            source_type = "string"
            write_data = data_source.encode('utf-8')
            data_size = len(write_data)
            print(f"[+] Using string data: {data_size} bytes")

    except Exception as e:
        print(f"[!] Data processing failed: {e}")
        return 1

    if data_size == 0:
        print("[!] No data to write")
        return 1

    # =========================================================================
    # 3. COMPREHENSIVE SAFETY CHECKS (NEW PROTECTION LAYER)
    # =========================================================================
    
    # Check size limits
    if target_size > 0 and data_size > target_size:
        print(f"[!] Data too large for target: {data_size} > {target_size}")
        if not force:
            return 1
        else:
            print("[!] Force mode: truncating data to target size")
            write_data = write_data[:target_size]
            data_size = target_size

    # Run protection checks (unless disabled)
    protection_info = None
    if not skip_protection_checks:
        safe, warning, protection_info = check_write_safety(dev, address, data_size, force, protection_manager)
        
        # Display protection warning
        if protection_info and protection_info.get("protected", False):
            display_protection_warning(protection_info, force)
        
        if not safe:
            print(f"\n[!] WRITE BLOCKED: {warning}")
            
            if protection_info and protection_info.get("severity") == "CRITICAL":
                print("\n💀 This operation would likely PERMANENTLY BRICK your device!")
                print("   The write has been BLOCKED to prevent damage.")
                return 1
            elif not force and protection_level != 'permissive':
                response = input("\nOverride protection? (yes/NO): ")
                if response.lower() != 'yes':
                    print("[*] Write cancelled")
                    return 1
                else:
                    print("[!!!] PROCEEDING WITH DANGEROUS WRITE OPERATION!")
    
    # Test if region is hardware read-only (if requested)
    if test_readonly and use_qslcl_functions and not skip_protection_checks:
        print("\n[*] Testing if target region is writable...")
        if not test_write_verify_readonly(dev, address):
            print("[!] Target region appears to be HARDWARE READ-ONLY!")
            if not force:
                response = input("Attempt write anyway? (yes/NO): ")
                if response.lower() != 'yes':
                    print("[*] Write cancelled")
                    return 1
        else:
            print("[+] Region appears writable")

    # Warn about critical partitions
    if partition_info and protection_manager.is_critical_partition(partition_info['name']) and not force:
        risk_level, risk_reason = protection_manager.get_partition_risk_level(partition_info['name'])
        print(f"\n[!!!] {risk_reason}")
        response = input(f"    Type 'YES' to write to {partition_info['name']}: ")
        if response != 'YES':
            print("[*] Operation cancelled")
            return 1

    # Show write summary
    print(f"\n[*] WRITE SUMMARY:")
    print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
    print(f"    Data size: 0x{data_size:08X} ({data_size} bytes)")
    print(f"    Source: {source_type}")
    print(f"    Chunk size: 0x{chunk_size:08X}")
    print(f"    Protection level: {protection_level}")
    
    if protection_info and protection_info.get("protected", False):
        print(f"    ⚠️  Protected region: {protection_info.get('region', 'Unknown')}")
    
    if not force:
        response = input("\n[*] Confirm write operation? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return 1

    # =========================================================================
    # 4. WRITE OPERATION - UPDATED for QSLCLCMD system
    # =========================================================================
    print(f"\n[*] Writing {data_size} bytes to 0x{address:08X}...")
    
    bytes_written = 0
    retry_count = 0
    max_retries = 3
    failed_chunks = []

    try:
        # Use appropriate ProgressBar
        if use_qslcl_functions and ProgressBar != ProgressBarLocal:
            progress_bar = ProgressBar(data_size, prefix='Writing', suffix='Complete', length=50)
        else:
            progress_bar = ProgressBarLocal(data_size, prefix='Writing', suffix='Complete', length=50)
            
        progress_bar.update(0)  # Initialize progress bar
        
        while bytes_written < data_size:
            chunk_addr = address + bytes_written
            remaining = data_size - bytes_written
            current_chunk_size = min(chunk_size, remaining)
            chunk_data = write_data[bytes_written:bytes_written + current_chunk_size]
            
            # Re-check protection for each chunk (in case we cross region boundaries)
            if not skip_protection_checks and protection_level == 'strict':
                chunk_protection = protection_manager.is_address_protected(chunk_addr, current_chunk_size)
                if chunk_protection["protected"] and chunk_protection["severity"] == "CRITICAL":
                    print(f"\n[!] Strict mode: Blocked write to protected region at 0x{chunk_addr:08X}")
                    failed_chunks.append((chunk_addr, current_chunk_size))
                    bytes_written += current_chunk_size
                    progress_bar.update(current_chunk_size)
                    continue
            
            try:
                # Build WRITE command packet
                write_header = struct.pack("<II", chunk_addr, current_chunk_size)
                write_payload = write_header + chunk_data
                
                # UPDATED: Use QSLCLCMD system (not QSLCLPAR)
                if use_qslcl_functions:
                    # Check QSLCLCMD_DB for WRITE command
                    write_commands = []
                    for key, value in QSLCLCMD_DB.items():
                        if isinstance(key, str) and key.upper() == "WRITE":
                            write_commands.append(("name", key))
                        elif isinstance(value, dict) and value.get("name", "").upper() == "WRITE":
                            write_commands.append(("opcode", key))
                    
                    if write_commands:
                        # Use first found WRITE command
                        cmd_type, cmd_key = write_commands[0]
                        if cmd_type == "name":
                            resp = qslcl_dispatch(dev, cmd_key, write_payload)
                        else:
                            resp = qslcl_dispatch(dev, str(cmd_key), write_payload)
                    else:
                        # Generic fallback
                        resp = qslcl_dispatch(dev, "WRITE", write_payload)
                else:
                    # Fallback without qslcl functions
                    print("[!] Cannot dispatch WRITE command without qslcl functions")
                    return 1
                
                if resp:
                    if use_qslcl_functions and hasattr(decode_runtime_result, '__call__'):
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            bytes_written += current_chunk_size
                            progress_bar.update(current_chunk_size)
                            retry_count = 0  # Reset retry counter
                        else:
                            print(f"\n[!] Write error at 0x{chunk_addr:08X}: {status}")
                            failed_chunks.append((chunk_addr, current_chunk_size))
                            retry_count += 1
                    else:
                        # Simple success check
                        if len(resp) > 0 and resp[0] == 0:  # Simple success code
                            bytes_written += current_chunk_size
                            progress_bar.update(current_chunk_size)
                            retry_count = 0
                        else:
                            print(f"\n[!] Write error at 0x{chunk_addr:08X}")
                            failed_chunks.append((chunk_addr, current_chunk_size))
                            retry_count += 1
                else:
                    print(f"\n[!] No response at 0x{chunk_addr:08X}")
                    failed_chunks.append((chunk_addr, current_chunk_size))
                    retry_count += 1
                
                # Handle retries
                if retry_count >= max_retries:
                    print(f"[!] Max retries exceeded at 0x{chunk_addr:08X}")
                    break
                    
            except Exception as e:
                print(f"\n[!] Write exception at 0x{chunk_addr:08X}: {e}")
                failed_chunks.append((chunk_addr, current_chunk_size))
                retry_count += 1
                if retry_count >= max_retries:
                    break
                time.sleep(0.1)  # Brief pause before retry

        progress_bar.update(0)  # Final update to ensure 100% display
        
        # =========================================================================
        # 5. RETRY FAILED CHUNKS
        # =========================================================================
        if failed_chunks and not no_verify:
            print(f"\n[*] Retrying {len(failed_chunks)} failed chunks...")
            retry_failed = failed_chunks.copy()
            for chunk_addr, chunk_size in retry_failed:
                retry_success = False
                for attempt in range(max_retries):
                    try:
                        # Calculate data offset
                        data_offset = chunk_addr - address
                        if 0 <= data_offset < data_size:
                            chunk_data = write_data[data_offset:data_offset + chunk_size]
                            write_header = struct.pack("<II", chunk_addr, chunk_size)
                            write_payload = write_header + chunk_data
                            
                            resp = qslcl_dispatch(dev, "WRITE", write_payload)
                            if resp:
                                if use_qslcl_functions:
                                    status = decode_runtime_result(resp)
                                    if status["severity"] == "SUCCESS":
                                        bytes_written += chunk_size
                                        failed_chunks.remove((chunk_addr, chunk_size))
                                        retry_success = True
                                        print(f"[+] Retry successful for 0x{chunk_addr:08X}")
                                        break
                                else:
                                    # Simple check
                                    if len(resp) > 0 and resp[0] == 0:
                                        bytes_written += chunk_size
                                        failed_chunks.remove((chunk_addr, chunk_size))
                                        retry_success = True
                                        print(f"[+] Retry successful for 0x{chunk_addr:08X}")
                                        break
                    except Exception as e:
                        print(f"[!] Retry failed for 0x{chunk_addr:08X}: {e}")
                
                if not retry_success:
                    print(f"[!] Permanent failure at 0x{chunk_addr:08X}")

        # =========================================================================
        # 6. VERIFICATION (if enabled)
        # =========================================================================
        if not no_verify and bytes_written > 0 and use_qslcl_functions:
            print("\n[*] Verifying write operation...")
            verify_success = True
            
            # Use appropriate ProgressBar
            if ProgressBar != ProgressBarLocal:
                verify_progress = ProgressBar(bytes_written, prefix='Verify', suffix='Complete', length=50)
            else:
                verify_progress = ProgressBarLocal(bytes_written, prefix='Verify', suffix='Complete', length=50)
                
            verify_progress.update(0)
            
            verify_addr = address
            remaining_verify = bytes_written
            verify_offset = 0
            
            while remaining_verify > 0 and verify_offset < data_size:
                verify_chunk_size = min(chunk_size, remaining_verify)
                
                # Read back for verification
                read_payload = struct.pack("<II", verify_addr, verify_chunk_size)
                
                # Use READ command
                read_commands = []
                for key, value in QSLCLCMD_DB.items():
                    if isinstance(key, str) and key.upper() == "READ":
                        read_commands.append(("name", key))
                    elif isinstance(value, dict) and value.get("name", "").upper() == "READ":
                        read_commands.append(("opcode", key))
                
                if read_commands:
                    cmd_type, cmd_key = read_commands[0]
                    if cmd_type == "name":
                        resp = qslcl_dispatch(dev, cmd_key, read_payload)
                    else:
                        resp = qslcl_dispatch(dev, str(cmd_key), read_payload)
                else:
                    resp = qslcl_dispatch(dev, "READ", read_payload)
                
                if resp:
                    status = decode_runtime_result(resp)
                    if status["severity"] == "SUCCESS":
                        read_data = status["extra"]
                        expected_data = write_data[verify_offset:verify_offset + verify_chunk_size]
                        
                        if read_data == expected_data:
                            verify_progress.update(verify_chunk_size)
                        else:
                            print(f"\n[!] Verify failed at 0x{verify_addr:08X}")
                            print(f"    Expected: {expected_data[:16].hex()}...")
                            print(f"    Got:      {read_data[:16].hex()}...")
                            verify_success = False
                            break
                    else:
                        print(f"\n[!] Verify read failed at 0x{verify_addr:08X}: {status}")
                        verify_success = False
                        break
                else:
                    print(f"\n[!] No verify response at 0x{verify_addr:08X}")
                    verify_success = False
                    break
                
                verify_addr += verify_chunk_size
                verify_offset += verify_chunk_size
                remaining_verify -= verify_chunk_size

            verify_progress.update(0)  # Final update
            
            if verify_success:
                print("\n[+] Verification passed!")
            else:
                print("\n[!] Verification failed!")
        elif not no_verify and bytes_written > 0:
            print("[!] Verification skipped (requires qslcl functions)")

        # =========================================================================
        # 7. FINAL SUMMARY
        # =========================================================================
        print(f"\n[+] WRITE operation completed!")
        print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
        print(f"    Data size: 0x{data_size:08X} ({data_size} bytes)")
        print(f"    Written: 0x{bytes_written:08X} ({bytes_written} bytes)")
        
        if data_size > 0:
            success_rate = (bytes_written / data_size) * 100
            print(f"    Success rate: {success_rate:.1f}%")
        
        if failed_chunks:
            print(f"    Failed chunks: {len(failed_chunks)}")
            for chunk_addr, chunk_size in failed_chunks:
                print(f"      - 0x{chunk_addr:08X} (0x{chunk_size:04X} bytes)")

        if source_type == "file":
            print(f"    Source file: {data_source}")
            print(f"    Source SHA256: {hashlib.sha256(write_data).hexdigest()}")
            
        # Final protection reminder
        if protection_info and protection_info.get("protected", False) and not skip_protection_checks:
            print("\n⚠️  Reminder: You wrote to a protected region!")
            print(f"   Region: {protection_info.get('region', 'Unknown')}")
            print("   Please verify your device still functions correctly.")

    except Exception as e:
        print(f"[!] WRITE operation failed: {e}")
        traceback.print_exc()
        return 1
    
    return 0