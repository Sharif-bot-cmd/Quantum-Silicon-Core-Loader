def cmd_mode(args=None):
    """
    Fully implemented MODE command for QSLCL mode management:
    - QSLCL mode activation and configuration
    - Mode-specific feature enabling
    - Safe mode transitions with validation
    - Mode persistence and settings
    """
    if not args:
        print("[!] MODE: No arguments provided")
        print_mode_help()
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'mode_subcommand', '').lower()
    mode_args = getattr(args, 'mode_args', [])
    force = getattr(args, 'force', False)
    persistent = getattr(args, 'persistent', False)

    if not subcommand:
        print("[!] MODE: No subcommand specified")
        print_mode_help()
        return

    print(f"[*] MODE command: {subcommand} {mode_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH - QSLCL MODES ONLY
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'show']:
            mode_list(dev, mode_args)
            
        elif subcommand in ['set', 'enable', 'activate']:
            mode_set(dev, mode_args, force, persistent)
            
        elif subcommand in ['unset', 'disable', 'deactivate']:
            mode_unset(dev, mode_args, force)
            
        elif subcommand in ['configure', 'config', 'cfg']:
            mode_configure(dev, mode_args, force)
            
        elif subcommand in ['save', 'store', 'persist']:
            mode_save(dev, mode_args, force)
            
        elif subcommand in ['load', 'restore']:
            mode_load(dev, mode_args, force)
            
        elif subcommand in ['reset', 'default', 'clear']:
            mode_reset(dev, mode_args, force)
            
        elif subcommand in ['help', '?']:
            print_mode_help()
            
        else:
            print(f"[!] Unknown MODE subcommand: {subcommand}")
            print(f"[!] Note: Only QSLCL modes are supported")
            print_mode_help()
            
    except Exception as e:
        print(f"[!] MODE operation failed: {e}")
        import traceback
        traceback.print_exc()

def cmd_mode_status(args=None):
    """
    Fully implemented MODE-STATUS command:
    - Current QSLCL mode status and configuration
    - Active mode features and capabilities
    - Mode transition history and state
    - Performance and resource usage
    """
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    print("[*] Querying QSLCL mode status...")

    # =========================================================================
    # 1. QUERY CURRENT MODE STATUS
    # =========================================================================
    try:
        # Query mode status
        status_payload = struct.pack("<B", 0x10)  # STATUS_QUERY command
        
        resp = qslcl_dispatch(dev, "MODE", status_payload)
        
        if not resp:
            print("[!] No response from device")
            return

        status = decode_runtime_result(resp)
        if status["severity"] != "SUCCESS":
            print(f"[!] Mode status query failed: {status}")
            return

        # Parse mode status
        mode_status = parse_mode_status(status["extra"])
        display_mode_status(mode_status, dev)
        
    except Exception as e:
        print(f"[!] Mode status query failed: {e}")

# =============================================================================
# MODE SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def mode_list(dev, args):
    """List available QSLCL modes and descriptions"""
    print("[*] Querying available QSLCL modes...")
    
    # Query mode capabilities
    capabilities = query_mode_capabilities(dev)
    
    print(f"\n[+] QSLCL Mode Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Mode Support: {capabilities.get('mode_support', 'Basic')}")
    print(f"    Active Mode: {capabilities.get('active_mode', 'Unknown')}")
    
    # List available modes
    modes = capabilities.get('modes', [])
    if modes:
        print(f"\n[+] Available QSLCL Modes:")
        for mode in modes:
            active = " ← ACTIVE" if mode.get('active', False) else ""
            safety = mode.get('safety', 'UNKNOWN')
            safety_icon = "🟢" if safety == 'SAFE' else "🟡" if safety == 'WARNING' else "🔴"
            print(f"    {safety_icon} {mode['name']:20} - {mode.get('description', '')}{active}")
    
    # List mode features
    features = capabilities.get('features', [])
    if features:
        print(f"\n[+] Mode Features:")
        for feature in features:
            enabled = "✓" if feature.get('enabled', False) else "✗"
            print(f"    {enabled} {feature['name']:25} - {feature.get('description', '')}")

def mode_set(dev, args, force=False, persistent=False):
    """Set or activate a QSLCL mode"""
    if not args:
        print("[!] Specify mode to activate")
        print("[*] Available modes: NORMAL, DEBUG, DIAGNOSTIC, RECOVERY, SECURE, PERFORMANCE")
        return
        
    mode_name = args[0].upper()
    mode_param = args[1] if len(args) > 1 else ""
    
    print(f"[*] Activating QSLCL mode: {mode_name}")
    
    # Validate mode name
    valid_modes = ['NORMAL', 'DEBUG', 'DIAGNOSTIC', 'RECOVERY', 'SECURE', 'PERFORMANCE', 
                   'DEVELOPMENT', 'TESTING', 'MAINTENANCE', 'BOOTSTRAP']
    
    if mode_name not in valid_modes:
        print(f"[!] Invalid QSLCL mode: {mode_name}")
        print(f"[+] Valid modes: {', '.join(valid_modes)}")
        return
    
    # Safety checks for dangerous modes
    dangerous_modes = ['DEBUG', 'DEVELOPMENT', 'MAINTENANCE', 'BOOTSTRAP']
    if mode_name in dangerous_modes and not force:
        print(f"[!] WARNING: {mode_name} mode may reduce security!")
        print(f"[!] Only use in controlled environments!")
        response = input("    Type 'ENABLE' to continue: ")
        if response != 'ENABLE':
            print("[*] Mode activation cancelled")
            return
    
    # Build mode set command
    set_payload = struct.pack("<B", 0x01)  # MODE_SET command
    set_payload += mode_name.encode('ascii').ljust(16, b'\x00')
    set_payload += struct.pack("<B", 1 if persistent else 0)  # Persistence flag
    
    if mode_param:
        set_payload += mode_param.encode('ascii').ljust(32, b'\x00')
    
    resp = qslcl_dispatch(dev, "MODE", set_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] QSLCL mode {mode_name} activated successfully")
            
            # Parse activation results
            activation_info = parse_mode_activation(status["extra"])
            if activation_info:
                print(f"    Features enabled: {activation_info.get('features_enabled', 0)}")
                print(f"    Persistence: {'Yes' if persistent else 'No'}")
                
            # Show mode-specific information
            show_mode_details(mode_name)
            
        else:
            print(f"[!] Failed to activate {mode_name} mode: {status}")
    else:
        print("[!] No response from device")

def mode_unset(dev, args, force=False):
    """Deactivate current QSLCL mode and return to normal"""
    print("[*] Deactivating current QSLCL mode...")
    
    # Get current mode first
    status_payload = struct.pack("<B", 0x10)  # STATUS_QUERY command
    resp = qslcl_dispatch(dev, "MODE", status_payload)
    
    current_mode = "UNKNOWN"
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            mode_status = parse_mode_status(status["extra"])
            current_mode = mode_status.get('current_mode', 'UNKNOWN')
    
    if current_mode == 'NORMAL':
        print("[+] Device already in NORMAL mode")
        return
    
    if not force and current_mode != 'UNKNOWN':
        print(f"[!] Current mode: {current_mode}")
        response = input("    Deactivate and return to NORMAL mode? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Mode deactivation cancelled")
            return
    
    # Build mode unset command
    unset_payload = struct.pack("<B", 0x02)  # MODE_UNSET command
    
    resp = qslcl_dispatch(dev, "MODE", unset_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] QSLCL mode deactivated successfully")
            print("[+] Device returned to NORMAL mode")
            
            # Show deactivation results
            deactivation_info = parse_mode_deactivation(status["extra"])
            if deactivation_info:
                print(f"    Features disabled: {deactivation_info.get('features_disabled', 0)}")
                print(f"    Resources released: {deactivation_info.get('resources_released', 0)}")
        else:
            print(f"[!] Failed to deactivate mode: {status}")
    else:
        print("[!] No response from device")

def mode_configure(dev, args, force=False):
    """Configure mode-specific settings"""
    if not args:
        print("[!] Specify configuration parameter")
        print("[*] Format: <parameter> <value>")
        return
        
    param_name = args[0].upper()
    param_value = args[1] if len(args) > 1 else ""
    
    if not param_value:
        print("[!] No value specified for parameter")
        return
    
    print(f"[*] Configuring mode parameter: {param_name} = {param_value}")
    
    # Build configuration command
    config_payload = struct.pack("<B", 0x03)  # MODE_CONFIGURE command
    config_payload += param_name.encode('ascii').ljust(16, b'\x00')
    config_payload += param_value.encode('ascii').ljust(32, b'\x00')
    
    resp = qslcl_dispatch(dev, "MODE", config_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Mode parameter {param_name} configured successfully")
        else:
            print(f"[!] Configuration failed: {status}")
    else:
        print("[!] No response from device")

def mode_save(dev, args, force=False):
    """Save current mode configuration"""
    profile_name = "default"
    if args:
        profile_name = args[0]
    
    print(f"[*] Saving current mode configuration as: {profile_name}")
    
    # Build save command
    save_payload = struct.pack("<B", 0x04)  # MODE_SAVE command
    save_payload += profile_name.encode('ascii').ljust(32, b'\x00')
    
    resp = qslcl_dispatch(dev, "MODE", save_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Mode configuration saved as '{profile_name}'")
            
            save_info = parse_mode_save(status["extra"])
            if save_info:
                print(f"    Settings saved: {save_info.get('settings_saved', 0)}")
                print(f"    Profile size: {save_info.get('profile_size', 0)} bytes")
        else:
            print(f"[!] Save failed: {status}")
    else:
        print("[!] No response from device")

def mode_load(dev, args, force=False):
    """Load saved mode configuration"""
    if not args:
        print("[!] Specify profile name to load")
        print("[*] Use 'mode list' to see available profiles")
        return
        
    profile_name = args[0]
    
    print(f"[*] Loading mode configuration: {profile_name}")
    
    # Build load command
    load_payload = struct.pack("<B", 0x05)  # MODE_LOAD command
    load_payload += profile_name.encode('ascii').ljust(32, b'\x00')
    
    resp = qslcl_dispatch(dev, "MODE", load_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Mode configuration '{profile_name}' loaded successfully")
            
            load_info = parse_mode_load(status["extra"])
            if load_info:
                print(f"    Settings applied: {load_info.get('settings_applied', 0)}")
                print(f"    Mode activated: {load_info.get('mode_activated', 'UNKNOWN')}")
        else:
            print(f"[!] Load failed: {status}")
    else:
        print("[!] No response from device")

def mode_reset(dev, args, force=False):
    """Reset all mode configurations to defaults"""
    print("[*] Resetting all mode configurations to defaults...")
    
    if not force:
        print("[!] This will clear all custom mode settings!")
        response = input("    Type 'RESET' to confirm: ")
        if response != 'RESET':
            print("[*] Reset cancelled")
            return
    
    # Build reset command
    reset_payload = struct.pack("<B", 0x06)  # MODE_RESET command
    
    resp = qslcl_dispatch(dev, "MODE", reset_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] All mode configurations reset to defaults")
            
            reset_info = parse_mode_reset(status["extra"])
            if reset_info:
                print(f"    Settings reset: {reset_info.get('settings_reset', 0)}")
                print(f"    Profiles cleared: {reset_info.get('profiles_cleared', 0)}")
        else:
            print(f"[!] Reset failed: {status}")
    else:
        print("[!] No response from device")

# =============================================================================
# MODE STATUS IMPLEMENTATION
# =============================================================================

def parse_mode_status(status_data):
    """Parse mode status information from device response"""
    status = {
        'current_mode': 'UNKNOWN',
        'mode_state': 'UNKNOWN',
        'features_active': 0,
        'performance_level': 'UNKNOWN',
        'security_level': 'UNKNOWN',
        'resources_used': 0,
        'uptime': 0
    }
    
    try:
        if len(status_data) >= 16:
            # Parse structured status data
            status['current_mode'] = status_data[0:16].decode('ascii', errors='ignore').rstrip('\x00')
            
            if len(status_data) >= 20:
                status['features_active'] = struct.unpack("<I", status_data[16:20])[0]
                
            if len(status_data) >= 24:
                status['resources_used'] = struct.unpack("<I", status_data[20:24])[0]
                
            if len(status_data) >= 28:
                status['uptime'] = struct.unpack("<I", status_data[24:28])[0]
                
            # Parse mode-specific flags
            if len(status_data) >= 32:
                flags = struct.unpack("<I", status_data[28:32])[0]
                status['performance_level'] = ['LOW', 'NORMAL', 'HIGH', 'MAX'][(flags >> 0) & 0x03]
                status['security_level'] = ['MINIMAL', 'NORMAL', 'ENHANCED', 'MAXIMUM'][(flags >> 2) & 0x03]
                status['mode_state'] = ['INACTIVE', 'ACTIVE', 'TRANSITION', 'ERROR'][(flags >> 4) & 0x03]
    
    except Exception as e:
        print(f"[!] Mode status parse error: {e}")
    
    return status

def display_mode_status(mode_status, dev):
    """Display comprehensive mode status information"""
    print(f"\n[+] QSLCL Mode Status:")
    print(f"    Current Mode: {mode_status['current_mode']}")
    print(f"    Mode State: {mode_status['mode_state']}")
    print(f"    Performance: {mode_status['performance_level']}")
    print(f"    Security: {mode_status['security_level']}")
    print(f"    Active Features: {mode_status['features_active']}")
    print(f"    Resources Used: {mode_status['resources_used']}")
    
    if mode_status['uptime'] > 0:
        uptime_str = format_time(mode_status['uptime'])
        print(f"    Mode Uptime: {uptime_str}")
    
    # Show mode-specific details
    show_current_mode_details(mode_status['current_mode'])
    
    # Show resource usage if available
    show_resource_usage(dev, mode_status)
    
    # Show recommendations based on current mode
    show_mode_recommendations(mode_status)

def show_current_mode_details(mode_name):
    """Show details about the current active mode"""
    mode_details = {
        'NORMAL': "Standard operation mode with balanced performance and security",
        'DEBUG': "Debugging mode with extended logging and diagnostic features",
        'DIAGNOSTIC': "Hardware diagnostics and system testing mode",
        'RECOVERY': "System recovery and maintenance mode",
        'SECURE': "Enhanced security with restricted access",
        'PERFORMANCE': "Maximum performance with reduced power savings",
        'DEVELOPMENT': "Development features enabled, security reduced",
        'TESTING': "Testing and validation mode",
        'MAINTENANCE': "System maintenance and update mode",
        'BOOTSTRAP': "Bootstrap and low-level initialization mode"
    }
    
    if mode_name in mode_details:
        print(f"\n[+] Mode Description: {mode_details[mode_name]}")

def show_resource_usage(dev, mode_status):
    """Show detailed resource usage for current mode"""
    if mode_status['resources_used'] == 0:
        return
    
    print(f"\n[+] Resource Usage:")
    
    # Calculate resource percentages (simplified)
    total_resources = 100  # Arbitrary total
    used_percent = min(100, (mode_status['resources_used'] / total_resources) * 100)
    
    # Create simple progress bar
    bar_length = 20
    filled = int(bar_length * used_percent / 100)
    bar = '█' * filled + '░' * (bar_length - filled)
    
    print(f"    Resources: [{bar}] {used_percent:.1f}%")
    
    # Show breakdown if available
    if mode_status['features_active'] > 0:
        print(f"    Active Features: {mode_status['features_active']}")

def show_mode_recommendations(mode_status):
    """Show recommendations based on current mode"""
    recommendations = []
    
    if mode_status['current_mode'] == 'DEBUG' and mode_status['security_level'] == 'MINIMAL':
        recommendations.append("Consider switching to NORMAL mode for production use")
    
    if mode_status['performance_level'] == 'MAX' and mode_status['resources_used'] > 80:
        recommendations.append("High resource usage detected, consider performance tuning")
    
    if mode_status['current_mode'] == 'NORMAL' and mode_status['features_active'] == 0:
        recommendations.append("No special features active in NORMAL mode")
    
    if recommendations:
        print(f"\n[+] Recommendations:")
        for rec in recommendations:
            print(f"    • {rec}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR MODE COMMANDS
# =============================================================================

def query_mode_capabilities(dev):
    """Query device mode capabilities"""
    capabilities = {
        'device_name': 'Unknown',
        'mode_support': 'Basic',
        'active_mode': 'UNKNOWN',
        'modes': [
            {'name': 'NORMAL', 'description': 'Standard operation', 'safety': 'SAFE', 'active': True},
            {'name': 'DEBUG', 'description': 'Debugging and diagnostics', 'safety': 'WARNING', 'active': False},
            {'name': 'DIAGNOSTIC', 'description': 'Hardware testing', 'safety': 'SAFE', 'active': False},
            {'name': 'RECOVERY', 'description': 'System recovery', 'safety': 'SAFE', 'active': False},
            {'name': 'SECURE', 'description': 'Enhanced security', 'safety': 'SAFE', 'active': False},
            {'name': 'PERFORMANCE', 'description': 'Maximum performance', 'safety': 'WARNING', 'active': False},
        ],
        'features': [
            {'name': 'EXTENDED_LOGGING', 'description': 'Detailed system logging', 'enabled': False},
            {'name': 'HARDWARE_ACCESS', 'description': 'Direct hardware register access', 'enabled': False},
            {'name': 'MEMORY_DEBUG', 'description': 'Memory debugging features', 'enabled': False},
            {'name': 'PERFORMANCE_MONITOR', 'description': 'Performance monitoring', 'enabled': False},
            {'name': 'SECURE_BOOT', 'description': 'Secure boot verification', 'enabled': True},
        ]
    }
    
    try:
        # Try to query actual capabilities
        query_payload = struct.pack("<B", 0x00)  # CAPABILITIES query
        
        if "MODE" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "MODE", query_payload)
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    # Parse capability data would go here
                    pass
    except Exception:
        pass
    
    return capabilities

def show_mode_details(mode_name):
    """Show detailed information about a specific mode"""
    mode_info = {
        'DEBUG': {
            'description': 'Debugging and development mode',
            'features': ['Extended logging', 'Hardware access', 'Memory debugging', 'Performance monitoring'],
            'warnings': ['Reduced security', 'Increased power consumption', 'Potential stability issues'],
            'usage': 'Use for development and troubleshooting only'
        },
        'DIAGNOSTIC': {
            'description': 'Hardware diagnostic mode',
            'features': ['Hardware testing', 'Component verification', 'Error detection', 'System validation'],
            'warnings': ['Limited normal operation', 'May require specialist knowledge'],
            'usage': 'Use for hardware testing and validation'
        },
        'RECOVERY': {
            'description': 'System recovery mode',
            'features': ['System restoration', 'Backup operations', 'Firmware updates', 'Data recovery'],
            'warnings': ['Limited functionality', 'May require reconfiguration'],
            'usage': 'Use for system recovery and maintenance'
        },
        'SECURE': {
            'description': 'Enhanced security mode',
            'features': ['Secure boot', 'Encrypted storage', 'Access controls', 'Audit logging'],
            'warnings': ['Reduced performance', 'Limited debug features'],
            'usage': 'Use for security-sensitive operations'
        },
        'PERFORMANCE': {
            'description': 'Maximum performance mode',
            'features': ['CPU/GPU boosting', 'Memory optimization', 'I/O prioritization', 'Power management bypass'],
            'warnings': ['Increased power consumption', 'Reduced battery life', 'Potential overheating'],
            'usage': 'Use for performance-critical applications'
        }
    }
    
    if mode_name in mode_info:
        info = mode_info[mode_name]
        print(f"\n[+] {mode_name} Mode Details:")
        print(f"    Description: {info['description']}")
        print(f"    Features: {', '.join(info['features'])}")
        print(f"    Warnings: {', '.join(info['warnings'])}")
        print(f"    Usage: {info['usage']}")

def parse_mode_activation(activation_data):
    """Parse mode activation results"""
    info = {}
    
    try:
        if len(activation_data) >= 4:
            info['features_enabled'] = struct.unpack("<I", activation_data[0:4])[0]
    except Exception:
        pass
    
    return info

def parse_mode_deactivation(deactivation_data):
    """Parse mode deactivation results"""
    info = {}
    
    try:
        if len(deactivation_data) >= 8:
            info['features_disabled'] = struct.unpack("<I", deactivation_data[0:4])[0]
            info['resources_released'] = struct.unpack("<I", deactivation_data[4:8])[0]
    except Exception:
        pass
    
    return info

def parse_mode_save(save_data):
    """Parse mode save results"""
    info = {}
    
    try:
        if len(save_data) >= 8:
            info['settings_saved'] = struct.unpack("<I", save_data[0:4])[0]
            info['profile_size'] = struct.unpack("<I", save_data[4:8])[0]
    except Exception:
        pass
    
    return info

def parse_mode_load(load_data):
    """Parse mode load results"""
    info = {}
    
    try:
        if len(load_data) >= 8:
            info['settings_applied'] = struct.unpack("<I", load_data[0:4])[0]
            mode_name = load_data[4:20].decode('ascii', errors='ignore').rstrip('\x00')
            info['mode_activated'] = mode_name if mode_name else 'UNKNOWN'
    except Exception:
        pass
    
    return info

def parse_mode_reset(reset_data):
    """Parse mode reset results"""
    info = {}
    
    try:
        if len(reset_data) >= 8:
            info['settings_reset'] = struct.unpack("<I", reset_data[0:4])[0]
            info['profiles_cleared'] = struct.unpack("<I", reset_data[4:8])[0]
    except Exception:
        pass
    
    return info

def print_mode_help():
    """Display mode command help"""
    print("""
MODE Command Usage (QSLCL Modes Only):
  mode list                    - List available QSLCL modes
  mode set <mode> [param]      - Activate QSLCL mode
  mode unset                   - Deactivate mode (return to NORMAL)
  mode configure <param> <val> - Configure mode parameters
  mode save [profile]          - Save current mode configuration
  mode load <profile>          - Load saved mode configuration
  mode reset                   - Reset all mode configurations

Available QSLCL Modes:
  NORMAL       - Standard operation (default)
  DEBUG        - Debugging and development
  DIAGNOSTIC   - Hardware diagnostics
  RECOVERY     - System recovery
  SECURE       - Enhanced security
  PERFORMANCE  - Maximum performance
  DEVELOPMENT  - Development features
  TESTING      - Testing and validation
  MAINTENANCE  - System maintenance
  BOOTSTRAP    - Low-level initialization

Common Parameters:
  LOG_LEVEL    - Debug logging level (0-3)
  SECURITY     - Security level (MINIMAL, NORMAL, ENHANCED, MAXIMUM)
  PERFORMANCE  - Performance level (LOW, NORMAL, HIGH, MAX)
  FEATURES     - Comma-separated feature list

Examples:
  qslcl mode set DEBUG
  qslcl mode set PERFORMANCE --persistent
  qslcl mode configure LOG_LEVEL 2
  qslcl mode save dev_profile
  qslcl mode status
  qslcl mode unset

Safety Levels:
  🟢 SAFE      - Normal operation, no special considerations
  🟡 WARNING   - Reduced security or stability, user confirmation
  🔴 DANGEROUS - Potential system instability, explicit confirmation

Note: Only QSLCL modes are supported. Other mode types are ignored.
    """)

# =============================================================================
# MODE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_mode_arguments(parser):
    """Add mode-specific arguments to argument parser"""
    parser.add_argument("--persistent", action="store_true",
                       help="Make mode changes persistent across reboots")
    return parser