def cmd_patch(args):
    """
    Advanced binary patching command for QSLCL devices
    Supports multiple patch types and verification
    """
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Check if PATCH command is available
    try:
        if "PATCH" not in QSLCLCMD_DB:
            print("[!] PATCH command not available in loaded QSLCL binary")
            # Show available commands
            available_cmds = [k for k in QSLCLCMD_DB.keys() 
                            if isinstance(k, str) and k.isalpha()]
            if available_cmds:
                print(f"[*] Available commands: {', '.join(available_cmds[:10])}")
            else:
                print("[*] No commands available in QSLCLCMD_DB")
            
            # Offer to continue anyway
            response = input("[?] Continue without PATCH command? (y/N): ")
            if response.lower() != 'y':
                return 1
    except (NameError, AttributeError):
        print("[*] Could not check command availability, continuing anyway")
    
    print("[*] QSLCL PATCH Engine v1.1 (Fixed)")
    print("[*] =================================")
    
    # Parse patch arguments
    if not hasattr(args, 'patch_args') or len(args.patch_args) < 2:
        if hasattr(args, 'patch_args') and len(args.patch_args) == 1 and args.patch_args[0].lower() == "list":
            # Handle "patch list" command
            devs = scan_all()
            if devs:
                list_available_targets(devs[0])
                return 0
        print_help()
        return 1
    
    target = args.patch_args[0]
    patch_data_spec = args.patch_args[1]
    
    # Handle additional arguments for replace/instruction types
    if len(args.patch_args) > 2:
        extra_args = args.patch_args[2:]
        if patch_data_spec.lower() in ["replace", "string"]:
            if len(extra_args) >= 2:
                patch_data_spec = f"replace:{extra_args[0]}:{extra_args[1]}"
        elif patch_data_spec.lower() in ["instruction", "asm"]:
            patch_data_spec = f"instruction:{' '.join(extra_args)}"
    
    patch_type = getattr(args, 'patch_type', 'auto')
    verify = not getattr(args, 'no_verify', False)
    force = getattr(args, 'force', False)
    
    # Parse target address and size
    target_info = parse_patch_target(target, dev)
    if target_info is None:
        print(f"[!] Invalid target: {target}")
        print(f"[*] Use 'patch list' to see available targets")
        return 1
    
    target_addr, target_size = target_info
    
    # Prepare patch data
    patch_data, actual_patch_type = prepare_patch_data(
        patch_data_spec, 
        patch_type,
        target_size if target_size > 0 else None
    )
    
    if patch_data is None:
        print(f"[!] Failed to prepare patch data from: {patch_data_spec}")
        return 1
    
    # Check if patch fits in target
    if target_size > 0 and len(patch_data) > target_size:
        if not force:
            print(f"[!] Patch size ({len(patch_data)} bytes) exceeds target size ({target_size} bytes)")
            print(f"[!] Use --force to override (DANGEROUS)")
            return 1
        else:
            print(f"[!] WARNING: Patch exceeds target size, truncating to {target_size} bytes")
            patch_data = patch_data[:target_size]
    
    print(f"[*] Patching target: {target}")
    print(f"[*] Target address: 0x{target_addr:08X}")
    if target_size > 0:
        print(f"[*] Target size: {target_size} bytes (0x{target_size:X})")
    print(f"[*] Patch size: {len(patch_data)} bytes")
    print(f"[*] Patch type: {actual_patch_type}")
    print(f"[*] Verification: {'ENABLED' if verify else 'DISABLED'}")
    
    if not force:
        # Safety confirmation for large/dangerous patches
        if len(patch_data) > 1024 * 1024:  # > 1MB
            response = input(f"[?] Apply {len(patch_data)//1024}KB patch? (y/N): ")
            if response.lower() != 'y':
                print("[*] Patch cancelled")
                return 0
        elif "boot" in target.lower() or "system" in target.lower() or "recovery" in target.lower():
            response = input(f"[?] Patch critical system partition '{target}'? (y/N): ")
            if response.lower() != 'y':
                print("[*] Patch cancelled")
                return 0
    
    # Execute patch operation
    success = execute_patch(dev, target_addr, patch_data, verify, args)
    
    if success:
        print("[✓] Patch applied successfully")
        return 0
    else:
        print("[!] Patch failed")
        return 1

def print_help():
    """Print detailed patch command help"""
    print("""
QSLCL Patch Command - Advanced Binary Patching
==============================================

Usage: qslcl patch <target> <patch_data> [options]

TARGET FORMATS:
  address <hex>                 - Raw memory address (0x12345678)
  partition <name>              - Partition start (boot, system, etc.)
  partition+offset <name+hex>   - Partition with offset (boot+0x1000)
  range <start-end>             - Address range (0x1000-0x2000)
  symbol <name>                 - Symbol name (if debug symbols loaded)
  list                          - List available targets

PATCH DATA FORMATS:
  file <filename>               - Binary patch file
  hex <hex_string>              - Hex string (AABBCCDDEEFF)
  pattern <value:count>         - Fill pattern (00:1024, FF:256)
  replace <old:new>             - String replacement
  instruction <asm>             - Assembly instruction
  zero <size>                   - Fill with zeros

EXAMPLES:
  qslcl patch 0x880000 file boot_patch.bin
  qslcl patch boot+0x1000 hex "DEADBEEF"
  qslcl patch system pattern 00:4096
  qslcl patch 0x12345678 replace "old:new"
  qslcl patch kernel instruction "nop"
  qslcl patch cache zero 1024

OPTIONS:
  --patch-type <type>          - Force patch type (file, hex, pattern, etc.)
  --no-verify                  - Skip read-back verification
  --chunk-size <size>          - Patch chunk size in bytes (default: 4096)
  --retries <count>            - Max retry attempts (default: 3)
  --force                      - Skip safety checks (DANGEROUS)
  --backup <file>              - Create backup before patching
  --dry-run                    - Test patch without writing
    """)

def parse_patch_target(target: str, dev) -> Optional[Tuple[int, int]]:
    """
    Parse various target formats into (address, size) tuple
    Returns None if target is invalid
    """
    if target is None:
        return None
    
    target_lower = target.lower()
    
    # Special command: list targets
    if target_lower == "list":
        list_available_targets(dev)
        return None
    
    # 1. Raw hex address (0x12345678)
    if target.startswith('0x'):
        try:
            address = int(target, 16)
            # For raw addresses, we don't know the size
            return address, 0
        except ValueError:
            pass
    
    # 2. Decimal address
    if target.isdigit():
        address = int(target)
        return address, 0
    
    # 3. Range format (0x1000-0x2000)
    if '-' in target and target.count('-') == 1:
        start_str, end_str = target.split('-')
        try:
            start = int(start_str, 0)  # Auto-detect hex/dec
            end = int(end_str, 0)
            if start < end:
                return start, end - start
        except ValueError:
            pass
    
    # 4. Partition + offset (e.g., "boot+0x1000")
    if '+' in target:
        try:
            part_name, offset_str = target.split('+', 1)
            part_info = find_partition(part_name, dev)
            if part_info:
                offset = int(offset_str, 0)  # Auto-detect hex/dec
                address = part_info['offset'] + offset
                # Calculate remaining size in partition
                if offset <= part_info['size']:
                    remaining = part_info['size'] - offset
                    return address, remaining
        except (ValueError, KeyError):
            pass
    
    # 5. Partition only
    part_info = find_partition(target, dev)
    if part_info:
        return part_info['offset'], part_info['size']
    
    # 6. Symbol lookup (future enhancement)
    if is_valid_symbol_name(target):
        symbol_addr = lookup_symbol(target, dev)
        if symbol_addr:
            return symbol_addr, 0
    
    return None

def list_available_targets(dev):
    """List all available patch targets"""
    print("[*] Available patch targets:")
    print("\nPartitions:")
    print("-" * 60)
    
    try:
        parts = load_partitions(dev)
        if not parts:
            print("  No partitions detected")
        else:
            for part in parts:
                size_kb = part['size'] // 1024 if part['size'] > 1024 else 1
                size_mb = part['size'] // (1024 * 1024) if part['size'] > 1024 * 1024 else 0
                if size_mb > 0:
                    size_str = f"{size_mb}MB"
                else:
                    size_str = f"{size_kb}KB"
                    
                print(f"  {part['name']:12} 0x{part['offset']:08X} - "
                      f"0x{part['offset'] + part['size']:08X} ({size_str})")
    except Exception as e:
        print(f"  Error loading partitions: {e}")
    
    print("\nMemory Regions (if available):")
    print("-" * 60)
    
    try:
        regions = detect_memory_regions(dev)
        if regions:
            for region in regions[:5]:  # Show first 5
                size_kb = region['size'] // 1024 if region['size'] > 1024 else 1
                size_mb = region['size'] // (1024 * 1024) if region['size'] > 1024 * 1024 else 0
                if size_mb > 0:
                    size_str = f"{size_mb}MB"
                else:
                    size_str = f"{size_kb}KB"
                    
                perms = region.get('permissions', '---')
                print(f"  {region['name']:12} 0x{region['start']:08X} - "
                      f"0x{region['end']:08X} ({size_str}) {perms}")
        else:
            print("  No memory regions detected")
    except Exception as e:
        print(f"  Error detecting memory regions: {e}")
    
    print("\nExamples:")
    print("  qslcl patch boot file update.bin      # Patch entire boot partition")
    print("  qslcl patch boot+0x1000 hex DEADBEEF  # Patch at offset in boot")
    print("  qslcl patch 0x880000 file patch.bin   # Patch at specific address")
    print("  qslcl patch list                      # List all targets")

def find_partition(part_name: str, dev) -> Optional[Dict[str, Any]]:
    """
    Find partition by name (case-insensitive)
    """
    try:
        parts = load_partitions(dev)
        for part in parts:
            if part['name'].lower() == part_name.lower():
                return part
        
        # Try partial match
        for part in parts:
            if part_name.lower() in part['name'].lower():
                return part
    except Exception as e:
        print(f"[!] Error finding partition: {e}")
    
    return None

def is_valid_symbol_name(name: str) -> bool:
    """Check if a string looks like a valid symbol name"""
    if not name or not isinstance(name, str):
        return False
    
    # Basic validation - could be enhanced
    return (len(name) > 1 and 
            name[0].isalpha() and 
            all(c.isalnum() or c in '_.$' for c in name))

def lookup_symbol(symbol: str, dev) -> Optional[int]:
    """
    Look up symbol address (placeholder for future implementation)
    """
    # TODO: Implement symbol table lookup
    # This could use debug symbols, kernel symbols, or a symbol database
    print(f"[*] Symbol lookup not implemented yet for: {symbol}")
    return None

def prepare_patch_data(spec: str, patch_type: str = 'auto', 
                      target_size: Optional[int] = None) -> Tuple[Optional[bytes], str]:
    """
    Prepare patch data from various input formats
    Returns (patch_data, detected_type)
    """
    if spec is None:
        return None, 'error'
    
    spec_lower = spec.lower()
    
    # 1. File input
    if patch_type == 'file' or (patch_type == 'auto' and os.path.isfile(spec)):
        try:
            with open(spec, 'rb') as f:
                data = f.read()
                return data, 'file'
        except Exception as e:
            print(f"[!] Failed to read patch file '{spec}': {e}")
            return None, 'error'
    
    # 2. Zero fill (special case)
    if patch_type == 'zero' or spec_lower.startswith('zero:'):
        try:
            if spec_lower.startswith('zero:'):
                size_str = spec[5:]  # Remove 'zero:' prefix
            else:
                size_str = spec
            
            # Parse size with K/M/G suffix
            size = parse_size_string(size_str)
            if size <= 0:
                print(f"[!] Invalid zero size: {size_str}")
                return None, 'error'
            if size > 100 * 1024 * 1024:  # 100MB limit
                print(f"[!] Zero size too large: {size} bytes (max 100MB)")
                return None, 'error'
            
            return b'\x00' * size, 'zero'
        except Exception as e:
            print(f"[!] Failed to parse zero size '{spec}': {e}")
            return None, 'error'
    
    # 3. Pattern format: value:count (e.g., "00:1024" or "FF:256")
    if ':' in spec and patch_type in ['auto', 'pattern']:
        # Check if it's a replace format first
        if spec.startswith('replace:'):
            pass  # Handle below
        else:
            parts = spec.split(':')
            if len(parts) == 2:
                value_str, count_str = parts
                try:
                    # Parse value (can be hex or decimal)
                    value_str_clean = value_str.strip()
                    if len(value_str_clean) == 2 and all(c in '0123456789ABCDEFabcdef' for c in value_str_clean):
                        value = bytes.fromhex(value_str_clean)[0]
                    else:
                        value = int(value_str_clean, 0) & 0xFF
                    
                    # Parse count (can have K/M suffix)
                    count = parse_size_string(count_str)
                    
                    if count <= 0:
                        print(f"[!] Invalid pattern count: {count}")
                        return None, 'error'
                    if count > 100 * 1024 * 1024:  # 100MB limit
                        print(f"[!] Pattern count too large: {count} (max 100MB)")
                        return None, 'error'
                    
                    return bytes([value] * count), 'pattern'
                except (ValueError, IndexError) as e:
                    if patch_type == 'pattern':
                        print(f"[!] Failed to parse pattern '{spec}': {e}")
                        return None, 'error'
                    # If auto mode and pattern fails, try other formats
    
    # 4. Replace format: old:new or replace:old:new
    if spec.count(':') >= 2 and (spec.startswith('replace:') or patch_type == 'replace'):
        try:
            if spec.startswith('replace:'):
                _, old_str, new_str = spec.split(':', 2)
            else:
                old_str, new_str = spec.split(':', 1)
            
            # Simple string replacement for now
            return new_str.encode('utf-8'), 'replace'
        except Exception as e:
            print(f"[!] Failed to parse replace format '{spec}': {e}")
            return None, 'error'
    
    # 5. Instruction format (placeholder)
    if spec.startswith('instruction:'):
        # TODO: Implement assembly instruction encoding
        print("[!] Instruction patching not yet implemented")
        print("[*] Supported architectures: ARM, x86, ARM64")
        return None, 'error'
    
    # 6. Hex string (default fallback)
    clean_hex = ''.join(spec.split()).replace('\n', '').replace('\r', '')
    
    # Validate hex string
    hex_chars = set('0123456789ABCDEFabcdef')
    if clean_hex and all(c in hex_chars for c in clean_hex):
        try:
            # Handle odd-length hex strings
            if len(clean_hex) % 2 != 0:
                clean_hex = '0' + clean_hex
            
            data = bytes.fromhex(clean_hex)
            return data, 'hex'
        except ValueError as e:
            print(f"[!] Invalid hex string '{spec}': {e}")
            return None, 'error'
    
    # 7. String (final fallback)
    try:
        data = spec.encode('utf-8')
        return data, 'string'
    except Exception as e:
        print(f"[!] Failed to encode string '{spec}': {e}")
        return None, 'error'

def parse_size_string(size_str: str) -> int:
    """
    Parse size string with K/M/G suffix support
    """
    if not size_str:
        return 0
    
    size_str = size_str.strip().upper()
    
    # Handle hex
    if size_str.startswith('0X'):
        try:
            return int(size_str[2:], 16)
        except ValueError:
            return 0
    
    # Handle K/M/G suffixes
    multipliers = {
        'K': 1024,
        'KB': 1024,
        'M': 1024 * 1024,
        'MB': 1024 * 1024,
        'G': 1024 * 1024 * 1024,
        'GB': 1024 * 1024 * 1024
    }
    
    for suffix, multiplier in multipliers.items():
        if size_str.endswith(suffix):
            number = size_str[:-len(suffix)]
            try:
                return int(float(number)) * multiplier
            except ValueError:
                break
    
    # Plain integer
    try:
        return int(size_str)
    except ValueError:
        try:
            return int(float(size_str))
        except ValueError:
            return 0

def execute_patch(dev, address: int, patch_data: bytes, 
                 verify: bool = True, args = None) -> bool:
    """
    Execute the actual patch operation with verification
    """
    max_retries = getattr(args, 'retries', 3) if args else 3
    chunk_size = getattr(args, 'chunk_size', 4096) if args else 4096
    dry_run = getattr(args, 'dry_run', False)
    backup_file = getattr(args, 'backup', None)
    
    if dry_run:
        print("[*] DRY RUN - No actual patching will be performed")
        print(f"[*] Would patch 0x{address:08X} with {len(patch_data)} bytes")
        return True
    
    # Create backup if requested
    if backup_file and not create_backup(dev, address, len(patch_data), backup_file):
        print(f"[!] Backup failed, aborting patch")
        return False
    
    # Split large patches into chunks
    if len(patch_data) > chunk_size:
        return execute_chunked_patch(dev, address, patch_data, chunk_size, 
                                    verify, max_retries)
    
    # Single chunk patch
    for attempt in range(max_retries + 1):
        try:
            print(f"[*] Patch attempt {attempt + 1}/{max_retries + 1}")
            
            # Build patch payload: address(4) + size(4) + data
            header = struct.pack("<II", address, len(patch_data))
            full_payload = header + patch_data
            
            # Send patch command
            resp = qslcl_dispatch(dev, "PATCH", full_payload)
            
            if not resp:
                print(f"[!] No response from PATCH command (attempt {attempt + 1})")
                if attempt < max_retries:
                    time.sleep(1)
                    continue
                else:
                    return False
            
            # Decode response
            status = decode_runtime_result(resp)
            print(f"[*] Patch response: {status.get('severity', 'UNKNOWN')} - "
                  f"{status.get('name', 'No status')}")
            
            if status.get("severity") == "SUCCESS":
                if verify:
                    if verify_patch(dev, address, patch_data):
                        return True
                    else:
                        print(f"[!] Patch verification failed (attempt {attempt + 1})")
                        if attempt < max_retries:
                            time.sleep(1)
                            continue
                        else:
                            return False
                else:
                    return True
            else:
                error_msg = status.get('name', 'UNKNOWN_ERROR')
                extra = status.get('extra', b'')
                if extra:
                    try:
                        error_msg += f" (extra: {extra[:32].hex()})"
                    except:
                        error_msg += " (extra data present)"
                print(f"[!] Patch command failed: {error_msg}")
                
                if attempt < max_retries:
                    time.sleep(1)
                    continue
                else:
                    return False
                
        except Exception as e:
            print(f"[!] Patch execution error (attempt {attempt + 1}): {e}")
            import traceback
            traceback.print_exc()
            
            if attempt < max_retries:
                time.sleep(1)
                continue
            else:
                return False
    
    return False

def execute_chunked_patch(dev, address: int, patch_data: bytes, 
                         chunk_size: int, verify: bool, max_retries: int) -> bool:
    """
    Execute patch in chunks for large patches
    """
    total_size = len(patch_data)
    chunks = (total_size + chunk_size - 1) // chunk_size
    
    print(f"[*] Patching {total_size} bytes in {chunks} chunks of {chunk_size} bytes")
    
    for chunk_idx in range(chunks):
        chunk_start = chunk_idx * chunk_size
        chunk_end = min(chunk_start + chunk_size, total_size)
        chunk_data = patch_data[chunk_start:chunk_end]
        chunk_addr = address + chunk_start
        
        print(f"[*] Chunk {chunk_idx + 1}/{chunks}: "
              f"0x{chunk_addr:08X} ({len(chunk_data)} bytes)")
        
        chunk_success = False
        for attempt in range(max_retries + 1):
            try:
                header = struct.pack("<II", chunk_addr, len(chunk_data))
                full_payload = header + chunk_data
                
                resp = qslcl_dispatch(dev, "PATCH", full_payload)
                
                if not resp:
                    print(f"[!] No response for chunk {chunk_idx + 1} (attempt {attempt + 1})")
                    if attempt < max_retries:
                        time.sleep(1)
                        continue
                    else:
                        return False
                
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    if verify:
                        if not verify_patch(dev, chunk_addr, chunk_data):
                            print(f"[!] Chunk {chunk_idx + 1} verification failed")
                            if attempt < max_retries:
                                time.sleep(1)
                                continue
                            else:
                                return False
                    chunk_success = True
                    break  # Chunk successful, move to next
                else:
                    print(f"[!] Chunk {chunk_idx + 1} failed: {status.get('name', 'UNKNOWN')}")
                    if attempt < max_retries:
                        time.sleep(1)
                        continue
                    else:
                        return False
                        
            except Exception as e:
                print(f"[!] Chunk {chunk_idx + 1} error: {e}")
                if attempt < max_retries:
                    time.sleep(1)
                    continue
                else:
                    return False
        
        if not chunk_success:
            return False
        
        # Update progress
        progress = (chunk_idx + 1) * 100 // chunks
        print(f"\r[*] Progress: {progress}%", end="")
        sys.stdout.flush()
    
    print()  # New line after progress
    return True

def create_backup(dev, address: int, size: int, backup_file: str) -> bool:
    """
    Create backup of area to be patched
    """
    print(f"[*] Creating backup to {backup_file}...")
    
    try:
        # Ensure backup directory exists
        backup_dir = os.path.dirname(os.path.abspath(backup_file))
        if backup_dir and not os.path.exists(backup_dir):
            os.makedirs(backup_dir, exist_ok=True)
        
        # Use READ command to backup the area
        backup_payload = struct.pack("<II", address, size)
        resp = qslcl_dispatch(dev, "READ", backup_payload)
        
        if not resp:
            print("[!] Failed to read area for backup")
            return False
        
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            print(f"[!] Backup read failed: {status.get('name', 'UNKNOWN')}")
            return False
        
        backup_data = status.get("extra", b"")
        if len(backup_data) != size:
            print(f"[!] Backup size mismatch: expected {size}, got {len(backup_data)}")
            print(f"[!] Will save what we got anyway")
        
        # Save backup
        with open(backup_file, 'wb') as f:
            f.write(backup_data)
        
        # Also save metadata
        meta_file = backup_file + ".meta"
        with open(meta_file, 'w') as f:
            import json
            metadata = {
                "address": address,
                "size": size,
                "timestamp": time.time(),
                "original_size": len(backup_data),
                "original_md5": hashlib.md5(backup_data).hexdigest() if backup_data else "",
                "original_sha256": hashlib.sha256(backup_data).hexdigest() if backup_data else ""
            }
            json.dump(metadata, f, indent=2)
        
        print(f"[✓] Backup saved: {backup_file} ({len(backup_data)} bytes)")
        print(f"[*] Metadata saved: {meta_file}")
        return True
        
    except Exception as e:
        print(f"[!] Backup failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def verify_patch(dev, address: int, expected_data: bytes) -> bool:
    """
    Verify that patch was applied correctly by reading back and comparing
    """
    print("[*] Verifying patch...")
    
    try:
        # Use READ command to verify the patched area
        verify_payload = struct.pack("<II", address, len(expected_data))
        resp = qslcl_dispatch(dev, "READ", verify_payload)
        
        if not resp:
            print("[!] No response during verification")
            return False
        
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            print(f"[!] Verification read failed: {status}")
            return False
        
        # Compare read data with expected patch
        read_data = status.get("extra", b"")
        if len(read_data) != len(expected_data):
            print(f"[!] Verification size mismatch: expected {len(expected_data)}, got {len(read_data)}")
            return False
            
        if read_data == expected_data:
            print("[✓] Patch verification successful")
            return True
        else:
            print("[!] Patch verification failed - data mismatch")
            
            # Find first mismatch
            for i in range(min(len(expected_data), len(read_data))):
                if expected_data[i] != read_data[i]:
                    print(f"    First mismatch at offset 0x{i:X}: "
                          f"expected 0x{expected_data[i]:02X}, got 0x{read_data[i]:02X}")
                    break
            
            # Show hex comparison
            show_len = min(64, len(expected_data), len(read_data))
            print(f"    Expected (first {show_len} bytes):")
            print_hex_dump(expected_data[:show_len], address)
            print(f"    Got (first {show_len} bytes):")
            print_hex_dump(read_data[:show_len], address)
            
            return False
            
    except Exception as e:
        print(f"[!] Verification error: {e}")
        return False

def print_hex_dump(data: bytes, base_address: int = 0):
    """
    Print hex dump of data
    """
    for i in range(0, len(data), 16):
        hex_part = ' '.join(f'{b:02X}' for b in data[i:i+8])
        if i + 8 < len(data):
            hex_part += '  ' + ' '.join(f'{b:02X}' for b in data[i+8:i+16])
        
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in data[i:i+16])
        
        print(f"    0x{base_address + i:08X}: {hex_part:<48}  {ascii_part}")