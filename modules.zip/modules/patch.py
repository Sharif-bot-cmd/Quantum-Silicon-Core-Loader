def cmd_patch(args):
    """
    Advanced binary patching command for QSLCL devices
    Supports multiple patch types and verification
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Check if PATCH command is available in QSLCLPAR
    if "PATCH" not in QSLCLPAR_DB:
        print("[!] PATCH command not available in loaded QSLCL binary")
        print("[*] Available commands:", [k for k in QSLCLPAR_DB.keys() if isinstance(k, str) and k.isalpha()][:10])
        return
    
    print("[*] QSLCL PATCH Engine")
    
    # Parse patch arguments
    if not hasattr(args, 'patch_args') or len(args.patch_args) < 2:
        print("""
Usage: patch <target> <patch_data> [options]

Target formats:
  address 0x12345678           - Raw memory address
  partition boot+0x1000        - Partition with offset
  symbol function_name         - Symbol name (if available)
  range 0x1000-0x2000          - Address range

Patch data formats:
  file patch.bin               - Binary patch file
  hex AABBCCDDEEFF             - Hex string
  pattern 00FF:1024            - Fill pattern (value:count)
  replace "old" "new"          - String replacement
  instruction "mov r0, 0x1234" - Assembly instruction

Examples:
  patch 0x880000 file boot_patch.bin
  patch boot+0x1000 hex "DEADBEEF"
  patch system pattern 00:4096
  patch 0x12345678 replace "old_string" "new_string"
        """)
        return
    
    target = args.patch_args[0]
    patch_data_spec = args.patch_args[1]
    patch_type = getattr(args, 'patch_type', 'auto')
    verify = not getattr(args, 'no_verify', False)
    
    # Parse target address
    target_addr = parse_patch_target(target, dev)
    if target_addr is None:
        print(f"[!] Invalid target: {target}")
        return
    
    # Prepare patch data
    patch_data = prepare_patch_data(patch_data_spec, patch_type)
    if patch_data is None:
        print(f"[!] Failed to prepare patch data from: {patch_data_spec}")
        return
    
    print(f"[*] Patching target: {target} (0x{target_addr:X})")
    print(f"[*] Patch size: {len(patch_data)} bytes")
    print(f"[*] Patch type: {patch_type}")
    
    # Execute patch operation
    success = execute_patch(dev, target_addr, patch_data, verify, args)
    
    if success:
        print("[✓] Patch applied successfully")
    else:
        print("[!] Patch failed")

def parse_patch_target(target, dev):
    """
    Parse various target formats into a memory address
    """
    # Raw hex address
    if target.startswith('0x'):
        try:
            return int(target, 16)
        except ValueError:
            pass
    
    # Decimal address
    if target.isdigit():
        return int(target)
    
    # Partition + offset (e.g., "boot+0x1000")
    if '+' in target:
        part_name, offset_str = target.split('+', 1)
        part_info = find_partition(part_name, dev)
        if part_info:
            try:
                offset = int(offset_str, 0)  # Auto-detect hex/dec
                return part_info['offset'] + offset
            except ValueError:
                pass
    
    # Partition only
    part_info = find_partition(target, dev)
    if part_info:
        return part_info['offset']
    
    # TODO: Add symbol table lookup if available
    # TODO: Add range parsing (start-end)
    
    return None

def find_partition(part_name, dev):
    """
    Find partition by name
    """
    parts = load_partitions(dev)
    for part in parts:
        if part['name'].lower() == part_name.lower():
            return part
    return None

def prepare_patch_data(spec, patch_type):
    """
    Prepare patch data from various input formats
    """
    # File input
    if os.path.isfile(spec):
        try:
            with open(spec, 'rb') as f:
                return f.read()
        except Exception as e:
            print(f"[!] Failed to read patch file: {e}")
            return None
    
    # Hex string
    if all(c in '0123456789ABCDEFabcdef' for c in spec.replace(' ', '').replace('\n', '')):
        try:
            clean_hex = spec.replace(' ', '').replace('\n', '')
            # Handle odd-length hex strings
            if len(clean_hex) % 2 != 0:
                clean_hex = '0' + clean_hex
            return bytes.fromhex(clean_hex)
        except ValueError:
            pass
    
    # Pattern format: value:count (e.g., "00:1024" or "FF:256")
    if ':' in spec and len(spec.split(':')) == 2:
        value_str, count_str = spec.split(':')
        try:
            if len(value_str) == 2 and all(c in '0123456789ABCDEFabcdef' for c in value_str):
                value = bytes.fromhex(value_str)[0]
                count = int(count_str)
                return bytes([value] * count)
        except (ValueError, IndexError):
            pass
    
    # String replacement (basic)
    if spec.startswith('"') and '"' in spec[1:]:
        # Simple string handling - in real implementation, parse properly
        return spec.encode('utf-8')
    
    # Default: treat as string
    return spec.encode('utf-8')

def execute_patch(dev, address, patch_data, verify=True, args=None):
    """
    Execute the actual patch operation with verification
    """
    max_retries = getattr(args, 'retries', 3) if args else 3
    chunk_size = getattr(args, 'chunk_size', 4096) if args else 4096
    
    # Build patch payload: address(4) + size(4) + data
    header = struct.pack("<II", address, len(patch_data))
    full_payload = header + patch_data
    
    for attempt in range(max_retries + 1):
        try:
            print(f"[*] Patch attempt {attempt + 1}/{max_retries + 1}")
            
            # Send patch command
            resp = qslcl_dispatch(dev, "PATCH", full_payload)
            
            if not resp:
                print(f"[!] No response from PATCH command (attempt {attempt + 1})")
                continue
            
            # Decode response
            status = decode_runtime_result(resp)
            print(f"[*] Patch response: {status}")
            
            if status.get("severity") == "SUCCESS":
                if verify:
                    if verify_patch(dev, address, patch_data):
                        return True
                    else:
                        print(f"[!] Patch verification failed (attempt {attempt + 1})")
                else:
                    return True
            else:
                print(f"[!] Patch command failed: {status.get('name', 'UNKNOWN')}")
                
        except Exception as e:
            print(f"[!] Patch execution error (attempt {attempt + 1}): {e}")
        
        if attempt < max_retries:
            print(f"[*] Retrying in 1 second...")
            time.sleep(1)
    
    return False

def verify_patch(dev, address, expected_data):
    """
    Verify that patch was applied correctly by reading back and comparing
    """
    print("[*] Verifying patch...")
    
    try:
        # Use PEEK or READ to verify the patched area
        if len(expected_data) <= 64:  # Small patches can use PEEK
            verify_payload = struct.pack("<II", address, len(expected_data))
            resp = qslcl_dispatch(dev, "PEEK", verify_payload)
        else:  # Larger patches use READ
            verify_payload = struct.pack("<II", address, len(expected_data))
            resp = qslcl_dispatch(dev, "READ", verify_payload)
        
        if not resp:
            print("[!] No response during verification")
            return False
        
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            print(f"[!] Verification read failed: {status}")
            return False
        
        # Compare read data with expected patch
        read_data = status.get("extra", b"")
        if read_data == expected_data:
            print("[✓] Patch verification successful")
            return True
        else:
            print("[!] Patch verification failed - data mismatch")
            print(f"    Expected: {expected_data.hex()[:64]}{'...' if len(expected_data) > 32 else ''}")
            print(f"    Got:      {read_data.hex()[:64]}{'...' if len(read_data) > 32 else ''}")
            return False
            
    except Exception as e:
        print(f"[!] Verification error: {e}")
        return False