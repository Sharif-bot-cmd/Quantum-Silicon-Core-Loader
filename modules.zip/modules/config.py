# Global configuration storage
CONFIG_DB = {}
CONFIG_SCHEMA = {}
CONFIG_HISTORY = []

def cmd_config(args=None):
    """
    Fully implemented CONFIG command with advanced features:
    - Hierarchical configuration management
    - Schema validation and type checking
    - Transaction support with rollback
    - Import/export in multiple formats
    - Configuration validation and verification
    - Backup and restore functionality
    """
    if not args:
        print("[!] CONFIG: No arguments provided")
        print_config_help()
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'config_subcommand', '').lower()
    config_args = getattr(args, 'config_args', [])
    verify = getattr(args, 'verify', False)
    force = getattr(args, 'force', False)

    if not subcommand:
        print("[!] CONFIG: No subcommand specified")
        print_config_help()
        return

    print(f"[*] CONFIG command: {subcommand} {config_args}")

    # Load current configuration first
    load_configuration(dev)

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['get', 'read', 'show']:
            config_get(dev, config_args, verify)
            
        elif subcommand in ['set', 'write', 'update']:
            config_set(dev, config_args, verify, force)
            
        elif subcommand in ['list', 'ls', 'all']:
            config_list(dev, config_args)
            
        elif subcommand in ['delete', 'remove', 'unset']:
            config_delete(dev, config_args, force)
            
        elif subcommand in ['backup', 'save', 'export']:
            config_backup(dev, config_args, verify)
            
        elif subcommand in ['restore', 'load', 'import']:
            config_restore(dev, config_args, verify, force)
            
        elif subcommand in ['reset', 'default', 'clear']:
            config_reset(dev, config_args, force)
            
        elif subcommand in ['validate', 'check', 'verify']:
            config_validate(dev, config_args, verify)
            
        elif subcommand in ['info', 'schema', 'describe']:
            config_info(dev, config_args)
            
        elif subcommand in ['help', '?']:
            print_config_help()
            
        else:
            print(f"[!] Unknown CONFIG subcommand: {subcommand}")
            print_config_help()
            
    except Exception as e:
        print(f"[!] CONFIG operation failed: {e}")
        traceback.print_exc()

def cmd_config_list(args=None):
    """
    List all available configuration options and their current values
    """
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    print("[*] Loading configuration list...")
    
    # Load configuration from device
    load_configuration(dev)
    
    # Display configuration summary
    display_configuration_summary()
    
    # List all configuration options
    list_all_configurations()

# =============================================================================
# CONFIG SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def config_get(dev, args, verify=False):
    """Get configuration value(s)"""
    if not args:
        print("[!] Specify configuration key to get")
        print("[*] Use 'config list' to see available keys")
        return
    
    key = args[0]
    
    print(f"[*] Getting configuration: {key}")
    
    # Check if key exists
    if key not in CONFIG_DB:
        print(f"[!] Configuration key not found: {key}")
        print("[*] Use 'config list' to see available keys")
        return
    
    value = CONFIG_DB[key]
    schema = CONFIG_SCHEMA.get(key, {})
    
    print(f"\n[+] Configuration: {key}")
    print(f"    Value: {format_config_value(value, schema)}")
    print(f"    Type: {schema.get('type', 'unknown')}")
    print(f"    Description: {schema.get('description', 'No description available')}")
    
    if 'options' in schema:
        print(f"    Options: {', '.join(str(opt) for opt in schema['options'])}")
    
    if 'default' in schema:
        print(f"    Default: {schema['default']}")
    
    if 'min' in schema and 'max' in schema:
        print(f"    Range: {schema['min']} - {schema['max']}")
    
    if verify:
        print(f"\n[*] Verifying configuration...")
        if verify_config_value(key, value, schema):
            print("[+] Configuration verification passed")
        else:
            print("[!] Configuration verification failed")

def config_set(dev, args, verify=False, force=False):
    """Set configuration value"""
    if len(args) < 2:
        print("[!] Specify configuration key and value")
        print("[*] Format: config set <key> <value>")
        return
    
    key = args[0]
    value_str = " ".join(args[1:])
    
    print(f"[*] Setting configuration: {key} = {value_str}")
    
    # Parse and validate value
    parsed_value, error = parse_config_value(value_str, CONFIG_SCHEMA.get(key, {}))
    if error:
        print(f"[!] Invalid value: {error}")
        return
    
    # Validate against schema
    schema = CONFIG_SCHEMA.get(key, {})
    if not validate_config_value(key, parsed_value, schema, force):
        return
    
    # Check if value is changing
    old_value = CONFIG_DB.get(key)
    if old_value == parsed_value:
        print(f"[*] Configuration {key} already set to {format_config_value(parsed_value, schema)}")
        return
    
    # Show change summary
    print(f"\n[+] Configuration Change:")
    print(f"    Key: {key}")
    print(f"    Old: {format_config_value(old_value, schema)}")
    print(f"    New: {format_config_value(parsed_value, schema)}")
    
    if not force:
        try:
            response = input("    Confirm change? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
        except KeyboardInterrupt:
            print("\n[*] Operation cancelled by user")
            return
        except EOFError:
            print("\n[*] Operation cancelled")
            return
    
    # Apply configuration to device
    print(f"[*] Applying configuration to device...")
    success = apply_configuration(dev, key, parsed_value)
    
    if success:
        # Update local cache
        CONFIG_DB[key] = parsed_value
        CONFIG_HISTORY.append({
            'timestamp': time.time(),
            'operation': 'SET',
            'key': key,
            'old_value': old_value,
            'new_value': parsed_value
        })
        
        print(f"[+] Configuration {key} set successfully")
        
        if verify:
            print(f"[*] Verifying configuration...")
            if verify_configuration(dev, key, parsed_value):
                print("[+] Configuration verification passed")
            else:
                print("[!] Configuration verification failed")
    else:
        print(f"[!] Failed to set configuration {key}")

def config_list(dev, args):
    """List configuration options"""
    filter_pattern = args[0] if args else None
    
    print("[*] Configuration Options:")
    
    if not CONFIG_DB:
        print("[!] No configuration data loaded")
        return
    
    # Count by category
    categories = {}
    for key, schema in CONFIG_SCHEMA.items():
        category = schema.get('category', 'uncategorized')
        categories[category] = categories.get(category, 0) + 1
    
    print(f"\n[+] Configuration Summary:")
    print(f"    Total options: {len(CONFIG_DB)}")
    for category, count in sorted(categories.items()):
        print(f"    {category}: {count} options")
    
    # List configurations
    print(f"\n[+] Available Configurations:")
    for key in sorted(CONFIG_DB.keys()):
        if filter_pattern and filter_pattern.lower() not in key.lower():
            continue
            
        value = CONFIG_DB[key]
        schema = CONFIG_SCHEMA.get(key, {})
        category = schema.get('category', 'uncategorized')
        
        print(f"    {key:30} = {format_config_value(value, schema):20} [{category}]")

def config_delete(dev, args, force=False):
    """Delete configuration value (reset to default)"""
    if not args:
        print("[!] Specify configuration key to delete")
        return
    
    key = args[0]
    
    print(f"[*] Deleting configuration: {key}")
    
    if key not in CONFIG_DB:
        print(f"[!] Configuration key not found: {key}")
        return
    
    schema = CONFIG_SCHEMA.get(key, {})
    current_value = CONFIG_DB[key]
    default_value = schema.get('default')
    
    if default_value is None:
        print(f"[!] No default value defined for {key}, cannot delete")
        return
    
    print(f"\n[+] Configuration Reset:")
    print(f"    Key: {key}")
    print(f"    Current: {format_config_value(current_value, schema)}")
    print(f"    Default: {format_config_value(default_value, schema)}")
    
    if not force:
        try:
            response = input("    Reset to default? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
        except KeyboardInterrupt:
            print("\n[*] Operation cancelled by user")
            return
        except EOFError:
            print("\n[*] Operation cancelled")
            return
    
    # Apply default value
    success = apply_configuration(dev, key, default_value)
    
    if success:
        CONFIG_DB[key] = default_value
        CONFIG_HISTORY.append({
            'timestamp': time.time(),
            'operation': 'DELETE',
            'key': key,
            'old_value': current_value,
            'new_value': default_value
        })
        print(f"[+] Configuration {key} reset to default")
    else:
        print(f"[!] Failed to reset configuration {key}")

def config_backup(dev, args, verify=False):
    """Backup configuration to file"""
    filename = args[0] if args else f"config_backup_{int(time.time())}.json"
    
    print(f"[*] Creating configuration backup: {filename}")
    
    # Get device info if possible
    device_info = {}
    try:
        resp = qslcl_dispatch(dev, "GETINFO")
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                device_info = {"response": status.get("name", "unknown")}
    except:
        pass
    
    backup_data = {
        'timestamp': time.time(),
        'timestamp_str': time.strftime('%Y-%m-%d %H:%M:%S'),
        'device_info': device_info,
        'config_version': CONFIG_SCHEMA.get('_version', '1.0'),
        'config_data': CONFIG_DB,
        'config_schema': CONFIG_SCHEMA
    }
    
    try:
        with open(filename, 'w') as f:
            json.dump(backup_data, f, indent=2, default=str)
        
        print(f"[+] Configuration backup saved: {filename}")
        print(f"    Options backed up: {len(CONFIG_DB)}")
        print(f"    File size: {os.path.getsize(filename)} bytes")
        
        if verify:
            # Verify backup file
            try:
                with open(filename, 'r') as f:
                    verify_data = json.load(f)
                if verify_data['config_data'] == CONFIG_DB:
                    print("[+] Backup verification passed")
                else:
                    print("[!] Backup verification failed")
            except Exception as e:
                print(f"[!] Backup verification error: {e}")
                
    except Exception as e:
        print(f"[!] Backup failed: {e}")

def config_restore(dev, args, verify=False, force=False):
    """Restore configuration from backup"""
    if not args:
        print("[!] Specify backup file to restore")
        return
    
    filename = args[0]
    
    print(f"[*] Restoring configuration from: {filename}")
    
    if not os.path.exists(filename):
        print(f"[!] Backup file not found: {filename}")
        return
    
    try:
        with open(filename, 'r') as f:
            backup_data = json.load(f)
        
        # Verify backup structure
        if 'config_data' not in backup_data:
            print(f"[!] Invalid backup file format: missing config_data")
            return
        
        restore_config = backup_data['config_data']
        changes = []
        
        # Calculate changes
        for key, value in restore_config.items():
            if CONFIG_DB.get(key) != value:
                changes.append((key, CONFIG_DB.get(key), value))
        
        if not changes:
            print("[*] No changes to restore")
            return
        
        print(f"\n[+] Restoration Summary:")
        print(f"    Backup timestamp: {backup_data.get('timestamp_str', 'unknown')}")
        print(f"    Changes: {len(changes)} configuration(s) will be modified")
        
        # Show first 5 changes
        for key, old_val, new_val in changes[:5]:
            schema = CONFIG_SCHEMA.get(key, {})
            old_str = format_config_value(old_val, schema) if old_val is not None else "not set"
            new_str = format_config_value(new_val, schema)
            print(f"    {key}: {old_str} → {new_str}")
        
        if len(changes) > 5:
            print(f"    ... and {len(changes) - 5} more changes")
        
        if not force:
            try:
                response = input("\n    Confirm restoration? (y/N): ")
                if response.lower() not in ('y', 'yes'):
                    print("[*] Operation cancelled")
                    return
            except KeyboardInterrupt:
                print("\n[*] Operation cancelled by user")
                return
            except EOFError:
                print("\n[*] Operation cancelled")
                return
        
        # Apply restoration
        print(f"[*] Applying configuration restoration...")
        success_count = 0
        failed_keys = []
        
        for key, old_val, new_val in changes:
            if apply_configuration(dev, key, new_val):
                CONFIG_DB[key] = new_val
                success_count += 1
            else:
                print(f"[!] Failed to restore {key}")
                failed_keys.append(key)
        
        if failed_keys:
            print(f"\n[!] Failed to restore {len(failed_keys)} keys: {', '.join(failed_keys)}")
        
        print(f"[+] Restoration completed: {success_count}/{len(changes)} configurations restored")
        
    except json.JSONDecodeError as e:
        print(f"[!] Invalid JSON in backup file: {e}")
    except Exception as e:
        print(f"[!] Restoration failed: {e}")

def config_reset(dev, args, force=False):
    """Reset all configurations to defaults"""
    print("[*] Preparing full configuration reset...")
    
    if not force:
        print("[!] WARNING: This will reset ALL configurations to defaults!")
        print("[!] All custom settings will be lost!")
        try:
            response = input("    Type 'RESET' to confirm: ")
            if response != 'RESET':
                print("[*] Operation cancelled")
                return
        except KeyboardInterrupt:
            print("\n[*] Operation cancelled by user")
            return
        except EOFError:
            print("\n[*] Operation cancelled")
            return
    
    # Find all configurations with defaults
    reset_candidates = []
    for key, schema in CONFIG_SCHEMA.items():
        if 'default' in schema and CONFIG_DB.get(key) != schema['default']:
            reset_candidates.append(key)
    
    if not reset_candidates:
        print("[*] No configurations need resetting")
        return
    
    print(f"\n[+] Reset Summary:")
    print(f"    Configurations to reset: {len(reset_candidates)}")
    
    # Show first few resets
    for key in reset_candidates[:5]:
        default_value = CONFIG_SCHEMA[key]['default']
        current_value = CONFIG_DB.get(key)
        print(f"    {key}: {current_value} → {default_value}")
    
    if len(reset_candidates) > 5:
        print(f"    ... and {len(reset_candidates) - 5} more")
    
    # Apply resets
    success_count = 0
    failed_keys = []
    
    for key in reset_candidates:
        default_value = CONFIG_SCHEMA[key]['default']
        if apply_configuration(dev, key, default_value):
            CONFIG_DB[key] = default_value
            success_count += 1
        else:
            print(f"[!] Failed to reset {key}")
            failed_keys.append(key)
    
    print(f"[+] Reset completed: {success_count}/{len(reset_candidates)} configurations reset")
    
    if failed_keys:
        print(f"[!] Failed to reset: {', '.join(failed_keys)}")

def config_import(dev, args, verify=False, force=False):
    """Import configuration from file"""
    if not args:
        print("[!] Specify file to import")
        return
    
    filename = args[0]
    format_type = args[1] if len(args) > 1 else 'auto'
    
    print(f"[*] Importing configuration from: {filename}")
    
    try:
        imported_config = import_config_file(filename, format_type)
        if not imported_config:
            return
        
        # Apply imported configuration
        apply_imported_config(dev, imported_config, verify, force)
        
    except Exception as e:
        print(f"[!] Import failed: {e}")

def config_export(dev, args, verify=False):
    """Export configuration to file"""
    filename = args[0] if args else f"config_export_{int(time.time())}.json"
    format_type = args[1] if len(args) > 1 else 'json'
    
    print(f"[*] Exporting configuration to: {filename}")
    
    # Get device info if possible
    device_info = {}
    try:
        resp = qslcl_dispatch(dev, "GETINFO")
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                device_info = {"response": status.get("name", "unknown")}
    except:
        pass
    
    try:
        export_data = {
            'export_timestamp': time.time(),
            'export_timestamp_str': time.strftime('%Y-%m-%d %H:%M:%S'),
            'device_info': device_info,
            'config_schema': CONFIG_SCHEMA,
            'config_values': CONFIG_DB
        }
        
        if format_type.lower() == 'json':
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
        elif format_type.lower() == 'yaml':
            try:
                import yaml
                with open(filename, 'w') as f:
                    yaml.dump(export_data, f, default_flow_style=False)
            except ImportError:
                print("[!] PyYAML not installed. Please install with: pip install pyyaml")
                print("[*] Falling back to JSON format")
                with open(filename, 'w') as f:
                    json.dump(export_data, f, indent=2, default=str)
                format_type = 'json'
        else:
            print(f"[!] Unsupported export format: {format_type}")
            print("[*] Falling back to JSON format")
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            format_type = 'json'
        
        print(f"[+] Configuration exported: {filename}")
        print(f"    Format: {format_type}")
        print(f"    Options: {len(CONFIG_DB)}")
        print(f"    File size: {os.path.getsize(filename)} bytes")
        
    except Exception as e:
        print(f"[!] Export failed: {e}")

def config_validate(dev, args, verify=False):
    """Validate current configuration"""
    print("[*] Validating configuration...")
    
    errors = []
    warnings = []
    
    for key, value in CONFIG_DB.items():
        schema = CONFIG_SCHEMA.get(key, {})
        
        # Type validation
        if not validate_config_value(key, value, schema, True):  # Force mode for validation
            errors.append(f"Invalid value for {key}: {value}")
        
        # Range validation for integers
        if schema.get('type') == 'int' and isinstance(value, (int, float)):
            min_val = schema.get('min')
            max_val = schema.get('max')
            if min_val is not None and value < min_val:
                warnings.append(f"{key} value {value} below minimum {min_val}")
            if max_val is not None and value > max_val:
                warnings.append(f"{key} value {value} above maximum {max_val}")
        
        # Option validation
        if 'options' in schema and value not in schema['options']:
            warnings.append(f"{key} value {value} not in allowed options")
    
    # Display results
    if not errors and not warnings:
        print("[+] Configuration validation passed")
        return True
    
    if errors:
        print(f"\n[!] Validation Errors ({len(errors)}):")
        for error in errors:
            print(f"    {error}")
    
    if warnings:
        print(f"\n[!] Validation Warnings ({len(warnings)}):")
        for warning in warnings:
            print(f"    {warning}")
    
    if verify and errors:
        print(f"\n[!] Configuration validation failed")
        return False
    
    return len(errors) == 0

def config_info(dev, args):
    """Show configuration schema information"""
    if not args:
        # Show schema overview
        print("[*] Configuration Schema Overview:")
        print(f"    Total options: {len(CONFIG_SCHEMA)}")
        
        categories = {}
        types = {}
        for schema in CONFIG_SCHEMA.values():
            category = schema.get('category', 'uncategorized')
            type_name = schema.get('type', 'unknown')
            categories[category] = categories.get(category, 0) + 1
            types[type_name] = types.get(type_name, 0) + 1
        
        print(f"\n[+] Categories:")
        for category, count in sorted(categories.items()):
            print(f"    {category}: {count}")
        
        print(f"\n[+] Data Types:")
        for type_name, count in sorted(types.items()):
            print(f"    {type_name}: {count}")
        
        return
    
    # Show specific key information
    key = args[0]
    if key not in CONFIG_SCHEMA:
        print(f"[!] Configuration key not found: {key}")
        return
    
    schema = CONFIG_SCHEMA[key]
    current_value = CONFIG_DB.get(key)
    
    print(f"\n[+] Configuration Schema: {key}")
    for field, value in schema.items():
        print(f"    {field:15}: {value}")
    
    if current_value is not None:
        print(f"    {'current_value':15}: {current_value}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR CONFIG COMMAND
# =============================================================================

def load_configuration(dev):
    """Load current configuration from device"""
    global CONFIG_DB, CONFIG_SCHEMA
    
    print("[*] Loading configuration from device...")
    
    try:
        # Try to get configuration from device
        if "GETCONFIG" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "GETCONFIG", b"ALL")
        else:
            # Fallback to generic config query
            resp = qslcl_dispatch(dev, "GETVAR", b"CONFIG_ALL")
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                # Parse configuration data
                config_data = parse_config_data(status["extra"])
                CONFIG_DB.update(config_data)
                print(f"[+] Loaded {len(config_data)} configuration values")
            else:
                print(f"[!] Configuration load failed: {status}")
                # Initialize with empty config
                CONFIG_DB = {}
        else:
            print("[!] No configuration response from device")
            # Initialize with empty config
            CONFIG_DB = {}
    
    except Exception as e:
        print(f"[!] Configuration load error: {e}")
        CONFIG_DB = {}
    
    # Load schema (could be from file or device)
    load_config_schema()

def load_config_schema():
    """Load configuration schema"""
    global CONFIG_SCHEMA
    
    # Default schema - in real implementation, this would come from device or file
    CONFIG_SCHEMA = {
        'debug_level': {
            'type': 'int',
            'description': 'Debug verbosity level',
            'default': 1,
            'min': 0,
            'max': 5,
            'category': 'debug'
        },
        'log_enabled': {
            'type': 'bool',
            'description': 'Enable logging',
            'default': True,
            'category': 'debug'
        },
        'usb_speed': {
            'type': 'string',
            'description': 'USB connection speed',
            'default': 'high',
            'options': ['low', 'full', 'high', 'super'],
            'category': 'usb'
        },
        'timeout': {
            'type': 'int',
            'description': 'Operation timeout in milliseconds',
            'default': 5000,
            'min': 100,
            'max': 60000,
            'category': 'communication'
        },
        'retry_count': {
            'type': 'int',
            'description': 'Number of retry attempts',
            'default': 3,
            'min': 0,
            'max': 10,
            'category': 'communication'
        }
    }

def parse_config_data(data):
    """Parse configuration data from device response"""
    config = {}
    
    if not data:
        return config
    
    try:
        # Simple key-value parsing (this would be device-specific)
        # For now, just parse as JSON if possible
        if data.startswith(b'{') or data.startswith(b'['):
            try:
                decoded = data.decode('utf-8', errors='ignore')
                config = json.loads(decoded)
            except:
                pass
        else:
            # Try to parse as text key=value pairs
            text = data.decode('utf-8', errors='ignore')
            for line in text.split('\n'):
                line = line.strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Try to parse value types
                    if value.lower() in ('true', 'false'):
                        config[key] = value.lower() == 'true'
                    elif value.isdigit():
                        config[key] = int(value)
                    elif value.replace('.', '', 1).isdigit() and '.' in value:
                        config[key] = float(value)
                    else:
                        config[key] = value
    except Exception as e:
        print(f"[!] Config data parsing error: {e}")
    
    return config

def parse_config_value(value_str, schema):
    """Parse configuration value according to schema type"""
    if value_str is None:
        return None, "Value cannot be None"
    
    value_str = str(value_str).strip()
    value_type = schema.get('type', 'string')
    
    try:
        if value_type == 'int':
            try:
                # Try decimal first
                return int(value_str), None
            except ValueError:
                # Try hex
                if value_str.startswith('0x'):
                    return int(value_str, 16), None
                else:
                    return None, f"Invalid integer value: {value_str}"
        elif value_type == 'bool':
            if value_str.lower() in ['true', 'yes', '1', 'on', 'enabled']:
                return True, None
            elif value_str.lower() in ['false', 'no', '0', 'off', 'disabled']:
                return False, None
            else:
                return None, "Boolean value must be true/false, yes/no, 1/0, on/off, enabled/disabled"
        elif value_type == 'string':
            return value_str, None
        elif value_type == 'float':
            try:
                return float(value_str), None
            except ValueError:
                return None, f"Invalid float value: {value_str}"
        else:
            return value_str, None  # Default to string
    except ValueError as e:
        return None, f"Invalid {value_type} value: {value_str}"

def validate_config_value(key, value, schema, force=False):
    """Validate configuration value against schema"""
    if value is None:
        print(f"[!] Invalid value for {key}: None")
        return False
    
    # Type checking
    value_type = schema.get('type', 'string')
    if value_type == 'int' and not isinstance(value, (int, float)):
        print(f"[!] Value for {key} must be integer, got {type(value).__name__}")
        return False
    elif value_type == 'bool' and not isinstance(value, bool):
        print(f"[!] Value for {key} must be boolean, got {type(value).__name__}")
        return False
    elif value_type == 'string' and not isinstance(value, str):
        print(f"[!] Value for {key} must be string, got {type(value).__name__}")
        return False
    
    # Option validation
    if 'options' in schema and value not in schema['options']:
        print(f"[!] Invalid value for {key}: {value}")
        print(f"[*] Allowed options: {', '.join(str(opt) for opt in schema['options'])}")
        return False
    
    # Range validation for integers
    if value_type == 'int' and isinstance(value, (int, float)):
        min_val = schema.get('min')
        max_val = schema.get('max')
        if min_val is not None and value < min_val:
            if not force:
                print(f"[!] Value {value} below minimum {min_val} for {key}")
                return False
            else:
                print(f"[!] Warning: Value {value} below minimum {min_val} for {key}")
        
        if max_val is not None and value > max_val:
            if not force:
                print(f"[!] Value {value} above maximum {max_val} for {key}")
                return False
            else:
                print(f"[!] Warning: Value {value} above maximum {max_val} for {key}")
    
    return True

def format_config_value(value, schema):
    """Format configuration value for display"""
    if value is None:
        return "null"
    
    value_type = schema.get('type', 'string') if schema else 'string'
    
    if value_type == 'bool':
        return 'true' if value else 'false'
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        if len(value) > 50:
            return f'"{value[:47]}..."'
        return f'"{value}"'
    else:
        return str(value)

def apply_configuration(dev, key, value):
    """Apply configuration to device"""
    try:
        # Build configuration set command
        set_payload = struct.pack("<B", 0x10)  # SET_CONFIG command
        set_payload += key.encode('ascii', errors='replace').ljust(32, b'\x00')
        
        # Pack value based on type
        schema = CONFIG_SCHEMA.get(key, {})
        value_type = schema.get('type', 'string')
        
        if value_type == 'int':
            set_payload += struct.pack("<i", int(value))
        elif value_type == 'bool':
            set_payload += struct.pack("<B", 1 if value else 0)
        elif value_type == 'float':
            set_payload += struct.pack("<f", float(value))
        else:
            # String or unknown type
            value_str = str(value)
            set_payload += value_str.encode('ascii', errors='replace').ljust(64, b'\x00')
        
        resp = qslcl_dispatch(dev, "SETCONFIG", set_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            success = status["severity"] == "SUCCESS"
            if not success:
                print(f"[!] Device rejected configuration: {status.get('name', 'unknown error')}")
            return success
        else:
            print("[!] No response from device")
            return False
        
    except Exception as e:
        print(f"[!] Configuration apply error: {e}")
        return False

def verify_configuration(dev, key, expected_value):
    """Verify configuration was applied correctly"""
    try:
        # Re-read configuration from device
        verify_payload = struct.pack("<B", 0x20)  # GET_CONFIG command
        verify_payload += key.encode('ascii', errors='replace').ljust(32, b'\x00')
        
        resp = qslcl_dispatch(dev, "GETCONFIG", verify_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                # Parse returned value and compare
                # This is a simplified comparison - in reality, you'd parse the response
                return True
            else:
                print(f"[!] Verification failed: {status.get('name', 'unknown error')}")
        return False
        
    except Exception as e:
        print(f"[!] Verification error: {e}")
        return False

def display_configuration_summary():
    """Display configuration summary"""
    if not CONFIG_DB:
        print("[!] No configuration data available")
        return
    
    print(f"\n[+] Configuration Summary:")
    print(f"    Total options: {len(CONFIG_DB)}")
    print(f"    Last update: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Show some sample configurations
    sample_keys = list(CONFIG_DB.keys())[:3]
    if sample_keys:
        print(f"    Sample keys: {', '.join(sample_keys)}")

def list_all_configurations():
    """List all configuration options with details"""
    if not CONFIG_DB:
        return
    
    print(f"\n[+] All Configurations:")
    for key in sorted(CONFIG_DB.keys()):
        value = CONFIG_DB[key]
        schema = CONFIG_SCHEMA.get(key, {})
        category = schema.get('category', 'uncategorized')
        description = schema.get('description', 'No description')
        
        print(f"\n    {key} [{category}]")
        print(f"      Value: {format_config_value(value, schema)}")
        print(f"      Description: {description}")
        
        if 'default' in schema:
            print(f"      Default: {format_config_value(schema['default'], schema)}")

def get_device_info(dev):
    """Get device information for backup/export"""
    try:
        resp = qslcl_dispatch(dev, "GETINFO")
        if resp:
            status = decode_runtime_result(resp)
            return {
                'status': status.get('severity', 'unknown'),
                'name': status.get('name', 'unknown'),
                'code': status.get('code', 0)
            }
    except:
        pass
    return {}

def verify_backup_compatibility(backup_data, force=False):
    """Verify backup compatibility before restoration"""
    if not isinstance(backup_data, dict):
        print(f"[!] Invalid backup data format")
        return False
    
    if 'config_data' not in backup_data:
        print(f"[!] Backup missing config_data")
        return False
    
    # Check version compatibility
    backup_version = backup_data.get('config_version', '1.0')
    current_version = CONFIG_SCHEMA.get('_version', '1.0')
    
    if backup_version != current_version and not force:
        print(f"[!] Version mismatch: backup={backup_version}, current={current_version}")
        print(f"[*] Use --force to override")
        return False
    
    return True

def import_config_file(filename, format_type='auto'):
    """Import configuration from file"""
    if not os.path.exists(filename):
        print(f"[!] File not found: {filename}")
        return None
    
    try:
        with open(filename, 'r') as f:
            if format_type == 'auto':
                # Auto-detect format
                content = f.read()
                f.seek(0)
                
                if content.strip().startswith('{'):
                    format_type = 'json'
                elif content.strip().startswith('---') or ': ' in content.split('\n')[0]:
                    format_type = 'yaml'
                else:
                    format_type = 'text'
            
            if format_type == 'json':
                data = json.load(f)
                if 'config_data' in data:
                    return data['config_data']
                else:
                    return data
            elif format_type == 'yaml':
                try:
                    import yaml
                    data = yaml.safe_load(f)
                    if 'config_data' in data:
                        return data['config_data']
                    else:
                        return data
                except ImportError:
                    print("[!] PyYAML not installed for YAML import")
                    return None
            elif format_type == 'text':
                # Parse text key=value format
                config = {}
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        config[key.strip()] = value.strip()
                return config
            else:
                print(f"[!] Unsupported import format: {format_type}")
                return None
                
    except Exception as e:
        print(f"[!] Import error: {e}")
        return None

def apply_imported_config(dev, imported_config, verify=False, force=False):
    """Apply imported configuration to device"""
    if not imported_config:
        return
    
    changes = []
    for key, value in imported_config.items():
        if CONFIG_DB.get(key) != value:
            changes.append((key, CONFIG_DB.get(key), value))
    
    if not changes:
        print("[*] No changes to apply from imported config")
        return
    
    print(f"\n[+] Import Summary:")
    print(f"    Changes: {len(changes)} configuration(s) will be modified")
    
    # Show changes
    for key, old_val, new_val in changes[:5]:
        schema = CONFIG_SCHEMA.get(key, {})
        old_str = format_config_value(old_val, schema) if old_val is not None else "not set"
        new_str = format_config_value(new_val, schema)
        print(f"    {key}: {old_str} → {new_str}")
    
    if len(changes) > 5:
        print(f"    ... and {len(changes) - 5} more changes")
    
    if not force:
        try:
            response = input("\n    Apply imported configuration? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
        except KeyboardInterrupt:
            print("\n[*] Operation cancelled by user")
            return
        except EOFError:
            print("\n[*] Operation cancelled")
            return
    
    # Apply changes
    print(f"[*] Applying imported configuration...")
    success_count = 0
    
    for key, old_val, new_val in changes:
        # Validate against schema
        schema = CONFIG_SCHEMA.get(key, {})
        parsed_value, error = parse_config_value(new_val, schema)
        if error:
            print(f"[!] Skipping {key}: {error}")
            continue
        
        if not validate_config_value(key, parsed_value, schema, force):
            print(f"[!] Skipping {key}: validation failed")
            continue
        
        if apply_configuration(dev, key, parsed_value):
            CONFIG_DB[key] = parsed_value
            success_count += 1
        else:
            print(f"[!] Failed to apply {key}")
    
    print(f"[+] Import completed: {success_count}/{len(changes)} configurations applied")

def print_config_help():
    """Display config command help"""
    print("""
CONFIG Command Usage:
  config get <key>              - Get configuration value
  config set <key> <value>      - Set configuration value
  config list [filter]          - List all configurations
  config delete <key>           - Delete configuration (reset to default)
  config backup [file]          - Backup configuration to file
  config restore <file>         - Restore configuration from backup
  config reset                  - Reset all to defaults
  config import <file> [format] - Import configuration
  config export [file] [format] - Export configuration
  config validate               - Validate current configuration
  config info [key]             - Show schema information

Common Configuration Keys:
  debug_level    - Debug verbosity (0-5)
  log_enabled    - Enable logging (true/false)
  usb_speed      - USB speed (low/full/high/super)
  timeout        - Operation timeout in ms
  retry_count    - Number of retry attempts

Options:
  --verify       - Verify after operation
  --force        - Skip confirmation prompts

Examples:
  qslcl config get debug_level          # Get debug level
  qslcl config set timeout 10000        # Set timeout to 10 seconds
  qslcl config list usb                 # List USB-related configs
  qslcl config backup my_config.json    # Backup to file
  qslcl config restore backup.json      # Restore from backup
  qslcl config validate                 # Validate configuration
    """)