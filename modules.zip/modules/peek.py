def cmd_peek(args=None):
    """
    Fully implemented PEEK command with advanced features:
    - Multiple address formats (hex, decimal, symbolic, expressions)
    - Flexible data type interpretation
    - Array and structure viewing
    - Memory region detection
    - Hex dump and formatted output
    - Cross-references and annotations
    """
    if not args:
        print("[!] PEEK: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    address_str = getattr(args, 'address', '')
    size = getattr(args, 'size', 4)
    data_type = getattr(args, 'data_type', 'auto')
    count = getattr(args, 'count', 1)
    show_hexdump = getattr(args, 'hexdump', False)
    show_disasm = getattr(args, 'disasm', False)

    if not address_str:
        print("[!] PEEK: No address specified")
        return

    print(f"[*] PEEK command: address={address_str}")

    # =========================================================================
    # 1. ADDRESS RESOLUTION
    # =========================================================================
    try:
        address = resolve_address(address_str, dev)
        if address is None:
            print(f"[!] Could not resolve address: {address_str}")
            return
        
        print(f"[+] Resolved address: 0x{address:08X}")
        
    except Exception as e:
        print(f"[!] Address resolution failed: {e}")
        return

    # =========================================================================
    # 2. SIZE AND DATA TYPE DETERMINATION
    # =========================================================================
    if data_type == 'auto':
        # Auto-detect based on size and address patterns
        data_type = auto_detect_data_type(address, size, count)
        print(f"[+] Auto-detected data type: {data_type}")

    # Calculate total bytes to read
    type_sizes = {
        'uint8': 1, 'int8': 1, 'char': 1,
        'uint16': 2, 'int16': 2, 'short': 2,
        'uint32': 4, 'int32': 4, 'float': 4, 'int': 4,
        'uint64': 8, 'int64': 8, 'double': 8, 'long': 8,
        'string': size, 'hex': size, 'bytes': size
    }
    
    bytes_per_element = type_sizes.get(data_type, 4)
    total_bytes = bytes_per_element * count

    if total_bytes > 1024 * 1024:  # 1MB limit
        print(f"[!] Requested size too large: {total_bytes} bytes")
        return

    print(f"[*] Reading {total_bytes} bytes from 0x{address:08X}")

    # =========================================================================
    # 3. MEMORY READ OPERATION
    # =========================================================================
    try:
        # Read memory data
        read_payload = struct.pack("<II", address, total_bytes)
        
        if "READ" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "READ", read_payload)
        elif "PEEK" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "PEEK", read_payload)
        else:
            # Fallback
            cmd = f"READ 0x{address:08X} 0x{total_bytes:04X}"
            resp = qslcl_dispatch(dev, "READ", cmd.encode())

        if not resp:
            print("[!] No response from device")
            return

        status = decode_runtime_result(resp)
        if status["severity"] != "SUCCESS":
            print(f"[!] Read failed: {status}")
            return

        raw_data = status["extra"]
        if len(raw_data) < total_bytes:
            print(f"[!] Short read: got {len(raw_data)} bytes, expected {total_bytes}")
            # Continue with available data
            raw_data = raw_data.ljust(total_bytes, b'\x00')

    except Exception as e:
        print(f"[!] Memory read failed: {e}")
        return

    # =========================================================================
    # 4. DATA INTERPRETATION AND DISPLAY
    # =========================================================================
    print(f"\n[*] Memory at 0x{address:08X}:")

    # Detect memory region type
    region_info = detect_memory_region(address, dev)
    if region_info:
        print(f"[+] Region: {region_info}")

    # Show hex dump for larger reads or when requested
    if total_bytes > 16 or show_hexdump:
        print("\n" + format_hex_dump(raw_data, address, bytes_per_element))

    # Interpret data based on type
    print(f"\n[*] Interpretation as {data_type}:")

    try:
        if data_type in ['uint8', 'int8', 'char']:
            display_integer_data(raw_data, 1, count, data_type, address)
        elif data_type in ['uint16', 'int16', 'short']:
            display_integer_data(raw_data, 2, count, data_type, address)
        elif data_type in ['uint32', 'int32', 'int', 'float']:
            if data_type == 'float':
                display_float_data(raw_data, count, address)
            else:
                display_integer_data(raw_data, 4, count, data_type, address)
        elif data_type in ['uint64', 'int64', 'long', 'double']:
            if data_type == 'double':
                display_double_data(raw_data, count, address)
            else:
                display_integer_data(raw_data, 8, count, data_type, address)
        elif data_type == 'string':
            display_string_data(raw_data, address)
        elif data_type in ['hex', 'bytes']:
            display_hex_data(raw_data, address)
        else:
            # Default to 32-bit integers
            display_integer_data(raw_data, 4, count, 'uint32', address)

    except Exception as e:
        print(f"[!] Data interpretation failed: {e}")
        # Fallback to raw hex
        print(f"Raw data: {raw_data.hex()}")

    # =========================================================================
    # 5. ADVANCED ANALYSIS
    # =========================================================================
    if total_bytes >= 4:
        # Show potential pointers and cross-references
        print(f"\n[*] Pointer Analysis:")
        analyze_pointers(raw_data, address, dev)

    if show_disasm and total_bytes >= 4:
        # Disassemble if possible
        print(f"\n[*] Disassembly:")
        disassemble_data(raw_data, address)

    # Show memory attributes if available
    print(f"\n[*] Memory Attributes:")
    display_memory_attributes(address, raw_data, dev)

# =============================================================================
# SUPPORTING FUNCTIONS FOR PEEK COMMAND
# =============================================================================

def resolve_address(address_str, dev):
    """
    Resolve address string to numeric address with support for:
    - Hex: 0x12345678, 12345678h
    - Decimal: 12345678
    - Partition names: boot, system, etc.
    - Partition offsets: boot+0x1000
    - Registers: r0, r1, sp, pc, etc.
    - Symbols: if symbol table available
    - Expressions: 0x1000 + 0x200 * 2
    """
    address_str = address_str.strip().lower()
    
    # Partition names
    partitions = load_partitions(dev)
    if '+' in address_str:
        # Partition+offset format
        part_name, offset_str = address_str.split('+', 1)
        for part in partitions:
            if part['name'].lower() == part_name.lower():
                offset = parse_address(offset_str)
                return part['offset'] + offset
    
    # Check for partition name alone
    for part in partitions:
        if part['name'].lower() == address_str:
            return part['offset']
    
    # Register names
    register_map = {
        'r0': 0x00, 'r1': 0x04, 'r2': 0x08, 'r3': 0x0C,
        'r4': 0x10, 'r5': 0x14, 'r6': 0x18, 'r7': 0x1C,
        'r8': 0x20, 'r9': 0x24, 'r10': 0x28, 'r11': 0x2C,
        'r12': 0x30, 'sp': 0x34, 'lr': 0x38, 'pc': 0x3C,
        'cpsr': 0x40
    }
    if address_str in register_map:
        return register_map[address_str]
    
    # Try to evaluate as expression
    try:
        # Handle hex formats
        expr = address_str.replace('h', '').replace('h', '')
        if '0x' in expr or any(c in 'abcdef' for c in expr):
            # Contains hex characters, try hex evaluation
            return eval(expr.replace('0x', '0x'))
        else:
            # Try decimal evaluation
            return eval(expr)
    except:
        # Final attempt: direct hex/decimal parsing
        return parse_address(address_str)

def auto_detect_data_type(address, size, count):
    """Auto-detect data type based on address patterns and size"""
    
    # Common hardware register patterns
    if address & 0xFF000000 == 0x10000000:  # Common peripheral base
        return 'uint32'
    elif address & 0xF0000000 == 0x40000000:  # STM32 peripheral
        return 'uint32'
    elif address & 0xFFF00000 == 0x80000000:  # DRAM region
        if size >= 8:
            return 'uint64'
        else:
            return 'uint32'
    
    # Size-based detection
    if size == 1:
        return 'uint8'
    elif size == 2:
        return 'uint16'
    elif size == 4:
        return 'uint32'
    elif size == 8:
        return 'uint64'
    elif size > 8 and count == 1:
        return 'bytes'
    else:
        return 'uint32'

def detect_memory_region(address, dev):
    """Detect what type of memory region this address belongs to"""
    partitions = load_partitions(dev)
    
    for part in partitions:
        if part['offset'] <= address < part['offset'] + part['size']:
            return f"Partition: {part['name']} (0x{part['offset']:08X}-0x{part['offset'] + part['size']:08X})"
    
    # Common memory regions
    if 0x00000000 <= address < 0x40000000:
        return "Memory: Low RAM/Peripheral"
    elif 0x40000000 <= address < 0x60000000:
        return "Memory: Peripheral Space"
    elif 0x80000000 <= address < 0xC0000000:
        return "Memory: DRAM/Cached"
    elif 0xC0000000 <= address < 0xFFFFFFFF:
        return "Memory: Kernel/Device"
    elif address >= 0x100000000:
        return "Memory: 64-bit Space"
    
    return "Memory: Unknown Region"

def format_hex_dump(data, base_address, bytes_per_element=1):
    """Create formatted hex dump with ASCII representation"""
    result = []
    line_size = 16
    
    for i in range(0, len(data), line_size):
        line_data = data[i:i+line_size]
        hex_part = ' '.join(f'{b:02x}' for b in line_data)
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in line_data)
        
        # Highlight current element if applicable
        if bytes_per_element > 1 and i % bytes_per_element == 0:
            result.append(f"→ 0x{base_address + i:08x}: {hex_part:<48} |{ascii_part}|")
        else:
            result.append(f"  0x{base_address + i:08x}: {hex_part:<48} |{ascii_part}|")
    
    return '\n'.join(result)

def display_integer_data(data, element_size, count, data_type, base_address):
    """Display integer data with proper formatting"""
    fmt_char = {
        'uint8': ('B', False), 'int8': ('b', True),
        'uint16': ('H', False), 'int16': ('h', True),
        'uint32': ('I', False), 'int32': ('i', True),
        'uint64': ('Q', False), 'int64': ('q', True)
    }.get(data_type, ('I', False))
    
    fmt_str, signed = fmt_char
    
    for i in range(0, min(count * element_size, len(data)), element_size):
        element_data = data[i:i+element_size]
        if len(element_data) < element_size:
            element_data = element_data.ljust(element_size, b'\x00')
        
        try:
            value = struct.unpack('<' + fmt_str, element_data)[0]
            addr = base_address + i
            
            # Format output
            if element_size == 1:
                hex_fmt = f"0x{value:02x}"
                dec_fmt = f"{value}" if not signed else f"{value:4d}"
                char_fmt = f"'{chr(value) if 32 <= value < 127 else '?'}'"
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt:8} = {char_fmt}")
            
            elif element_size == 2:
                hex_fmt = f"0x{value:04x}"
                dec_fmt = f"{value}" if not signed else f"{value:6d}"
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}")
            
            elif element_size == 4:
                hex_fmt = f"0x{value:08x}"
                dec_fmt = f"{value}" if not signed else f"{value:11d}"
                # Check for common magic values
                magic = check_magic_value(value)
                magic_str = f" [{magic}]" if magic else ""
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}{magic_str}")
            
            elif element_size == 8:
                hex_fmt = f"0x{value:016x}"
                dec_fmt = f"{value}" if not signed else f"{value:20d}"
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}")
                
        except struct.error as e:
            print(f"  0x{base_address + i:08x}: <unpack error: {e}>")

def display_float_data(data, count, base_address):
    """Display floating point data"""
    for i in range(0, min(count * 4, len(data)), 4):
        element_data = data[i:i+4]
        if len(element_data) < 4:
            element_data = element_data.ljust(4, b'\x00')
        
        try:
            value = struct.unpack('<f', element_data)[0]
            int_value = struct.unpack('<I', element_data)[0]
            addr = base_address + i
            
            # Special float values
            if value == float('inf'):
                special = " (+INF)"
            elif value == float('-inf'):
                special = " (-INF)"
            elif value != value:  # NaN
                special = " (NaN)"
            else:
                special = ""
            
            print(f"  0x{addr:08x}: {value:12.6f} (0x{int_value:08x}){special}")
            
        except struct.error:
            print(f"  0x{base_address + i:08x}: <float unpack error>")

def display_double_data(data, count, base_address):
    """Display double precision floating point data"""
    for i in range(0, min(count * 8, len(data)), 8):
        element_data = data[i:i+8]
        if len(element_data) < 8:
            element_data = element_data.ljust(8, b'\x00')
        
        try:
            value = struct.unpack('<d', element_data)[0]
            int_value = struct.unpack('<Q', element_data)[0]
            addr = base_address + i
            
            # Special double values
            if value == float('inf'):
                special = " (+INF)"
            elif value == float('-inf'):
                special = " (-INF)"
            elif value != value:  # NaN
                special = " (NaN)"
            else:
                special = ""
            
            print(f"  0x{addr:08x}: {value:18.10f} (0x{int_value:016x}){special}")
            
        except struct.error:
            print(f"  0x{base_address + i:08x}: <double unpack error>")

def display_string_data(data, base_address):
    """Display string data with null termination detection"""
    try:
        # Find null terminator
        null_pos = data.find(b'\x00')
        if null_pos != -1:
            string_data = data[:null_pos]
        else:
            string_data = data
        
        # Decode as ASCII/UTF-8
        try:
            string = string_data.decode('utf-8')
            encoding = "UTF-8"
        except UnicodeDecodeError:
            string = string_data.decode('ascii', errors='replace')
            encoding = "ASCII"
        
        print(f"  0x{base_address:08x}: \"{string}\" ({encoding})")
        print(f"    Length: {len(string_data)} bytes")
        
    except Exception as e:
        print(f"  0x{base_address:08x}: <string decode error: {e}>")

def display_hex_data(data, base_address):
    """Display raw hex data"""
    print(f"  0x{base_address:08x}: {data.hex()}")

def check_magic_value(value):
    """Check for common magic numbers and constants"""
    magic_values = {
        0xDEADBEEF: "DEADBEEF",
        0xCAFEBABE: "CAFEBABE", 
        0xBAADF00D: "BAADF00D",
        0x8BADF00D: "8BADF00D",
        0xDEADC0DE: "DEADC0DE",
        0xDEADFA11: "DEADFA11",
        0xDEAD10CC: "DEAD10CC",
        0xABADBABE: "ABADBABE",
        0xABADCAFE: "ABADCAFE",
        0x00000000: "NULL",
        0xFFFFFFFF: "ALL_ONES",
        0x0000FFFF: "LOW_ONES",
        0xFFFF0000: "HIGH_ONES",
        0x12345678: "TEST_PATTERN",
        0xAAAAAAAA: "ALT_BITS",
        0x55555555: "ALT_BITS",
    }
    return magic_values.get(value)

def analyze_pointers(data, base_address, dev):
    """Analyze data for potential pointers and cross-references"""
    pointers = []
    
    # Look for 32-bit values that could be pointers
    for i in range(0, len(data) - 3, 4):
        potential_ptr = struct.unpack('<I', data[i:i+4])[0]
        
        # Check if this looks like a valid pointer
        if is_likely_pointer(potential_ptr):
            pointers.append((base_address + i, potential_ptr))
    
    if pointers:
        for addr, ptr in pointers[:5]:  # Show first 5
            region = detect_memory_region(ptr, dev)
            print(f"  0x{addr:08x} → 0x{ptr:08x} {region}")
        
        if len(pointers) > 5:
            print(f"  ... and {len(pointers) - 5} more pointers")
    else:
        print("  No obvious pointers found")

def is_likely_pointer(value):
    """Determine if a value is likely a pointer"""
    # Common pointer ranges
    if value == 0:
        return False  # NULL pointer
    
    pointer_ranges = [
        (0x10000000, 0x60000000),  # Peripheral space
        (0x80000000, 0xC0000000),  # DRAM
        (0xC0000000, 0xFFFFFFFF),  # Kernel
    ]
    
    for start, end in pointer_ranges:
        if start <= value < end:
            return True
    
    return False

def disassemble_data(data, base_address):
    """Simple disassembly for ARM/Thumb code"""
    try:
        from capstone import Cs, CS_ARCH_ARM, CS_MODE_ARM, CS_MODE_THUMB
        
        # Try ARM mode first
        md = Cs(CS_ARCH_ARM, CS_MODE_ARM)
        md.detail = True
        
        for i in md.disasm(data, base_address):
            print(f"  0x{i.address:08x}: {i.mnemonic:8} {i.op_str}")
            if i.address - base_address >= 16:  # Limit output
                print("  ... (truncated)")
                break
                
    except ImportError:
        print("  (Install capstone for disassembly: pip install capstone)")
    except Exception as e:
        print(f"  Disassembly failed: {e}")

def display_memory_attributes(address, data, dev):
    """Display memory attributes and characteristics"""
    # Check for all zeros
    if all(b == 0 for b in data):
        print("  Content: All zeros (erased/uninitialized)")
    
    # Check for all ones
    elif all(b == 0xFF for b in data):
        print("  Content: All ones (erased)")
    
    # Check for pattern
    elif len(data) >= 2 and data == data[0:1] * len(data):
        print(f"  Content: Repeated pattern 0x{data[0]:02x}")
    
    # Check alignment
    if address % 4 == 0:
        print("  Alignment: 4-byte aligned")
    elif address % 2 == 0:
        print("  Alignment: 2-byte aligned")
    else:
        print("  Alignment: Unaligned")
    
    # Check if readable from different commands
    print("  Access: Readable")