def cmd_peek(args):
    """
    Fixed PEEK command for QSLCL v1.2.5 compatibility:
    - Uses QSLCLCMD system for memory reads
    - Properly handles structured responses
    - Integrates with partition and memory detection
    - Enhanced error handling and validation
    """
    if not args:
        print("[!] PEEK: No arguments provided")
        return

    # Scan for devices
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    # Get the first available device
    dev = devs[0]
    
    # Auto-load loader if specified
    if hasattr(args, 'loader') and args.loader:
        auto_loader_if_needed(args, dev)

    # Extract arguments with safe defaults
    address_str = getattr(args, 'address', '')
    size = getattr(args, 'size', 4)
    data_type = getattr(args, 'data_type', 'auto')
    count = getattr(args, 'count', 1)

    if not address_str:
        print("[!] PEEK: No address specified")
        return

    print(f"[*] PEEK command: address={address_str}, size={size}, type={data_type}, count={count}")

    # =========================================================================
    # 1. ADDRESS RESOLUTION - FIXED to use proper resolve_target
    # =========================================================================
    try:
        # Get partitions and memory regions
        partitions = load_partitions(dev)
        memory_regions = detect_memory_regions(dev)
        
        # Use resolve_target with proper parameters
        target_info = resolve_target(address_str, partitions, memory_regions, dev)
        if not target_info:
            print(f"[!] Could not resolve address: {address_str}")
            print(f"[*] Available partitions:")
            for part in partitions[:5]:  # Show first 5 partitions
                print(f"    {part['name']}: 0x{part['offset']:08X}-0x{part['offset'] + part['size']:08X}")
            return
        
        address = target_info['address']
        available_size = target_info.get('size', 0x1000)  # Default 4KB
        
        print(f"[+] Resolved address: 0x{address:08X}")
        print(f"[+] Available size: 0x{available_size:X} bytes")
        
        if target_info.get('partition_info'):
            part = target_info['partition_info']
            print(f"[+] In partition: {part['name']} (0x{part['offset']:08X}+0x{part['size']:08X})")
        elif target_info.get('region_info'):
            region = target_info['region_info']
            print(f"[+] In region: {region['name']} (0x{region['start']:08X}-0x{region['end']:08X})")
        
    except Exception as e:
        print(f"[!] Address resolution failed: {e}")
        import traceback
        traceback.print_exc()
        return

    # =========================================================================
    # 2. SIZE AND DATA TYPE DETERMINATION - FIXED calculation
    # =========================================================================
    if data_type == 'auto':
        # Auto-detect based on size and address patterns
        data_type = auto_detect_data_type(address, size, count)
        print(f"[+] Auto-detected data type: {data_type}")

    # Calculate total bytes to read
    type_sizes = {
        'uint8': 1, 'int8': 1, 'char': 1,
        'uint16': 2, 'int16': 2, 'short': 2,
        'uint32': 4, 'int32': 4, 'float': 4, 'int': 4,
        'uint64': 8, 'int64': 8, 'double': 8, 'long': 8,
        'string': size, 'hex': size, 'bytes': size
    }
    
    bytes_per_element = type_sizes.get(data_type, 4)
    total_bytes = bytes_per_element * count

    # Cap to available size
    if total_bytes > available_size:
        print(f"[!] Requested size exceeds available region: {total_bytes} > {available_size}")
        print(f"[*] Capping to available size: {available_size} bytes")
        total_bytes = available_size
        count = available_size // bytes_per_element
    
    if total_bytes > 1024 * 1024:  # 1MB limit
        print(f"[!] Requested size too large: {total_bytes} bytes (max 1MB)")
        return

    print(f"[*] Reading {total_bytes} bytes from 0x{address:08X} ({count} elements)")

    # =========================================================================
    # 3. MEMORY READ OPERATION - FIXED to use proper QSLCLCMD
    # =========================================================================
    try:
        raw_data = b""
        
        # Try multiple read strategies
        read_strategies = [
            ("QSLCLCMD READ", lambda: read_via_qslclcmd(dev, "READ", address, total_bytes)),
            ("QSLCLCMD PEEK", lambda: read_via_qslclcmd(dev, "PEEK", address, total_bytes)),
            ("QSLCLCMD MEMREAD", lambda: read_via_qslclcmd(dev, "MEMREAD", address, total_bytes)),
            ("Direct READ", lambda: read_direct(dev, address, total_bytes)),
        ]
        
        for strategy_name, read_func in read_strategies:
            print(f"[*] Trying read strategy: {strategy_name}")
            raw_data = read_func()
            if raw_data and len(raw_data) >= min(16, total_bytes):
                print(f"[+] Read successful via {strategy_name}")
                break
            time.sleep(0.1)
        
        if not raw_data:
            print("[!] All read strategies failed")
            return
        
        if len(raw_data) < total_bytes:
            print(f"[!] Short read: got {len(raw_data)} bytes, expected {total_bytes}")
            # Pad with zeros for display
            raw_data = raw_data.ljust(total_bytes, b'\x00')

    except Exception as e:
        print(f"[!] Memory read failed: {e}")
        import traceback
        traceback.print_exc()
        return

    # =========================================================================
    # 4. DATA INTERPRETATION AND DISPLAY
    # =========================================================================
    print(f"\n{'='*60}")
    print(f"[*] Memory at 0x{address:08X}:")

    # Detect memory region type
    region_info = detect_memory_region_qslcl(address, dev)
    if region_info:
        print(f"[+] Region: {region_info}")

    # Show hex dump for reasonable sizes
    if 16 <= total_bytes <= 1024:
        print(f"\n[*] Hex Dump (16 bytes per line):")
        print(format_hex_dump_qslcl(raw_data, address))
    elif total_bytes < 16:
        print(f"\n[*] Raw bytes: {raw_data.hex()}")

    # Interpret data based on type
    print(f"\n[*] Interpretation as {data_type}:")

    try:
        if data_type in ['uint8', 'int8', 'char']:
            display_integer_data_qslcl(raw_data, 1, count, data_type, address)
        elif data_type in ['uint16', 'int16', 'short']:
            display_integer_data_qslcl(raw_data, 2, count, data_type, address)
        elif data_type in ['uint32', 'int32', 'int', 'float']:
            if data_type == 'float':
                display_float_data_qslcl(raw_data, count, address)
            else:
                display_integer_data_qslcl(raw_data, 4, count, data_type, address)
        elif data_type in ['uint64', 'int64', 'long', 'double']:
            if data_type == 'double':
                display_double_data_qslcl(raw_data, count, address)
            else:
                display_integer_data_qslcl(raw_data, 8, count, data_type, address)
        elif data_type == 'string':
            display_string_data_qslcl(raw_data, address)
        elif data_type in ['hex', 'bytes']:
            display_hex_data_qslcl(raw_data, address)
        else:
            # Default to 32-bit integers
            print(f"[!] Unknown data type: {data_type}, defaulting to uint32")
            display_integer_data_qslcl(raw_data, 4, count, 'uint32', address)

    except Exception as e:
        print(f"[!] Data interpretation failed: {e}")
        # Fallback to raw hex
        print(f"[*] Raw data (hex): {raw_data.hex()}")

    # =========================================================================
    # 5. ADVANCED ANALYSIS (only for meaningful data sizes)
    # =========================================================================
    if total_bytes >= 4:
        # Show potential pointers and cross-references
        print(f"\n[*] Pointer Analysis:")
        analyze_pointers_qslcl(raw_data, address, dev)

    # Show memory attributes
    print(f"\n[*] Memory Attributes:")
    display_memory_attributes_qslcl(address, raw_data, dev)
    
    print(f"{'='*60}")

# =============================================================================
# FIXED READ FUNCTIONS FOR QSLCLCMD SYSTEM
# =============================================================================

def read_via_qslclcmd(dev, cmd_name, address, size):
    """Read memory using QSLCLCMD system"""
    try:
        # Build payload: address(4) + size(4)
        payload = struct.pack("<II", address, size)
        
        # Use qslcl_dispatch with the command
        resp = qslcl_dispatch(dev, cmd_name, payload)
        
        if not resp:
            return None
            
        # Handle different response types
        if isinstance(resp, bytes):
            # Direct byte response
            if len(resp) >= 8 and resp[:4] == b"DATA":
                # Structured DATA response: "DATA" + size + data
                resp_size = struct.unpack("<I", resp[4:8])[0]
                if len(resp) >= 8 + resp_size:
                    return resp[8:8+resp_size]
            return resp[:size]
        else:
            # Try to decode as runtime result
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                if extra:
                    return extra[:size]
    
    except Exception as e:
        print(f"[!] QSLCLCMD read failed: {e}")
    
    return None

def read_direct(dev, address, size):
    """Fallback direct read using device interface"""
    try:
        # Build a direct READ command
        cmd = f"READ 0x{address:08X} 0x{size:08X}".encode()
        frame = b"QSLCLCMD" + struct.pack("<I", len(cmd)) + cmd
        
        # Send command
        if hasattr(dev, 'write'):
            dev.write(frame)
            time.sleep(0.1)
            
            # Read response
            if hasattr(dev, 'read'):
                resp = dev.read(timeout=2.0)
                if resp and isinstance(resp, bytes):
                    # Try to extract data from response frame
                    if resp.startswith(b"QSLCLRESP"):
                        if len(resp) >= 14:
                            resp_size = struct.unpack("<I", resp[9:13])[0]
                            if len(resp) >= 14 + resp_size:
                                return resp[14:14+resp_size]
                    return resp[:size]
    
    except Exception as e:
        print(f"[!] Direct read failed: {e}")
    
    return None

# =============================================================================
# SUPPORTING FUNCTIONS (UPDATED AND FIXED)
# =============================================================================

def auto_detect_data_type(address, size, count):
    """Auto-detect data type based on address patterns and size"""
    
    # Common hardware register patterns
    if 0x10000000 <= address < 0x60000000:  # Peripheral space
        return 'uint32'
    elif 0x40000000 <= address < 0x60000000:  # STM32 peripheral
        return 'uint32'
    elif 0x80000000 <= address < 0xC0000000:  # DRAM region
        if size >= 8 or count > 1:
            return 'uint32'  # Usually 32-bit in DRAM
        else:
            return 'uint32'
    elif address >= 0xC0000000:  # Kernel/Device memory
        return 'uint32'
    
    # Size-based detection
    if size == 1:
        return 'uint8'
    elif size == 2:
        return 'uint16'
    elif size == 4:
        return 'uint32'
    elif size == 8:
        return 'uint64'
    elif size > 8 and count == 1:
        return 'bytes'
    else:
        return 'uint32'

def detect_memory_region_qslcl(address, dev):
    """Detect what type of memory region this address belongs to"""
    try:
        partitions = load_partitions(dev)
        
        for part in partitions:
            if part['offset'] <= address < part['offset'] + part['size']:
                return f"Partition: {part['name']} (0x{part['offset']:08X}-0x{part['offset'] + part['size']:08X})"
        
        # Common memory regions
        if 0x00000000 <= address < 0x40000000:
            return "Memory: Low RAM/Peripheral"
        elif 0x40000000 <= address < 0x60000000:
            return "Memory: Peripheral Space"
        elif 0x60000000 <= address < 0x80000000:
            return "Memory: Reserved/MMIO"
        elif 0x80000000 <= address < 0xC0000000:
            return "Memory: DRAM/Cached"
        elif 0xC0000000 <= address < 0xFFFFFFFF:
            return "Memory: Kernel/Device"
        elif address >= 0x100000000:
            return "Memory: 64-bit Space"
        
    except Exception:
        pass
    
    return "Memory: Unknown Region"

def format_hex_dump_qslcl(data, base_address):
    """Create formatted hex dump with ASCII representation"""
    if not data:
        return "  [No data]"
    
    result = []
    line_size = 16
    
    for i in range(0, len(data), line_size):
        line_data = data[i:i+line_size]
        hex_part = ' '.join(f'{b:02x}' for b in line_data)
        hex_part = hex_part.ljust(47)  # Pad to consistent width
        
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in line_data)
        
        result.append(f"  0x{base_address + i:08x}: {hex_part} |{ascii_part}|")
    
    return '\n'.join(result)

def display_integer_data_qslcl(data, element_size, count, data_type, base_address):
    """Display integer data with proper formatting"""
    fmt_map = {
        'uint8': ('B', False), 'int8': ('b', True),
        'uint16': ('H', False), 'int16': ('h', True),
        'uint32': ('I', False), 'int32': ('i', True),
        'uint64': ('Q', False), 'int64': ('q', True),
        'char': ('B', False)
    }
    
    fmt_info = fmt_map.get(data_type, ('I', False))
    fmt_str, signed = fmt_info
    
    max_elements = min(count, len(data) // element_size)
    if max_elements == 0:
        print("  [No data to display]")
        return
    
    for i in range(max_elements):
        offset = i * element_size
        element_data = data[offset:offset + element_size]
        
        if len(element_data) < element_size:
            element_data = element_data.ljust(element_size, b'\x00')
        
        try:
            value = struct.unpack('<' + fmt_str, element_data)[0]
            addr = base_address + offset
            
            # Format based on element size
            if element_size == 1:
                hex_fmt = f"0x{value:02x}"
                dec_fmt = f"{value:3d}" if not signed else f"{value:4d}"
                char_fmt = f"'{chr(value)}'" if 32 <= value < 127 else "'\\x{:02x}'".format(value)
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt} = {char_fmt}")
            
            elif element_size == 2:
                hex_fmt = f"0x{value:04x}"
                dec_fmt = f"{value:5d}" if not signed else f"{value:6d}"
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}")
            
            elif element_size == 4:
                hex_fmt = f"0x{value:08x}"
                dec_fmt = f"{value:10d}" if not signed else f"{value:11d}"
                # Check for common magic values
                magic = check_magic_value_qslcl(value)
                magic_str = f" [{magic}]" if magic else ""
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}{magic_str}")
            
            elif element_size == 8:
                hex_fmt = f"0x{value:016x}"
                dec_fmt = f"{value:19d}" if not signed else f"{value:20d}"
                print(f"  0x{addr:08x}: {hex_fmt} = {dec_fmt}")
                
        except struct.error as e:
            print(f"  0x{base_address + offset:08x}: <unpack error>")
        except Exception as e:
            print(f"  0x{base_address + offset:08x}: <display error: {e}>")

def display_float_data_qslcl(data, count, base_address):
    """Display floating point data"""
    max_elements = min(count, len(data) // 4)
    if max_elements == 0:
        print("  [No float data to display]")
        return
    
    for i in range(max_elements):
        offset = i * 4
        element_data = data[offset:offset + 4]
        
        if len(element_data) < 4:
            element_data = element_data.ljust(4, b'\x00')
        
        try:
            value = struct.unpack('<f', element_data)[0]
            int_value = struct.unpack('<I', element_data)[0]
            addr = base_address + offset
            
            # Special float values
            if value == float('inf'):
                special = " (+INF)"
            elif value == float('-inf'):
                special = " (-INF)"
            elif value != value:  # NaN
                special = " (NaN)"
            elif value == 0.0 and int_value != 0:
                special = " (DENORMAL)"
            else:
                special = ""
            
            # Choose appropriate precision
            if abs(value) > 1e6 or (abs(value) < 1e-6 and value != 0):
                print(f"  0x{addr:08x}: {value:.6e} (0x{int_value:08x}){special}")
            else:
                print(f"  0x{addr:08x}: {value:12.6f} (0x{int_value:08x}){special}")
            
        except struct.error:
            print(f"  0x{base_address + offset:08x}: <float unpack error>")

def display_double_data_qslcl(data, count, base_address):
    """Display double precision floating point data"""
    max_elements = min(count, len(data) // 8)
    if max_elements == 0:
        print("  [No double data to display]")
        return
    
    for i in range(max_elements):
        offset = i * 8
        element_data = data[offset:offset + 8]
        
        if len(element_data) < 8:
            element_data = element_data.ljust(8, b'\x00')
        
        try:
            value = struct.unpack('<d', element_data)[0]
            int_value = struct.unpack('<Q', element_data)[0]
            addr = base_address + offset
            
            # Special double values
            if value == float('inf'):
                special = " (+INF)"
            elif value == float('-inf'):
                special = " (-INF)"
            elif value != value:  # NaN
                special = " (NaN)"
            elif value == 0.0 and int_value != 0:
                special = " (DENORMAL)"
            else:
                special = ""
            
            # Choose appropriate precision
            if abs(value) > 1e12 or (abs(value) < 1e-12 and value != 0):
                print(f"  0x{addr:08x}: {value:.12e} (0x{int_value:016x}){special}")
            else:
                print(f"  0x{addr:08x}: {value:18.10f} (0x{int_value:016x}){special}")
            
        except struct.error:
            print(f"  0x{base_address + offset:08x}: <double unpack error>")

def display_string_data_qslcl(data, base_address):
    """Display string data with null termination detection"""
    try:
        # Find null terminator
        null_pos = data.find(b'\x00')
        if null_pos != -1:
            string_data = data[:null_pos]
        else:
            string_data = data
        
        # Try different encodings
        encodings = ['utf-8', 'ascii', 'latin-1']
        string = None
        encoding = None
        
        for enc in encodings:
            try:
                string = string_data.decode(enc)
                encoding = enc
                break
            except UnicodeDecodeError:
                continue
        
        if string is None:
            # Fallback to hex representation
            print(f"  0x{base_address:08x}: <binary data: {string_data.hex()[:64]}...>")
            print(f"    Length: {len(string_data)} bytes")
            return
        
        # Display the string
        print(f"  0x{base_address:08x}: \"{string}\"")
        print(f"    Encoding: {encoding}, Length: {len(string_data)} bytes")
        
        # Show hex representation for non-printable
        non_printable = sum(1 for b in string_data if b < 32 or b >= 127)
        if non_printable > 0:
            print(f"    Non-printable bytes: {non_printable}")
        
    except Exception as e:
        print(f"  0x{base_address:08x}: <string decode error: {e}>")

def display_hex_data_qslcl(data, base_address):
    """Display raw hex data"""
    if len(data) <= 64:
        print(f"  0x{base_address:08x}: {data.hex()}")
    else:
        print(f"  0x{base_address:08x}: {data[:64].hex()}...")
        print(f"    Total: {len(data)} bytes")

def check_magic_value_qslcl(value):
    """Check for common magic numbers and constants"""
    magic_values = {
        0xDEADBEEF: "DEADBEEF",
        0xCAFEBABE: "CAFEBABE", 
        0xBAADF00D: "BAADF00D",
        0x8BADF00D: "8BADF00D",
        0xDEADC0DE: "DEADC0DE",
        0xDEADFA11: "DEADFA11",
        0xDEAD10CC: "DEAD10CC",
        0xABADBABE: "ABADBABE",
        0xABADCAFE: "ABADCAFE",
        0x00000000: "NULL",
        0xFFFFFFFF: "ALL_ONES",
        0x0000FFFF: "LOW_ONES",
        0xFFFF0000: "HIGH_ONES",
        0x12345678: "TEST_PATTERN",
        0xAAAAAAAA: "ALT_BITS(1010)",
        0x55555555: "ALT_BITS(0101)",
        0xFEEDFACE: "FEEDFACE",
        0xFEEDF00D: "FEEDFOOD",
        0x0D15EA5E: "DISEASE",
        0x1BADB002: "1BADBOOT",
        0x8BADF00D: "ATE FOOD",
    }
    return magic_values.get(value)

def analyze_pointers_qslcl(data, base_address, dev):
    """Analyze data for potential pointers and cross-references"""
    if len(data) < 4:
        print("  [Data too small for pointer analysis]")
        return
    
    pointers_32 = []
    pointers_64 = []
    
    # Look for 32-bit pointers
    for i in range(0, len(data) - 3, 4):
        try:
            value = struct.unpack('<I', data[i:i+4])[0]
            if is_likely_pointer_qslcl(value, 32):
                pointers_32.append((base_address + i, value))
        except:
            continue
    
    # Look for 64-bit pointers (if data is large enough)
    if len(data) >= 8:
        for i in range(0, len(data) - 7, 8):
            try:
                value = struct.unpack('<Q', data[i:i+8])[0]
                if is_likely_pointer_qslcl(value, 64):
                    pointers_64.append((base_address + i, value))
            except:
                continue
    
    if not pointers_32 and not pointers_64:
        print("  No obvious pointers found")
        return
    
    if pointers_32:
        print("  32-bit pointers:")
        for addr, ptr in pointers_32[:3]:  # Show first 3
            region = detect_memory_region_qslcl(ptr, dev)
            print(f"    0x{addr:08x} → 0x{ptr:08x} {region}")
        
        if len(pointers_32) > 3:
            print(f"    ... and {len(pointers_32) - 3} more")
    
    if pointers_64:
        print("  64-bit pointers:")
        for addr, ptr in pointers_64[:3]:
            region = detect_memory_region_qslcl(ptr, dev)
            print(f"    0x{addr:08x} → 0x{ptr:016x} {region}")
        
        if len(pointers_64) > 3:
            print(f"    ... and {len(pointers_64) - 3} more")

def is_likely_pointer_qslcl(value, bits=32):
    """Determine if a value is likely a pointer"""
    if value == 0:
        return False  # NULL pointer
    
    if bits == 32:
        # 32-bit pointer ranges
        pointer_ranges = [
            (0x10000000, 0x60000000),  # Peripheral space
            (0x80000000, 0xC0000000),  # DRAM
            (0xC0000000, 0xFFFFFFFF),  # Kernel
        ]
        
        for start, end in pointer_ranges:
            if start <= value < end:
                # Also check alignment (pointers are usually aligned)
                if value % 4 == 0:
                    return True
        
        return False
    
    elif bits == 64:
        # 64-bit pointer ranges (simplified)
        if value > 0xFFFFFFFF:  # Above 32-bit space
            # Check for reasonable alignment
            if value % 8 == 0:
                return True
    
    return False

def display_memory_attributes_qslcl(address, data, dev):
    """Display memory attributes and characteristics"""
    if not data:
        print("  [No data to analyze]")
        return
    
    # Check for all zeros
    if all(b == 0 for b in data):
        print("  Content: All zeros (erased/uninitialized)")
    
    # Check for all ones
    elif all(b == 0xFF for b in data):
        print("  Content: All ones (erased flash)")
    
    # Check for repeating pattern
    elif len(data) >= 2:
        first_byte = data[0]
        if all(b == first_byte for b in data):
            print(f"  Content: Repeated pattern 0x{first_byte:02x}")
        elif len(data) >= 4:
            # Check for common patterns
            if data.startswith(b'\x00\x01\x02\x03'):
                print("  Content: Incremental pattern 00 01 02 03...")
            elif data.startswith(b'\xFF\xFE\xFD\xFC'):
                print("  Content: Decremental pattern FF FE FD FC...")
    
    # Check alignment
    alignment = ""
    if address % 16 == 0:
        alignment = "16-byte"
    elif address % 8 == 0:
        alignment = "8-byte"
    elif address % 4 == 0:
        alignment = "4-byte"
    elif address % 2 == 0:
        alignment = "2-byte"
    else:
        alignment = "Unaligned"
    
    print(f"  Alignment: {alignment}")
    
    # Check entropy
    entropy = calculate_entropy_qslcl(data)
    if entropy > 7.5:
        print(f"  Entropy: {entropy:.2f} (high - likely encrypted/compressed/random)")
    elif entropy < 1.0:
        print(f"  Entropy: {entropy:.2f} (low - structured/repeating)")
    else:
        print(f"  Entropy: {entropy:.2f} (normal - mixed data)")
    
    # Check for ASCII content
    ascii_count = sum(1 for b in data if 32 <= b < 127)
    ascii_percent = (ascii_count / len(data)) * 100 if data else 0
    if ascii_percent > 70:
        print(f"  ASCII content: {ascii_percent:.1f}% (textual data)")
    elif ascii_percent > 30:
        print(f"  ASCII content: {ascii_percent:.1f}% (mixed)")
    else:
        print(f"  ASCII content: {ascii_percent:.1f}% (binary)")

def calculate_entropy_qslcl(data):
    """Calculate Shannon entropy of data (0-8 bits per byte)"""
    if not data or len(data) == 0:
        return 0.0
    
    entropy = 0.0
    byte_counts = [0] * 256
    
    # Count byte frequencies
    for byte in data:
        byte_counts[byte] += 1
    
    total = len(data)
    
    # Calculate entropy
    for count in byte_counts:
        if count > 0:
            probability = count / total
            entropy -= probability * math.log2(probability)
    
    return entropy