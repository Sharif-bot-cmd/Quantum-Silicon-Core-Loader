def cmd_rawstate(args=None):
    """
    Fully implemented RAWSTATE command with advanced features:
    - Low-level hardware state inspection and manipulation
    - Register access and bit-level operations
    - System state snapshots and comparison
    - Real-time state monitoring and tracing
    - Hardware debugging and diagnostics
    """
    if args is None:
        print("[!] RAWSTATE: No arguments provided")
        print_rawstate_help()
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'rawstate_subcommand', '').lower()
    rawstate_args = getattr(args, 'rawstate_args', [])
    verbose = getattr(args, 'verbose', False)
    force = getattr(args, 'force', False)

    if not subcommand:
        print("[!] RAWSTATE: No subcommand specified")
        print_rawstate_help()
        return

    print(f"[*] RAWSTATE command: {subcommand} {rawstate_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH - FIXED: Added missing commands
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'show']:
            rawstate_list(dev, rawstate_args, verbose)
            
        elif subcommand in ['read', 'get', 'peek']:
            rawstate_read(dev, rawstate_args, verbose)
            
        elif subcommand in ['write', 'set', 'poke']:
            rawstate_write(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['dump', 'snapshot', 'capture']:
            rawstate_dump(dev, rawstate_args, verbose)
            
        elif subcommand in ['compare', 'diff']:
            rawstate_compare(dev, rawstate_args, verbose)
            
        elif subcommand in ['monitor', 'watch', 'trace']:
            rawstate_monitor(dev, rawstate_args, verbose)
            
        elif subcommand in ['bit', 'bits', 'bitwise']:
            rawstate_bit(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['field', 'fields']:
            rawstate_field(dev, rawstate_args, verbose)
            
        elif subcommand in ['scan', 'search', 'find']:
            rawstate_scan(dev, rawstate_args, verbose)
            
        elif subcommand in ['reset', 'clear', 'init']:
            rawstate_reset(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['bank', 'banks']:
            rawstate_bank(dev, rawstate_args, verbose)
            
        elif subcommand in ['help', '?', '--help']:
            print_rawstate_help()
            
        else:
            print(f"[!] Unknown RAWSTATE subcommand: {subcommand}")
            print_rawstate_help()
            
    except Exception as e:
        print(f"[!] RAWSTATE operation failed: {e}")
        if verbose:
            traceback.print_exc()

# =============================================================================
# RAWSTATE SUBCOMMAND IMPLEMENTATIONS - FIXED
# =============================================================================

def rawstate_list(dev, args, verbose=False):
    """List available hardware states and registers"""
    print("[*] Querying hardware state capabilities...")
    
    capabilities = query_rawstate_capabilities(dev, verbose)
    
    print(f"\n[+] RAWSTATE Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    State Access: {capabilities.get('state_access', 'Basic')}")
    print(f"    Endianness: {capabilities.get('endianness', 'little')}")
    
    # List available register banks - FIXED: Added bounds checking
    register_banks = capabilities.get('register_banks', [])
    if register_banks:
        print(f"\n[+] Register Banks ({len(register_banks)}):")
        for i, bank in enumerate(register_banks[:20]):  # Limit display
            access = bank.get('access', 'UNKNOWN')
            access_icon = "🟢" if access == 'RW' else "🟡" if access == 'RO' else "🔴"
            base = bank.get('base', 0)
            size = bank.get('size', 0)
            end = base + size - 1 if size > 0 else base
            print(f"    {i:2d}. {access_icon} {bank.get('name', f'BANK_{i}'):20} - 0x{base:08X}-0x{end:08X} ({size} bytes)")
        
        if len(register_banks) > 20:
            print(f"    ... and {len(register_banks) - 20} more banks")
    
    # List hardware blocks - FIXED: Added bounds checking
    hardware_blocks = capabilities.get('hardware_blocks', [])
    if hardware_blocks:
        print(f"\n[+] Hardware Blocks ({len(hardware_blocks)}):")
        for i, block in enumerate(hardware_blocks[:15]):  # Limit display
            print(f"    {i:2d}. {block.get('name', f'BLOCK_{i}'):20} - {block.get('description', 'No description')}")
        
        if len(hardware_blocks) > 15:
            print(f"    ... and {len(hardware_blocks) - 15} more blocks")
    
    # List common state locations - FIXED: Added bounds checking
    state_locations = capabilities.get('state_locations', [])
    if state_locations:
        print(f"\n[+] Common State Locations ({len(state_locations)}):")
        for i, location in enumerate(state_locations[:20]):  # Limit display
            name = location.get('name', f'REG_{i}')
            addr = location.get('address', 0)
            size = location.get('size', 4)
            print(f"    {i:2d}. {name:20} - 0x{addr:08X} ({size} bytes)")
        
        if len(state_locations) > 20:
            print(f"    ... and {len(state_locations) - 20} more locations")

def rawstate_read(dev, args, verbose=False):
    """Read hardware state/register"""
    if not args:
        print("[!] Specify address or register name to read")
        print("    Usage: rawstate read <address|register> [size]")
        return
        
    target = args[0]
    size = 4  # Default 32-bit read
    
    if len(args) > 1:
        try:
            size = int(args[1], 0)  # FIXED: Added base-0 for hex support
            if size <= 0 or size > 256:  # FIXED: Added bounds check
                print(f"[!] Invalid size: {size}. Must be 1-256 bytes")
                size = 4
        except ValueError as e:
            print(f"[!] Invalid size format: {args[1]} - {e}")
            size = 4
    
    print(f"[*] Reading raw state from: {target} (size: {size} bytes)")
    
    try:
        # Resolve address - FIXED: Added error handling
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            # Try to parse as raw number
            try:
                if target.startswith('0x'):
                    address = int(target, 16)
                else:
                    address = int(target)
                print(f"[*] Interpreting as raw address: 0x{address:08X}")
            except ValueError:
                print(f"[!] Invalid address format: {target}")
                return
            
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Validate address alignment for common sizes
        if size in [2, 4, 8] and (address % size != 0):
            print(f"[!] Warning: Address 0x{address:X} not aligned for {size}-byte access")
            print(f"    (Address should be divisible by {size})")
        
        # Read state
        state_data, success = read_raw_state(dev, address, size, verbose)
        
        if success and state_data:
            display_state_data(state_data, address, size, target, verbose)
        else:
            print(f"[!] Failed to read state from 0x{address:08X}")
            
    except Exception as e:
        print(f"[!] State read failed: {e}")
        if verbose:
            traceback.print_exc()

def rawstate_write(dev, args, force=False, verbose=False):
    """Write hardware state/register"""
    if len(args) < 2:
        print("[!] Specify address and value to write")
        print("    Usage: rawstate write <address|register> <value> [size]")
        return
        
    target = args[0]
    value_str = args[1]
    size = 4  # Default 32-bit write
    
    # Check for optional size parameter
    if len(args) > 2:
        try:
            size = int(args[2], 0)
            if size <= 0 or size > 256:
                print(f"[!] Invalid size: {size}. Using default 4 bytes")
                size = 4
        except ValueError:
            pass  # Use default size
    
    print(f"[*] Writing raw state to: {target} = {value_str} (size: {size} bytes)")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            # Try to parse as raw number
            try:
                if target.startswith('0x'):
                    address = int(target, 16)
                else:
                    address = int(target)
                print(f"[*] Interpreting as raw address: 0x{address:08X}")
            except ValueError:
                print(f"[!] Invalid address format: {target}")
                return
            
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Validate address alignment
        if size in [2, 4, 8] and (address % size != 0):
            print(f"[!] Warning: Address 0x{address:X} not aligned for {size}-byte write")
            print(f"    This may cause alignment faults on some hardware")
        
        # Safety check for critical registers - FIXED: Improved warning
        if not force and is_critical_register(address):
            print(f"\n[!] ⚠️  WARNING: Writing to critical register 0x{address:08X}!")
            print(f"[!] This may:")
            print(f"    • Damage hardware")
            print(f"    • Brick the device")
            print(f"    • Cause system instability")
            print(f"[!] Register name: {get_register_name(address)}")
            response = input("\n    Type 'YES' to continue: ")
            if response.upper() != 'YES':
                print("[*] Operation cancelled")
                return
        
        # Parse value - FIXED: Enhanced value parsing
        write_data = parse_rawstate_value(value_str, size)
        if write_data is None:
            print(f"[!] Invalid value: {value_str}")
            print(f"    Supported formats: 0x1234, 1234, 'AABBCCDD'")
            return
            
        hex_str = write_data.hex().upper()
        if len(hex_str) > 32:  # Truncate long values
            hex_str = hex_str[:32] + "..."
        print(f"[+] Writing {len(write_data)} bytes: {hex_str}")
        
        # Read original value first (optional)
        read_original = True
        if size > 64:  # Don't read large blocks just for verification
            read_original = False
            
        if read_original:
            original_data, _ = read_raw_state(dev, address, min(size, 8), False)
            if original_data and len(original_data) >= 4:
                original_value = int.from_bytes(original_data[:4], 'little')
                print(f"[+] Original (first 4 bytes): 0x{original_value:08X}")
        
        # Write state
        success = write_raw_state(dev, address, write_data, verbose)
        
        if success:
            print("[+] State write successful")
            
            # Verify write if possible (small sizes only)
            if size <= 8 and read_original:
                verify_data, _ = read_raw_state(dev, address, size, False)
                if verify_data:
                    verify_value = int.from_bytes(verify_data, 'little')
                    new_value = int.from_bytes(write_data, 'little')
                    
                    if verify_value == new_value:
                        print("[+] Write verification PASSED")
                    else:
                        print(f"[!] Write verification FAILED:")
                        print(f"    Expected: 0x{new_value:0{size*2}X}")
                        print(f"    Got:      0x{verify_value:0{size*2}X}")
                        print(f"    Difference: 0x{verify_value ^ new_value:0{size*2}X}")
                        
        else:
            print(f"[!] Failed to write state to 0x{address:08X}")
            
    except Exception as e:
        print(f"[!] State write failed: {e}")
        if verbose:
            traceback.print_exc()

def rawstate_dump(dev, args, verbose=False):
    """Dump hardware state region"""
    if not args:
        print("[!] Specify address range to dump")
        print("    Usage: rawstate dump <address|register> [size]")
        return
        
    target = args[0]
    size_str = "256"  # Default dump size
    if len(args) > 1:
        size_str = args[1]
    
    print(f"[*] Dumping raw state region: {target}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            # Try to parse as raw number
            try:
                if target.startswith('0x'):
                    address = int(target, 16)
                else:
                    address = int(target)
                print(f"[*] Interpreting as raw address: 0x{address:08X}")
            except ValueError:
                print(f"[!] Invalid address format: {target}")
                return
        
        size = parse_size_string(size_str)
        
        # Limit dump size for safety
        MAX_DUMP_SIZE = 1024 * 1024  # 1MB max
        if size > MAX_DUMP_SIZE:
            print(f"[!] Requested size {size} too large, limiting to {MAX_DUMP_SIZE}")
            size = MAX_DUMP_SIZE
        
        print(f"[+] Dump range: 0x{address:08X}-0x{address+size:08X} ({size} bytes)")
        
        if size > 65536 and not verbose:
            print("[*] Large dump requested, this may take a while...")
        
        # Dump state region
        dump_data = dump_raw_state_region(dev, address, size, verbose)
        
        if dump_data:
            display_state_dump(dump_data, address, target, verbose)
            
            # Additional analysis
            if verbose and size >= 16:
                analyze_state_dump(dump_data, address)
        else:
            print(f"[!] Failed to dump state region")
            
    except Exception as e:
        print(f"[!] State dump failed: {e}")
        if verbose:
            traceback.print_exc()

def rawstate_compare(dev, args, verbose=False):
    """Compare hardware states"""
    if len(args) < 2:
        print("[!] Specify two states to compare")
        print("    Usage: rawstate compare <addr1> <addr2> [size]")
        return
        
    target1 = args[0]
    target2 = args[1]
    size = 4  # Default comparison size
    
    if len(args) > 2:
        try:
            size = int(args[2], 0)
            if size <= 0 or size > 64:
                print(f"[!] Invalid size: {size}. Using default 4 bytes")
                size = 4
        except ValueError:
            pass
    
    print(f"[*] Comparing states: {target1} vs {target2} ({size} bytes)")
    
    try:
        # Resolve addresses
        addr1 = resolve_rawstate_address(target1, dev)
        addr2 = resolve_rawstate_address(target2, dev)
        
        if addr1 is None:
            print(f"[!] Could not resolve: {target1}")
            return
        if addr2 is None:
            print(f"[!] Could not resolve: {target2}")
            return
            
        # Read both states
        state1, success1 = read_raw_state(dev, addr1, size, False)
        state2, success2 = read_raw_state(dev, addr2, size, False)
        
        if success1 and success2 and state1 and state2:
            if len(state1) != len(state2):
                print(f"[!] State sizes don't match: {len(state1)} vs {len(state2)}")
                return
            
            print(f"\n[+] Comparison Results:")
            print(f"    {target1} (0x{addr1:08X}): {len(state1)} bytes")
            print(f"    {target2} (0x{addr2:08X}): {len(state2)} bytes")
            
            # Compare byte by byte
            identical = True
            differences = []
            
            for i in range(min(len(state1), len(state2))):
                if state1[i] != state2[i]:
                    identical = False
                    differences.append({
                        'offset': i,
                        'addr1_val': state1[i],
                        'addr2_val': state2[i],
                        'diff': state1[i] ^ state2[i]
                    })
            
            if identical:
                print(f"    ✅ States are IDENTICAL")
                
                # Show values for small comparisons
                if size <= 8:
                    value1 = int.from_bytes(state1, 'little')
                    value2 = int.from_bytes(state2, 'little')
                    print(f"    Value: 0x{value1:0{size*2}X}")
            else:
                print(f"    🔄 States are DIFFERENT ({len(differences)} bytes differ)")
                
                # Show first few differences
                max_diffs_to_show = 10
                for i, diff in enumerate(differences[:max_diffs_to_show]):
                    byte_offset = diff['offset']
                    print(f"    Byte {byte_offset:3d}: 0x{state1[byte_offset]:02X} != 0x{state2[byte_offset]:02X} (diff: 0x{diff['diff']:02X})")
                
                if len(differences) > max_diffs_to_show:
                    print(f"    ... and {len(differences) - max_diffs_to_show} more differences")
                    
                # Calculate total difference
                if size == 4:
                    value1 = int.from_bytes(state1, 'little')
                    value2 = int.from_bytes(state2, 'little')
                    diff_total = value1 ^ value2
                    print(f"    Total difference: 0x{diff_total:08X}")
                    
                    # Show bit differences
                    differing_bits = []
                    for bit in range(32):
                        if diff_total & (1 << bit):
                            differing_bits.append(bit)
                    
                    if differing_bits:
                        bit_groups = []
                        start_bit = differing_bits[0]
                        prev_bit = start_bit
                        
                        for bit in differing_bits[1:]:
                            if bit != prev_bit + 1:
                                if start_bit == prev_bit:
                                    bit_groups.append(str(start_bit))
                                else:
                                    bit_groups.append(f"{start_bit}-{prev_bit}")
                                start_bit = bit
                            prev_bit = bit
                        
                        # Add last group
                        if start_bit == prev_bit:
                            bit_groups.append(str(start_bit))
                        else:
                            bit_groups.append(f"{start_bit}-{prev_bit}")
                        
                        print(f"    Differing bits: {', '.join(bit_groups)}")
                    
        else:
            print(f"[!] Failed to read states for comparison")
            if not success1:
                print(f"    Failed to read: {target1}")
            if not success2:
                print(f"    Failed to read: {target2}")
            
    except Exception as e:
        print(f"[!] State comparison failed: {e}")

def rawstate_monitor(dev, args, verbose=False):
    """Monitor hardware state changes"""
    if not args:
        print("[!] Specify state to monitor")
        print("    Usage: rawstate monitor <address|register> [interval] [duration]")
        return
        
    target = args[0]
    interval = 1.0  # Default interval
    duration = None  # Run indefinitely by default
    
    if len(args) > 1:
        try:
            interval = float(args[1])
            if interval < 0.01 or interval > 60:
                print(f"[!] Invalid interval: {interval}s. Using 1.0s")
                interval = 1.0
        except ValueError:
            pass
    
    if len(args) > 2:
        try:
            duration = float(args[2])
            if duration <= 0:
                duration = None
        except ValueError:
            pass
    
    print(f"[*] Monitoring state: {target} (interval: {interval}s)")
    if duration:
        print(f"[*] Duration: {duration}s")
    print("[*] Press Ctrl+C to stop monitoring")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        previous_value = None
        start_time = time.time()
        last_change_time = start_time
        change_count = 0
        
        print(f"[+] Monitoring address: 0x{address:08X}")
        print(f"[+] Starting at: {time.strftime('%H:%M:%S')}")
        print("-" * 60)
        
        try:
            while True:
                current_time = time.time()
                elapsed = current_time - start_time
                
                # Check duration limit
                if duration and elapsed >= duration:
                    print(f"\n[*] Duration limit reached ({duration}s)")
                    break
                
                # Read current state
                state_data, success = read_raw_state(dev, address, 4, False)
                
                if success and state_data and len(state_data) >= 4:
                    current_value = int.from_bytes(state_data[:4], 'little')
                    current_hex = f"0x{current_value:08X}"
                    
                    if previous_value is None:
                        print(f"[{elapsed:7.3f}s] Initial: {current_hex}")
                        previous_value = current_value
                    elif current_value != previous_value:
                        change_count += 1
                        time_since_last = current_time - last_change_time
                        diff = current_value ^ previous_value
                        
                        print(f"[{elapsed:7.3f}s] CHANGE #{change_count:3d} (+{time_since_last:.3f}s):")
                        print(f"          Old: 0x{previous_value:08X}")
                        print(f"          New: {current_hex}")
                        print(f"          Diff: 0x{diff:08X}")
                        
                        # Show changed bits
                        if diff != 0:
                            changed_bits = []
                            for bit in range(32):
                                if diff & (1 << bit):
                                    old_bit = (previous_value >> bit) & 1
                                    new_bit = (current_value >> bit) & 1
                                    changed_bits.append(f"bit{bit}:{old_bit}→{new_bit}")
                            
                            if len(changed_bits) <= 8:
                                print(f"          Bits: {', '.join(changed_bits)}")
                            else:
                                print(f"          {len(changed_bits)} bits changed")
                        
                        previous_value = current_value
                        last_change_time = current_time
                    elif verbose:
                        # Only show stable values in verbose mode
                        print(f"[{elapsed:7.3f}s] Stable: {current_hex}")
                    
                else:
                    print(f"[{elapsed:7.3f}s] READ FAILED")
                
                # Sleep for interval
                time.sleep(interval)
                
        except KeyboardInterrupt:
            print(f"\n[*] Monitoring stopped by user")
        
        # Summary
        total_time = time.time() - start_time
        print("-" * 60)
        print(f"[+] Monitoring Summary:")
        print(f"    Total time: {total_time:.2f}s")
        print(f"    Changes detected: {change_count}")
        if change_count > 0:
            avg_change_interval = (total_time - (start_time - last_change_time)) / change_count if change_count > 0 else 0
            print(f"    Average change interval: {avg_change_interval:.2f}s")
        print(f"[+] Finished at: {time.strftime('%H:%M:%S')}")
                
    except Exception as e:
        print(f"[!] State monitoring failed: {e}")

def rawstate_bit(dev, args, force=False, verbose=False):
    """Bit-level state operations"""
    if len(args) < 3:
        print("[!] Specify address, operation, and bit number")
        print("    Usage: rawstate bit <address|register> <operation> <bit>")
        print("    Operations: SET, CLEAR, TOGGLE")
        return
        
    target = args[0]
    operation = args[1].upper()
    bit_num = 0
    
    try:
        bit_num = int(args[2])
        if bit_num < 0 or bit_num > 63:  # Support up to 64-bit
            print(f"[!] Bit number must be 0-63, got: {bit_num}")
            return
    except ValueError:
        print(f"[!] Invalid bit number: {args[2]}")
        return
    
    # Validate operation
    valid_operations = {
        'SET': 'SET', '1': 'SET', 'HIGH': 'SET',
        'CLEAR': 'CLEAR', '0': 'CLEAR', 'LOW': 'CLEAR',
        'TOGGLE': 'TOGGLE', 'FLIP': 'TOGGLE', 'XOR': 'TOGGLE',
        'TEST': 'TEST', 'READ': 'TEST'
    }
    
    if operation not in valid_operations:
        print(f"[!] Invalid operation: {operation}")
        print(f"    Valid operations: {', '.join(set(valid_operations.values()))}")
        return
    
    normalized_op = valid_operations[operation]
    
    print(f"[*] Bit operation: {target} bit {bit_num} -> {normalized_op}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Determine size based on bit number
        if bit_num < 8:
            size = 1
        elif bit_num < 16:
            size = 2
        elif bit_num < 32:
            size = 4
        else:
            size = 8
        
        # Read current state
        current_data, success = read_raw_state(dev, address, size, False)
        if not success or not current_data:
            print(f"[!] Failed to read current state")
            return
            
        # Pad or truncate to size
        if len(current_data) < size:
            current_data = current_data.ljust(size, b'\x00')
        elif len(current_data) > size:
            current_data = current_data[:size]
            
        current_value = int.from_bytes(current_data, 'little')
        print(f"[+] Current: 0x{current_value:0{size*2}X}")
        print(f"[+] Bit {bit_num} currently: {(current_value >> bit_num) & 1}")
        
        # For TEST/READ operation, just display and exit
        if normalized_op == 'TEST':
            bit_value = (current_value >> bit_num) & 1
            print(f"[+] Bit {bit_num} = {bit_value}")
            return
        
        # Perform bit operation
        if normalized_op == 'SET':
            new_value = current_value | (1 << bit_num)
            operation_desc = f"SET bit {bit_num} to 1"
        elif normalized_op == 'CLEAR':
            new_value = current_value & ~(1 << bit_num)
            operation_desc = f"CLEAR bit {bit_num} to 0"
        elif normalized_op == 'TOGGLE':
            new_value = current_value ^ (1 << bit_num)
            operation_desc = f"TOGGLE bit {bit_num}"
        else:
            print(f"[!] Unsupported operation: {normalized_op}")
            return
            
        print(f"[+] {operation_desc}")
        print(f"[+] New value: 0x{new_value:0{size*2}X}")
        print(f"[+] Bit {bit_num} will be: {(new_value >> bit_num) & 1}")
        
        # Show other affected bits
        diff = current_value ^ new_value
        if diff != (1 << bit_num):
            print(f"[!] Warning: Operation affects more than just bit {bit_num}")
            print(f"    Difference: 0x{diff:0{size*2}X}")
        
        # Safety check
        if not force and is_critical_register(address):
            print(f"\n[!] WARNING: Modifying critical register!")
            print(f"[!] Register: {get_register_name(address)}")
            response = input("    Type 'BIT' to continue: ")
            if response.upper() != 'BIT':
                print("[*] Operation cancelled")
                return
        
        # Write new value
        new_data = new_value.to_bytes(size, 'little')
        success = write_raw_state(dev, address, new_data, verbose)
        
        if success:
            print(f"[+] Bit operation successful")
            
            # Verify
            verify_data, _ = read_raw_state(dev, address, size, False)
            if verify_data:
                verify_value = int.from_bytes(verify_data[:size], 'little')
                if verify_value == new_value:
                    print(f"[+] Verification: Bit {bit_num} = {(verify_value >> bit_num) & 1}")
                else:
                    print(f"[!] Verification failed")
        else:
            print(f"[!] Bit operation failed")
            
    except Exception as e:
        print(f"[!] Bit operation failed: {e}")

def rawstate_field(dev, args, verbose=False):
    """Extract and display bit fields"""
    if len(args) < 2:
        print("[!] Specify address and field range")
        print("    Usage: rawstate field <address|register> <range>")
        print("    Range formats: '7:0' (bits 7-0), '15' (bit 15)")
        return
        
    target = args[0]
    field_spec = args[1]  # Format: "high:low" or "bit"
    
    print(f"[*] Extracting field: {target} [{field_spec}]")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Determine size based on field spec
        if ':' in field_spec:
            parts = field_spec.split(':')
            if len(parts) != 2:
                print(f"[!] Invalid field format: {field_spec}")
                return
                
            high_bit = int(parts[0])
            low_bit = int(parts[1])
            
            if high_bit < low_bit:
                high_bit, low_bit = low_bit, high_bit
                
            if high_bit > 63 or low_bit < 0:
                print(f"[!] Bit range must be 0-63")
                return
                
            # Determine required size
            required_bits = high_bit + 1
            if required_bits <= 8:
                size = 1
            elif required_bits <= 16:
                size = 2
            elif required_bits <= 32:
                size = 4
            else:
                size = 8
        else:
            # Single bit
            bit_num = int(field_spec)
            if bit_num > 63:
                print(f"[!] Bit number must be 0-63")
                return
                
            required_bits = bit_num + 1
            if required_bits <= 8:
                size = 1
            elif required_bits <= 16:
                size = 2
            elif required_bits <= 32:
                size = 4
            else:
                size = 8
            
            high_bit = low_bit = bit_num
        
        # Read state
        state_data, success = read_raw_state(dev, address, size, False)
        if not success or not state_data:
            print(f"[!] Failed to read state")
            return
            
        # Pad to size if needed
        if len(state_data) < size:
            state_data = state_data.ljust(size, b'\x00')
            
        value = int.from_bytes(state_data[:size], 'little')
        print(f"[+] Raw value: 0x{value:0{size*2}X}")
        print(f"[+] Size: {size} bytes ({size*8} bits)")
        
        # Parse field specification
        if ':' in field_spec:
            # Range format: "high:low"
            field_width = high_bit - low_bit + 1
            field_mask = ((1 << field_width) - 1) << low_bit
            field_value = (value & field_mask) >> low_bit
            
            print(f"\n[+] Field [{high_bit}:{low_bit}]:")
            print(f"    Width: {field_width} bits")
            print(f"    Mask: 0x{field_mask:0{size*2}X}")
            print(f"    Value: 0x{field_value:0{(field_width+3)//4}X} ({field_value})")
            
            # Show binary representation
            binary = format(field_value, f'0{field_width}b')
            # Group bits for readability
            grouped_binary = ' '.join([binary[max(0, i-4):i] for i in range(len(binary), 0, -4)][::-1])
            print(f"    Binary: {grouped_binary}")
            
            # Show as signed if width > 1
            if field_width > 1:
                # Check if value is negative (two's complement)
                if field_value & (1 << (field_width - 1)):
                    signed_value = field_value - (1 << field_width)
                    print(f"    Signed: {signed_value}")
            
        else:
            # Single bit
            bit_value = (value >> bit_num) & 1
            
            print(f"\n[+] Bit [{bit_num}]:")
            print(f"    Value: {bit_value}")
            print(f"    Meaning: {'Set (1)' if bit_value else 'Clear (0)'}")
            
    except ValueError as e:
        print(f"[!] Invalid field specification: {field_spec} - {e}")
    except Exception as e:
        print(f"[!] Field extraction failed: {e}")

def rawstate_scan(dev, args, verbose=False):
    """Scan for state patterns"""
    if len(args) < 2:
        print("[!] Specify address range and pattern")
        print("    Usage: rawstate scan <start> <end> <pattern> [size]")
        return
        
    start_addr_str = args[0]
    end_addr_str = args[1]
    pattern_str = args[2] if len(args) > 2 else "0x00000000"
    scan_size = 4  # Default scan for 32-bit values
    
    if len(args) > 3:
        try:
            scan_size = int(args[3], 0)
            if scan_size not in [1, 2, 4, 8]:
                print(f"[!] Scan size must be 1, 2, 4, or 8 bytes")
                scan_size = 4
        except ValueError:
            pass
    
    print(f"[*] Scanning: {start_addr_str} to {end_addr_str}")
    print(f"[*] Pattern: {pattern_str} ({scan_size} bytes)")
    
    try:
        # Resolve addresses
        start_addr = resolve_rawstate_address(start_addr_str, dev)
        end_addr = resolve_rawstate_address(end_addr_str, dev)
        
        if start_addr is None:
            print(f"[!] Could not resolve start: {start_addr_str}")
            return
        if end_addr is None:
            print(f"[!] Could not resolve end: {end_addr_str}")
            return
            
        # Parse pattern
        try:
            if pattern_str.startswith('0x'):
                pattern_value = int(pattern_str, 16)
            else:
                pattern_value = int(pattern_str)
        except ValueError:
            print(f"[!] Invalid pattern: {pattern_str}")
            return
        
        scan_range = end_addr - start_addr
        if scan_range <= 0:
            print(f"[!] Invalid range: start must be less than end")
            return
            
        # Limit scan size for safety
        MAX_SCAN_SIZE = 64 * 1024  # 64KB max
        if scan_range > MAX_SCAN_SIZE:
            print(f"[!] Scan range too large ({scan_range} bytes), limiting to {MAX_SCAN_SIZE}")
            end_addr = start_addr + MAX_SCAN_SIZE
            scan_range = MAX_SCAN_SIZE
        
        print(f"[+] Scan range: 0x{start_addr:08X}-0x{end_addr:08X} ({scan_range} bytes)")
        print(f"[+] Target pattern: 0x{pattern_value:0{scan_size*2}X}")
        print(f"[+] Alignment: Scanning every {scan_size} bytes")
        
        if scan_range > 4096:
            print("[*] Large scan requested, this may take a while...")
        
        # Scan region
        found_addresses = scan_state_region(dev, start_addr, end_addr, pattern_value, scan_size, verbose)
        
        if found_addresses:
            print(f"\n[+] Found {len(found_addresses)} matches:")
            
            # Group by proximity
            groups = []
            current_group = []
            last_addr = None
            
            for addr, value in found_addresses:
                if last_addr is None or (addr - last_addr) > (scan_size * 4):
                    if current_group:
                        groups.append(current_group)
                    current_group = [(addr, value)]
                else:
                    current_group.append((addr, value))
                last_addr = addr
            
            if current_group:
                groups.append(current_group)
            
            # Display groups
            for i, group in enumerate(groups[:5]):  # Show first 5 groups
                if len(group) == 1:
                    addr, value = group[0]
                    print(f"    [SINGLE] 0x{addr:08X}: 0x{value:0{scan_size*2}X}")
                else:
                    first_addr, first_val = group[0]
                    last_addr, last_val = group[-1]
                    print(f"    [GROUP {i+1}] 0x{first_addr:08X}-0x{last_addr:08X}: {len(group)} matches")
                    
                    if verbose and len(group) <= 5:
                        for addr, value in group:
                            print(f"        0x{addr:08X}: 0x{value:0{scan_size*2}X}")
            
            if len(groups) > 5:
                remaining = sum(len(g) for g in groups[5:])
                print(f"    ... and {remaining} more matches in {len(groups)-5} additional groups")
            
            print(f"\n[+] Total matches: {len(found_addresses)}")
        else:
            print(f"[+] No matches found")
            
    except Exception as e:
        print(f"[!] State scan failed: {e}")

def rawstate_reset(dev, args, force=False, verbose=False):
    """Reset hardware state to default"""
    if not args:
        print("[!] Specify state to reset")
        print("    Usage: rawstate reset <address|register> [value] [size]")
        return
        
    target = args[0]
    default_value = 0x00000000
    size = 4
    
    if len(args) > 1:
        try:
            default_value = int(args[1], 0)
        except ValueError:
            print(f"[!] Invalid default value: {args[1]}")
            return
    
    if len(args) > 2:
        try:
            size = int(args[2], 0)
            if size not in [1, 2, 4, 8]:
                print(f"[!] Size must be 1, 2, 4, or 8 bytes")
                size = 4
        except ValueError:
            pass
    
    print(f"[*] Resetting state: {target} to 0x{default_value:0{size*2}X} ({size} bytes)")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Safety check
        if not force and is_critical_register(address):
            print(f"\n[!] WARNING: Resetting critical register!")
            print(f"[!] Register: {get_register_name(address)}")
            print(f"[!] Current value will be overwritten with: 0x{default_value:0{size*2}X}")
            response = input("    Type 'RESET' to continue: ")
            if response.upper() != 'RESET':
                print("[*] Operation cancelled")
                return
        
        # Read original value first
        original_data, _ = read_raw_state(dev, address, size, False)
        if original_data:
            original_value = int.from_bytes(original_data[:size], 'little')
            print(f"[+] Original: 0x{original_value:0{size*2}X}")
        
        # Write default value
        reset_data = default_value.to_bytes(size, 'little')
        success = write_raw_state(dev, address, reset_data, verbose)
        
        if success:
            print(f"[+] State reset successful")
            
            # Verify
            verify_data, _ = read_raw_state(dev, address, size, False)
            if verify_data:
                verify_value = int.from_bytes(verify_data[:size], 'little')
                if verify_value == default_value:
                    print(f"[+] Verification: 0x{verify_value:0{size*2}X}")
                else:
                    print(f"[!] Verification failed: 0x{verify_value:0{size*2}X} != 0x{default_value:0{size*2}X}")
        else:
            print(f"[!] State reset failed")
            
    except Exception as e:
        print(f"[!] State reset failed: {e}")

def rawstate_bank(dev, args, verbose=False):
    """Display register bank information"""
    if not args:
        print("[!] Specify register bank or 'all'")
        print("    Usage: rawstate bank <bank_name|address|'all'>")
        return
    
    bank_spec = args[0].upper()
    
    print(f"[*] Displaying register bank: {bank_spec}")
    
    capabilities = query_rawstate_capabilities(dev, verbose)
    register_banks = capabilities.get('register_banks', [])
    
    if not register_banks:
        print("[!] No register banks defined")
        return
    
    if bank_spec == 'ALL':
        print(f"\n[+] All Register Banks ({len(register_banks)}):")
        for i, bank in enumerate(register_banks):
            name = bank.get('name', f'BANK_{i}')
            base = bank.get('base', 0)
            size = bank.get('size', 0)
            access = bank.get('access', 'UNKNOWN')
            
            print(f"\n    Bank {i}: {name}")
            print(f"        Base: 0x{base:08X}")
            print(f"        Size: 0x{size:X} bytes ({size} bytes)")
            print(f"        End:  0x{base+size-1:08X}")
            print(f"        Access: {access}")
            
            if 'description' in bank:
                print(f"        Description: {bank['description']}")
                
            # Show example registers if defined
            if 'registers' in bank and bank['registers']:
                print(f"        Example registers:")
                for reg_name, reg_offset in list(bank['registers'].items())[:5]:
                    reg_addr = base + reg_offset
                    print(f"          {reg_name:20} - 0x{reg_addr:08X} (offset: 0x{reg_offset:X})")
                
                if len(bank['registers']) > 5:
                    print(f"          ... and {len(bank['registers']) - 5} more")
    else:
        # Find specific bank
        found_bank = None
        bank_index = -1
        
        # Try to find by name
        for i, bank in enumerate(register_banks):
            if bank.get('name', '').upper() == bank_spec:
                found_bank = bank
                bank_index = i
                break
        
        # Try to find by address
        if found_bank is None:
            try:
                if bank_spec.startswith('0x'):
                    target_addr = int(bank_spec, 16)
                else:
                    target_addr = int(bank_spec)
                
                for i, bank in enumerate(register_banks):
                    base = bank.get('base', 0)
                    size = bank.get('size', 0)
                    if base <= target_addr < base + size:
                        found_bank = bank
                        bank_index = i
                        break
            except ValueError:
                pass
        
        if found_bank is None:
            print(f"[!] Bank not found: {bank_spec}")
            print(f"    Available banks: {', '.join([b.get('name', 'UNKNOWN') for b in register_banks])}")
            return
        
        name = found_bank.get('name', f'BANK_{bank_index}')
        base = found_bank.get('base', 0)
        size = found_bank.get('size', 0)
        access = found_bank.get('access', 'UNKNOWN')
        
        print(f"\n[+] Register Bank: {name}")
        print(f"    Index: {bank_index}")
        print(f"    Base address: 0x{base:08X}")
        print(f"    Size: 0x{size:X} bytes ({size} bytes)")
        print(f"    End address: 0x{base+size-1:08X}")
        print(f"    Access: {access}")
        
        if 'description' in found_bank:
            print(f"    Description: {found_bank['description']}")
        
        # Show registers if defined
        if 'registers' in found_bank and found_bank['registers']:
            print(f"\n    Registers in this bank:")
            registers = found_bank['registers']
            
            # Sort by offset
            sorted_regs = sorted(registers.items(), key=lambda x: x[1])
            
            for reg_name, reg_offset in sorted_regs[:20]:  # Limit display
                reg_addr = base + reg_offset
                print(f"      0x{reg_offset:04X}  [0x{reg_addr:08X}]  {reg_name}")
            
            if len(sorted_regs) > 20:
                print(f"      ... and {len(sorted_regs) - 20} more registers")
        else:
            print(f"\n    No specific registers defined for this bank")
            
        # Suggest reading some addresses
        print(f"\n    Quick read examples:")
        print(f"      rawstate read 0x{base:08X}      # Read first register")
        if size >= 4:
            print(f"      rawstate read 0x{base+4:08X}    # Read second 32-bit register")
        if size >= 16:
            print(f"      rawstate dump 0x{base:08X} 16  # Dump first 16 bytes")

# =============================================================================
# SUPPORTING FUNCTIONS FOR RAWSTATE - FIXED
# =============================================================================

def query_rawstate_capabilities(dev, verbose=False):
    """Query device rawstate capabilities - FIXED with more realistic data"""
    # Try to query actual capabilities from device
    capabilities = {
        'device_name': 'Generic Hardware',
        'architecture': 'ARMv8',
        'state_access': 'Full',
        'endianness': 'little',
        'register_banks': [],
        'hardware_blocks': [],
        'state_locations': []
    }
    
    try:
        # Try to query actual capabilities via RAWSTATE command
        # FIXED: Changed from QSLCLPAR_DB to QSLCLCMD_DB
        if "RAWSTATE" in QSLCLCMD_DB or "GETINFO" in QSLCLCMD_DB:
            query_payload = struct.pack("<B", 0x00)  # CAPABILITIES query
            
            # Try RAWSTATE first, then GETINFO
            resp = None
            if "RAWSTATE" in QSLCLCMD_DB:
                resp = qslcl_dispatch(dev, "RAWSTATE", query_payload)
            elif "GETINFO" in QSLCLCMD_DB:
                resp = qslcl_dispatch(dev, "GETINFO", query_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    # Parse capability data
                    # This is a simplified parser - real implementation would parse binary data
                    extra = status["extra"]
                    if len(extra) >= 4:
                        # Extract device info from response
                        pass
    except Exception as e:
        if verbose:
            print(f"[DEBUG] Capability query failed: {e}")
    
    # Add default/fallback data if no device-specific data
    if not capabilities['register_banks']:
        capabilities['register_banks'] = [
            {'name': 'SYSTEM_CTRL', 'base': 0x10000000, 'size': 0x1000, 'access': 'RW', 
             'description': 'System Control Registers',
             'registers': {'CPUID': 0x00, 'SYSCFG': 0x04, 'RST_CTL': 0x08, 'CLK_SRC': 0x0C}},
            {'name': 'POWER_MGMT', 'base': 0x20000000, 'size': 0x1000, 'access': 'RW',
             'description': 'Power Management Unit',
             'registers': {'PWR_CTL': 0x00, 'PWR_STAT': 0x04, 'VOLT_CTL': 0x08, 'PMIC_CFG': 0x0C}},
            {'name': 'CLOCK_CTRL', 'base': 0x30000000, 'size': 0x1000, 'access': 'RW',
             'description': 'Clock Control Unit',
             'registers': {'CLK_CTL': 0x00, 'PLL_CTL': 0x04, 'DIV_CTL': 0x08, 'FREQ_STAT': 0x0C}},
            {'name': 'GPIO_BANK0', 'base': 0x40000000, 'size': 0x1000, 'access': 'RW',
             'description': 'General Purpose I/O Bank 0',
             'registers': {'GPIO_DIR': 0x00, 'GPIO_DATA': 0x04, 'GPIO_SET': 0x08, 'GPIO_CLR': 0x0C}},
            {'name': 'UART0', 'base': 0x50000000, 'size': 0x1000, 'access': 'RW',
             'description': 'UART Controller 0',
             'registers': {'UART_TX': 0x00, 'UART_RX': 0x04, 'UART_STAT': 0x08, 'UART_BAUD': 0x0C}},
        ]
    
    if not capabilities['hardware_blocks']:
        capabilities['hardware_blocks'] = [
            {'name': 'CPU', 'description': 'Processor core(s)'},
            {'name': 'GPU', 'description': 'Graphics Processing Unit'},
            {'name': 'NPU', 'description': 'Neural Processing Unit'},
            {'name': 'DSP', 'description': 'Digital Signal Processor'},
            {'name': 'DDR', 'description': 'Memory Controller'},
            {'name': 'USB', 'description': 'USB 3.0/2.0 Controller'},
            {'name': 'PCIE', 'description': 'PCI Express Controller'},
            {'name': 'EMMC', 'description': 'eMMC Storage Controller'},
            {'name': 'UFS', 'description': 'UFS Storage Controller'},
            {'name': 'DISPLAY', 'description': 'Display Controller'},
            {'name': 'AUDIO', 'description': 'Audio Codec'},
            {'name': 'SECURITY', 'description': 'Security Engine'},
        ]
    
    if not capabilities['state_locations']:
        capabilities['state_locations'] = [
            {'name': 'CPUID', 'address': 0x10000000, 'size': 4},
            {'name': 'SYSCFG', 'address': 0x10000004, 'size': 4},
            {'name': 'RST_CTL', 'address': 0x10000008, 'size': 4},
            {'name': 'CLK_CTL', 'address': 0x30000000, 'size': 4},
            {'name': 'PWR_CTL', 'address': 0x20000000, 'size': 4},
            {'name': 'GPIO_DIR', 'address': 0x40000000, 'size': 4},
            {'name': 'GPIO_DATA', 'address': 0x40000004, 'size': 4},
            {'name': 'UART_BAUD', 'address': 0x5000000C, 'size': 4},
        ]
    
    return capabilities

def resolve_rawstate_address(target, dev):
    """Resolve rawstate address with hardware awareness - FIXED"""
    # Check for named registers first
    named_registers = {
        'CPUID': 0x10000000,
        'SYSCFG': 0x10000004,
        'RST_CTL': 0x10000008,
        'CLK_CTL': 0x30000000,
        'PWR_CTL': 0x20000000,
        'GPIO_BASE': 0x40000000,
        'GPIO_DIR': 0x40000000,
        'GPIO_DATA': 0x40000004,
        'GPIO_SET': 0x40000008,
        'GPIO_CLR': 0x4000000C,
        'UART_BASE': 0x50000000,
        'UART_TX': 0x50000000,
        'UART_RX': 0x50000004,
        'UART_STAT': 0x50000008,
        'UART_BAUD': 0x5000000C,
    }
    
    target_upper = target.upper()
    if target_upper in named_registers:
        return named_registers[target_upper]
    
    # Try standard address resolution
    try:
        return resolve_address(target, dev)
    except:
        return None

def read_raw_state(dev, address, size, verbose=False):
    """Read raw hardware state - FIXED with better error handling"""
    try:
        # Validate inputs
        if size <= 0 or size > 1024:  # Limit read size
            if verbose:
                print(f"[!] Invalid read size: {size}")
            return None, False
        
        read_payload = struct.pack("<II", address, size)
        
        # Try RAWSTATE command first
        # FIXED: Changed from QSLCLPAR_DB to QSLCLCMD_DB
        if "RAWSTATE" in QSLCLCMD_DB:
            if verbose:
                print(f"[DEBUG] Using RAWSTATE command for read at 0x{address:08X}")
            resp = qslcl_dispatch(dev, "RAWSTATE", read_payload)
        else:
            # Fallback to memory read
            if verbose:
                print(f"[DEBUG] Using READ command for read at 0x{address:08X}")
            # FIXED: Use proper command dispatch
            resp = qslcl_dispatch(dev, "READ", read_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                data = status["extra"]
                if len(data) >= size:
                    return data[:size], True
                elif len(data) > 0:
                    # Pad with zeros if needed
                    if verbose:
                        print(f"[DEBUG] Received {len(data)} bytes, expected {size}")
                    return data.ljust(size, b'\x00'), True
                else:
                    return b'\x00' * size, True  # Return zeros for empty response
            elif verbose:
                print(f"[!] Read error: {status}")
        elif verbose:
            print("[!] No response from device")
            
    except Exception as e:
        if verbose:
            print(f"[!] Read exception: {e}")
    
    return None, False

def write_raw_state(dev, address, data, verbose=False):
    """Write raw hardware state - FIXED with better error handling"""
    try:
        size = len(data)
        if size <= 0 or size > 1024:  # Limit write size
            if verbose:
                print(f"[!] Invalid write size: {size}")
            return False
        
        write_payload = struct.pack("<II", address, size) + data
        
        # Try RAWSTATE command first
        # FIXED: Changed from QSLCLPAR_DB to QSLCLCMD_DB
        if "RAWSTATE" in QSLCLCMD_DB:
            if verbose:
                print(f"[DEBUG] Using RAWSTATE command for write at 0x{address:08X}")
            resp = qslcl_dispatch(dev, "RAWSTATE", write_payload)
        else:
            # Fallback to memory write
            if verbose:
                print(f"[DEBUG] Using WRITE command for write at 0x{address:08X}")
            # FIXED: Use proper command dispatch
            resp = qslcl_dispatch(dev, "WRITE", write_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                return True
            elif verbose:
                print(f"[!] Write error: {status}")
        elif verbose:
            print("[!] No response from device")
            
    except Exception as e:
        if verbose:
            print(f"[!] Write exception: {e}")
    
    return False

def dump_raw_state_region(dev, address, size, verbose=False):
    """Dump a region of hardware state - FIXED with progress indication"""
    if size <= 0:
        return b""
    
    dump_data = bytearray()
    chunk_size = 64  # Read in 64-byte chunks
    
    if verbose:
        print(f"[*] Dumping {size} bytes from 0x{address:08X}")
    
    for offset in range(0, size, chunk_size):
        current_addr = address + offset
        current_size = min(chunk_size, size - offset)
        
        chunk, success = read_raw_state(dev, current_addr, current_size, False)
        if success and chunk:
            dump_data.extend(chunk)
        else:
            # Pad with zeros on failure
            dump_data.extend(b'\x00' * current_size)
            if verbose:
                print(f"[!] Read failed at offset 0x{offset:X}, padding with zeros")
            
        if verbose and (offset % 1024 == 0 or offset + chunk_size >= size):
            percent = min(100, (offset + current_size) * 100 // size)
            print(f"    Progress: {offset + current_size}/{size} bytes ({percent}%)")
    
    if verbose:
        print(f"[+] Dump complete: {len(dump_data)} bytes")
    
    return bytes(dump_data)

def parse_rawstate_value(value_str, size):
    """Parse rawstate value string - FIXED with more formats"""
    try:
        value_str = value_str.strip()
        
        # Handle hex strings without 0x prefix
        if ' ' in value_str:
            # Space-separated bytes: "12 34 56 78"
            bytes_list = []
            for part in value_str.split():
                if part.startswith('0x'):
                    bytes_list.append(int(part, 16))
                else:
                    bytes_list.append(int(part, 16) if all(c in '0123456789ABCDEFabcdef' for c in part) else int(part))
            
            # Convert to bytes
            result = bytes(bytes_list)
            
            # Pad or truncate to requested size
            if len(result) < size:
                result = result.ljust(size, b'\x00')
            elif len(result) > size:
                result = result[:size]
            
            return result
        
        # Handle hex string: "AABBCCDD"
        if len(value_str) % 2 == 0 and all(c in '0123456789ABCDEFabcdef' for c in value_str):
            # Even length hex string
            value = int(value_str, 16)
            return value.to_bytes(size, 'little')
        
        # Handle 0x prefix
        if value_str.startswith('0x'):
            value = int(value_str[2:], 16)
            return value.to_bytes(size, 'little')
        
        # Handle binary: "0b1010"
        if value_str.startswith('0b'):
            value = int(value_str[2:], 2)
            return value.to_bytes(size, 'little')
        
        # Decimal
        value = int(value_str)
        return value.to_bytes(size, 'little')
        
    except ValueError:
        return None

def is_critical_register(address):
    """Check if register address is critical - FIXED with more ranges"""
    critical_ranges = [
        (0x10000000, 0x10000FFF),  # System control
        (0x20000000, 0x20000FFF),  # Power management
        (0x30000000, 0x30000FFF),  # Clock control
        (0x40000000, 0x40000FFF),  # Reset control
        (0x50000000, 0x50000FFF),  # Boot control
        (0x60000000, 0x60000FFF),  # Security control
        (0x70000000, 0x70000FFF),  # Fuse control
    ]
    
    for start, end in critical_ranges:
        if start <= address <= end:
            return True
    
    # Also check specific critical addresses
    critical_addresses = [
        0x10000000,  # CPUID
        0x10000004,  # SYSCFG
        0x10000008,  # RST_CTL
        0x20000000,  # PWR_CTL
        0x30000000,  # CLK_CTL
    ]
    
    return address in critical_addresses

def get_register_name(address):
    """Get register name from address - FIXED"""
    register_map = {
        0x10000000: "CPUID (Processor Identification)",
        0x10000004: "SYSCFG (System Configuration)",
        0x10000008: "RST_CTL (Reset Control)",
        0x20000000: "PWR_CTL (Power Control)",
        0x30000000: "CLK_CTL (Clock Control)",
        0x40000000: "GPIO_DIR (GPIO Direction)",
        0x40000004: "GPIO_DATA (GPIO Data)",
        0x40000008: "GPIO_SET (GPIO Set)",
        0x4000000C: "GPIO_CLR (GPIO Clear)",
        0x50000000: "UART_TX (UART Transmit)",
        0x50000004: "UART_RX (UART Receive)",
        0x50000008: "UART_STAT (UART Status)",
        0x5000000C: "UART_BAUD (UART Baud Rate)",
    }
    
    return register_map.get(address, f"Unknown Register (0x{address:08X})")

def display_state_data(data, address, size, target, verbose=False):
    """Display state data in formatted output - FIXED"""
    if not data or len(data) < size:
        print(f"[!] Invalid data: {len(data) if data else 0} bytes, expected {size}")
        return
    
    # Convert to integer
    if len(data) >= size:
        value = int.from_bytes(data[:size], 'little')
    else:
        value = int.from_bytes(data.ljust(size, b'\x00')[:size], 'little')
    
    print(f"\n[+] State Data:")
    print(f"    Target: {target}")
    print(f"    Address: 0x{address:08X}")
    print(f"    Size: {size} bytes ({size*8} bits)")
    print(f"    Hex: 0x{value:0{size*2}X}")
    print(f"    Decimal: {value}")
    
    if value > 2**31:  # For 32-bit values, show as signed
        signed_value = value - 2**32
        print(f"    Signed: {signed_value}")
    
    if size <= 8:
        # Show binary representation
        binary = format(value, f'0{size*8}b')
        
        # Group bits for readability (8-bit groups)
        grouped_binary = ' '.join([binary[i:i+8] for i in range(0, len(binary), 8)])
        print(f"    Binary: {grouped_binary}")
        
        # Show nibble groups for small values
        if size <= 2:
            nibble_groups = ' '.join([binary[i:i+4] for i in range(0, len(binary), 4)])
            print(f"    Nibbles: {nibble_groups}")
        
        if size == 4:
            # Additional 32-bit specific information
            print(f"\n    32-bit Interpretation:")
            print(f"    High 16 bits: 0x{(value >> 16) & 0xFFFF:04X}")
            print(f"    Low 16 bits:  0x{value & 0xFFFF:04X}")
            print(f"    High byte:    0x{(value >> 24) & 0xFF:02X}")
            print(f"    2nd byte:     0x{(value >> 16) & 0xFF:02X}")
            print(f"    3rd byte:     0x{(value >> 8) & 0xFF:02X}")
            print(f"    Low byte:     0x{value & 0xFF:02X}")

def display_state_dump(data, address, target, verbose=False):
    """Display state dump in hex format - FIXED with better formatting"""
    if not data:
        print("[!] No data to display")
        return
    
    data_len = len(data)
    print(f"\n[+] State Dump: {target}")
    print(f"    Address: 0x{address:08X}-0x{address+data_len:08X}")
    print(f"    Size: {data_len} bytes")
    
    # Show hex dump
    bytes_per_line = 16
    
    for i in range(0, data_len, bytes_per_line):
        line_data = data[i:i+bytes_per_line]
        hex_part = ' '.join(f'{b:02x}' for b in line_data)
        
        # ASCII representation
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in line_data)
        
        # Offset
        offset = address + i
        
        # Format the line
        hex_groups = []
        for j in range(0, len(line_data), 4):
            group = line_data[j:j+4]
            if group:
                hex_groups.append(''.join(f'{b:02x}' for b in group))
        
        hex_formatted = ' '.join(hex_groups)
        
        print(f"    0x{offset:08x}: {hex_formatted:<39} |{ascii_part}|")
    
    # Summary
    print(f"\n    Summary:")
    print(f"      Total bytes: {data_len}")
    
    # Calculate statistics
    if data_len > 0:
        zero_count = data.count(b'\x00')
        ff_count = data.count(b'\xff')
        printable_count = sum(1 for b in data if 32 <= b < 127)
        
        print(f"      Zero bytes: {zero_count} ({zero_count*100/data_len:.1f}%)")
        print(f"      0xFF bytes: {ff_count} ({ff_count*100/data_len:.1f}%)")
        print(f"      Printable: {printable_count} ({printable_count*100/data_len:.1f}%)")
        
        # Check for patterns
        if zero_count == data_len:
            print(f"      Note: All bytes are zero")
        elif ff_count == data_len:
            print(f"      Note: All bytes are 0xFF")

def analyze_state_dump(data, base_address):
    """Analyze state dump for patterns - NEW FUNCTION"""
    if len(data) < 4:
        return
    
    print(f"\n[+] Pattern Analysis:")
    
    # Check for repeating patterns
    for pattern_len in [1, 2, 4, 8]:
        if len(data) >= pattern_len * 3:
            pattern = data[:pattern_len]
            repeats = 0
            for i in range(pattern_len, len(data), pattern_len):
                if data[i:i+pattern_len] == pattern:
                    repeats += 1
                else:
                    break
            
            if repeats >= 2:
                pattern_hex = pattern.hex()
                print(f"    Repeating {pattern_len}-byte pattern: {pattern_hex}")
                print(f"    Repeats: {repeats + 1} times")
    
    # Check for incrementing/decrementing values
    if len(data) >= 8:
        # Try to interpret as 32-bit values
        inc_count = 0
        dec_count = 0
        
        for i in range(0, len(data) - 4, 4):
            if i + 8 > len(data):
                break
                
            val1 = int.from_bytes(data[i:i+4], 'little')
            val2 = int.from_bytes(data[i+4:i+8], 'little')
            
            if val2 == val1 + 1:
                inc_count += 1
            elif val2 == val1 - 1:
                dec_count += 1
        
        if inc_count > len(data) // 8:  # At least half increment
            print(f"    Pattern: Incrementing 32-bit values")
        elif dec_count > len(data) // 8:
            print(f"    Pattern: Decrementing 32-bit values")

def scan_state_region(dev, start_addr, end_addr, pattern, size=4, verbose=False):
    """Scan region for state pattern - FIXED"""
    found = []
    scan_range = end_addr - start_addr
    
    if scan_range <= 0:
        return found
    
    # Read scan region
    scan_data = dump_raw_state_region(dev, start_addr, scan_range, verbose)
    
    if not scan_data:
        return found
    
    # Convert pattern to bytes
    pattern_bytes = pattern.to_bytes(size, 'little')
    
    if verbose:
        print(f"[*] Scanning {scan_range} bytes for pattern...")
    
    # Search for pattern
    for offset in range(0, len(scan_data) - size + 1, size):
        chunk = scan_data[offset:offset+size]
        if chunk == pattern_bytes:
            found_addr = start_addr + offset
            found_value = int.from_bytes(chunk, 'little')
            found.append((found_addr, found_value))
            
            if verbose and len(found) % 100 == 0:
                print(f"    Found {len(found)} matches...")
    
    return found

def print_rawstate_help():
    """Display rawstate command help - FIXED with better formatting"""
    print("""
╔═══════════════════════════════════════════════════════════════════════╗
║                         RAWSTATE COMMAND HELP                         ║
╚═══════════════════════════════════════════════════════════════════════╝

USAGE:
  rawstate <subcommand> [arguments] [options]

SUBCOMMANDS:
  list, ls, show                List available hardware states and registers
  read, get, peek <addr> [size] Read hardware state/register
  write, set, poke <addr> <value> [size] Write hardware state/register
  dump, snapshot <addr> [size]  Dump state region to screen
  compare, diff <addr1> <addr2> [size] Compare two states
  monitor, watch <addr> [interval] [duration] Monitor state changes
  bit, bits <addr> <op> <bit>   Bit-level operations (SET, CLEAR, TOGGLE, TEST)
  field, fields <addr> <range>  Extract bit fields (e.g., "7:0" or "15")
  scan, search <start> <end> <pattern> [size] Scan for patterns
  reset, clear <addr> [value] [size] Reset state to default value
  bank, banks <bank|all>        Display register bank information
  help, ?                       Show this help message

ARGUMENTS:
  <addr>        Address, register name, or expression
  <value>       Value to write (hex: 0x1234, decimal: 4660, binary: 0b1010)
  <size>        Size in bytes (1, 2, 4, 8) or with suffix (256, 0x100, 1K)
  <pattern>     Pattern to scan for (same formats as value)
  <range>       Bit range "high:low" (e.g., "31:24") or single bit "15"
  <interval>    Monitoring interval in seconds (default: 1.0)
  <duration>    Maximum monitoring duration in seconds

OPTIONS:
  --verbose, -v     Verbose output with debugging information
  --force           Skip safety checks (DANGEROUS!)

REGISTER NAMES:
  CPUID      (0x10000000) - Processor identification
  SYSCFG     (0x10000004) - System configuration  
  RST_CTL    (0x10000008) - Reset control
  CLK_CTL    (0x30000000) - Clock control
  PWR_CTL    (0x20000000) - Power control
  GPIO_*     (0x40000000) - General Purpose I/O
  UART_*     (0x50000000) - UART controller

BIT OPERATIONS:
  SET, 1, HIGH     - Set bit to 1
  CLEAR, 0, LOW    - Clear bit to 0
  TOGGLE, FLIP, XOR - Toggle bit (0→1, 1→0)
  TEST, READ       - Read bit value without changing

EXAMPLES:
  rawstate list                     # List all hardware states
  rawstate read CPUID               # Read CPU identification register
  rawstate read 0x10000000 8        # Read 8 bytes from address
  rawstate write PWR_CTL 0x1234     # Write to power control register
  rawstate dump 0x20000000 256      # Dump 256 bytes from power management
  rawstate compare CPUID SYSCFG     # Compare two registers
  rawstate monitor CLK_CTL 0.1 30   # Monitor for 30 seconds every 0.1s
  rawstate bit GPIO_SET SET 15      # Set GPIO bit 15
  rawstate field STATUS 31:28       # Extract bits 31-28 as a field
  rawstate scan 0x1000 0x2000 0xAA  # Scan for 0xAA pattern
  rawstate reset RST_CTL            # Reset register to 0
  rawstate bank all                 # Show all register banks
  rawstate bank SYSTEM_CTRL         # Show system control bank

SAFETY WARNINGS:
  ⚠️  Writing hardware registers can DAMAGE DEVICES
  ⚠️  Critical registers require explicit confirmation
  ⚠️  Use --force only in controlled environments
  ⚠️  Always verify operations before writing
  
  When in doubt, use 'read' and 'monitor' commands first to understand
  the current state before attempting any writes.

TIPS:
  • Use 'rawstate list' to discover available registers
  • Start with 'read' operations to verify addresses
  • Use 'monitor' to observe register behavior
  • For bit operations, verify with 'field' command first
  • Large dumps/scans can be slow - use smaller ranges first
  • Hexadecimal (0x...) is the recommended format for addresses/values
    """)

# =============================================================================
# RAWSTATE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================
def add_rawstate_arguments(parser):
    """Add rawstate-specific arguments to argument parser - FIXED"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output with detailed information")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Skip safety checks (DANGEROUS!)")
    parser.add_argument("--bank", "-b", type=str,
                       help="Specify register bank (overrides address)")
    parser.add_argument("--size", "-s", type=str,
                       help="Size in bytes (supports K, M suffixes)")
    parser.add_argument("--format", "-fmt", choices=['hex', 'dec', 'bin', 'all'],
                       default='hex', help="Output format")
    return parser