def cmd_rawstate(args=None):
    """
    Fully implemented RAWSTATE command with advanced features:
    - Low-level hardware state inspection and manipulation
    - Register access and bit-level operations
    - System state snapshots and comparison
    - Real-time state monitoring and tracing
    - Hardware debugging and diagnostics
    """
    if not args:
        print("[!] RAWSTATE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'rawstate_subcommand', '').lower()
    rawstate_args = getattr(args, 'rawstate_args', [])
    verbose = getattr(args, 'verbose', False)
    force = getattr(args, 'force', False)

    if not subcommand:
        print("[!] RAWSTATE: No subcommand specified")
        print_rawstate_help()
        return

    print(f"[*] RAWSTATE command: {subcommand} {rawstate_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'show']:
            rawstate_list(dev, rawstate_args, verbose)
            
        elif subcommand in ['read', 'get', 'peek']:
            rawstate_read(dev, rawstate_args, verbose)
            
        elif subcommand in ['write', 'set', 'poke']:
            rawstate_write(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['dump', 'snapshot', 'capture']:
            rawstate_dump(dev, rawstate_args, verbose)
            
        elif subcommand in ['compare', 'diff']:
            rawstate_compare(dev, rawstate_args, verbose)
            
        elif subcommand in ['monitor', 'watch', 'trace']:
            rawstate_monitor(dev, rawstate_args, verbose)
            
        elif subcommand in ['bit', 'bits', 'bitwise']:
            rawstate_bit(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['field', 'fields']:
            rawstate_field(dev, rawstate_args, verbose)
            
        elif subcommand in ['scan', 'search', 'find']:
            rawstate_scan(dev, rawstate_args, verbose)
            
        elif subcommand in ['reset', 'clear', 'init']:
            rawstate_reset(dev, rawstate_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_rawstate_help()
            
        else:
            print(f"[!] Unknown RAWSTATE subcommand: {subcommand}")
            print_rawstate_help()
            
    except Exception as e:
        print(f"[!] RAWSTATE operation failed: {e}")
        if verbose:
            import traceback
            traceback.print_exc()

# =============================================================================
# RAWSTATE SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def rawstate_list(dev, args, verbose=False):
    """List available hardware states and registers"""
    print("[*] Querying hardware state capabilities...")
    
    capabilities = query_rawstate_capabilities(dev, verbose)
    
    print(f"\n[+] RAWSTATE Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    State Access: {capabilities.get('state_access', 'Basic')}")
    
    # List available register banks
    register_banks = capabilities.get('register_banks', [])
    if register_banks:
        print(f"\n[+] Register Banks:")
        for bank in register_banks:
            access = bank.get('access', 'UNKNOWN')
            access_icon = "🟢" if access == 'RW' else "🟡" if access == 'RO' else "🔴"
            print(f"    {access_icon} {bank['name']:20} - 0x{bank['base']:08X}-0x{bank['base']+bank['size']:08X}")
    
    # List hardware blocks
    hardware_blocks = capabilities.get('hardware_blocks', [])
    if hardware_blocks:
        print(f"\n[+] Hardware Blocks:")
        for block in hardware_blocks:
            print(f"    {block['name']:20} - {block.get('description', '')}")
    
    # List common state locations
    state_locations = capabilities.get('state_locations', [])
    if state_locations:
        print(f"\n[+] Common State Locations:")
        for location in state_locations:
            print(f"    {location['name']:20} - 0x{location['address']:08X}")

def rawstate_read(dev, args, verbose=False):
    """Read hardware state/register"""
    if not args:
        print("[!] Specify address or register name to read")
        return
        
    target = args[0]
    size = 4  # Default 32-bit read
    if len(args) > 1:
        try:
            size = int(args[1])
        except ValueError:
            pass
    
    print(f"[*] Reading raw state from: {target}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Read state
        state_data, success = read_raw_state(dev, address, size, verbose)
        
        if success and state_data:
            display_state_data(state_data, address, size, target, verbose)
        else:
            print(f"[!] Failed to read state from 0x{address:08X}")
            
    except Exception as e:
        print(f"[!] State read failed: {e}")

def rawstate_write(dev, args, force=False, verbose=False):
    """Write hardware state/register"""
    if len(args) < 2:
        print("[!] Specify address and value to write")
        return
        
    target = args[0]
    value_str = args[1]
    size = 4  # Default 32-bit write
    
    print(f"[*] Writing raw state to: {target} = {value_str}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Safety check for critical registers
        if not force and is_critical_register(address):
            print(f"[!] WARNING: Writing to critical register 0x{address:08X}!")
            print(f"[!] This may damage hardware or brick device!")
            response = input("    Type 'WRITE' to continue: ")
            if response != 'WRITE':
                print("[*] Operation cancelled")
                return
        
        # Parse value
        write_data = parse_rawstate_value(value_str, size)
        if write_data is None:
            print(f"[!] Invalid value: {value_str}")
            return
            
        print(f"[+] Writing: {write_data.hex()}")
        
        # Read original value first
        original_data, _ = read_raw_state(dev, address, size, False)
        if original_data:
            original_value = int.from_bytes(original_data, 'little')
            print(f"[+] Original: 0x{original_value:0{size*2}X}")
        
        # Write state
        success = write_raw_state(dev, address, write_data, verbose)
        
        if success:
            print("[+] State write successful")
            
            # Verify write if possible
            if original_data:
                verify_data, _ = read_raw_state(dev, address, size, False)
                if verify_data:
                    verify_value = int.from_bytes(verify_data, 'little')
                    new_value = int.from_bytes(write_data, 'little')
                    
                    if verify_value == new_value:
                        print("[+] Write verification PASSED")
                    else:
                        print(f"[!] Write verification FAILED: 0x{verify_value:0{size*2}X} != 0x{new_value:0{size*2}X}")
                        
        else:
            print(f"[!] Failed to write state to 0x{address:08X}")
            
    except Exception as e:
        print(f"[!] State write failed: {e}")

def rawstate_dump(dev, args, verbose=False):
    """Dump hardware state region"""
    if not args:
        print("[!] Specify address range to dump")
        return
        
    target = args[0]
    size_str = "256"  # Default dump size
    if len(args) > 1:
        size_str = args[1]
    
    print(f"[*] Dumping raw state region: {target}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        size = parse_size_string(size_str)
        
        print(f"[+] Dump range: 0x{address:08X}-0x{address+size:08X} ({size} bytes)")
        
        # Dump state region
        dump_data = dump_raw_state_region(dev, address, size, verbose)
        
        if dump_data:
            display_state_dump(dump_data, address, target, verbose)
        else:
            print(f"[!] Failed to dump state region")
            
    except Exception as e:
        print(f"[!] State dump failed: {e}")

def rawstate_compare(dev, args, verbose=False):
    """Compare hardware states"""
    if len(args) < 2:
        print("[!] Specify two states to compare")
        return
        
    target1 = args[0]
    target2 = args[1]
    size = 4
    
    print(f"[*] Comparing states: {target1} vs {target2}")
    
    try:
        # Resolve addresses
        addr1 = resolve_rawstate_address(target1, dev)
        addr2 = resolve_rawstate_address(target2, dev)
        
        if addr1 is None or addr2 is None:
            print(f"[!] Could not resolve addresses")
            return
            
        # Read both states
        state1, success1 = read_raw_state(dev, addr1, size, False)
        state2, success2 = read_raw_state(dev, addr2, size, False)
        
        if success1 and success2 and state1 and state2:
            value1 = int.from_bytes(state1, 'little')
            value2 = int.from_bytes(state2, 'little')
            
            print(f"\n[+] Comparison Results:")
            print(f"    {target1} (0x{addr1:08X}): 0x{value1:08X}")
            print(f"    {target2} (0x{addr2:08X}): 0x{value2:08X}")
            
            if value1 == value2:
                print(f"    ✅ States are IDENTICAL")
            else:
                print(f"    🔄 States are DIFFERENT")
                diff = value1 ^ value2
                print(f"    Difference: 0x{diff:08X}")
                
                # Show bit differences
                differing_bits = []
                for bit in range(32):
                    if diff & (1 << bit):
                        differing_bits.append(bit)
                
                if differing_bits:
                    print(f"    Differing bits: {', '.join(map(str, differing_bits))}")
                    
        else:
            print(f"[!] Failed to read states for comparison")
            
    except Exception as e:
        print(f"[!] State comparison failed: {e}")

def rawstate_monitor(dev, args, verbose=False):
    """Monitor hardware state changes"""
    if not args:
        print("[!] Specify state to monitor")
        return
        
    target = args[0]
    interval = 1.0  # Default interval
    if len(args) > 1:
        try:
            interval = float(args[1])
        except ValueError:
            pass
    
    print(f"[*] Monitoring state: {target} (interval: {interval}s)")
    print("[*] Press Ctrl+C to stop monitoring")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        previous_value = None
        start_time = time.time()
        
        while True:
            try:
                # Read current state
                state_data, success = read_raw_state(dev, address, 4, False)
                
                if success and state_data:
                    current_value = int.from_bytes(state_data, 'little')
                    elapsed = time.time() - start_time
                    
                    if previous_value is None:
                        print(f"[{elapsed:6.1f}s] Initial: 0x{current_value:08X}")
                    elif current_value != previous_value:
                        diff = current_value ^ previous_value
                        print(f"[{elapsed:6.1f}s] CHANGED: 0x{current_value:08X} (diff: 0x{diff:08X})")
                    elif verbose:
                        print(f"[{elapsed:6.1f}s] Stable: 0x{current_value:08X}")
                    
                    previous_value = current_value
                    
                time.sleep(interval)
                
            except KeyboardInterrupt:
                print(f"\n[*] Monitoring stopped")
                break
            except Exception as e:
                print(f"[!] Monitor error: {e}")
                time.sleep(interval)
                
    except Exception as e:
        print(f"[!] State monitoring failed: {e}")

def rawstate_bit(dev, args, force=False, verbose=False):
    """Bit-level state operations"""
    if len(args) < 2:
        print("[!] Specify address and bit operation")
        return
        
    target = args[0]
    operation = args[1].upper()
    bit_num = 0
    if len(args) > 2:
        try:
            bit_num = int(args[2])
        except ValueError:
            print(f"[!] Invalid bit number: {args[2]}")
            return
    
    print(f"[*] Bit operation: {target} bit {bit_num} -> {operation}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Read current state
        current_data, success = read_raw_state(dev, address, 4, False)
        if not success or not current_data:
            print(f"[!] Failed to read current state")
            return
            
        current_value = int.from_bytes(current_data, 'little')
        print(f"[+] Current: 0x{current_value:08X}")
        
        # Perform bit operation
        if operation in ['SET', '1', 'HIGH']:
            new_value = current_value | (1 << bit_num)
            operation_desc = f"SET bit {bit_num}"
        elif operation in ['CLEAR', '0', 'LOW']:
            new_value = current_value & ~(1 << bit_num)
            operation_desc = f"CLEAR bit {bit_num}"
        elif operation in ['TOGGLE', 'FLIP', 'XOR']:
            new_value = current_value ^ (1 << bit_num)
            operation_desc = f"TOGGLE bit {bit_num}"
        else:
            print(f"[!] Unknown bit operation: {operation}")
            return
            
        print(f"[+] {operation_desc}: 0x{new_value:08X}")
        
        # Safety check
        if not force and is_critical_register(address):
            print(f"[!] WARNING: Modifying critical register!")
            response = input("    Type 'BIT' to continue: ")
            if response != 'BIT':
                print("[*] Operation cancelled")
                return
        
        # Write new value
        new_data = new_value.to_bytes(4, 'little')
        success = write_raw_state(dev, address, new_data, verbose)
        
        if success:
            print(f"[+] Bit operation successful")
        else:
            print(f"[!] Bit operation failed")
            
    except Exception as e:
        print(f"[!] Bit operation failed: {e}")

def rawstate_field(dev, args, verbose=False):
    """Extract and display bit fields"""
    if len(args) < 2:
        print("[!] Specify address and field range")
        return
        
    target = args[0]
    field_spec = args[1]  # Format: "high:low" or "bit"
    
    print(f"[*] Extracting field: {target} [{field_spec}]")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Read state
        state_data, success = read_raw_state(dev, address, 4, False)
        if not success or not state_data:
            print(f"[!] Failed to read state")
            return
            
        value = int.from_bytes(state_data, 'little')
        print(f"[+] Raw value: 0x{value:08X}")
        
        # Parse field specification
        if ':' in field_spec:
            # Range format: "high:low"
            high_str, low_str = field_spec.split(':')
            high_bit = int(high_str)
            low_bit = int(low_str)
            
            if high_bit < low_bit:
                high_bit, low_bit = low_bit, high_bit
                
            field_width = high_bit - low_bit + 1
            field_mask = ((1 << field_width) - 1) << low_bit
            field_value = (value & field_mask) >> low_bit
            
            print(f"[+] Field [{high_bit}:{low_bit}]:")
            print(f"    Width: {field_width} bits")
            print(f"    Mask: 0x{field_mask:08X}")
            print(f"    Value: 0x{field_value:0{field_width//4}X} ({field_value})")
            
            # Show binary representation
            binary = format(field_value, f'0{field_width}b')
            print(f"    Binary: {binary}")
            
        else:
            # Single bit
            bit_num = int(field_spec)
            bit_value = (value >> bit_num) & 1
            
            print(f"[+] Bit [{bit_num}]: {bit_value}")
            
    except Exception as e:
        print(f"[!] Field extraction failed: {e}")

def rawstate_scan(dev, args, verbose=False):
    """Scan for state patterns"""
    if len(args) < 2:
        print("[!] Specify address range and pattern")
        return
        
    start_addr_str = args[0]
    end_addr_str = args[1]
    pattern_str = args[2] if len(args) > 2 else "0x00000000"
    
    print(f"[*] Scanning: {start_addr_str} to {end_addr_str} for {pattern_str}")
    
    try:
        # Resolve addresses
        start_addr = resolve_rawstate_address(start_addr_str, dev)
        end_addr = resolve_rawstate_address(end_addr_str, dev)
        
        if start_addr is None or end_addr is None:
            print(f"[!] Could not resolve addresses")
            return
            
        # Parse pattern
        pattern_value = parse_address(pattern_str)
        
        print(f"[+] Scan range: 0x{start_addr:08X}-0x{end_addr:08X}")
        print(f"[+] Target pattern: 0x{pattern_value:08X}")
        
        # Scan region
        found_addresses = scan_state_region(dev, start_addr, end_addr, pattern_value, verbose)
        
        if found_addresses:
            print(f"\n[+] Found {len(found_addresses)} matches:")
            for addr, value in found_addresses[:10]:  # Show first 10
                print(f"    0x{addr:08X}: 0x{value:08X}")
            if len(found_addresses) > 10:
                print(f"    ... and {len(found_addresses) - 10} more")
        else:
            print(f"[+] No matches found")
            
    except Exception as e:
        print(f"[!] State scan failed: {e}")

def rawstate_reset(dev, args, force=False, verbose=False):
    """Reset hardware state to default"""
    if not args:
        print("[!] Specify state to reset")
        return
        
    target = args[0]
    default_value = 0x00000000
    if len(args) > 1:
        default_value = parse_address(args[1])
    
    print(f"[*] Resetting state: {target} to 0x{default_value:08X}")
    
    try:
        # Resolve address
        address = resolve_rawstate_address(target, dev)
        if address is None:
            print(f"[!] Could not resolve: {target}")
            return
            
        # Safety check
        if not force and is_critical_register(address):
            print(f"[!] WARNING: Resetting critical register!")
            response = input("    Type 'RESET' to continue: ")
            if response != 'RESET':
                print("[*] Operation cancelled")
                return
        
        # Write default value
        reset_data = default_value.to_bytes(4, 'little')
        success = write_raw_state(dev, address, reset_data, verbose)
        
        if success:
            print(f"[+] State reset successful")
        else:
            print(f"[!] State reset failed")
            
    except Exception as e:
        print(f"[!] State reset failed: {e}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR RAWSTATE
# =============================================================================

def query_rawstate_capabilities(dev, verbose=False):
    """Query device rawstate capabilities"""
    capabilities = {
        'device_name': 'Unknown',
        'architecture': 'Unknown',
        'state_access': 'Basic',
        'register_banks': [
            {'name': 'SYSTEM', 'base': 0x10000000, 'size': 0x1000, 'access': 'RW'},
            {'name': 'POWER', 'base': 0x20000000, 'size': 0x1000, 'access': 'RW'},
            {'name': 'CLOCK', 'base': 0x30000000, 'size': 0x1000, 'access': 'RW'},
            {'name': 'GPIO', 'base': 0x40000000, 'size': 0x1000, 'access': 'RW'},
            {'name': 'UART', 'base': 0x50000000, 'size': 0x1000, 'access': 'RW'},
        ],
        'hardware_blocks': [
            {'name': 'CPU', 'description': 'Processor core'},
            {'name': 'GPU', 'description': 'Graphics processor'},
            {'name': 'DSP', 'description': 'Digital signal processor'},
            {'name': 'DDR', 'description': 'Memory controller'},
            {'name': 'USB', 'description': 'USB controller'},
            {'name': 'PCIE', 'description': 'PCI Express'},
            {'name': 'EMMC', 'description': 'Storage controller'},
        ],
        'state_locations': [
            {'name': 'CPUID', 'address': 0x10000000},
            {'name': 'SYSCFG', 'address': 0x10000004},
            {'name': 'RST_CTL', 'address': 0x10000008},
            {'name': 'CLK_CTL', 'address': 0x30000000},
            {'name': 'PWR_CTL', 'address': 0x20000000},
        ]
    }
    
    try:
        # Try to query actual capabilities
        query_payload = struct.pack("<B", 0x00)  # CAPABILITIES query
        
        if "RAWSTATE" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RAWSTATE", query_payload)
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    # Parse capability data (simplified)
                    pass
    except Exception:
        pass
    
    return capabilities

def resolve_rawstate_address(target, dev):
    """Resolve rawstate address with hardware awareness"""
    # Check for named registers first
    named_registers = {
        'CPUID': 0x10000000,
        'SYSCFG': 0x10000004,
        'RST_CTL': 0x10000008,
        'CLK_CTL': 0x30000000,
        'PWR_CTL': 0x20000000,
        'GPIO_BASE': 0x40000000,
        'UART_BASE': 0x50000000,
    }
    
    if target.upper() in named_registers:
        return named_registers[target.upper()]
    
    # Try standard address resolution
    return resolve_address(target, dev)

def read_raw_state(dev, address, size, verbose=False):
    """Read raw hardware state"""
    try:
        read_payload = struct.pack("<II", address, size)
        
        if "RAWSTATE" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RAWSTATE", read_payload)
        else:
            # Fallback to memory read
            resp = qslcl_dispatch(dev, "READ", read_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                return status["extra"], True
            elif verbose:
                print(f"[!] Read error: {status}")
        elif verbose:
            print("[!] No response from device")
            
    except Exception as e:
        if verbose:
            print(f"[!] Read exception: {e}")
    
    return None, False

def write_raw_state(dev, address, data, verbose=False):
    """Write raw hardware state"""
    try:
        write_payload = struct.pack("<II", address, len(data)) + data
        
        if "RAWSTATE" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RAWSTATE", write_payload)
        else:
            # Fallback to memory write
            resp = qslcl_dispatch(dev, "WRITE", write_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                return True
            elif verbose:
                print(f"[!] Write error: {status}")
        elif verbose:
            print("[!] No response from device")
            
    except Exception as e:
        if verbose:
            print(f"[!] Write exception: {e}")
    
    return False

def dump_raw_state_region(dev, address, size, verbose=False):
    """Dump a region of hardware state"""
    dump_data = bytearray()
    chunk_size = 64
    
    for offset in range(0, size, chunk_size):
        current_addr = address + offset
        current_size = min(chunk_size, size - offset)
        
        chunk, success = read_raw_state(dev, current_addr, current_size, False)
        if success and chunk:
            dump_data.extend(chunk)
        else:
            # Pad with zeros on failure
            dump_data.extend(b'\x00' * current_size)
            
        if verbose and offset % 256 == 0:
            print(f"    Dumped: {offset}/{size} bytes")
    
    return bytes(dump_data)

def parse_rawstate_value(value_str, size):
    """Parse rawstate value string"""
    try:
        if value_str.startswith('0x'):
            value = int(value_str, 16)
        else:
            value = int(value_str)
        
        return value.to_bytes(size, 'little')
    except ValueError:
        return None

def is_critical_register(address):
    """Check if register address is critical"""
    critical_ranges = [
        (0x10000000, 0x10000FFF),  # System control
        (0x20000000, 0x20000FFF),  # Power management
        (0x30000000, 0x30000FFF),  # Clock control
        (0x40000000, 0x40000FFF),  # Reset control
    ]
    
    for start, end in critical_ranges:
        if start <= address <= end:
            return True
    
    return False

def display_state_data(data, address, size, target, verbose=False):
    """Display state data in formatted output"""
    value = int.from_bytes(data, 'little')
    
    print(f"\n[+] State Data:")
    print(f"    Target: {target}")
    print(f"    Address: 0x{address:08X}")
    print(f"    Size: {size} bytes")
    print(f"    Value: 0x{value:0{size*2}X}")
    print(f"    Decimal: {value}")
    
    if size == 4:
        # Show binary representation for 32-bit values
        binary = format(value, '032b')
        print(f"    Binary: {binary}")
        
        # Show bit fields
        print(f"    Bit fields:")
        for i in range(0, 32, 4):
            bits = binary[28-i:32-i] if i < 28 else binary[0:4]
            print(f"      [{31-i}:{28-i}] {bits} = 0x{int(bits, 2):X}")

def display_state_dump(data, address, target, verbose=False):
    """Display state dump in hex format"""
    print(f"\n[+] State Dump: {target} (0x{address:08X}-0x{address+len(data):08X})")
    
    # Show hex dump
    for i in range(0, len(data), 16):
        line_data = data[i:i+16]
        hex_part = ' '.join(f'{b:02x}' for b in line_data)
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in line_data)
        print(f"    0x{address+i:08x}: {hex_part:<48} |{ascii_part}|")

def scan_state_region(dev, start_addr, end_addr, pattern, verbose=False):
    """Scan region for state pattern"""
    found = []
    scan_size = end_addr - start_addr
    
    if scan_size > 0x10000:  # Limit large scans
        print(f"[!] Scan region too large, limiting to 64KB")
        scan_size = 0x10000
    
    # Read scan region
    scan_data = dump_raw_state_region(dev, start_addr, scan_size, verbose)
    
    if not scan_data:
        return found
    
    # Search for pattern
    pattern_bytes = pattern.to_bytes(4, 'little')
    
    for offset in range(0, len(scan_data) - 3, 4):
        chunk = scan_data[offset:offset+4]
        if chunk == pattern_bytes:
            found_addr = start_addr + offset
            found_value = int.from_bytes(chunk, 'little')
            found.append((found_addr, found_value))
            
            if verbose and len(found) % 10 == 0:
                print(f"    Found {len(found)} matches...")
    
    return found

def print_rawstate_help():
    """Display rawstate command help"""
    print("""
RAWSTATE Command Usage:
  rawstate list                    - List available hardware states
  rawstate read <addr> [size]      - Read hardware state/register
  rawstate write <addr> <value>    - Write hardware state/register
  rawstate dump <addr> [size]      - Dump state region
  rawstate compare <addr1> <addr2> - Compare two states
  rawstate monitor <addr> [interval] - Monitor state changes
  rawstate bit <addr> <op> <bit>   - Bit-level operations
  rawstate field <addr> <range>    - Extract bit fields
  rawstate scan <start> <end> <pattern> - Scan for state patterns
  rawstate reset <addr> [value]    - Reset state to default

Bit Operations:
  SET, 1, HIGH    - Set bit to 1
  CLEAR, 0, LOW   - Clear bit to 0  
  TOGGLE, FLIP    - Toggle bit state

Field Specification:
  <high>:<low>    - Bit range (e.g., "7:0" for bits 7-0)
  <bit>           - Single bit (e.g., "15" for bit 15)

Common Registers:
  CPUID    - Processor identification
  SYSCFG   - System configuration
  RST_CTL  - Reset control
  CLK_CTL  - Clock control
  PWR_CTL  - Power control

Examples:
  rawstate read CPUID              # Read CPU identification
  rawstate write CLK_CTL 0x1234    # Write clock control
  rawstate bit GPIO_SET 1 15       # Set bit 15
  rawstate field STATUS 31:28      # Extract bits 31-28
  rawstate monitor RST_CTL 0.5     # Monitor every 0.5s
  rawstate scan 0x1000 0x2000 0xAA # Scan for pattern

Safety:
  - Writing hardware registers can damage devices
  - Use --force to bypass safety checks (DANGEROUS)
  - Critical registers require explicit confirmation
  - Always verify operations in safe environment
    """)

# =============================================================================
# RAWSTATE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_rawstate_arguments(parser):
    """Add rawstate-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    return parser