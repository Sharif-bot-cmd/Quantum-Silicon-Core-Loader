def cmd_erase(args=None):
    """
    Fully implemented ERASE command with advanced features:
    - Multiple erase modes (zero fill, ones fill, pattern erase)
    - Partition and region targeting
    - Smart size detection
    - Progress tracking with verification
    - Safety checks and confirmation
    - Multiple erase algorithms
    """
    if not args:
        print("[!] ERASE: No arguments provided")
        return 1

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    
    # Load loader if specified
    if hasattr(args, 'loader') and args.loader:
        auto_loader_if_needed(args, dev)

    # =========================================================================
    # ARGUMENT PARSING
    # =========================================================================
    # Get target from args (multiple possible attribute names)
    target = None
    target_attrs = ['target', 'arg1', 'erase_target']
    for attr in target_attrs:
        if hasattr(args, attr) and getattr(args, attr):
            target = getattr(args, attr)
            break
    
    if not target:
        print("[!] ERASE: No target specified")
        print("[*] Usage: erase <partition|address> [size]")
        return 1

    # Get size from various possible argument names
    size_arg = None
    size_attrs = ['size', 'arg2', 'erase_size']
    for attr in size_attrs:
        if hasattr(args, attr) and getattr(args, attr):
            size_arg = getattr(args, attr)
            break

    # Get other parameters with defaults
    chunk_size = getattr(args, 'chunk_size', 1048576)  # 1MB default for erase
    force = getattr(args, 'force', False)
    
    # Get erase pattern from arguments
    erase_pattern = getattr(args, 'pattern', '00')  # Default to zero fill
    if hasattr(args, 'erase_pattern') and args.erase_pattern:
        erase_pattern = args.erase_pattern

    print(f"[*] ERASE command: target={target}, pattern={erase_pattern}")

    # =========================================================================
    # 1. TARGET RESOLUTION
    # =========================================================================
    address = 0
    erase_size = 0
    partition_info = None
    partitions = load_partitions(dev)

    if not partitions:
        print("[!] No partitions detected on device")
        print("[*] Using raw address mode only")

    # Parse target (partition or address)
    if '+' in str(target):
        # Partition+offset format: "boot+0x1000"
        try:
            part_name, offset_str = str(target).split('+', 1)
            part_name = part_name.strip().lower()
            offset_str = offset_str.strip()
            
            found = False
            for part in partitions:
                if part['name'].lower() == part_name:
                    offset = parse_address(offset_str)
                    address = part['offset'] + offset
                    partition_info = part
                    
                    if size_arg:
                        erase_size = parse_size_string(size_arg)
                    else:
                        erase_size = part['size'] - offset
                    
                    print(f"[+] Target: {part['name']}+{offset_str} = 0x{address:08X}")
                    found = True
                    break
            
            if not found:
                print(f"[!] Unknown partition: {part_name}")
                print(f"[*] Available partitions: {[p['name'] for p in partitions]}")
                return 1
                
        except Exception as e:
            print(f"[!] Failed to parse partition+offset '{target}': {e}")
            return 1
    else:
        # Check if target is a partition name
        target_lower = str(target).strip().lower()
        found = False
        
        for part in partitions:
            if part['name'].lower() == target_lower:
                partition_info = part
                address = part['offset']
                erase_size = part['size']
                print(f"[+] Target is partition: {part['name']} (0x{address:08X}, size: 0x{erase_size:08X})")
                found = True
                break
        
        # If not a partition, parse as raw address
        if not found:
            try:
                address = parse_address(target)
                print(f"[+] Target address: 0x{address:08X}")
                
                # For raw addresses, require size specification
                if not size_arg:
                    print("[!] Size required for raw address erase")
                    print("[*] Use --size <bytes> or specify a partition name")
                    return 1
                
                erase_size = parse_size_string(size_arg)
            except (ValueError, TypeError) as e:
                print(f"[!] Invalid target format: {target} - {e}")
                print("[*] Valid formats: partition_name, address, partition+offset")
                return 1

    if erase_size <= 0:
        print(f"[!] Invalid erase size: {erase_size}")
        return 1

    # =========================================================================
    # 2. ERASE PATTERN CONFIGURATION
    # =========================================================================
    erase_byte = None  # Default to None for random
    pattern_name = "Random"
    
    pattern = str(erase_pattern).lower().strip()
    
    if pattern in ['00', 'zero', 'zeros', 'clean']:
        erase_byte = 0x00
        pattern_name = "Zero fill (0x00)"
    elif pattern in ['ff', 'ones', 'erase', 'blank']:
        erase_byte = 0xFF
        pattern_name = "One fill (0xFF)"
    elif pattern in ['aa', 'checker']:
        erase_byte = 0xAA
        pattern_name = "Checker (0xAA)"
    elif pattern in ['55', 'checker2']:
        erase_byte = 0x55
        pattern_name = "Checker (0x55)"
    elif pattern in ['f0', 'stripes']:
        erase_byte = 0xF0
        pattern_name = "Stripes (0xF0)"
    elif pattern in ['random', 'rand', 'secure']:
        erase_byte = None  # Special case for random data
        pattern_name = "Random data (secure erase)"
    else:
        # Try to parse as hex byte
        try:
            if pattern.startswith('0x'):
                pattern = pattern[2:]
            erase_byte = int(pattern, 16) & 0xFF
            pattern_name = f"Custom (0x{erase_byte:02X})"
        except ValueError:
            print(f"[!] Invalid erase pattern: {erase_pattern}")
            print("[*] Valid patterns: 00, ff, aa, 55, f0, random")
            return 1

    # =========================================================================
    # 3. SAFETY CHECKS AND CONFIRMATION
    # =========================================================================
    if partition_info:
        # Check critical partitions
        critical_partitions = ['boot', 'recovery', 'system', 'bootloader', 
                              'aboot', 'sbl', 'tz', 'trustzone', 'lk', 'xbl']
        partition_name_lower = partition_info['name'].lower()
        
        is_critical = any(crit in partition_name_lower for crit in critical_partitions)
        
        if is_critical:
            print(f"\n[!] ⚠️  WARNING: ERASING CRITICAL PARTITION: {partition_info['name']}")
            print(f"[!] ⚠️  THIS CAN PERMANENTLY BRICK YOUR DEVICE!")
            print(f"[!] ⚠️  Only proceed if you know what you're doing!")
            
            if not force:
                print("\n[*] Type 'I_ACCEPT_THE_RISK' to confirm (exactly as shown)")
                response = input("    Confirmation: ")
                if response != 'I_ACCEPT_THE_RISK':
                    print("[*] Operation cancelled - safety first!")
                    return 0
                print("[*] Confirmation accepted, proceeding...")

        # Check if erase fits in partition
        if erase_size > partition_info['size']:
            print(f"[!] Erase size exceeds partition: 0x{erase_size:08X} > 0x{partition_info['size']:08X}")
            if not force:
                return 1
            else:
                print("[!] Force mode: truncating to partition size")
                erase_size = partition_info['size']

    # Show erase summary
    print(f"\n{'='*60}")
    print(f"[*] ERASE SUMMARY:")
    print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
    print(f"    Size: 0x{erase_size:08X} ({erase_size:,} bytes, {erase_size/1024/1024:.2f} MB)")
    print(f"    Pattern: {pattern_name}")
    print(f"    Chunk size: 0x{chunk_size:08X} ({chunk_size:,} bytes)")
    print(f"{'='*60}")

    if not force:
        print("\n[*] Confirm erase operation?")
        print("    Type 'YES' to proceed, anything else to cancel")
        response = input("    Confirm: ")
        if response.upper() != 'YES':
            print("[*] Operation cancelled")
            return 0

    # =========================================================================
    # 4. ERASE OPERATION
    # =========================================================================
    print(f"\n[*] Starting erase operation...")
    print(f"    Erasing 0x{erase_size:08X} bytes at 0x{address:08X}")
    
    bytes_erased = 0
    retry_count = 0
    max_retries = 3
    failed_chunks = []
    start_time = time.time()

    try:
        with ProgressBar(erase_size, prefix='Erasing', suffix='Complete', length=50) as progress:
            chunk_num = 0
            while bytes_erased < erase_size:
                chunk_addr = address + bytes_erased
                remaining = erase_size - bytes_erased
                current_chunk_size = min(chunk_size, remaining)
                chunk_num += 1
                
                # Show chunk info (every 10 chunks or for first/last)
                if chunk_num <= 3 or chunk_num % 10 == 0 or remaining <= chunk_size:
                    print(f"\n[*] Chunk {chunk_num}: 0x{chunk_addr:08X} (0x{current_chunk_size:04X} bytes)")
                
                # Generate erase data for this chunk
                if erase_byte is not None:
                    # Fixed pattern
                    chunk_data = bytes([erase_byte]) * current_chunk_size
                else:
                    # Random data - more secure but slower
                    chunk_data = os.urandom(current_chunk_size)
                
                try:
                    # Build ERASE/WRITE command packet
                    # Format: <address(4)><size(4)><data>
                    erase_header = struct.pack("<II", chunk_addr, current_chunk_size)
                    erase_payload = erase_header + chunk_data
                    
                    # Try different command approaches
                    success = False
                    
                    # Approach 1: Use ERASE command if available
                    if "ERASE" in QSLCLCMD_DB:
                        resp = qslcl_dispatch(dev, "ERASE", erase_payload)
                        if resp:
                            status = decode_runtime_result(resp)
                            success = (status["severity"] == "SUCCESS")
                    
                    # Approach 2: Fallback to WRITE command
                    if not success and "WRITE" in QSLCLCMD_DB:
                        resp = qslcl_dispatch(dev, "WRITE", erase_payload)
                        if resp:
                            status = decode_runtime_result(resp)
                            success = (status["severity"] == "SUCCESS")
                    
                    # Approach 3: Generic fallback
                    if not success:
                        cmd = f"ERASE 0x{chunk_addr:08X} 0x{current_chunk_size:04X}"
                        full_payload = cmd.encode() + b' ' + chunk_data
                        resp = qslcl_dispatch(dev, "ERASE", full_payload)
                        if resp:
                            status = decode_runtime_result(resp)
                            success = (status["severity"] == "SUCCESS")
                    
                    if success:
                        bytes_erased += current_chunk_size
                        progress.update(current_chunk_size)
                        retry_count = 0  # Reset retry counter
                    else:
                        error_msg = status.get("name", "UNKNOWN") if 'status' in locals() else "NO_RESPONSE"
                        print(f"\n[!] Erase error at 0x{chunk_addr:08X}: {error_msg}")
                        failed_chunks.append({
                            'address': chunk_addr,
                            'size': current_chunk_size,
                            'error': error_msg,
                            'retry_count': 0
                        })
                        retry_count += 1
                    
                    # Handle retries
                    if retry_count >= max_retries:
                        print(f"[!] Max retries ({max_retries}) exceeded")
                        break
                        
                except Exception as e:
                    print(f"\n[!] Erase exception at 0x{chunk_addr:08X}: {type(e).__name__}: {e}")
                    failed_chunks.append({
                        'address': chunk_addr,
                        'size': current_chunk_size,
                        'error': str(e),
                        'retry_count': 0
                    })
                    retry_count += 1
                    if retry_count >= max_retries:
                        print(f"[!] Max retries exceeded due to exceptions")
                        break
                    
                    # Exponential backoff for retries
                    backoff_time = 0.1 * (2 ** retry_count)
                    print(f"[*] Retrying in {backoff_time:.2f}s...")
                    time.sleep(backoff_time)

        elapsed_time = time.time() - start_time
        speed = bytes_erased / elapsed_time if elapsed_time > 0 else 0
        
        # =========================================================================
        # 5. RETRY FAILED CHUNKS
        # =========================================================================
        if failed_chunks:
            print(f"\n[*] Retrying {len(failed_chunks)} failed chunks...")
            retry_successful = 0
            
            for chunk_info in failed_chunks[:]:  # Copy list for modification
                chunk_addr = chunk_info['address']
                chunk_size = chunk_info['size']
                
                for attempt in range(max_retries):
                    try:
                        # Generate data for retry
                        if erase_byte is not None:
                            chunk_data = bytes([erase_byte]) * chunk_size
                        else:
                            chunk_data = os.urandom(chunk_size)
                        
                        erase_header = struct.pack("<II", chunk_addr, chunk_size)
                        erase_payload = erase_header + chunk_data
                        
                        # Use WRITE for retry (more reliable)
                        resp = qslcl_dispatch(dev, "WRITE", erase_payload)
                        if resp:
                            status = decode_runtime_result(resp)
                            if status["severity"] == "SUCCESS":
                                bytes_erased += chunk_size
                                failed_chunks.remove(chunk_info)
                                retry_successful += 1
                                print(f"[+] Retry successful for 0x{chunk_addr:08X}")
                                break
                            else:
                                print(f"[!] Retry failed for 0x{chunk_addr:08X} (attempt {attempt+1}): {status['name']}")
                        else:
                            print(f"[!] No response for 0x{chunk_addr:08X} (attempt {attempt+1})")
                        
                        time.sleep(0.05 * (attempt + 1))  # Increasing delay
                        
                    except Exception as e:
                        print(f"[!] Retry exception for 0x{chunk_addr:08X}: {e}")
                
                if chunk_info in failed_chunks:  # Still failed after retries
                    print(f"[!] Permanent failure at 0x{chunk_addr:08X}")
            
            if retry_successful > 0:
                print(f"[+] {retry_successful} chunks recovered via retry")

        # =========================================================================
        # 6. VERIFICATION (Optional)
        # =========================================================================
        verify = not getattr(args, 'no_verify', False)
        
        if verify and bytes_erased > 0 and erase_byte is not None:
            print("\n[*] Verifying erase operation...")
            verify_success = True
            verification_errors = []
            verify_start_time = time.time()
            
            with ProgressBar(bytes_erased, prefix='Verify', suffix='Complete', length=50) as progress:
                verify_addr = address
                remaining_verify = bytes_erased
                verify_chunk_num = 0
                
                while remaining_verify > 0 and verify_success:
                    verify_chunk_size = min(chunk_size, remaining_verify)
                    verify_chunk_num += 1
                    
                    # Read back for verification
                    read_payload = struct.pack("<II", verify_addr, verify_chunk_size)
                    resp = qslcl_dispatch(dev, "READ", read_payload)
                    
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            read_data = status["extra"] if "extra" in status else b""
                            
                            if len(read_data) == verify_chunk_size:
                                # Verify erase pattern
                                expected_byte = bytes([erase_byte])
                                if all(read_data[i:i+1] == expected_byte for i in range(len(read_data))):
                                    progress.update(verify_chunk_size)
                                else:
                                    # Count mismatched bytes
                                    mismatches = sum(1 for i in range(len(read_data)) 
                                                   if read_data[i:i+1] != expected_byte)
                                    error_info = {
                                        'address': verify_addr,
                                        'mismatches': mismatches,
                                        'total': verify_chunk_size,
                                        'percentage': mismatches/verify_chunk_size*100
                                    }
                                    verification_errors.append(error_info)
                                    
                                    if mismatches > verify_chunk_size * 0.01:  # >1% error
                                        print(f"\n[!] Verify failed at 0x{verify_addr:08X}: "
                                              f"{mismatches}/{verify_chunk_size} bytes mismatch ({error_info['percentage']:.1f}%)")
                                        if not force:
                                            verify_success = False
                                    else:
                                        # Minor errors, continue
                                        progress.update(verify_chunk_size)
                            else:
                                error_info = {
                                    'address': verify_addr,
                                    'error': f"Size mismatch: {len(read_data)} != {verify_chunk_size}"
                                }
                                verification_errors.append(error_info)
                                print(f"\n[!] Size mismatch at 0x{verify_addr:08X}")
                                if not force:
                                    verify_success = False
                        else:
                            error_info = {
                                'address': verify_addr,
                                'error': f"Read error: {status.get('name', 'UNKNOWN')}"
                            }
                            verification_errors.append(error_info)
                            print(f"\n[!] Verify read failed at 0x{verify_addr:08X}: {status.get('name', 'UNKNOWN')}")
                            if not force:
                                verify_success = False
                    else:
                        error_info = {
                            'address': verify_addr,
                            'error': "No response"
                        }
                        verification_errors.append(error_info)
                        print(f"\n[!] No verify response at 0x{verify_addr:08X}")
                        if not force:
                            verify_success = False
                    
                    verify_addr += verify_chunk_size
                    remaining_verify -= verify_chunk_size
            
            verify_time = time.time() - verify_start_time
            print(f"[*] Verification completed in {verify_time:.2f}s")
        else:
            verification_errors = []
            print("\n[*] Skipping verification (random pattern or verification disabled)")

        # =========================================================================
        # 7. FINAL SUMMARY
        # =========================================================================
        total_time = time.time() - start_time
        
        print(f"\n{'='*60}")
        print(f"[+] ERASE OPERATION COMPLETED")
        print(f"{'='*60}")
        print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
        print(f"    Requested size: 0x{erase_size:08X} ({erase_size:,} bytes)")
        print(f"    Erased: 0x{bytes_erased:08X} ({bytes_erased:,} bytes)")
        print(f"    Success rate: {bytes_erased/erase_size*100:.1f}%")
        print(f"    Pattern: {pattern_name}")
        print(f"    Time elapsed: {total_time:.2f} seconds")
        print(f"    Average speed: {speed/1024:.1f} KB/s")
        
        if failed_chunks:
            print(f"\n    Failed chunks: {len(failed_chunks)}")
            for chunk in failed_chunks[:5]:  # Show first 5 errors
                print(f"      - 0x{chunk['address']:08X}: {chunk['error']}")
            if len(failed_chunks) > 5:
                print(f"      ... and {len(failed_chunks) - 5} more")

        if verification_errors:
            print(f"\n    Verification errors: {len(verification_errors)}")
            total_mismatches = sum(e.get('mismatches', 0) for e in verification_errors)
            total_verified = sum(e.get('total', 0) for e in verification_errors if 'total' in e)
            
            if total_verified > 0:
                error_percent = total_mismatches / total_verified * 100
                print(f"    Total mismatched bytes: {total_mismatches:,}/{total_verified:,} ({error_percent:.3f}%)")
            
            for error in verification_errors[:3]:  # Show first 3 errors
                if 'mismatches' in error:
                    print(f"      - 0x{error['address']:08X}: {error['mismatches']}/{error['total']} bytes ({error['percentage']:.1f}%)")
                else:
                    print(f"      - 0x{error['address']:08X}: {error.get('error', 'Unknown error')}")

        if verification_errors and force:
            print(f"\n    [!] Force mode: Verification errors ignored")

        if bytes_erased == erase_size and not failed_chunks and not verification_errors:
            print(f"\n    ✅ Status: COMPLETE SUCCESS")
            return 0
        elif bytes_erased == erase_size and (failed_chunks or verification_errors):
            print(f"\n    ⚠️  Status: COMPLETE WITH ERRORS")
            return 1
        else:
            print(f"\n    ❌ Status: PARTIAL - {bytes_erased}/{erase_size} bytes ({bytes_erased/erase_size*100:.1f}%)")
            return 1

    except KeyboardInterrupt:
        print("\n\n[!] ERASE operation interrupted by user")
        print(f"[*] Partially erased: 0x{bytes_erased:08X}/{erase_size:08X} bytes")
        return 1
    except Exception as e:
        print(f"\n[!] ERASE operation failed: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return 1