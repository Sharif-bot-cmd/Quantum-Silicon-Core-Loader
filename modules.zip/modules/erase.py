def cmd_erase(args=None):
    """
    Fully implemented ERASE command with advanced features:
    - Multiple erase modes (zero fill, ones fill, pattern erase)
    - Partition and region targeting
    - Smart size detection
    - Progress tracking with verification
    - Safety checks and confirmation
    - Multiple erase algorithms
    """
    if not args:
        print("[!] ERASE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    target = getattr(args, 'target', '')
    size_arg = getattr(args, 'size', None)
    chunk_size = getattr(args, 'chunk_size', 1048576)  # 1MB default for erase
    force = getattr(args, 'force', False)
    erase_pattern = getattr(args, 'pattern', '00')  # Default to zero fill

    if not target:
        print("[!] ERASE: No target specified")
        return

    print(f"[*] ERASE command: target={target}")

    # =========================================================================
    # 1. TARGET RESOLUTION
    # =========================================================================
    address = 0
    erase_size = 0
    partition_info = None
    partitions = load_partitions(dev)

    # Parse target (partition or address)
    if '+' in target:
        # Partition+offset format
        part_name, offset_str = target.split('+', 1)
        for part in partitions:
            if part['name'].lower() == part_name.lower():
                offset = parse_address(offset_str)
                address = part['offset'] + offset
                partition_info = part
                if size_arg:
                    erase_size = size_arg
                else:
                    erase_size = part['size'] - offset
                print(f"[+] Target: {part_name}+{offset_str} = 0x{address:08X}")
                break
        if not partition_info:
            print(f"[!] Unknown partition: {part_name}")
            return
    else:
        # Check if target is a partition name
        for part in partitions:
            if part['name'].lower() == target.lower():
                partition_info = part
                address = part['offset']
                erase_size = part['size']
                print(f"[+] Target is partition: {part['name']} (0x{address:08X}, size: 0x{erase_size:08X})")
                break
        
        # If not a partition, parse as raw address
        if not partition_info:
            try:
                address = parse_address(target)
                print(f"[+] Target address: 0x{address:08X}")
                
                # For raw addresses, require size specification
                if not size_arg:
                    print("[!] Size required for raw address erase")
                    print("[*] Use --size or specify a partition name")
                    return
                erase_size = size_arg
            except ValueError as e:
                print(f"[!] Invalid target format: {target} - {e}")
                return

    # Convert size to integer if it's a string
    if isinstance(erase_size, str):
        erase_size = parse_size_string(erase_size)

    if erase_size <= 0:
        print("[!] Invalid erase size")
        return

    # =========================================================================
    # 2. ERASE PATTERN CONFIGURATION
    # =========================================================================
    erase_byte = 0x00  # Default to zero fill
    
    if hasattr(args, 'pattern'):
        pattern = args.pattern.lower()
        if pattern in ['00', 'zero', 'zeros', 'clean']:
            erase_byte = 0x00
            print("[+] Erase pattern: Zero fill (0x00)")
        elif pattern in ['ff', 'ones', 'erase', 'blank']:
            erase_byte = 0xFF
            print("[+] Erase pattern: One fill (0xFF)")
        elif pattern in ['aa', 'checker']:
            erase_byte = 0xAA
            print("[+] Erase pattern: Checker (0xAA)")
        elif pattern in ['55', 'checker2']:
            erase_byte = 0x55
            print("[+] Erase pattern: Checker (0x55)")
        elif pattern in ['f0', 'stripes']:
            erase_byte = 0xF0
            print("[+] Erase pattern: Stripes (0xF0)")
        elif pattern in ['random', 'rand']:
            erase_byte = None  # Special case for random data
            print("[+] Erase pattern: Random data")
        else:
            # Try to parse as hex byte
            try:
                erase_byte = int(pattern, 16) & 0xFF
                print(f"[+] Erase pattern: Custom (0x{erase_byte:02X})")
            except ValueError:
                print(f"[!] Invalid erase pattern: {pattern}")
                return

    # =========================================================================
    # 3. SAFETY CHECKS AND CONFIRMATION
    # =========================================================================
    if partition_info:
        # Check critical partitions
        critical_partitions = ['boot', 'recovery', 'system', 'bootloader', 'aboot', 'sbl', 'tz']
        if partition_info['name'].lower() in critical_partitions:
            print(f"[!] WARNING: ERASING CRITICAL PARTITION: {partition_info['name']}")
            print(f"[!] THIS WILL BRICK YOUR DEVICE IF NOT DONE CORRECTLY!")
            
            if not force:
                response = input("    Type 'BRICK' to confirm: ")
                if response != 'BRICK':
                    print("[*] Operation cancelled")
                    return

        # Check if erase fits in partition
        if erase_size > partition_info['size']:
            print(f"[!] Erase size exceeds partition: 0x{erase_size:08X} > 0x{partition_info['size']:08X}")
            if not force:
                return
            else:
                print("[!] Force mode: truncating to partition size")
                erase_size = partition_info['size']

    # Show erase summary
    print(f"\n[*] ERASE SUMMARY:")
    print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
    print(f"    Size: 0x{erase_size:08X} ({erase_size} bytes)")
    print(f"    Pattern: {f'0x{erase_byte:02X}' if erase_byte is not None else 'Random'}")
    print(f"    Chunk size: 0x{chunk_size:08X}")

    if not force:
        response = input("\n[*] Confirm erase operation? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return

    # =========================================================================
    # 4. ERASE OPERATION
    # =========================================================================
    print(f"\n[*] Erasing 0x{erase_size:08X} bytes at 0x{address:08X}...")
    
    bytes_erased = 0
    retry_count = 0
    max_retries = 3
    failed_chunks = []

    try:
        with ProgressBar(erase_size, prefix='Erasing', suffix='Complete', length=50) as progress:
            while bytes_erased < erase_size:
                chunk_addr = address + bytes_erased
                remaining = erase_size - bytes_erased
                current_chunk_size = min(chunk_size, remaining)
                
                # Generate erase data for this chunk
                if erase_byte is not None:
                    # Fixed pattern
                    chunk_data = bytes([erase_byte]) * current_chunk_size
                else:
                    # Random data
                    chunk_data = os.urandom(current_chunk_size)
                
                try:
                    # Build ERASE/WRITE command packet
                    erase_header = struct.pack("<II", chunk_addr, current_chunk_size)
                    erase_payload = erase_header + chunk_data
                    
                    # Try ERASE command first, fallback to WRITE
                    if "ERASE" in QSLCLPAR_DB:
                        resp = qslcl_dispatch(dev, "ERASE", erase_payload)
                    elif "WRITE" in QSLCLPAR_DB:
                        resp = qslcl_dispatch(dev, "WRITE", erase_payload)
                    else:
                        # Generic fallback
                        cmd = f"ERASE 0x{chunk_addr:08X} 0x{current_chunk_size:04X}"
                        full_payload = cmd.encode() + b' ' + chunk_data
                        resp = qslcl_dispatch(dev, "ERASE", full_payload)
                    
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            bytes_erased += current_chunk_size
                            progress.update(current_chunk_size)
                            retry_count = 0  # Reset retry counter
                        else:
                            print(f"\n[!] Erase error at 0x{chunk_addr:08X}: {status}")
                            failed_chunks.append((chunk_addr, current_chunk_size))
                            retry_count += 1
                    else:
                        print(f"\n[!] No response at 0x{chunk_addr:08X}")
                        failed_chunks.append((chunk_addr, current_chunk_size))
                        retry_count += 1
                    
                    # Handle retries
                    if retry_count >= max_retries:
                        print(f"[!] Max retries exceeded at 0x{chunk_addr:08X}")
                        break
                        
                except Exception as e:
                    print(f"\n[!] Erase exception at 0x{chunk_addr:08X}: {e}")
                    failed_chunks.append((chunk_addr, current_chunk_size))
                    retry_count += 1
                    if retry_count >= max_retries:
                        break
                    time.sleep(0.1)  # Brief pause before retry

        # =========================================================================
        # 5. RETRY FAILED CHUNKS
        # =========================================================================
        if failed_chunks:
            print(f"\n[*] Retrying {len(failed_chunks)} failed chunks...")
            for chunk_addr, chunk_size in failed_chunks[:]:  # Copy list for modification
                retry_success = False
                for attempt in range(max_retries):
                    try:
                        # Generate data for retry
                        if erase_byte is not None:
                            chunk_data = bytes([erase_byte]) * chunk_size
                        else:
                            chunk_data = os.urandom(chunk_size)
                        
                        erase_header = struct.pack("<II", chunk_addr, chunk_size)
                        erase_payload = erase_header + chunk_data
                        
                        resp = qslcl_dispatch(dev, "WRITE", erase_payload)  # Use WRITE for retry
                        if resp and decode_runtime_result(resp)["severity"] == "SUCCESS":
                            bytes_erased += chunk_size
                            failed_chunks.remove((chunk_addr, chunk_size))
                            retry_success = True
                            print(f"[+] Retry successful for 0x{chunk_addr:08X}")
                            break
                    except Exception as e:
                        print(f"[!] Retry failed for 0x{chunk_addr:08X} (attempt {attempt+1}): {e}")
                
                if not retry_success:
                    print(f"[!] Permanent failure at 0x{chunk_addr:08X}")

        # =========================================================================
        # 6. VERIFICATION
        # =========================================================================
        print("\n[*] Verifying erase operation...")
        verify_success = True
        verification_errors = []

        with ProgressBar(bytes_erased, prefix='Verify', suffix='Complete', length=50) as progress:
            verify_addr = address
            remaining_verify = bytes_erased
            
            while remaining_verify > 0 and verify_success:
                verify_chunk_size = min(chunk_size, remaining_verify)
                
                # Read back for verification
                read_payload = struct.pack("<II", verify_addr, verify_chunk_size)
                resp = qslcl_dispatch(dev, "READ", read_payload)
                
                if resp:
                    status = decode_runtime_result(resp)
                    if status["severity"] == "SUCCESS":
                        read_data = status["extra"]
                        
                        # Verify erase pattern
                        if erase_byte is not None:
                            expected_byte = bytes([erase_byte])
                            if all(read_data[i:i+1] == expected_byte for i in range(len(read_data))):
                                progress.update(verify_chunk_size)
                            else:
                                # Count mismatched bytes
                                mismatches = sum(1 for i in range(len(read_data)) 
                                              if read_data[i:i+1] != expected_byte)
                                verification_errors.append((verify_addr, mismatches, verify_chunk_size))
                                print(f"\n[!] Verify failed at 0x{verify_addr:08X}: {mismatches}/{verify_chunk_size} bytes mismatch")
                                if not force:
                                    verify_success = False
                        else:
                            # For random data, we can't verify content, just check we can read
                            progress.update(verify_chunk_size)
                    else:
                        print(f"\n[!] Verify read failed at 0x{verify_addr:08X}: {status}")
                        verification_errors.append((verify_addr, verify_chunk_size, "READ_ERROR"))
                        if not force:
                            verify_success = False
                else:
                    print(f"\n[!] No verify response at 0x{verify_addr:08X}")
                    verification_errors.append((verify_addr, verify_chunk_size, "NO_RESPONSE"))
                    if not force:
                        verify_success = False
                
                verify_addr += verify_chunk_size
                remaining_verify -= verify_chunk_size

        # =========================================================================
        # 7. FINAL SUMMARY
        # =========================================================================
        print(f"\n[+] ERASE operation completed!")
        print(f"    Target: 0x{address:08X}" + (f" ({partition_info['name']})" if partition_info else ""))
        print(f"    Requested size: 0x{erase_size:08X} ({erase_size} bytes)")
        print(f"    Erased: 0x{bytes_erased:08X} ({bytes_erased} bytes)")
        print(f"    Success rate: {bytes_erased/erase_size*100:.1f}%")
        print(f"    Pattern: {f'0x{erase_byte:02X}' if erase_byte is not None else 'Random'}")
        
        if failed_chunks:
            print(f"    Failed chunks: {len(failed_chunks)}")
            for chunk_addr, chunk_size in failed_chunks:
                print(f"      - 0x{chunk_addr:08X} (0x{chunk_size:04X} bytes)")

        if verification_errors:
            print(f"    Verification errors: {len(verification_errors)}")
            for error in verification_errors[:5]:  # Show first 5 errors
                if len(error) == 3:
                    addr, mismatches, total = error
                    print(f"      - 0x{addr:08X}: {mismatches}/{total} bytes mismatch")
                else:
                    addr, size, error_type = error
                    print(f"      - 0x{addr:08X}: {error_type}")

        if verification_errors and force:
            print(f"    Force mode: {len(verification_errors)} verification errors ignored")

        if bytes_erased == erase_size and not verification_errors:
            print(f"    Status: COMPLETE SUCCESS")
        elif bytes_erased == erase_size and verification_errors:
            print(f"    Status: COMPLETE WITH VERIFICATION ERRORS")
        else:
            print(f"    Status: PARTIAL - {bytes_erased}/{erase_size} bytes")

    except Exception as e:
        print(f"[!] ERASE operation failed: {e}")

# =============================================================================
# ERASE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_erase_arguments(parser):
    """Add erase-specific arguments to argument parser"""
    parser.add_argument("--pattern", choices=['00', 'ff', 'aa', '55', 'f0', 'random', 'zero', 'ones', 'erase', 'blank', 'checker', 'stripes'],
                       default='00', help="Erase pattern (default: 00)")
    parser.add_argument("--algorithm", choices=['simple', 'secure', 'quick', 'verify'],
                       default='simple', help="Erase algorithm")
    return parser