PRIVILEGE_LEVELS = {
    0: {"name": "USER", "description": "Normal user mode, limited access"},
    1: {"name": "PRIVILEGED", "description": "System services, some drivers"},
    2: {"name": "SUPERVISOR", "description": "OS kernel, memory management"},
    3: {"name": "HYPERVISOR", "description": "VM control, hardware virtualization"},
    4: {"name": "ROOT", "description": "Bare metal, all hardware access"},
    5: {"name": "BOOTROM", "description": "Boot ROM level, unrestricted"}
}

# RAWMODE Features
RAWMODE_FEATURES = {
    "MMU_BYPASS": {
        "opcode": 0xA1,
        "description": "Bypass Memory Management Unit protection",
        "risk": "HIGH",
        "requires": "SUPERVISOR+"
    },
    "SECURITY_DISABLE": {
        "opcode": 0xA2,
        "description": "Disable security features (TrustZone, Secure Boot)",
        "risk": "CRITICAL",
        "requires": "HYPERVISOR+"
    },
    "JTAG_ENABLE": {
        "opcode": 0xA3,
        "description": "Enable JTAG debugging interface",
        "risk": "MEDIUM",
        "requires": "PRIVILEGED+"
    },
    "BOOTROM_ACCESS": {
        "opcode": 0xA4,
        "description": "Access boot ROM regions",
        "risk": "CRITICAL",
        "requires": "ROOT"
    },
    "DMA_ENABLE": {
        "opcode": 0xA5,
        "description": "Enable Direct Memory Access",
        "risk": "HIGH",
        "requires": "SUPERVISOR+"
    },
    "REGISTER_ACCESS": {
        "opcode": 0xA6,
        "description": "Access protected hardware registers",
        "risk": "MEDIUM",
        "requires": "PRIVILEGED+"
    },
    "DEBUG_ENABLE": {
        "opcode": 0xA7,
        "description": "Enable debug features and breakpoints",
        "risk": "MEDIUM",
        "requires": "SUPERVISOR+"
    },
    "TRACE_ENABLE": {
        "opcode": 0xA8,
        "description": "Enable instruction and memory tracing",
        "risk": "LOW",
        "requires": "PRIVILEGED+"
    }
}

# RAWMODE Commands
RAWMODE_CMDS = {
    "CAPABILITIES": 0x01,
    "STATUS": 0x02,
    "UNLOCK": 0x03,
    "LOCK": 0x04,
    "SET_FEATURE": 0x05,
    "CONFIGURE": 0x06,
    "ESCALATE": 0x07,
    "MONITOR": 0x08,
    "AUDIT": 0x09,
    "RESET": 0x0A,
    "LIST_FEATURES": 0x0B
}

# =============================================================================
# MAIN RAWMODE COMMAND
# =============================================================================

def cmd_rawmode(args=None):
    """
    Fixed and Enhanced RAWMODE command with:
    - Proper error handling
    - Enhanced security warnings
    - Session management
    - Audit logging
    - State persistence
    """
    if not args:
        print("[!] RAWMODE: No arguments provided")
        print_rawmode_help()
        return 1

    # Wait for device if specified
    if hasattr(args, 'wait') and args.wait > 0:
        print(f"[*] Waiting {args.wait} seconds for device...")
        time.sleep(args.wait)

    # Scan for devices
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    
    # Auto-load loader if specified
    if hasattr(args, 'loader') and args.loader:
        auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'rawmode_subcommand', '').lower()
    rawmode_args = getattr(args, 'rawmode_args', [])
    
    # Get optional arguments
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)
    timeout = getattr(args, 'timeout', 5.0)

    if not subcommand:
        print("[!] RAWMODE: No subcommand specified")
        print_rawmode_help()
        return 1

    print(f"[*] RAWMODE command: {subcommand} {' '.join(rawmode_args)}")

    # Initialize session
    session = RawmodeSession(dev, verbose=verbose, timeout=timeout)
    
    try:
        # Dispatch subcommands
        if subcommand in ['list', 'ls', 'show']:
            return rawmode_list(session, rawmode_args, verbose)
            
        elif subcommand in ['set', 'enable', 'on']:
            return rawmode_set(session, rawmode_args, force, verbose)
            
        elif subcommand in ['status', 'stat', 'info']:
            return rawmode_status(session, verbose)
            
        elif subcommand in ['unlock', 'auth', 'authenticate']:
            return rawmode_unlock(session, rawmode_args, force, verbose)
            
        elif subcommand in ['lock', 'disable', 'off']:
            return rawmode_lock(session, rawmode_args, verbose)
            
        elif subcommand in ['configure', 'config', 'cfg']:
            return rawmode_configure(session, rawmode_args, verbose)
            
        elif subcommand in ['escalate', 'priv', 'privilege']:
            return rawmode_escalate(session, rawmode_args, force, verbose)
            
        elif subcommand in ['monitor', 'watch', 'trace']:
            return rawmode_monitor(session, rawmode_args, verbose)
            
        elif subcommand in ['audit', 'log', 'history']:
            return rawmode_audit(session, rawmode_args, verbose)
            
        elif subcommand in ['reset', 'restart', 'reboot']:
            return rawmode_reset(session, rawmode_args, force, verbose)
            
        elif subcommand in ['help', '?', '-h', '--help']:
            print_rawmode_help()
            return 0
            
        else:
            print(f"[!] Unknown RAWMODE subcommand: {subcommand}")
            print_rawmode_help()
            return 1
            
    except Exception as e:
        print(f"[!] RAWMODE operation failed: {e}")
        if verbose:
            traceback.print_exc()
        return 1
    finally:
        # Clean up session
        if 'session' in locals():
            session.close()

# =============================================================================
# RAWMODE SESSION MANAGER
# =============================================================================

class RawmodeSession:
    """Manages RAWMODE sessions with state and security"""
    
    def __init__(self, dev, verbose=False, timeout=5.0):
        self.dev = dev
        self.verbose = verbose
        self.timeout = timeout
        self.session_id = None
        self.privilege_level = "USER"
        self.features_enabled = []
        self.audit_log = []
        self.start_time = time.time()
        
        # Generate session ID
        self.session_id = hashlib.sha256(
            f"{dev.identifier}{time.time()}".encode()
        ).hexdigest()[:16]
        
        self.log_audit("SESSION_START", "INFO", f"Session {self.session_id} started")
        
        if verbose:
            print(f"[*] RAWMODE Session ID: {self.session_id}")
    
    def execute(self, command, payload=b""):
        """Execute RAWMODE command with proper formatting"""
        if command not in RAWMODE_CMDS:
            # Try direct QSLCLPAR dispatch
            if "RAWMODE" in QSLCLPAR_DB:
                return qslcl_dispatch(self.dev, "RAWMODE", payload)
            else:
                # Build custom RAWMODE packet
                cmd_packet = struct.pack("<B", RAWMODE_CMDS.get(command, 0x00))
                cmd_packet += payload
                return qslcl_dispatch(self.dev, "RAWMODE", cmd_packet)
        
        # Use standard RAWMODE command
        cmd_packet = struct.pack("<B", RAWMODE_CMDS[command])
        cmd_packet += payload
        return qslcl_dispatch(self.dev, "RAWMODE", cmd_packet, timeout=self.timeout)
    
    def log_audit(self, event_type, severity, description):
        """Log audit event"""
        audit_entry = {
            "timestamp": time.time(),
            "session_id": self.session_id,
            "event_type": event_type,
            "severity": severity,
            "description": description,
            "privilege_level": self.privilege_level
        }
        self.audit_log.append(audit_entry)
        
        if self.verbose:
            ts = datetime.fromtimestamp(audit_entry["timestamp"]).strftime("%H:%M:%S")
            print(f"[AUDIT {ts}] [{severity}] {event_type}: {description}")
    
    def update_privilege(self, new_level):
        """Update privilege level with audit"""
        old_level = self.privilege_level
        self.privilege_level = new_level
        self.log_audit(
            "PRIVILEGE_CHANGE",
            "WARNING",
            f"Privilege changed from {old_level} to {new_level}"
        )
    
    def enable_feature(self, feature_name):
        """Track enabled features"""
        if feature_name not in self.features_enabled:
            self.features_enabled.append(feature_name)
            self.log_audit(
                "FEATURE_ENABLE",
                "WARNING",
                f"Feature {feature_name} enabled"
            )
    
    def close(self):
        """Close session and log summary"""
        duration = time.time() - self.start_time
        self.log_audit(
            "SESSION_END",
            "INFO",
            f"Session ended after {duration:.1f}s, "
            f"privilege: {self.privilege_level}, "
            f"features: {len(self.features_enabled)} enabled"
        )
        
        if self.verbose:
            print(f"[*] Session {self.session_id} closed")

# =============================================================================
# SUBCOMMAND IMPLEMENTATIONS (FIXED)
# =============================================================================

def rawmode_list(session, args, verbose=False):
    """List available rawmode features and capabilities"""
    print("[*] Querying RAWMODE capabilities...")
    
    try:
        # Query capabilities
        resp = session.execute("CAPABILITIES")
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                capabilities = parse_capability_data(status["extra"])
                display_capabilities(capabilities, verbose)
                session.log_audit("CAPABILITIES_QUERY", "INFO", "Success")
                return 0
            else:
                print(f"[!] Query failed: {status}")
                session.log_audit("CAPABILITIES_QUERY", "ERROR", f"Failed: {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("CAPABILITIES_QUERY", "ERROR", "No response")
            return 1
            
    except Exception as e:
        print(f"[!] Query error: {e}")
        session.log_audit("CAPABILITIES_QUERY", "ERROR", f"Exception: {str(e)}")
        return 1

def rawmode_set(session, args, force=False, verbose=False):
    """Enable or configure rawmode features"""
    if not args:
        print("[!] Specify feature to enable")
        print("    Usage: rawmode set <FEATURE_NAME> [VALUE]")
        return 1
    
    feature = args[0].upper()
    value = args[1] if len(args) > 1 else "1"
    
    # Validate feature
    if feature not in RAWMODE_FEATURES:
        print(f"[!] Unknown feature: {feature}")
        print(f"    Available features: {', '.join(RAWMODE_FEATURES.keys())}")
        return 1
    
    feature_info = RAWMODE_FEATURES[feature]
    
    print(f"[*] Setting RAWMODE feature: {feature} = {value}")
    print(f"    Description: {feature_info['description']}")
    print(f"    Risk Level: {feature_info['risk']}")
    print(f"    Requires: {feature_info['requires']}")
    
    # Security warning for dangerous features
    if feature_info['risk'] in ['HIGH', 'CRITICAL'] and not force:
        print(f"\n[!] WARNING: Enabling {feature} may:")
        print(f"    - Compromise device security")
        print(f"    - Cause system instability")
        print(f"    - Void warranties")
        print(f"    - Brick the device")
        
        response = input("\n    Type 'DANGER' to continue, or press Enter to cancel: ")
        if response != 'DANGER':
            print("[*] Operation cancelled")
            session.log_audit("FEATURE_SET", "INFO", f"Cancelled: {feature}")
            return 0
    
    # Build set command
    try:
        value_int = parse_address(value)
        set_payload = struct.pack("<B", feature_info['opcode'])
        set_payload += struct.pack("<I", value_int)
        
        resp = session.execute("SET_FEATURE", set_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Feature {feature} set successfully")
                session.enable_feature(feature)
                session.log_audit("FEATURE_SET", "WARNING", f"Enabled: {feature}")
                return 0
            else:
                print(f"[!] Failed to set {feature}: {status}")
                session.log_audit("FEATURE_SET", "ERROR", f"Failed: {feature} - {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("FEATURE_SET", "ERROR", f"No response for: {feature}")
            return 1
            
    except Exception as e:
        print(f"[!] Set operation failed: {e}")
        session.log_audit("FEATURE_SET", "ERROR", f"Exception: {feature} - {str(e)}")
        return 1

def rawmode_status(session, verbose=False):
    """Get current rawmode status and configuration"""
    print("[*] Querying RAWMODE status...")
    
    try:
        resp = session.execute("STATUS")
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                status_data = parse_rawmode_status(status["extra"])
                display_status(status_data, session, verbose)
                session.log_audit("STATUS_QUERY", "INFO", "Success")
                return 0
            else:
                print(f"[!] Status query failed: {status}")
                session.log_audit("STATUS_QUERY", "ERROR", f"Failed: {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("STATUS_QUERY", "ERROR", "No response")
            return 1
            
    except Exception as e:
        print(f"[!] Status query error: {e}")
        session.log_audit("STATUS_QUERY", "ERROR", f"Exception: {str(e)}")
        return 1

def rawmode_unlock(session, args, force=False, verbose=False):
    """Authenticate and unlock rawmode privileges"""
    print("[*] Attempting RAWMODE unlock...")
    
    # Determine authentication method
    auth_method = "DEFAULT"
    auth_data = b""
    
    if args:
        auth_method = args[0].upper()
        if len(args) > 1:
            # Support multiple auth data formats
            if args[1].startswith("0x"):
                auth_data = bytes.fromhex(args[1][2:])
            elif len(args[1]) % 2 == 0 and re.match(r'^[0-9a-fA-F]+$', args[1]):
                auth_data = bytes.fromhex(args[1])
            else:
                auth_data = args[1].encode('utf-8')
    
    # Security warning
    if not force:
        print("\n[!] WARNING: RAWMODE UNLOCK GRANTS FULL SYSTEM ACCESS!")
        print("    This operation:")
        print("    1. Removes all software security layers")
        print("    2. Grants bare-metal hardware access")
        print("    3. May void device warranties")
        print("    4. Can permanently damage devices if misused")
        print("    5. Is intended for AUTHORIZED RESEARCH ONLY")
        
        response = input("\n    Type 'UNLOCK' to continue, or press Enter to cancel: ")
        if response != 'UNLOCK':
            print("[*] Operation cancelled")
            session.log_audit("UNLOCK", "INFO", "Cancelled by user")
            return 0
    
    # Build unlock command
    try:
        unlock_payload = struct.pack("<B", 0x30)  # UNLOCK command
        unlock_payload += auth_method.encode('ascii').ljust(8, b'\x00')
        unlock_payload += struct.pack("<I", len(auth_data))
        unlock_payload += auth_data
        
        resp = session.execute("UNLOCK", unlock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                unlock_info = parse_unlock_info(status["extra"])
                print("[+] RAWMODE unlocked successfully!")
                
                if unlock_info:
                    new_level = unlock_info.get('privilege_level', 'UNKNOWN')
                    session.update_privilege(new_level)
                    print(f"    Privilege Level: {new_level}")
                    print(f"    Access Rights: {unlock_info.get('access_rights', 'UNKNOWN')}")
                    print(f"    Session ID: {unlock_info.get('session_id', 'UNKNOWN')}")
                
                session.log_audit("UNLOCK", "WARNING", "Success - Full access granted")
                return 0
            else:
                print(f"[!] Unlock failed: {status}")
                session.log_audit("UNLOCK", "ERROR", f"Failed: {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("UNLOCK", "ERROR", "No response")
            return 1
            
    except Exception as e:
        print(f"[!] Unlock failed: {e}")
        session.log_audit("UNLOCK", "ERROR", f"Exception: {str(e)}")
        return 1

def rawmode_lock(session, args, verbose=False):
    """Lock rawmode and reduce privileges"""
    print("[*] Locking RAWMODE...")
    
    lock_level = "FULL"
    if args:
        lock_level = args[0].upper()
    
    try:
        lock_payload = struct.pack("<B", 0x40)  # LOCK command
        lock_payload += lock_level.encode('ascii').ljust(8, b'\x00')
        
        resp = session.execute("LOCK", lock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] RAWMODE locked successfully")
                print("[+] Privileges reduced to normal mode")
                session.update_privilege("USER")
                session.features_enabled.clear()
                session.log_audit("LOCK", "INFO", "Success - Privileges reduced")
                return 0
            else:
                print(f"[!] Lock failed: {status}")
                session.log_audit("LOCK", "ERROR", f"Failed: {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("LOCK", "ERROR", "No response")
            return 1
            
    except Exception as e:
        print(f"[!] Lock failed: {e}")
        session.log_audit("LOCK", "ERROR", f"Exception: {str(e)}")
        return 1

def rawmode_configure(session, args, verbose=False):
    """Configure rawmode settings and parameters"""
    if len(args) < 2:
        print("[!] Specify configuration parameter and value")
        print("    Usage: rawmode configure <KEY> <VALUE>")
        return 1
    
    config_key = args[0].upper()
    config_value = args[1]
    
    print(f"[*] Configuring RAWMODE: {config_key} = {config_value}")
    
    try:
        config_payload = struct.pack("<B", 0x50)  # CONFIGURE command
        config_payload += config_key.encode('ascii').ljust(16, b'\x00')
        
        # Handle different value types
        if config_value.isdigit():
            config_payload += struct.pack("<I", int(config_value))
        elif config_value.startswith('0x'):
            config_payload += struct.pack("<I", int(config_value, 16))
        elif '.' in config_value:
            try:
                config_payload += struct.pack("<f", float(config_value))
            except:
                config_payload += config_value.encode('ascii').ljust(16, b'\x00')
        else:
            config_payload += config_value.encode('ascii').ljust(16, b'\x00')
        
        resp = session.execute("CONFIGURE", config_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Configuration {config_key} applied successfully")
                session.log_audit("CONFIGURE", "INFO", f"Set {config_key}={config_value}")
                return 0
            else:
                print(f"[!] Configuration failed: {status}")
                session.log_audit("CONFIGURE", "ERROR", f"Failed: {config_key} - {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("CONFIGURE", "ERROR", f"No response for: {config_key}")
            return 1
            
    except Exception as e:
        print(f"[!] Configuration failed: {e}")
        session.log_audit("CONFIGURE", "ERROR", f"Exception: {config_key} - {str(e)}")
        return 1

def rawmode_escalate(session, args, force=False, verbose=False):
    """Escalate privileges to higher levels"""
    if not args:
        print("[!] Specify target privilege level")
        print("    Usage: rawmode escalate <LEVEL>")
        print("    Levels: USER, PRIVILEGED, SUPERVISOR, HYPERVISOR, ROOT, BOOTROM")
        return 1
    
    target_level = args[0].upper()
    
    # Validate level
    valid_levels = [info["name"] for info in PRIVILEGE_LEVELS.values()]
    if target_level not in valid_levels:
        print(f"[!] Invalid privilege level: {target_level}")
        print(f"    Valid levels: {', '.join(valid_levels)}")
        return 1
    
    print(f"[*] Attempting privilege escalation to: {target_level}")
    
    # Security warning for high privilege escalation
    high_privileges = ['ROOT', 'BOOTROM', 'HYPERVISOR']
    if target_level in high_privileges and not force:
        print("\n[!] WARNING: HIGH PRIVILEGE ESCALATION DETECTED!")
        print(f"    Target: {target_level}")
        print("    This grants complete system control including:")
        print("    - Bare-metal hardware access")
        print("    - Boot ROM modification")
        print("    - Security feature bypass")
        print("    - Permanent device changes")
        
        response = input("\n    Type 'ESCALATE' to continue, or press Enter to cancel: ")
        if response != 'ESCALATE':
            print("[*] Operation cancelled")
            session.log_audit("ESCALATE", "INFO", f"Cancelled: {target_level}")
            return 0
    
    try:
        escalate_payload = struct.pack("<B", 0x60)  # ESCALATE command
        escalate_payload += target_level.encode('ascii').ljust(8, b'\x00')
        
        resp = session.execute("ESCALATE", escalate_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                esc_info = parse_escalation_info(status["extra"])
                print(f"[+] Privilege escalation successful!")
                
                if esc_info:
                    new_level = esc_info.get('new_level', target_level)
                    session.update_privilege(new_level)
                    print(f"    New Level: {new_level}")
                    print(f"    Access: {esc_info.get('access_granted', 'UNKNOWN')}")
                
                session.log_audit("ESCALATE", "WARNING", f"To {target_level}")
                return 0
            else:
                print(f"[!] Escalation failed: {status}")
                session.log_audit("ESCALATE", "ERROR", f"Failed to {target_level}: {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("ESCALATE", "ERROR", f"No response for: {target_level}")
            return 1
            
    except Exception as e:
        print(f"[!] Escalation failed: {e}")
        session.log_audit("ESCALATE", "ERROR", f"Exception: {target_level} - {str(e)}")
        return 1

def rawmode_monitor(session, args, verbose=False):
    """Monitor system activity and debug information"""
    monitor_type = "SYSTEM"
    duration = 10  # seconds
    
    if args:
        monitor_type = args[0].upper()
        if len(args) > 1:
            try:
                duration = int(args[1])
                if duration > 300:  # Cap at 5 minutes
                    print("[!] Duration capped at 300 seconds")
                    duration = 300
            except ValueError:
                pass
    
    print(f"[*] Starting {monitor_type} monitoring for {duration} seconds...")
    print("[*] Press Ctrl+C to stop early")
    
    try:
        monitor_payload = struct.pack("<B", 0x70)  # MONITOR command
        monitor_payload += monitor_type.encode('ascii').ljust(8, b'\x00')
        monitor_payload += struct.pack("<I", duration)
        
        resp = session.execute("MONITOR", monitor_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Monitoring started successfully")
                monitor_data = parse_monitor_data(status["extra"])
                display_monitor_info(monitor_data, monitor_type, duration, verbose)
                session.log_audit("MONITOR", "INFO", f"{monitor_type} for {duration}s")
                return 0
            else:
                print(f"[!] Monitor start failed: {status}")
                session.log_audit("MONITOR", "ERROR", f"Failed: {monitor_type} - {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("MONITOR", "ERROR", f"No response for: {monitor_type}")
            return 1
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring interrupted by user")
        session.log_audit("MONITOR", "INFO", f"Interrupted: {monitor_type}")
        return 0
    except Exception as e:
        print(f"[!] Monitoring failed: {e}")
        session.log_audit("MONITOR", "ERROR", f"Exception: {monitor_type} - {str(e)}")
        return 1

def rawmode_audit(session, args, verbose=False):
    """View audit logs and security events"""
    audit_type = "ALL"
    if args:
        audit_type = args[0].upper()
    
    print(f"[*] Retrieving {audit_type} audit logs...")
    
    try:
        audit_payload = struct.pack("<B", 0x80)  # AUDIT command
        audit_payload += audit_type.encode('ascii').ljust(8, b'\x00')
        
        resp = session.execute("AUDIT", audit_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                audit_data = parse_audit_data(status["extra"])
                display_audit_logs(audit_data, audit_type, verbose)
                
                # Also show local session audit log
                if verbose and session.audit_log:
                    print("\n[+] Local Session Audit Log:")
                    for entry in session.audit_log[-10:]:
                        ts = datetime.fromtimestamp(entry["timestamp"]).strftime("%H:%M:%S")
                        print(f"    [{ts}] [{entry['severity']}] {entry['event_type']}: {entry['description']}")
                
                session.log_audit("AUDIT_QUERY", "INFO", f"Type: {audit_type}")
                return 0
            else:
                print(f"[!] Audit query failed: {status}")
                session.log_audit("AUDIT_QUERY", "ERROR", f"Failed: {audit_type} - {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("AUDIT_QUERY", "ERROR", f"No response for: {audit_type}")
            return 1
            
    except Exception as e:
        print(f"[!] Audit query failed: {e}")
        session.log_audit("AUDIT_QUERY", "ERROR", f"Exception: {audit_type} - {str(e)}")
        return 1

def rawmode_reset(session, args, force=False, verbose=False):
    """Reset rawmode state or entire system"""
    reset_type = "SOFT"
    if args:
        reset_type = args[0].upper()
    
    print(f"[*] Preparing {reset_type} reset...")
    
    # Warning for hard resets
    dangerous_resets = ["HARD", "FULL", "BOOTLOADER", "BOOTROM"]
    if reset_type in dangerous_resets and not force:
        print(f"\n[!] WARNING: {reset_type} RESET DETECTED!")
        print("    This may:")
        print("    - Cause data loss")
        print("    - Reboot the device")
        print("    - Reset all configurations")
        print("    - Require reconnection")
        
        response = input("\n    Type 'RESET' to continue, or press Enter to cancel: ")
        if response != 'RESET':
            print("[*] Operation cancelled")
            session.log_audit("RESET", "INFO", f"Cancelled: {reset_type}")
            return 0
    
    try:
        reset_payload = struct.pack("<B", 0x90)  # RESET command
        reset_payload += reset_type.encode('ascii').ljust(8, b'\x00')
        
        resp = session.execute("RESET", reset_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {reset_type} reset initiated successfully")
                if reset_type in dangerous_resets:
                    print("[+] Device may reboot...")
                    print("[+] Please reconnect if necessary")
                
                # Update session state
                if reset_type in ["FULL", "HARD"]:
                    session.update_privilege("USER")
                    session.features_enabled.clear()
                
                session.log_audit("RESET", "WARNING", f"Type: {reset_type}")
                return 0
            else:
                print(f"[!] Reset failed: {status}")
                session.log_audit("RESET", "ERROR", f"Failed: {reset_type} - {status['name']}")
                return 1
        else:
            print("[!] No response from device")
            session.log_audit("RESET", "ERROR", f"No response for: {reset_type}")
            return 1
            
    except Exception as e:
        print(f"[!] Reset failed: {e}")
        session.log_audit("RESET", "ERROR", f"Exception: {reset_type} - {str(e)}")
        return 1

# =============================================================================
# PARSING AND DISPLAY FUNCTIONS (FIXED)
# =============================================================================

def parse_capability_data(cap_data):
    """Parse capability data from device"""
    capabilities = {
        'device_name': 'Unknown',
        'architecture': 'Unknown',
        'security_level': 'Unknown',
        'rawmode_support': 'No',
        'features': [],
        'privilege_levels': [],
        'hardware_access': []
    }
    
    try:
        if len(cap_data) >= 32:
            # Parse structured capability data
            capabilities['device_name'] = cap_data[0:16].decode('ascii', errors='ignore').rstrip('\x00')
            capabilities['architecture'] = cap_data[16:24].decode('ascii', errors='ignore').rstrip('\x00')
            capabilities['security_level'] = cap_data[24:32].decode('ascii', errors='ignore').rstrip('\x00')
            
            # Parse feature bitmap
            if len(cap_data) >= 36:
                feature_bits = struct.unpack("<I", cap_data[32:36])[0]
                for i, (name, info) in enumerate(RAWMODE_FEATURES.items()):
                    if i < 32 and (feature_bits >> i) & 1:
                        capabilities['features'].append({
                            'name': name,
                            'description': info['description'],
                            'enabled': False,  # Will be updated by status
                            'risk': info['risk'],
                            'requires': info['requires']
                        })
            
            # Parse privilege levels
            if len(cap_data) >= 40:
                priv_bits = struct.unpack("<I", cap_data[36:40])[0]
                for level in range(6):  # 0-5 privilege levels
                    if (priv_bits >> level) & 1:
                        priv_info = PRIVILEGE_LEVELS.get(level, {"name": f"LEVEL_{level}", "description": "Unknown"})
                        capabilities['privilege_levels'].append({
                            'level': level,
                            'name': priv_info['name'],
                            'description': priv_info['description'],
                            'current': False  # Will be updated by status
                        })
    
    except Exception as e:
        print(f"[!] Capability parse error: {e}")
    
    return capabilities

def parse_rawmode_status(status_data):
    """Parse rawmode status information"""
    status = {
        'mode': 'UNKNOWN',
        'privilege_level': 'UNKNOWN',
        'security_state': 'UNKNOWN',
        'features_enabled': [],
        'hardware_access': 'UNKNOWN',
        'session_active': False,
        'detailed_info': {}
    }
    
    try:
        if len(status_data) >= 16:
            # Parse structured status data
            status['mode'] = status_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            status['privilege_level'] = status_data[8:12].decode('ascii', errors='ignore').rstrip('\x00')
            status['security_state'] = status_data[12:16].decode('ascii', errors='ignore').rstrip('\x00')
            
            # Parse features enabled
            if len(status_data) >= 20:
                features_enabled = struct.unpack("<I", status_data[16:20])[0]
                enabled_list = []
                for i, (name, info) in enumerate(RAWMODE_FEATURES.items()):
                    if i < 32 and (features_enabled >> i) & 1:
                        enabled_list.append(name)
                status['features_enabled'] = enabled_list
            
            # Parse hardware access level
            if len(status_data) >= 24:
                hw_access = struct.unpack("<I", status_data[20:24])[0]
                status['hardware_access'] = {
                    0: 'NONE', 1: 'LIMITED', 2: 'FULL', 3: 'UNRESTRICTED'
                }.get(hw_access, 'UNKNOWN')
            
            # Parse session info
            if len(status_data) >= 25:
                status['session_active'] = bool(status_data[24])
    
    except Exception as e:
        print(f"[!] Status parse error: {e}")
    
    return status

def parse_unlock_info(unlock_data):
    """Parse unlock operation results"""
    info = {}
    
    try:
        if len(unlock_data) >= 12:
            info['privilege_level'] = unlock_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['access_rights'] = unlock_data[8:12].decode('ascii', errors='ignore').rstrip('\x00')
            
            if len(unlock_data) >= 16:
                info['session_id'] = struct.unpack("<I", unlock_data[12:16])[0]
            if len(unlock_data) >= 20:
                info['expiration'] = struct.unpack("<I", unlock_data[16:20])[0]
    
    except Exception:
        pass
    
    return info

def parse_escalation_info(esc_data):
    """Parse privilege escalation results"""
    info = {}
    
    try:
        if len(esc_data) >= 16:
            info['new_level'] = esc_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['access_granted'] = esc_data[8:16].decode('ascii', errors='ignore').rstrip('\x00')
        
        if len(esc_data) >= 24:
            info['previous_level'] = esc_data[16:24].decode('ascii', errors='ignore').rstrip('\x00')
    
    except Exception:
        pass
    
    return info

def parse_monitor_data(monitor_data):
    """Parse monitoring data"""
    data = {
        'events': [],
        'metrics': {},
        'raw_size': len(monitor_data),
        'timestamp': time.time()
    }
    
    try:
        if monitor_data:
            # Simple parser - in real implementation this would decode structured data
            # based on monitor type
            pos = 0
            while pos + 8 <= len(monitor_data):
                event_type = monitor_data[pos:pos+4].decode('ascii', errors='ignore')
                event_value = struct.unpack("<I", monitor_data[pos+4:pos+8])[0]
                data['events'].append({
                    'type': event_type,
                    'value': event_value,
                    'time': data['timestamp'] + (pos / 1000.0)  # Simulated timestamp
                })
                pos += 8
    
    except Exception as e:
        print(f"[!] Monitor data parse error: {e}")
    
    return data

def parse_audit_data(audit_data):
    """Parse audit log data"""
    logs = []
    
    try:
        pos = 0
        while pos + 32 <= len(audit_data):
            entry = {
                'timestamp': struct.unpack("<I", audit_data[pos:pos+4])[0],
                'event_type': audit_data[pos+4:pos+12].decode('ascii', errors='ignore').rstrip('\x00'),
                'severity': audit_data[pos+12:pos+16].decode('ascii', errors='ignore').rstrip('\x00'),
                'description': audit_data[pos+16:pos+32].decode('ascii', errors='ignore').rstrip('\x00'),
                'raw_data': audit_data[pos:pos+32].hex()
            }
            logs.append(entry)
            pos += 32
    
    except Exception as e:
        print(f"[!] Audit data parse error: {e}")
    
    return logs

def display_capabilities(capabilities, verbose=False):
    """Display device capabilities"""
    print(f"\n[+] RAWMODE Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    Security Level: {capabilities.get('security_level', 'Unknown')}")
    print(f"    RAWMODE Support: {capabilities.get('rawmode_support', 'No')}")
    
    # List available features
    features = capabilities.get('features', [])
    if features:
        print(f"\n[+] Available Features ({len(features)}):")
        for feature in features:
            risk_color = {
                'LOW': '\033[92m',    # Green
                'MEDIUM': '\033[93m',  # Yellow
                'HIGH': '\033[91m',    # Red
                'CRITICAL': '\033[91;1m'  # Bright Red
            }.get(feature.get('risk', 'LOW'), '\033[0m')
            
            reset_color = '\033[0m'
            status = "✓" if feature.get('enabled', False) else "✗"
            print(f"    {status} {risk_color}{feature['name']:20}{reset_color} - {feature.get('description', '')}")
            if verbose:
                print(f"        Risk: {feature.get('risk')}, Requires: {feature.get('requires')}")
    
    # List privilege levels
    privileges = capabilities.get('privilege_levels', [])
    if privileges:
        print(f"\n[+] Supported Privilege Levels ({len(privileges)}):")
        for priv in privileges:
            current = "← CURRENT" if priv.get('current', False) else ""
            print(f"    Level {priv['level']}: {priv['name']:15} {priv.get('description', '')} {current}")
    
    # List hardware access modes (if any)
    hw_access = capabilities.get('hardware_access', [])
    if hw_access:
        print(f"\n[+] Hardware Access Modes:")
        for hw in hw_access:
            print(f"    {hw['name']:20} - {hw.get('description', '')}")

def display_status(status_data, session, verbose=False):
    """Display RAWMODE status"""
    print(f"\n[+] RAWMODE Status:")
    print(f"    Mode: {status_data.get('mode', 'Unknown')}")
    print(f"    Privilege Level: {status_data.get('privilege_level', 'Unknown')}")
    print(f"    Security State: {status_data.get('security_state', 'Unknown')}")
    print(f"    Hardware Access: {status_data.get('hardware_access', 'Unknown')}")
    print(f"    Session Active: {'Yes' if status_data.get('session_active') else 'No'}")
    
    # Features enabled
    features_enabled = status_data.get('features_enabled', [])
    if features_enabled:
        print(f"\n[+] Features Enabled ({len(features_enabled)}):")
        for feature in features_enabled:
            feature_info = RAWMODE_FEATURES.get(feature, {})
            risk = feature_info.get('risk', 'UNKNOWN')
            risk_color = {
                'LOW': '\033[92m',
                'MEDIUM': '\033[93m',
                'HIGH': '\033[91m',
                'CRITICAL': '\033[91;1m'
            }.get(risk, '\033[0m')
            reset_color = '\033[0m'
            print(f"    {risk_color}✓ {feature:20}{reset_color} - {feature_info.get('description', 'Unknown')}")
    
    # Session info
    if session:
        print(f"\n[+] Local Session:")
        print(f"    Session ID: {session.session_id}")
        print(f"    Duration: {time.time() - session.start_time:.1f}s")
        print(f"    Audit Events: {len(session.audit_log)}")

def display_monitor_info(monitor_data, monitor_type, duration, verbose=False):
    """Display monitoring information"""
    print(f"\n[+] {monitor_type} Monitoring Results ({duration}s):")
    print(f"    Data Size: {monitor_data.get('raw_size', 0)} bytes")
    print(f"    Events Captured: {len(monitor_data.get('events', []))}")
    
    if verbose and monitor_data.get('events'):
        print(f"\n[+] Sample Events:")
        for i, event in enumerate(monitor_data['events'][:5]):  # Show first 5
            print(f"    {i+1}. {event['type']}: {event['value']}")
    
    # Show summary based on monitor type
    if monitor_type == "MEMORY":
        print("    Monitoring: Memory access patterns")
    elif monitor_type == "SYSTEM":
        print("    Monitoring: System calls and interrupts")
    elif monitor_type == "SECURITY":
        print("    Monitoring: Security events and violations")
    else:
        print(f"    Monitoring: {monitor_type} events")

def display_audit_logs(audit_data, audit_type, verbose=False):
    """Display audit logs"""
    if not audit_data:
        print("[+] No audit logs found")
        return
    
    print(f"\n[+] {audit_type} Audit Logs ({len(audit_data)} entries):")
    
    # Show most recent entries
    for i, log in enumerate(audit_data[-10:]):  # Show last 10 entries
        timestamp = datetime.fromtimestamp(log['timestamp']).strftime("%Y-%m-%d %H:%M:%S")
        
        # Color code by severity
        severity_color = {
            'INFO': '\033[92m',      # Green
            'WARNING': '\033[93m',   # Yellow
            'ERROR': '\033[91m',     # Red
            'CRITICAL': '\033[91;1m' # Bright Red
        }.get(log['severity'], '\033[0m')
        reset_color = '\033[0m'
        
        print(f"    {timestamp} [{severity_color}{log['severity']:8}{reset_color}] "
              f"{log['event_type']:12} - {log['description']}")
        
        if verbose and i == len(audit_data[-10:]) - 1:  # Show raw data for last entry
            print(f"        Raw: {log.get('raw_data', '')[:32]}...")

# =============================================================================
# HELP AND UTILITY FUNCTIONS
# =============================================================================

def print_rawmode_help():
    """Display comprehensive rawmode command help"""
    help_text = """
RAWMODE - Privilege Escalation and Hardware Access Module
=========================================================

Usage: qslcl.py rawmode <SUBCOMMAND> [ARGS] [OPTIONS]

Subcommands:
  list | ls | show                    List available features and capabilities
  status | stat | info                Show current rawmode status
  unlock [method] [data]              Authenticate and unlock rawmode
  lock [level]                        Lock rawmode and reduce privileges
  set <feature> <value>               Enable/configure rawmode feature
  configure <key> <value>             Configure rawmode parameters
  escalate <level>                    Escalate privileges to target level
  monitor [type] [duration]           Monitor system activity
  audit [type]                        View audit logs
  reset [type]                        Reset rawmode or system
  help | ?                            Show this help message

Privilege Levels (increasing access):
  USER        - Normal user privileges (default)
  PRIVILEGED  - Elevated system access (drivers, services)
  SUPERVISOR  - Kernel-level access (memory management, interrupts)
  HYPERVISOR  - Virtualization control (VM management)
  ROOT        - Complete system control (bare metal)
  BOOTROM     - Boot ROM level (unrestricted, dangerous)

Common Features (use with caution):
  MMU_BYPASS      - Bypass Memory Management Unit protection
  SECURITY_DISABLE- Disable security features (TrustZone, Secure Boot)
  JTAG_ENABLE     - Enable JTAG debugging interface
  BOOTROM_ACCESS  - Access boot ROM regions
  DMA_ENABLE      - Enable Direct Memory Access
  REGISTER_ACCESS - Access protected hardware registers
  DEBUG_ENABLE    - Enable debug features and breakpoints
  TRACE_ENABLE    - Enable instruction and memory tracing

Monitor Types:
  SYSTEM          - System calls, interrupts, scheduling
  MEMORY          - Memory access patterns, page faults
  SECURITY        - Security events, policy violations
  HARDWARE        - Hardware register access
  NETWORK         - Network activity (if supported)
  ALL             - All available monitoring

Reset Types:
  SOFT            - Soft reset (preserve state)
  HARD            - Hard reset (clear state)
  FULL            - Full reset (reboot RAWMODE)
  BOOTLOADER      - Reboot to bootloader
  BOOTROM         - Reset to boot ROM mode

Options:
  --force          Bypass safety prompts (DANGEROUS)
  --verbose, -v    Verbose output
  --timeout N      Command timeout in seconds (default: 5)
  --loader FILE    Load qslcl.bin before executing
  --auth           Authenticate loader before executing
  --wait N         Wait N seconds for device

Examples:
  qslcl.py rawmode list
  qslcl.py rawmode status
  qslcl.py rawmode unlock
  qslcl.py rawmode escalate ROOT
  qslcl.py rawmode set JTAG_ENABLE 1
  qslcl.py rawmode monitor SYSTEM 30
  qslcl.py rawmode audit SECURITY
  qslcl.py rawmode reset SOFT

Safety Notes:
  - RAWMODE operations may void device warranties
  - Some operations can permanently damage devices
  - Use --force flag only when absolutely necessary
  - Always verify device compatibility before use
  - This tool is for AUTHORIZED RESEARCH ONLY
  - Keep audit logs for compliance and troubleshooting

Session Management:
  - Each RAWMODE command creates a session
  - Sessions are automatically closed
  - Audit logs track all operations
  - Privilege changes are logged
  - Features enabled are tracked

Troubleshooting:
  - If commands fail, try: qslcl.py rawmode reset SOFT
  - Check device connection with: qslcl.py hello
  - Verify loader is loaded: qslcl.py --loader qslcl.bin hello
  - For verbose debugging, use: qslcl.py rawmode status -v
    """
    print(help_text)

def add_rawmode_arguments(parser):
    """Add rawmode-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Bypass safety prompts (DANGEROUS)")
    parser.add_argument("--timeout", type=float, default=5.0,
                       help="Command timeout in seconds")
    return parser