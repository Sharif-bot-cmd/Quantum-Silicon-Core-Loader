def cmd_rawmode(args=None):
    """
    Fully implemented RAWMODE command with advanced features:
    - Privilege escalation and security bypass
    - Direct hardware access modes
    - Secure authentication and validation
    - System introspection and monitoring
    - Advanced debugging capabilities
    - Safety controls and audit logging
    """
    if not args:
        print("[!] RAWMODE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'rawmode_subcommand', '').lower()
    rawmode_args = getattr(args, 'rawmode_args', [])
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)

    if not subcommand:
        print("[!] RAWMODE: No subcommand specified")
        print_rawmode_help()
        return

    print(f"[*] RAWMODE command: {subcommand} {rawmode_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'show']:
            rawmode_list(dev, rawmode_args, verbose)
            
        elif subcommand in ['set', 'enable', 'on']:
            rawmode_set(dev, rawmode_args, force, verbose)
            
        elif subcommand in ['status', 'stat', 'info']:
            rawmode_status(dev, verbose)
            
        elif subcommand in ['unlock', 'auth', 'authenticate']:
            rawmode_unlock(dev, rawmode_args, force, verbose)
            
        elif subcommand in ['lock', 'disable', 'off']:
            rawmode_lock(dev, rawmode_args, verbose)
            
        elif subcommand in ['configure', 'config', 'cfg']:
            rawmode_configure(dev, rawmode_args, verbose)
            
        elif subcommand in ['escalate', 'priv', 'privilege']:
            rawmode_escalate(dev, rawmode_args, force, verbose)
            
        elif subcommand in ['monitor', 'watch', 'trace']:
            rawmode_monitor(dev, rawmode_args, verbose)
            
        elif subcommand in ['audit', 'log', 'history']:
            rawmode_audit(dev, rawmode_args, verbose)
            
        elif subcommand in ['reset', 'restart', 'reboot']:
            rawmode_reset(dev, rawmode_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_rawmode_help()
            
        else:
            print(f"[!] Unknown RAWMODE subcommand: {subcommand}")
            print_rawmode_help()
            
    except Exception as e:
        print(f"[!] RAWMODE operation failed: {e}")
        if verbose:
            import traceback
            traceback.print_exc()

# =============================================================================
# RAWMODE SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def rawmode_list(dev, args, verbose=False):
    """List available rawmode features and capabilities"""
    print("[*] Querying RAWMODE capabilities...")
    
    # Query device capabilities
    capabilities = query_rawmode_capabilities(dev, verbose)
    
    print(f"\n[+] RAWMODE Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    Security Level: {capabilities.get('security_level', 'Unknown')}")
    print(f"    RAWMODE Support: {capabilities.get('rawmode_support', 'No')}")
    
    # List available features
    features = capabilities.get('features', [])
    if features:
        print(f"\n[+] Available Features:")
        for feature in features:
            status = "✓" if feature.get('enabled', False) else "✗"
            print(f"    {status} {feature['name']:20} - {feature.get('description', '')}")
    
    # List privilege levels
    privileges = capabilities.get('privilege_levels', [])
    if privileges:
        print(f"\n[+] Privilege Levels:")
        for priv in privileges:
            current = "← CURRENT" if priv.get('current', False) else ""
            print(f"    Level {priv['level']}: {priv['name']:15} {priv.get('description', '')} {current}")
    
    # List hardware access modes
    hw_access = capabilities.get('hardware_access', [])
    if hw_access:
        print(f"\n[+] Hardware Access:")
        for hw in hw_access:
            print(f"    {hw['name']:20} - {hw.get('description', '')}")

def rawmode_set(dev, args, force=False, verbose=False):
    """Enable or configure rawmode features"""
    if not args:
        print("[!] Specify feature to enable")
        return
        
    feature = args[0].upper()
    value = args[1] if len(args) > 1 else "1"
    
    print(f"[*] Setting RAWMODE feature: {feature} = {value}")
    
    # Security warning for dangerous features
    dangerous_features = ['MMU_BYPASS', 'SECURITY_DISABLE', 'BOOTROM_ACCESS', 'JTAG_ENABLE']
    if feature in dangerous_features and not force:
        print(f"[!] WARNING: Enabling {feature} may compromise device security!")
        response = input("    Type 'DANGER' to continue: ")
        if response != 'DANGER':
            print("[*] Operation cancelled")
            return
    
    # Build set command
    set_payload = struct.pack("<B", 0x10)  # SET command
    set_payload += feature.encode('ascii').ljust(16, b'\x00')
    set_payload += struct.pack("<I", parse_address(value))
    
    resp = qslcl_dispatch(dev, "RAWMODE", set_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Feature {feature} set successfully")
            if verbose:
                print(f"    Response: {status}")
        else:
            print(f"[!] Failed to set {feature}: {status}")
    else:
        print("[!] No response from device")

def rawmode_status(dev, verbose=False):
    """Get current rawmode status and configuration"""
    print("[*] Querying RAWMODE status...")
    
    status_payload = struct.pack("<B", 0x20)  # STATUS command
    
    resp = qslcl_dispatch(dev, "RAWMODE", status_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            status_data = parse_rawmode_status(status["extra"])
            print(f"\n[+] RAWMODE Status:")
            print(f"    Mode: {status_data.get('mode', 'Unknown')}")
            print(f"    Privilege Level: {status_data.get('privilege_level', 'Unknown')}")
            print(f"    Security State: {status_data.get('security_state', 'Unknown')}")
            print(f"    Features Enabled: {status_data.get('features_enabled', 0)}")
            print(f"    Hardware Access: {status_data.get('hardware_access', 'Limited')}")
            
            if verbose and status_data.get('detailed_info'):
                print(f"\n[+] Detailed Information:")
                for key, value in status_data['detailed_info'].items():
                    print(f"    {key}: {value}")
        else:
            print(f"[!] Status query failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_unlock(dev, args, force=False, verbose=False):
    """Authenticate and unlock rawmode privileges"""
    print("[*] Attempting RAWMODE unlock...")
    
    # Check if authentication is required
    auth_method = "DEFAULT"
    auth_data = b""
    
    if args:
        auth_method = args[0].upper()
        if len(args) > 1:
            auth_data = args[1].encode('ascii')
    
    # Security warning
    if not force:
        print("[!] WARNING: RAWMODE unlock grants full system access!")
        print("[!] This may void warranties and compromise security!")
        response = input("    Type 'UNLOCK' to continue: ")
        if response != 'UNLOCK':
            print("[*] Operation cancelled")
            return
    
    # Build unlock command
    unlock_payload = struct.pack("<B", 0x30)  # UNLOCK command
    unlock_payload += auth_method.encode('ascii').ljust(8, b'\x00')
    unlock_payload += struct.pack("<I", len(auth_data))
    unlock_payload += auth_data
    
    resp = qslcl_dispatch(dev, "RAWMODE", unlock_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] RAWMODE unlocked successfully!")
            unlock_info = parse_unlock_info(status["extra"])
            if unlock_info:
                print(f"    Privilege Level: {unlock_info.get('privilege_level', 'Unknown')}")
                print(f"    Access Rights: {unlock_info.get('access_rights', 'Unknown')}")
                print(f"    Session ID: {unlock_info.get('session_id', 'Unknown')}")
        else:
            print(f"[!] Unlock failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_lock(dev, args, verbose=False):
    """Lock rawmode and reduce privileges"""
    print("[*] Locking RAWMODE...")
    
    lock_level = "FULL"
    if args:
        lock_level = args[0].upper()
    
    lock_payload = struct.pack("<B", 0x40)  # LOCK command
    lock_payload += lock_level.encode('ascii').ljust(8, b'\x00')
    
    resp = qslcl_dispatch(dev, "RAWMODE", lock_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] RAWMODE locked successfully")
            print("[+] Privileges reduced to normal mode")
        else:
            print(f"[!] Lock failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_configure(dev, args, verbose=False):
    """Configure rawmode settings and parameters"""
    if not args:
        print("[!] Specify configuration parameter")
        return
        
    config_key = args[0].upper()
    config_value = args[1] if len(args) > 1 else ""
    
    print(f"[*] Configuring RAWMODE: {config_key} = {config_value}")
    
    config_payload = struct.pack("<B", 0x50)  # CONFIGURE command
    config_payload += config_key.encode('ascii').ljust(16, b'\x00')
    
    # Handle different value types
    if config_value.isdigit():
        config_payload += struct.pack("<I", int(config_value))
    elif config_value.startswith('0x'):
        config_payload += struct.pack("<I", int(config_value, 16))
    else:
        config_payload += config_value.encode('ascii').ljust(16, b'\x00')
    
    resp = qslcl_dispatch(dev, "RAWMODE", config_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Configuration {config_key} applied successfully")
        else:
            print(f"[!] Configuration failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_escalate(dev, args, force=False, verbose=False):
    """Escalate privileges to higher levels"""
    target_level = "MAX"
    if args:
        target_level = args[0].upper()
    
    print(f"[*] Attempting privilege escalation to: {target_level}")
    
    # Security warning for high privilege escalation
    high_privileges = ['ROOT', 'MAX', 'SUPERVISOR', 'HYPERVISOR']
    if target_level in high_privileges and not force:
        print("[!] WARNING: High privilege escalation detected!")
        print("[!] This grants complete system control!")
        response = input("    Type 'ESCALATE' to continue: ")
        if response != 'ESCALATE':
            print("[*] Operation cancelled")
            return
    
    escalate_payload = struct.pack("<B", 0x60)  # ESCALATE command
    escalate_payload += target_level.encode('ascii').ljust(8, b'\x00')
    
    resp = qslcl_dispatch(dev, "RAWMODE", escalate_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] Privilege escalation successful!")
            esc_info = parse_escalation_info(status["extra"])
            if esc_info:
                print(f"    New Level: {esc_info.get('new_level', 'Unknown')}")
                print(f"    Access: {esc_info.get('access_granted', 'Unknown')}")
        else:
            print(f"[!] Escalation failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_monitor(dev, args, verbose=False):
    """Monitor system activity and debug information"""
    monitor_type = "SYSTEM"
    duration = 10  # seconds
    
    if args:
        monitor_type = args[0].upper()
        if len(args) > 1:
            try:
                duration = int(args[1])
            except ValueError:
                pass
    
    print(f"[*] Starting {monitor_type} monitoring for {duration} seconds...")
    print("[*] Press Ctrl+C to stop early")
    
    monitor_payload = struct.pack("<B", 0x70)  # MONITOR command
    monitor_payload += monitor_type.encode('ascii').ljust(8, b'\x00')
    monitor_payload += struct.pack("<I", duration)
    
    try:
        resp = qslcl_dispatch(dev, "RAWMODE", monitor_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Monitoring started successfully")
                monitor_data = parse_monitor_data(status["extra"])
                display_monitor_info(monitor_data, monitor_type)
            else:
                print(f"[!] Monitor start failed: {status}")
        else:
            print("[!] No response from device")
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring interrupted by user")

def rawmode_audit(dev, args, verbose=False):
    """View audit logs and security events"""
    audit_type = "ALL"
    if args:
        audit_type = args[0].upper()
    
    print(f"[*] Retrieving {audit_type} audit logs...")
    
    audit_payload = struct.pack("<B", 0x80)  # AUDIT command
    audit_payload += audit_type.encode('ascii').ljust(8, b'\x00')
    
    resp = qslcl_dispatch(dev, "RAWMODE", audit_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            audit_data = parse_audit_data(status["extra"])
            display_audit_logs(audit_data, audit_type, verbose)
        else:
            print(f"[!] Audit query failed: {status}")
    else:
        print("[!] No response from device")

def rawmode_reset(dev, args, force=False, verbose=False):
    """Reset rawmode state or entire system"""
    reset_type = "SOFT"
    if args:
        reset_type = args[0].upper()
    
    print(f"[*] Preparing {reset_type} reset...")
    
    # Warning for hard resets
    if reset_type in ["HARD", "FULL", "BOOTLOADER"] and not force:
        print("[!] WARNING: This reset may cause data loss or reboot!")
        response = input("    Type 'RESET' to continue: ")
        if response != 'RESET':
            print("[*] Operation cancelled")
            return
    
    reset_payload = struct.pack("<B", 0x90)  # RESET command
    reset_payload += reset_type.encode('ascii').ljust(8, b'\x00')
    
    resp = qslcl_dispatch(dev, "RAWMODE", reset_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print(f"[+] {reset_type} reset initiated successfully")
            if reset_type in ["HARD", "FULL", "BOOTLOADER"]:
                print("[+] Device may reboot...")
        else:
            print(f"[!] Reset failed: {status}")
    else:
        print("[!] No response from device")

# =============================================================================
# SUPPORTING FUNCTIONS FOR RAWMODE
# =============================================================================

def query_rawmode_capabilities(dev, verbose=False):
    """Query device rawmode capabilities"""
    capabilities = {
        'device_name': 'Unknown',
        'architecture': 'Unknown',
        'security_level': 'Unknown',
        'rawmode_support': 'No',
        'features': [],
        'privilege_levels': [],
        'hardware_access': []
    }
    
    try:
        # Try to query capabilities
        query_payload = struct.pack("<B", 0x01)  # CAPABILITIES query
        
        if "RAWMODE" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RAWMODE", query_payload)
        else:
            # Fallback to generic query
            resp = qslcl_dispatch(dev, "GETINFO", b"RAWMODE_CAPABILITIES")
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                # Parse capability data
                capabilities.update(parse_capability_data(status["extra"]))
    
    except Exception as e:
        if verbose:
            print(f"[!] Capability query error: {e}")
    
    return capabilities

def parse_rawmode_status(status_data):
    """Parse rawmode status information"""
    status = {
        'mode': 'UNKNOWN',
        'privilege_level': 'UNKNOWN',
        'security_state': 'UNKNOWN',
        'features_enabled': 0,
        'hardware_access': 'UNKNOWN'
    }
    
    try:
        if len(status_data) >= 16:
            # Parse structured status data
            status['mode'] = status_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            status['privilege_level'] = status_data[8:12].decode('ascii', errors='ignore').rstrip('\x00')
            status['security_state'] = status_data[12:16].decode('ascii', errors='ignore').rstrip('\x00')
            
            if len(status_data) >= 20:
                status['features_enabled'] = struct.unpack("<I", status_data[16:20])[0]
                
            if len(status_data) >= 24:
                hw_access = struct.unpack("<I", status_data[20:24])[0]
                status['hardware_access'] = {
                    0: 'NONE', 1: 'LIMITED', 2: 'FULL', 3: 'UNRESTRICTED'
                }.get(hw_access, 'UNKNOWN')
    
    except Exception as e:
        print(f"[!] Status parse error: {e}")
    
    return status

def parse_unlock_info(unlock_data):
    """Parse unlock operation results"""
    info = {}
    
    try:
        if len(unlock_data) >= 12:
            info['privilege_level'] = unlock_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['access_rights'] = unlock_data[8:12].decode('ascii', errors='ignore').rstrip('\x00')
            
            if len(unlock_data) >= 16:
                info['session_id'] = struct.unpack("<I", unlock_data[12:16])[0]
    
    except Exception:
        pass
    
    return info

def parse_escalation_info(esc_data):
    """Parse privilege escalation results"""
    info = {}
    
    try:
        if len(esc_data) >= 16:
            info['new_level'] = esc_data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['access_granted'] = esc_data[8:16].decode('ascii', errors='ignore').rstrip('\x00')
    
    except Exception:
        pass
    
    return info

def parse_monitor_data(monitor_data):
    """Parse monitoring data"""
    # Simple monitoring data parser
    data = {'events': [], 'metrics': {}}
    
    try:
        # This would be more complex in a real implementation
        if monitor_data:
            data['raw_data'] = monitor_data.hex()
    
    except Exception:
        pass
    
    return data

def parse_audit_data(audit_data):
    """Parse audit log data"""
    logs = []
    
    try:
        # Simple audit log parser
        pos = 0
        while pos + 32 <= len(audit_data):
            entry = {
                'timestamp': struct.unpack("<I", audit_data[pos:pos+4])[0],
                'event_type': audit_data[pos+4:pos+8].decode('ascii', errors='ignore').rstrip('\x00'),
                'severity': audit_data[pos+8:pos+12].decode('ascii', errors='ignore').rstrip('\x00'),
                'description': audit_data[pos+12:pos+32].decode('ascii', errors='ignore').rstrip('\x00')
            }
            logs.append(entry)
            pos += 32
    
    except Exception as e:
        print(f"[!] Audit data parse error: {e}")
    
    return logs

def parse_capability_data(cap_data):
    """Parse capability data from device"""
    capabilities = {}
    
    try:
        # Simple capability parser
        if cap_data:
            capabilities['rawmode_support'] = 'Yes'
            
            # This would be more sophisticated in real implementation
            # parsing structured capability data
    
    except Exception:
        pass
    
    return capabilities

def display_monitor_info(monitor_data, monitor_type):
    """Display monitoring information"""
    print(f"\n[+] {monitor_type} Monitoring Results:")
    if 'raw_data' in monitor_data:
        print(f"    Raw Data: {monitor_data['raw_data'][:64]}...")
    else:
        print("    No monitoring data received")

def display_audit_logs(audit_data, audit_type, verbose=False):
    """Display audit logs"""
    if not audit_data:
        print("[+] No audit logs found")
        return
    
    print(f"\n[+] {audit_type} Audit Logs ({len(audit_data)} entries):")
    
    for i, log in enumerate(audit_data[-10:]):  # Show last 10 entries
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(log['timestamp']))
        print(f"    {timestamp} [{log['severity']}] {log['event_type']}: {log['description']}")

def print_rawmode_help():
    """Display rawmode command help"""
    print("""
RAWMODE Command Usage:
  rawmode list                    - List available features and capabilities
  rawmode status                  - Show current rawmode status
  rawmode unlock [method] [data]  - Authenticate and unlock rawmode
  rawmode lock [level]            - Lock rawmode and reduce privileges
  rawmode set <feature> <value>   - Enable/configure rawmode feature
  rawmode configure <key> <value> - Configure rawmode parameters
  rawmode escalate <level>        - Escalate privileges
  rawmode monitor [type] [time]   - Monitor system activity
  rawmode audit [type]            - View audit logs
  rawmode reset [type]            - Reset rawmode or system

Privilege Levels:
  USER        - Normal user privileges
  PRIVILEGED  - Elevated system access
  SUPERVISOR  - Kernel-level access
  HYPERVISOR  - Virtualization control
  ROOT        - Complete system control

Common Features:
  MMU_BYPASS      - Bypass memory protection
  SECURITY_DISABLE- Disable security features
  JTAG_ENABLE     - Enable JTAG debugging
  BOOTROM_ACCESS  - Access boot ROM
  DMA_ENABLE      - Enable direct memory access
  REGISTER_ACCESS - Unlock hardware registers

Safety Notes:
  - Use --force to bypass safety prompts (DANGEROUS)
  - RAWMODE operations may void warranties
  - Some operations may brick devices
  - Always verify device compatibility
    """)

# =============================================================================
# RAWMODE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_rawmode_arguments(parser):
    """Add rawmode-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    return parser