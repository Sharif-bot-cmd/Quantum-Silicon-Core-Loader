def cmd_glitch(args):
    """
    Advanced GLITCH command handler for hardware fault injection and timing attacks
    Supports voltage glitching, clock glitching, EM glitching, and laser fault injection simulation
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse GLITCH subcommand
    if not hasattr(args, 'glitch_subcommand') or not args.glitch_subcommand:
        # Backward compatibility with old syntax
        if hasattr(args, 'level') and hasattr(args, 'iter') and hasattr(args, 'window') and hasattr(args, 'sweep'):
            return execute_legacy_glitch(dev, args)
        return print("[!] GLITCH command requires subcommand (list, voltage, clock, em, laser, advanced, etc.)")
    
    subcmd = args.glitch_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_glitch_commands(dev)
    elif subcmd == "VOLTAGE":
        return execute_voltage_glitch(dev, args)
    elif subcmd == "CLOCK":
        return execute_clock_glitch(dev, args)
    elif subcmd == "EM":
        return execute_em_glitch(dev, args)
    elif subcmd == "LASER":
        return execute_laser_glitch(dev, args)
    elif subcmd == "TIMING":
        return execute_timing_glitch(dev, args)
    elif subcmd == "RESET":
        return execute_reset_glitch(dev, args)
    elif subcmd == "ADVANCED":
        return execute_advanced_glitch(dev, args)
    elif subcmd == "SCAN":
        return scan_glitch_parameters(dev, args)
    elif subcmd == "AUTO":
        return execute_auto_glitch(dev, args)
    elif subcmd == "ANALYZE":
        return analyze_glitch_results(dev, args)
    elif subcmd == "CALIBRATE":
        return calibrate_glitch_parameters(dev, args)
    else:
        return handle_glitch_operation(dev, subcmd, args)

def list_available_glitch_commands(dev):
    """
    List all available GLITCH commands from QSLCL loader
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL GLITCHING COMMANDS")
    print("="*60)
    
    glitch_found = []
    
    # Check QSLCLPAR for GLITCH commands
    print("\n[QSLCLPAR] Glitch Commands:")
    par_glitch = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "GLITCH", "FAULT", "INJECTION", "VOLTAGE", "CLOCK", "TIMING",
        "RESET", "UNDERVOLT", "OVERVOLT", "FREQUENCY", "PULSE"
    ])]
    for glitch_cmd in par_glitch:
        print(f"  • {glitch_cmd}")
        glitch_found.append(glitch_cmd)
    
    # Check QSLCLEND for glitch-related opcodes
    print("\n[QSLCLEND] Glitch Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["GLITCH", "FAULT", "INJECTION"]) or any(x in entry_str for x in ["GLITCH", "FAULT"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            glitch_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for glitch microservices
    print("\n[QSLCLVM5] Glitch Microservices:")
    vm5_glitch = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["GLITCH", "FAULT", "INJECTION"])]
    for glitch_cmd in vm5_glitch:
        print(f"  • {glitch_cmd}")
        glitch_found.append(f"VM5_{glitch_cmd}")
    
    # Check QSLCLIDX for glitch indices
    print("\n[QSLCLIDX] Glitch Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["GLITCH", "FAULT", "INJECTION"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                glitch_found.append(f"IDX_{name}")
    
    if not glitch_found:
        print("  No glitch commands found in loader")
    else:
        print(f"\n[*] Total glitch commands found: {len(glitch_found)}")
    
    print("\n[*] Common Glitching Techniques Available:")
    print("  • VOLTAGE    - Voltage glitching (undervolt/overvolt)")
    print("  • CLOCK      - Clock glitching (frequency manipulation)")
    print("  • EM         - Electromagnetic pulse injection")
    print("  • LASER      - Laser fault injection simulation")
    print("  • TIMING     - Timing attacks and race conditions")
    print("  • RESET      - Reset line glitching")
    print("  • ADVANCED   - Advanced multi-parameter glitching")
    print("  • SCAN       - Automated glitch parameter scanning")
    print("  • AUTO       - Automatic glitch parameter discovery")
    print("  • ANALYZE    - Glitch result analysis")
    print("  • CALIBRATE  - Glitch hardware calibration")
    
    print("="*60)
    
    return True

def execute_legacy_glitch(dev, args):
    """
    Execute legacy glitch command for backward compatibility
    """
    print("[*] Using legacy glitch syntax...")
    
    level = int(args.level)
    iterations = int(args.iter)
    window = int(args.window)
    sweep = int(args.sweep)

    print(f"[*] GLITCH: level={level}  iter={iterations}  window={window}  sweep={sweep}")

    # Build virtual glitch payload
    entropy = os.urandom(16)
    jitter = random.randint(1, 9999)

    payload = struct.pack(
        "<BIII16sI",
        level,          # glitch intensity
        iterations,     # iteration count
        window,         # timing window
        sweep,          # sweep width
        entropy,        # entropy seed
        jitter          # timing jitter
    )

    return execute_glitch_operation(dev, "LEGACY", payload)

def execute_voltage_glitch(dev, args):
    """
    Execute voltage glitching attack
    """
    print("[*] Preparing voltage glitching attack...")
    
    # Parse parameters
    voltage_type = "UNDERVOLT"  # Default to undervoltage
    intensity = 2               # Default intensity
    duration = 100              # Default duration in microseconds
    target_domain = "VDD_CORE"  # Default target
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            voltage_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                intensity = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                duration = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            target_domain = args.glitch_args[3].upper()
    
    print(f"[*] Voltage Glitch: type={voltage_type}, intensity={intensity}, duration={duration}μs, target={target_domain}")
    
    # Safety warning
    print("[!] WARNING: Voltage glitching can cause permanent hardware damage!")
    confirm = input("!! CONFIRM VOLTAGE GLITCH (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Voltage glitch cancelled")
        return False
    
    # Build voltage glitch payload
    payload = struct.pack(
        "<B B H 12s",
        0x01,  # Voltage glitch type
        intensity,
        duration,
        target_domain.encode('ascii').ljust(12, b'\x00')
    )
    
    return execute_glitch_operation(dev, "VOLTAGE", payload)

def execute_clock_glitch(dev, args):
    """
    Execute clock glitching attack
    """
    print("[*] Preparing clock glitching attack...")
    
    # Parse parameters
    clock_source = "CPU"        # Default clock source
    frequency_shift = 100       # Default frequency shift in MHz
    duration = 50              # Default duration in microseconds
    pattern = "SINGLE"         # Default pattern
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            clock_source = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                frequency_shift = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                duration = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            pattern = args.glitch_args[3].upper()
    
    print(f"[*] Clock Glitch: source={clock_source}, shift={frequency_shift}MHz, duration={duration}μs, pattern={pattern}")
    
    # Build clock glitch payload
    pattern_code = {
        "SINGLE": 0x01,
        "BURST": 0x02,
        "CONTINUOUS": 0x03,
        "RANDOM": 0x04
    }.get(pattern, 0x01)
    
    payload = struct.pack(
        "<B h H B 10s",
        0x02,  # Clock glitch type
        frequency_shift,
        duration,
        pattern_code,
        clock_source.encode('ascii').ljust(10, b'\x00')
    )
    
    return execute_glitch_operation(dev, "CLOCK", payload)

def execute_em_glitch(dev, args):
    """
    Execute electromagnetic glitching attack
    """
    print("[*] Preparing electromagnetic glitching attack...")
    
    # Parse parameters
    em_strength = 3            # Default EM strength (1-5)
    pulse_width = 20           # Default pulse width in nanoseconds
    frequency = 100            # Default frequency in MHz
    target_coords = (0, 0)     # Default target coordinates
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            try:
                em_strength = int(args.glitch_args[0])
            except:
                pass
        if len(args.glitch_args) > 1:
            try:
                pulse_width = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                frequency = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            try:
                x, y = map(int, args.glitch_args[3].split(','))
                target_coords = (x, y)
            except:
                pass
    
    print(f"[*] EM Glitch: strength={em_strength}, width={pulse_width}ns, freq={frequency}MHz, target={target_coords}")
    
    # Build EM glitch payload
    payload = struct.pack(
        "<B B H H h h",
        0x03,  # EM glitch type
        em_strength,
        pulse_width,
        frequency,
        target_coords[0],  # X coordinate
        target_coords[1]   # Y coordinate
    )
    
    return execute_glitch_operation(dev, "EM", payload)

def execute_laser_glitch(dev, args):
    """
    Execute laser fault injection simulation
    """
    print("[*] Preparing laser fault injection...")
    
    # Parse parameters
    laser_power = 80           # Default laser power (0-100)
    pulse_duration = 10        # Default pulse duration in nanoseconds
    wavelength = 1064          # Default wavelength in nm
    target_area = "CPU_CORE"   # Default target area
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            try:
                laser_power = int(args.glitch_args[0])
            except:
                pass
        if len(args.glitch_args) > 1:
            try:
                pulse_duration = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                wavelength = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            target_area = args.glitch_args[3].upper()
    
    print(f"[*] Laser Injection: power={laser_power}%, duration={pulse_duration}ns, wavelength={wavelength}nm, target={target_area}")
    
    # Build laser glitch payload
    payload = struct.pack(
        "<B B H H 12s",
        0x04,  # Laser glitch type
        laser_power,
        pulse_duration,
        wavelength,
        target_area.encode('ascii').ljust(12, b'\x00')
    )
    
    return execute_glitch_operation(dev, "LASER", payload)

def execute_timing_glitch(dev, args):
    """
    Execute timing-based glitching attacks
    """
    print("[*] Preparing timing glitching attack...")
    
    # Parse parameters
    attack_type = "RACE"       # Default attack type
    precision = 10             # Default precision in nanoseconds
    iterations = 1000          # Default iterations
    target_operation = "AUTH"  # Default target operation
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            attack_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                precision = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                iterations = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            target_operation = args.glitch_args[3].upper()
    
    attack_codes = {
        "RACE": 0x01,
        "SETUP": 0x02,
        "HOLD": 0x03,
        "CLOCK_RECOVERY": 0x04
    }
    
    attack_code = attack_codes.get(attack_type, 0x01)
    
    print(f"[*] Timing Glitch: type={attack_type}, precision={precision}ns, iterations={iterations}, target={target_operation}")
    
    # Build timing glitch payload
    payload = struct.pack(
        "<B B I H 10s",
        0x05,  # Timing glitch type
        attack_code,
        iterations,
        precision,
        target_operation.encode('ascii').ljust(10, b'\x00')
    )
    
    return execute_glitch_operation(dev, "TIMING", payload)

def execute_reset_glitch(dev, args):
    """
    Execute reset line glitching
    """
    print("[*] Preparing reset line glitching...")
    
    # Parse parameters
    reset_type = "SOFT"        # Default reset type
    pulse_count = 5            # Default pulse count
    pulse_width = 100          # Default pulse width in microseconds
    delay_between = 1000       # Default delay between pulses in microseconds
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            reset_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                pulse_count = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            try:
                pulse_width = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            try:
                delay_between = int(args.glitch_args[3])
            except:
                pass
    
    reset_codes = {
        "SOFT": 0x01,
        "HARD": 0x02,
        "WATCHDOG": 0x03,
        "BROWN_OUT": 0x04
    }
    
    reset_code = reset_codes.get(reset_type, 0x01)
    
    print(f"[*] Reset Glitch: type={reset_type}, pulses={pulse_count}, width={pulse_width}μs, delay={delay_between}μs")
    
    # Build reset glitch payload
    payload = struct.pack(
        "<B B H H H",
        0x06,  # Reset glitch type
        reset_code,
        pulse_count,
        pulse_width,
        delay_between
    )
    
    return execute_glitch_operation(dev, "RESET", payload)

def execute_advanced_glitch(dev, args):
    """
    Execute advanced multi-parameter glitching
    """
    print("[*] Preparing advanced multi-parameter glitching...")
    
    # Parse complex parameters
    glitch_combination = "VOLTAGE_CLOCK"  # Default combination
    synchronization = "PRECISE"           # Default synchronization
    iteration_strategy = "ADAPTIVE"       # Default iteration strategy
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            glitch_combination = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            synchronization = args.glitch_args[1].upper()
        if len(args.glitch_args) > 2:
            iteration_strategy = args.glitch_args[2].upper()
    
    print(f"[*] Advanced Glitch: combination={glitch_combination}, sync={synchronization}, strategy={iteration_strategy}")
    
    # Build advanced glitch payload with multiple parameters
    combination_code = sum(glitch_combination.encode()) & 0xFF
    sync_code = 0x01 if synchronization == "PRECISE" else 0x02
    strategy_code = 0x01 if iteration_strategy == "ADAPTIVE" else 0x02
    
    # Complex payload with multiple glitch parameters
    payload = struct.pack(
        "<B B B B 16s 16s",
        0x07,  # Advanced glitch type
        combination_code,
        sync_code,
        strategy_code,
        os.urandom(16),  # Parameter set 1
        os.urandom(16)   # Parameter set 2
    )
    
    return execute_glitch_operation(dev, "ADVANCED", payload)

def scan_glitch_parameters(dev, args):
    """
    Automated glitch parameter scanning
    """
    print("[*] Starting automated glitch parameter scanning...")
    
    scan_type = "VOLTAGE"      # Default scan type
    parameter_range = "1-5"    # Default parameter range
    step_size = 1              # Default step size
    max_iterations = 100       # Default max iterations
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            scan_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            parameter_range = args.glitch_args[1]
        if len(args.glitch_args) > 2:
            try:
                step_size = int(args.glitch_args[2])
            except:
                pass
        if len(args.glitch_args) > 3:
            try:
                max_iterations = int(args.glitch_args[3])
            except:
                pass
    
    # Parse parameter range
    try:
        if '-' in parameter_range:
            start, end = map(int, parameter_range.split('-'))
        else:
            start = end = int(parameter_range)
    except:
        start, end = 1, 5
    
    print(f"[*] Parameter Scan: type={scan_type}, range={start}-{end}, step={step_size}, max_iter={max_iterations}")
    
    results = []
    successful_glitches = 0
    
    for param_value in range(start, end + 1, step_size):
        if len(results) >= max_iterations:
            break
            
        print(f"\n[*] Testing parameter value: {param_value}")
        
        # Build scan payload
        payload = struct.pack(
            "<B I I",
            0x08,  # Scan glitch type
            param_value,
            len(results)  # Iteration counter
        )
        
        resp, origin = execute_glitch_with_strategy(dev, "SCAN", payload)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                successful_glitches += 1
                results.append((param_value, "SUCCESS", origin))
                print(f"  [✓] Parameter {param_value}: SUCCESS (via {origin})")
            else:
                results.append((param_value, status.get("name", "UNKNOWN"), origin))
                print(f"  [!] Parameter {param_value}: {status.get('name', 'UNKNOWN')}")
        else:
            results.append((param_value, "NO_RESPONSE", "NONE"))
            print(f"  [!] Parameter {param_value}: NO RESPONSE")
    
    # Generate scan report
    print(f"\n[*] Parameter Scan Complete: {successful_glitches}/{len(results)} successful glitches")
    
    if successful_glitches > 0:
        optimal_params = [r[0] for r in results if r[1] == "SUCCESS"]
        if optimal_params:
            print(f"[*] Optimal parameter range: {min(optimal_params)}-{max(optimal_params)}")
    
    return successful_glitches > 0

def execute_auto_glitch(dev, args):
    """
    Automatic glitch parameter discovery and optimization
    """
    print("[*] Starting automatic glitch parameter discovery...")
    
    target_effect = "BYPASS"   # Default target effect
    timeout = 30               # Default timeout in seconds
    optimization = "AGGRESSIVE" # Default optimization strategy
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            target_effect = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                timeout = int(args.glitch_args[1])
            except:
                pass
        if len(args.glitch_args) > 2:
            optimization = args.glitch_args[2].upper()
    
    print(f"[*] Auto Glitch: target={target_effect}, timeout={timeout}s, optimization={optimization}")
    
    # Build auto glitch payload
    optimization_code = {
        "CONSERVATIVE": 0x01,
        "MODERATE": 0x02,
        "AGGRESSIVE": 0x03
    }.get(optimization, 0x02)
    
    payload = struct.pack(
        "<B 12s I B",
        0x09,  # Auto glitch type
        target_effect.encode('ascii').ljust(12, b'\x00'),
        timeout,
        optimization_code
    )
    
    print("[*] Auto glitch in progress... This may take several minutes.")
    print("[*] Press Ctrl+C to abort.")
    
    try:
        start_time = time.time()
        resp = execute_glitch_operation(dev, "AUTO", payload)
        elapsed_time = time.time() - start_time
        
        print(f"[*] Auto glitch completed in {elapsed_time:.1f} seconds")
        return resp
        
    except KeyboardInterrupt:
        print("\n[*] Auto glitch aborted by user")
        return False

def analyze_glitch_results(dev, args):
    """
    Analyze glitch results and provide insights
    """
    print("[*] Analyzing glitch results...")
    
    analysis_type = "RECENT"   # Default analysis type
    detail_level = "SUMMARY"   # Default detail level
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            analysis_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            detail_level = args.glitch_args[1].upper()
    
    # Build analysis payload
    analysis_code = {
        "RECENT": 0x01,
        "STATISTICS": 0x02,
        "PATTERNS": 0x03,
        "EFFECTIVENESS": 0x04
    }.get(analysis_type, 0x01)
    
    detail_code = {
        "SUMMARY": 0x01,
        "DETAILED": 0x02,
        "VERBOSE": 0x03
    }.get(detail_level, 0x01)
    
    payload = struct.pack("<B B", analysis_code, detail_code)
    
    resp, origin = execute_glitch_with_strategy(dev, "ANALYZE", payload)
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if extra:
                try:
                    analysis_data = extra.decode('utf-8', errors='ignore')
                    print("\n[*] Glitch Analysis Results:")
                    print(analysis_data)
                except:
                    print(f"[*] Analysis data (raw): {extra.hex()}")
            return True
        else:
            print(f"[!] Analysis failed: {status.get('name', 'UNKNOWN')}")
    else:
        print("[!] No analysis data available")
    
    return False

def calibrate_glitch_parameters(dev, args):
    """
    Calibrate glitch hardware and parameters
    """
    print("[*] Starting glitch hardware calibration...")
    
    calibration_type = "AUTO"  # Default calibration type
    target_precision = 10      # Default target precision in nanoseconds
    
    if hasattr(args, 'glitch_args') and args.glitch_args:
        if len(args.glitch_args) > 0:
            calibration_type = args.glitch_args[0].upper()
        if len(args.glitch_args) > 1:
            try:
                target_precision = int(args.glitch_args[1])
            except:
                pass
    
    print(f"[*] Glitch Calibration: type={calibration_type}, target_precision={target_precision}ns")
    
    # Build calibration payload
    calibration_code = {
        "AUTO": 0x01,
        "MANUAL": 0x02,
        "VERIFY": 0x03
    }.get(calibration_type, 0x01)
    
    payload = struct.pack("<B H", calibration_code, target_precision)
    
    resp, origin = execute_glitch_with_strategy(dev, "CALIBRATE", payload)
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Glitch calibration completed successfully")
            
            # Extract calibration results if available
            extra = status.get("extra", b"")
            if extra and len(extra) >= 4:
                achieved_precision = struct.unpack("<H", extra[:2])[0]
                calibration_score = struct.unpack("<H", extra[2:4])[0]
                print(f"[*] Achieved precision: {achieved_precision}ns")
                print(f"[*] Calibration score: {calibration_score}/100")
            
            return True
        else:
            print(f"[!] Calibration failed: {status.get('name', 'UNKNOWN')}")
    else:
        print("[!] No calibration capability available")
    
    return False

def execute_glitch_operation(dev, glitch_type, payload):
    """
    Execute glitch operation with strategy fallback
    """
    print(f"[*] Executing {glitch_type} glitch...")
    
    resp, origin = execute_glitch_with_strategy(dev, glitch_type, payload)
    
    if resp:
        status = decode_runtime_result(resp)
        print(f"[✓] {glitch_type} glitch completed via {origin}: {status}")
        return status.get("severity") == "SUCCESS"
    else:
        print(f"[!] {glitch_type} glitch failed: No response from device")
        return False

def execute_glitch_with_strategy(dev, glitch_type, payload):
    """
    Execute glitch with multiple strategy fallbacks
    """
    strategies = [
        try_direct_glitch_command,
        try_par_glitch_command,
        try_end_glitch_opcode,
        try_vm5_glitch_service,
        try_idx_glitch_command,
        try_generic_glitch_dispatch
    ]
    
    for strategy in strategies:
        result = strategy(dev, glitch_type, payload)
        if result is not None:
            return result
    
    return None, "NO_STRATEGY"

def try_direct_glitch_command(dev, glitch_type, payload):
    """Try direct GLITCH command"""
    resp = qslcl_dispatch(dev, "GLITCH", glitch_type.encode() + b"\x00" + payload)
    if resp:
        return resp, "DIRECT"
    return None

def try_par_glitch_command(dev, glitch_type, payload):
    """Try QSLCLPAR glitch command"""
    if glitch_type in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, glitch_type, payload)
        if resp:
            return resp, "QSLCLPAR"
    return None

def try_end_glitch_opcode(dev, glitch_type, payload):
    """Try QSLCLEND glitch opcode"""
    opcode = sum(glitch_type.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + payload
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        if resp:
            return resp, f"QSLCLEND_0x{opcode:02X}"
    return None

def try_vm5_glitch_service(dev, glitch_type, payload):
    """Try QSLCLVM5 glitch service"""
    if glitch_type in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[glitch_type]["raw"]
        pkt = b"QSLCLVM5" + raw + payload
        resp = qslcl_dispatch(dev, "NANO", pkt)
        if resp:
            return resp, "QSLCLVM5"
    return None

def try_idx_glitch_command(dev, glitch_type, payload):
    """Try QSLCLIDX glitch command"""
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == glitch_type:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + payload
            resp = qslcl_dispatch(dev, "IDX", pkt)
            if resp:
                return resp, f"QSLCLIDX_{name}"
    return None

def try_generic_glitch_dispatch(dev, glitch_type, payload):
    """Try generic glitch dispatch"""
    resp = qslcl_dispatch(dev, glitch_type, payload)
    if resp:
        return resp, "GENERIC"
    return None

def handle_glitch_operation(dev, operation, args):
    """
    Handle other glitch operations
    """
    print(f"[*] Executing glitch operation: {operation}")
    
    # Build operation parameters
    params = build_glitch_operation_params(operation, args)
    
    resp, origin = execute_glitch_with_strategy(dev, operation, params)
    
    if resp:
        status = decode_runtime_result(resp)
        print(f"[✓] {operation} glitch completed via {origin}: {status}")
        return status.get("severity") == "SUCCESS"
    else:
        print(f"[!] {operation} glitch failed")
        return False

def build_glitch_operation_params(operation, args):
    """
    Build parameters for glitch operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'glitch_args'):
        for arg in args.glitch_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

# Update the argument parser in main() function
def update_glitch_parser(sub):
    """
    Update the GLITCH command parser with new subcommands
    """
    glitch_parser = sub.add_parser("glitch", help="Hardware fault injection and glitching commands")
    glitch_parser.add_argument("glitch_subcommand", help="Glitch subcommand (list, voltage, clock, em, laser, timing, reset, advanced, scan, auto, analyze, calibrate)")
    glitch_parser.add_argument("glitch_args", nargs="*", help="Additional arguments for glitch command")
    
    # Legacy parameters for backward compatibility
    glitch_parser.add_argument("--level", type=int, help="Legacy: Glitch intensity level (1-5)")
    glitch_parser.add_argument("--iter", type=int, help="Legacy: Iteration count")
    glitch_parser.add_argument("--window", type=int, help="Legacy: Timing window")
    glitch_parser.add_argument("--sweep", type=int, help="Legacy: Sweep width")
    
    glitch_parser.set_defaults(func=cmd_glitch)