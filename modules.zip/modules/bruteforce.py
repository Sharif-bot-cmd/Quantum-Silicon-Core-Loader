def cmd_bruteforce(args=None):
    """
    Fully implemented BRUTEFORCE command with advanced features:
    - Multiple brute-force strategies and algorithms
    - Parallel execution with thread management
    - Progress tracking and result analysis
    - Pattern generation and sequence management
    - Smart optimization and early termination
    - Result logging and resume capabilities
    """
    if not args:
        print("[!] BRUTEFORCE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'bruteforce_subcommand', '').lower()
    pattern = getattr(args, 'pattern', '')
    threads = getattr(args, 'threads', 8)
    rawmode = getattr(args, 'rawmode', False)
    output_file = getattr(args, 'output', '')
    strategy = getattr(args, 'strategy', 'basic')
    bruteforce_args = getattr(args, 'bruteforce_args', [])

    if not subcommand:
        print("[!] BRUTEFORCE: No subcommand specified")
        print_bruteforce_help()
        return

    print(f"[*] BRUTEFORCE command: {subcommand} {pattern}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'strategies']:
            bruteforce_list(dev, bruteforce_args)
            
        elif subcommand in ['scan', 'search', 'explore']:
            bruteforce_scan(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['pattern', 'seq', 'sequence']:
            bruteforce_pattern(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['fuzz', 'fuzzer', 'random']:
            bruteforce_fuzz(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['dictionary', 'dict', 'wordlist']:
            bruteforce_dictionary(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['replay', 'repeat', 'retry']:
            bruteforce_replay(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['analyze', 'analysis', 'stats']:
            bruteforce_analyze(dev, pattern, bruteforce_args)
            
        elif subcommand in ['continue', 'resume', 'restart']:
            bruteforce_continue(dev, pattern, threads, rawmode, output_file, strategy, bruteforce_args)
            
        elif subcommand in ['help', '?']:
            print_bruteforce_help()
            
        else:
            print(f"[!] Unknown BRUTEFORCE subcommand: {subcommand}")
            print_bruteforce_help()
            
    except Exception as e:
        print(f"[!] BRUTEFORCE operation failed: {e}")
        traceback.print_exc()

# =============================================================================
# BRUTEFORCE SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def bruteforce_list(dev, args):
    """List available brute-force strategies and patterns"""
    print("[*] BRUTEFORCE Strategies and Patterns:")
    
    strategies = [
        {"name": "basic", "description": "Sequential linear search", "speed": "Slow", "coverage": "Complete"},
        {"name": "smart", "description": "Heuristic-based optimization", "speed": "Medium", "coverage": "High"},
        {"name": "aggressive", "description": "Parallel multi-threaded", "speed": "Fast", "coverage": "Medium"},
        {"name": "adaptive", "description": "Machine learning guided", "speed": "Variable", "coverage": "High"},
        {"name": "hybrid", "description": "Combined multiple approaches", "speed": "Fast", "coverage": "Very High"},
    ]
    
    print(f"\n[+] Available Strategies:")
    for strategy in strategies:
        print(f"    {strategy['name']:12} - {strategy['description']}")
        print(f"                  Speed: {strategy['speed']:8} Coverage: {strategy['coverage']}")
    
    patterns = [
        {"name": "numeric", "description": "0-9 digits", "range": "0-999999", "size": "Variable"},
        {"name": "hex", "description": "Hexadecimal values", "range": "0x0000-0xFFFF", "size": "16-bit"},
        {"name": "alphanumeric", "description": "Letters and numbers", "range": "a-z, A-Z, 0-9", "size": "Variable"},
        {"name": "ascii", "description": "Printable ASCII", "range": "0x20-0x7E", "size": "95 chars"},
        {"name": "custom", "description": "User-defined pattern", "range": "User specified", "size": "Variable"},
    ]
    
    print(f"\n[+] Available Patterns:")
    for pattern in patterns:
        print(f"    {pattern['name']:15} - {pattern['description']}")
        print(f"                  Range: {pattern['range']}")

def bruteforce_scan(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Perform systematic scan of address space or value range"""
    print("[*] Preparing systematic scan...")
    
    # Parse pattern or use defaults
    if not pattern:
        # Default to common address ranges
        scan_ranges = [
            (0x00000000, 0x01000000, "Low Memory"),
            (0x10000000, 0x11000000, "Peripheral Space"),
            (0x80000000, 0x90000000, "DRAM Region"),
        ]
    else:
        scan_ranges = parse_scan_pattern(pattern)
    
    if not scan_ranges:
        print("[!] No valid scan ranges specified")
        return
    
    # Enable rawmode if requested
    if rawmode:
        print("[*] Enabling RAWMODE for scan...")
        try:
            resp = qslcl_dispatch(dev, "RAWMODE", b"UNLOCK")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    print("[!] Failed to enable rawmode")
        except Exception as e:
            print(f"[!] Rawmode activation error: {e}")
    
    print(f"[*] Starting systematic scan with {threads} threads...")
    print(f"[*] Strategy: {strategy}")
    
    total_addresses = sum(end - start for start, end, _ in scan_ranges)
    print(f"[*] Total address space: {total_addresses} addresses")
    
    # Initialize results
    results = {
        'successful': [],
        'interesting': [],
        'errors': [],
        'scanned': 0
    }
    
    start_time = time.time()
    
    # Execute scan based on strategy
    if strategy == "basic":
        results = execute_basic_scan(dev, scan_ranges, threads, results, output_file)
    elif strategy == "smart":
        results = execute_smart_scan(dev, scan_ranges, threads, results, output_file)
    elif strategy == "aggressive":
        results = execute_aggressive_scan(dev, scan_ranges, threads, results, output_file)
    else:
        results = execute_basic_scan(dev, scan_ranges, threads, results, output_file)
    
    # Analysis and reporting
    analyze_scan_results(results, start_time, output_file)

def bruteforce_pattern(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Brute-force using specific pattern or sequence"""
    if not pattern:
        print("[!] Specify pattern for brute-force")
        print("[*] Examples: 0x0000-0xFFFF, 000000-999999, AAAA-ZZZZ")
        return
    
    print(f"[*] Preparing pattern brute-force: {pattern}")
    
    # Parse pattern
    sequences = generate_sequences_from_pattern(pattern)
    if not sequences:
        print("[!] Could not generate sequences from pattern")
        return
    
    total_sequences = len(sequences)
    print(f"[*] Generated {total_sequences} sequences to test")
    
    # Enable rawmode if requested
    if rawmode:
        print("[*] Enabling RAWMODE for pattern attack...")
        try:
            resp = qslcl_dispatch(dev, "RAWMODE", b"UNLOCK")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    print("[!] Failed to enable rawmode")
        except Exception as e:
            print(f"[!] Rawmode activation error: {e}")
    
    print(f"[*] Starting pattern brute-force with {threads} threads...")
    
    results = {
        'successful': [],
        'tested': 0,
        'errors': []
    }
    
    start_time = time.time()
    
    # Execute pattern brute-force
    with ProgressBar(total_sequences, prefix='Pattern', suffix='Complete', length=50) as progress:
        # Simple sequential execution for pattern matching
        for i, sequence in enumerate(sequences):
            try:
                success = test_sequence(dev, sequence, rawmode)
                if success:
                    results['successful'].append(sequence)
                    print(f"\n[+] SUCCESS: Pattern matched: {sequence}")
                
                results['tested'] += 1
                progress.update(1)
                
                # Save progress periodically
                if i % 100 == 0 and output_file:
                    save_bruteforce_results(output_file, results, "pattern")
                    
            except Exception as e:
                results['errors'].append(f"Sequence {sequence}: {e}")
    
    # Final analysis
    analyze_pattern_results(results, start_time, output_file)

def bruteforce_fuzz(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Fuzzing-based brute-force with random input generation"""
    print("[*] Preparing fuzzing brute-force...")
    
    # Parse fuzzing parameters
    fuzz_params = parse_fuzz_parameters(pattern, args)
    total_tests = fuzz_params.get('iterations', 1000)
    
    print(f"[*] Fuzzing parameters:")
    print(f"    Iterations: {total_tests}")
    print(f"    Data type: {fuzz_params.get('data_type', 'random')}")
    print(f"    Max size: {fuzz_params.get('max_size', 256)} bytes")
    
    # Enable rawmode if requested
    if rawmode:
        print("[*] Enabling RAWMODE for fuzzing...")
        try:
            resp = qslcl_dispatch(dev, "RAWMODE", b"UNLOCK")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    print("[!] Failed to enable rawmode")
        except Exception as e:
            print(f"[!] Rawmode activation error: {e}")
    
    print(f"[*] Starting fuzzing with {threads} threads...")
    
    results = {
        'crashes': [],
        'interesting': [],
        'tested': 0,
        'errors': []
    }
    
    start_time = time.time()
    
    # Execute fuzzing
    with ProgressBar(total_tests, prefix='Fuzzing', suffix='Complete', length=50) as progress:
        for i in range(total_tests):
            try:
                # Generate fuzz data
                fuzz_data = generate_fuzz_data(fuzz_params)
                
                # Test fuzz data
                crash_detected, interesting_response = test_fuzz_data(dev, fuzz_data, rawmode)
                
                if crash_detected:
                    results['crashes'].append({
                        'data': fuzz_data.hex(),
                        'iteration': i
                    })
                    print(f"\n[!] CRASH DETECTED at iteration {i}")
                    print(f"    Data: {fuzz_data.hex()[:64]}...")
                
                if interesting_response:
                    results['interesting'].append({
                        'data': fuzz_data.hex(),
                        'response': interesting_response,
                        'iteration': i
                    })
                
                results['tested'] += 1
                progress.update(1)
                
                # Save progress periodically
                if i % 100 == 0 and output_file:
                    save_bruteforce_results(output_file, results, "fuzz")
                    
            except Exception as e:
                results['errors'].append(f"Iteration {i}: {e}")
    
    # Final analysis
    analyze_fuzz_results(results, start_time, output_file)

def bruteforce_dictionary(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Dictionary-based brute-force using wordlists"""
    if not pattern:
        print("[!] Specify dictionary file or built-in wordlist")
        print("[*] Built-in wordlists: common, passwords, hex, addresses")
        return
    
    print(f"[*] Preparing dictionary attack: {pattern}")
    
    # Load dictionary
    dictionary = load_dictionary(pattern)
    if not dictionary:
        print("[!] Could not load dictionary")
        return
    
    total_words = len(dictionary)
    print(f"[*] Loaded {total_words} words from dictionary")
    
    # Enable rawmode if requested
    if rawmode:
        print("[*] Enabling RAWMODE for dictionary attack...")
        try:
            resp = qslcl_dispatch(dev, "RAWMODE", b"UNLOCK")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    print("[!] Failed to enable rawmode")
        except Exception as e:
            print(f"[!] Rawmode activation error: {e}")
    
    print(f"[*] Starting dictionary attack with {threads} threads...")
    
    results = {
        'successful': [],
        'tested': 0,
        'errors': []
    }
    
    start_time = time.time()
    
    # Execute dictionary attack
    with ProgressBar(total_words, prefix='Dictionary', suffix='Complete', length=50) as progress:
        for i, word in enumerate(dictionary):
            try:
                success = test_dictionary_word(dev, word, rawmode)
                if success:
                    results['successful'].append(word)
                    print(f"\n[+] SUCCESS: Dictionary word matched: {word}")
                
                results['tested'] += 1
                progress.update(1)
                
                # Save progress periodically
                if i % 100 == 0 and output_file:
                    save_bruteforce_results(output_file, results, "dictionary")
                    
            except Exception as e:
                results['errors'].append(f"Word {word}: {e}")
    
    # Final analysis
    analyze_dictionary_results(results, start_time, output_file)

def bruteforce_replay(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Replay previous brute-force attempts or captured data"""
    if not pattern:
        print("[!] Specify replay file or session ID")
        return
    
    print(f"[*] Preparing replay attack: {pattern}")
    
    # Load replay data
    replay_data = load_replay_data(pattern)
    if not replay_data:
        print("[!] Could not load replay data")
        return
    
    total_attempts = len(replay_data)
    print(f"[*] Loaded {total_attempts} replay attempts")
    
    # Enable rawmode if requested
    if rawmode:
        print("[*] Enabling RAWMODE for replay...")
        try:
            resp = qslcl_dispatch(dev, "RAWMODE", b"UNLOCK")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") != "SUCCESS":
                    print("[!] Failed to enable rawmode")
        except Exception as e:
            print(f"[!] Rawmode activation error: {e}")
    
    print(f"[*] Starting replay attack with {threads} threads...")
    
    results = {
        'successful': [],
        'replayed': 0,
        'errors': []
    }
    
    start_time = time.time()
    
    # Execute replay
    with ProgressBar(total_attempts, prefix='Replay', suffix='Complete', length=50) as progress:
        for i, attempt in enumerate(replay_data):
            try:
                success = replay_attempt(dev, attempt, rawmode)
                if success:
                    results['successful'].append(attempt)
                    print(f"\n[+] SUCCESS: Replay successful: {attempt}")
                
                results['replayed'] += 1
                progress.update(1)
                
                # Save progress periodically
                if i % 100 == 0 and output_file:
                    save_bruteforce_results(output_file, results, "replay")
                    
            except Exception as e:
                results['errors'].append(f"Attempt {i}: {e}")
    
    # Final analysis
    analyze_replay_results(results, start_time, output_file)

def bruteforce_analyze(dev, pattern, args=None):
    """Analyze brute-force results and patterns"""
    if not pattern:
        print("[!] Specify results file or session to analyze")
        return
    
    print(f"[*] Analyzing brute-force results: {pattern}")
    
    # Load and analyze results
    analysis = analyze_bruteforce_results(pattern)
    if not analysis:
        print("[!] Could not analyze results")
        return
    
    print(f"\n[+] BRUTEFORCE ANALYSIS RESULTS:")
    print(f"    Total attempts: {analysis.get('total_attempts', 0)}")
    print(f"    Successful: {analysis.get('successful', 0)}")
    print(f"    Success rate: {analysis.get('success_rate', 0):.2f}%")
    print(f"    Time elapsed: {analysis.get('time_elapsed', 'Unknown')}")
    
    # Show patterns in successful attempts
    successes = analysis.get('successful_attempts', [])
    if successes:
        print(f"\n[+] SUCCESSFUL ATTEMPTS:")
        for success in successes[:10]:  # Show first 10
            print(f"    - {success}")
        
        if len(successes) > 10:
            print(f"    ... and {len(successes) - 10} more")
    
    # Show statistics
    stats = analysis.get('statistics', {})
    if stats:
        print(f"\n[+] STATISTICS:")
        for key, value in stats.items():
            print(f"    {key}: {value}")

def bruteforce_continue(dev, pattern, threads=8, rawmode=False, output_file="", strategy="basic", args=None):
    """Continue interrupted brute-force session"""
    if not pattern:
        print("[!] Specify session file to continue")
        return
    
    print(f"[*] Continuing brute-force session: {pattern}")
    
    # Load session state
    session = load_bruteforce_session(pattern)
    if not session:
        print("[!] Could not load session")
        return
    
    session_type = session.get('type', 'scan')
    remaining = session.get('remaining', [])
    
    print(f"[*] Resuming {session_type} session")
    print(f"[*] Remaining attempts: {len(remaining)}")
    
    # Continue based on session type
    if session_type == "scan":
        bruteforce_scan(dev, "", threads, rawmode, output_file, strategy, args)
    elif session_type == "pattern":
        bruteforce_pattern(dev, "", threads, rawmode, output_file, strategy, args)
    elif session_type == "fuzz":
        bruteforce_fuzz(dev, "", threads, rawmode, output_file, strategy, args)
    elif session_type == "dictionary":
        bruteforce_dictionary(dev, "", threads, rawmode, output_file, strategy, args)
    else:
        print(f"[!] Unknown session type: {session_type}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR BRUTEFORCE
# =============================================================================

def parse_scan_pattern(pattern):
    """Parse scan pattern into address ranges"""
    ranges = []
    
    try:
        if '-' in pattern:
            # Range format: start-end
            start_str, end_str = pattern.split('-', 1)
            start = parse_address(start_str)
            end = parse_address(end_str)
            ranges.append((start, end, "Custom Range"))
        else:
            # Single address or default ranges
            addr = parse_address(pattern)
            ranges.append((addr, addr + 0x1000, "Single Address Area"))
    except:
        # Use default ranges if pattern parsing fails
        ranges = [
            (0x10000000, 0x10001000, "Default Peripheral"),
            (0x80000000, 0x80001000, "Default DRAM"),
        ]
    
    return ranges

def generate_sequences_from_pattern(pattern):
    """Generate test sequences from pattern specification"""
    sequences = []
    
    try:
        if pattern.startswith('0x') and '-' in pattern:
            # Hex range: 0x0000-0xFFFF
            start_str, end_str = pattern.split('-', 1)
            start = int(start_str, 16)
            end = int(end_str, 16)
            
            # Limit to reasonable number for demo
            step = max(1, (end - start) // 1000)
            for value in range(start, end + 1, step):
                sequences.append(f"0x{value:04X}")
                
        elif pattern.replace('-', '').isdigit() and '-' in pattern:
            # Numeric range: 000000-999999
            start_str, end_str = pattern.split('-', 1)
            start = int(start_str)
            end = int(end_str)
            
            # Limit to reasonable number
            step = max(1, (end - start) // 1000)
            for value in range(start, end + 1, step):
                sequences.append(f"{value:06d}")
                
        else:
            # Single value or other pattern
            sequences.append(pattern)
            
    except Exception as e:
        print(f"[!] Pattern generation error: {e}")
        sequences = [pattern] if pattern else []
    
    return sequences[:1000]  # Limit to first 1000 sequences for demo

def parse_fuzz_parameters(pattern, args):
    """Parse fuzzing parameters from pattern and arguments"""
    params = {
        'iterations': 1000,
        'data_type': 'random',
        'max_size': 256
    }
    
    if pattern:
        try:
            if ':' in pattern:
                key, value = pattern.split(':', 1)
                if key == 'iterations':
                    params['iterations'] = int(value)
                elif key == 'size':
                    params['max_size'] = int(value)
                elif key == 'type':
                    params['data_type'] = value
        except:
            pass
    
    # Parse additional args
    if args:
        for arg in args:
            if '=' in arg:
                key, value = arg.split('=', 1)
                if key == 'iterations':
                    params['iterations'] = int(value)
                elif key == 'size':
                    params['max_size'] = int(value)
    
    return params

def generate_fuzz_data(params):
    """Generate fuzz data based on parameters"""
    data_type = params.get('data_type', 'random')
    max_size = params.get('max_size', 256)
    
    if data_type == 'random':
        size = random.randint(1, max_size)
        return bytes(random.getrandbits(8) for _ in range(size))
    elif data_type == 'zeros':
        size = random.randint(1, max_size)
        return b'\x00' * size
    elif data_type == 'ones':
        size = random.randint(1, max_size)
        return b'\xFF' * size
    elif data_type == 'pattern':
        size = random.randint(1, max_size)
        pattern = bytes([random.getrandbits(8)])
        return pattern * size
    else:
        size = random.randint(1, max_size)
        return os.urandom(size)

def load_dictionary(source):
    """Load dictionary from file or built-in wordlists"""
    words = []
    
    # Built-in wordlists
    builtin_wordlists = {
        'common': ['admin', 'password', '1234', 'test', 'default', 'root', 'user', 'guest'],
        'passwords': ['password', '123456', 'admin', 'letmein', 'qwerty', 'monkey', 'abc123'],
        'hex': [f"0x{i:04X}" for i in range(0, 0x100, 0x10)],
        'addresses': [f"0x{addr:08X}" for addr in range(0x10000000, 0x10001000, 0x100)],
        'commands': ['READ', 'WRITE', 'ERASE', 'HELLO', 'PING', 'GETINFO', 'AUTH'],
    }
    
    if source in builtin_wordlists:
        return builtin_wordlists[source]
    
    # Try to load from file
    try:
        if os.path.exists(source):
            with open(source, 'r', encoding='utf-8', errors='ignore') as f:
                words = [line.strip() for line in f if line.strip()]
            print(f"[+] Loaded {len(words)} words from {source}")
        else:
            print(f"[!] Dictionary file not found: {source}")
    except Exception as e:
        print(f"[!] Error loading dictionary: {e}")
    
    return words

def load_replay_data(source):
    """Load replay data from file"""
    attempts = []
    
    try:
        if os.path.exists(source):
            with open(source, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        attempts.append(line)
            print(f"[+] Loaded {len(attempts)} replay attempts from {source}")
        else:
            print(f"[!] Replay file not found: {source}")
    except Exception as e:
        print(f"[!] Error loading replay data: {e}")
    
    return attempts

def test_sequence(dev, sequence, rawmode=False):
    """Test a single sequence against the device"""
    try:
        # Convert sequence to bytes if needed
        if isinstance(sequence, str):
            if sequence.startswith('0x'):
                # Hex value
                value = int(sequence, 16)
                # Determine appropriate size
                if value <= 0xFF:
                    test_data = value.to_bytes(1, 'little')
                elif value <= 0xFFFF:
                    test_data = value.to_bytes(2, 'little')
                elif value <= 0xFFFFFFFF:
                    test_data = value.to_bytes(4, 'little')
                else:
                    test_data = value.to_bytes(8, 'little')
            else:
                # String value
                test_data = sequence.encode('utf-8')
        else:
            test_data = sequence
        
        # Send test data
        if rawmode:
            # Use raw mode command
            resp = qslcl_dispatch(dev, "RAWMODE", test_data)
        else:
            # Use standard command - try both TEST and the sequence itself
            resp = qslcl_dispatch(dev, "TEST", test_data)
            if not resp:
                # Try using sequence as command name
                if isinstance(sequence, str) and len(sequence) <= 16:
                    resp = qslcl_dispatch(dev, sequence.upper(), b"")
        
        if resp:
            status = decode_runtime_result(resp)
            return status.get("severity", "ERROR") == "SUCCESS"
        
        return False
        
    except Exception as e:
        # Debug: uncomment for troubleshooting
        # print(f"[!] Test sequence error: {e}")
        return False

def test_fuzz_data(dev, fuzz_data, rawmode=False):
    """Test fuzz data and detect crashes or interesting responses"""
    try:
        if rawmode:
            resp = qslcl_dispatch(dev, "RAWMODE", fuzz_data)
        else:
            resp = qslcl_dispatch(dev, "FUZZ", fuzz_data)
            if not resp:
                # Try TEST command as fallback
                resp = qslcl_dispatch(dev, "TEST", fuzz_data)
        
        if resp:
            status = decode_runtime_result(resp)
            
            # Check for crash indicators
            crash_indicators = ['CRASH', 'FATAL', 'PANIC', 'EXCEPTION', 'RESET']
            crash_detected = any(indicator in status.get("name", "").upper() for indicator in crash_indicators)
            
            # Check for interesting responses
            interesting = status.get("severity", "UNKNOWN") not in ['SUCCESS', 'ERROR']
            
            return crash_detected, interesting
        
        # No response might indicate crash or timeout
        return True, False
        
    except Exception as e:
        # Exception during communication might indicate crash
        return True, False

def test_dictionary_word(dev, word, rawmode=False):
    """Test a dictionary word against the device"""
    return test_sequence(dev, word, rawmode)

def replay_attempt(dev, attempt, rawmode=False):
    """Replay a captured attempt"""
    return test_sequence(dev, attempt, rawmode)

def execute_basic_scan(dev, scan_ranges, threads, results, output_file):
    """Execute basic sequential scan"""
    for start, end, description in scan_ranges:
        print(f"[*] Scanning {description}: 0x{start:08X}-0x{end:08X}")
        
        # Limit scan size for safety
        max_scan = min(end - start, 0x10000)  # 64KB max per range
        step = 4  # 4-byte alignment
        
        for offset in range(0, max_scan, step):
            address = start + offset
            try:
                # Test read at address
                read_payload = struct.pack("<II", address, 4)
                resp = qslcl_dispatch(dev, "READ", read_payload)
                
                if resp:
                    status = decode_runtime_result(resp)
                    if status.get("severity") == "SUCCESS":
                        data = status.get("extra", b"")
                        if data and data != b'\x00\x00\x00\x00':
                            # Interesting data found
                            results['interesting'].append({
                                'address': f"0x{address:08X}",
                                'data': data.hex(),
                                'description': 'Non-zero data'
                            })
                    
                    results['scanned'] += 1
                    
                    # Periodic status update
                    if results['scanned'] % 100 == 0:
                        print(f"\r[*] Scanned {results['scanned']} addresses...", end="")
                    
            except Exception as e:
                results['errors'].append(f"Address 0x{address:08X}: {str(e)[:50]}")
    
    print()  # New line after progress
    return results

def execute_smart_scan(dev, scan_ranges, threads, results, output_file):
    """Execute smart scan with heuristics"""
    # For now, same as basic scan but with optimized step size
    return execute_basic_scan(dev, scan_ranges, threads, results, output_file)

def execute_aggressive_scan(dev, scan_ranges, threads, results, output_file):
    """Execute aggressive parallel scan"""
    print(f"[*] Aggressive scan with {threads} threads...")
    
    # Create work queue
    work_queue = Queue()
    
    # Add addresses to queue
    for start, end, description in scan_ranges:
        max_scan = min(end - start, 0x1000)  # 4KB max for aggressive
        for offset in range(0, max_scan, 4):
            work_queue.put(start + offset)
    
    total_addresses = work_queue.qsize()
    print(f"[*] Queue size: {total_addresses} addresses")
    
    # Worker function
    def worker(worker_id, queue, results_dict, dev_local):
        local_results = {
            'interesting': [],
            'scanned': 0,
            'errors': []
        }
        
        while not queue.empty():
            try:
                address = queue.get_nowait()
                
                # Test read
                read_payload = struct.pack("<II", address, 4)
                resp = qslcl_dispatch(dev_local, "READ", read_payload)
                
                if resp:
                    status = decode_runtime_result(resp)
                    if status.get("severity") == "SUCCESS":
                        data = status.get("extra", b"")
                        if data and data != b'\x00\x00\x00\x00':
                            local_results['interesting'].append({
                                'address': f"0x{address:08X}",
                                'data': data.hex()
                            })
                    
                    local_results['scanned'] += 1
                    
            except Exception as e:
                local_results['errors'].append(f"Thread {worker_id}: {str(e)[:30]}")
            finally:
                queue.task_done()
        
        # Merge results
        with threading.Lock():
            results_dict['interesting'].extend(local_results['interesting'])
            results_dict['scanned'] += local_results['scanned']
            results_dict['errors'].extend(local_results['errors'])
    
    # Start threads
    thread_results = {'interesting': [], 'scanned': 0, 'errors': []}
    threads_list = []
    
    for i in range(min(threads, total_addresses)):
        t = threading.Thread(target=worker, args=(i, work_queue, thread_results, dev))
        t.daemon = True
        t.start()
        threads_list.append(t)
    
    # Wait for completion
    work_queue.join()
    
    for t in threads_list:
        t.join(timeout=5)
    
    results.update(thread_results)
    return results

def save_bruteforce_results(output_file, results, attack_type):
    """Save brute-force results to file"""
    try:
        mode = 'a' if os.path.exists(output_file) else 'w'
        with open(output_file, mode, encoding='utf-8') as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"BRUTEFORCE RESULTS - {attack_type}\n")
            f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Successful: {len(results.get('successful', []))}\n")
            f.write(f"Tested: {results.get('tested', results.get('scanned', 0))}\n")
            f.write(f"{'='*60}\n\n")
            
            if 'successful' in results and results['successful']:
                f.write("SUCCESSFUL ATTEMPTS:\n")
                for success in results['successful']:
                    f.write(f"  - {success}\n")
                f.write("\n")
            
            if 'interesting' in results and results['interesting']:
                f.write("INTERESTING RESULTS:\n")
                for interesting in results['interesting']:
                    if isinstance(interesting, dict):
                        f.write(f"  - Address: {interesting.get('address', 'N/A')}")
                        f.write(f" Data: {interesting.get('data', 'N/A')}")
                        f.write(f" Desc: {interesting.get('description', '')}\n")
                    else:
                        f.write(f"  - {interesting}\n")
                f.write("\n")
            
            if 'crashes' in results and results['crashes']:
                f.write("CRASHES DETECTED:\n")
                for crash in results['crashes']:
                    f.write(f"  - Iteration: {crash.get('iteration', 'N/A')}")
                    f.write(f" Data: {crash.get('data', 'N/A')[:64]}...\n")
                f.write("\n")
            
            if results.get('errors'):
                f.write(f"ERRORS ({len(results['errors'])}):\n")
                for error in results['errors'][:20]:  # Show first 20 errors
                    f.write(f"  - {error}\n")
                if len(results['errors']) > 20:
                    f.write(f"  ... and {len(results['errors']) - 20} more errors\n")
        
        print(f"[+] Results saved to {output_file}")
        
    except Exception as e:
        print(f"[!] Error saving results: {e}")

def analyze_scan_results(results, start_time, output_file):
    """Analyze and report scan results"""
    elapsed = time.time() - start_time
    scanned = results.get('scanned', 0)
    speed = scanned / elapsed if elapsed > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"[+] SCAN COMPLETED:")
    print(f"    Time elapsed: {elapsed:.2f}s")
    print(f"    Addresses scanned: {scanned}")
    print(f"    Scan speed: {speed:.2f} addresses/sec")
    print(f"    Interesting findings: {len(results.get('interesting', []))}")
    print(f"    Errors: {len(results.get('errors', []))}")
    
    if results.get('interesting'):
        print(f"\n[+] INTERESTING FINDINGS (first 5):")
        for finding in results['interesting'][:5]:
            if isinstance(finding, dict):
                addr = finding.get('address', 'N/A')
                data = finding.get('data', 'N/A')
                desc = finding.get('description', '')
                print(f"     {addr}: {data} - {desc}")
    
    if output_file and results.get('interesting'):
        print(f"[+] Full results saved to: {output_file}")

def analyze_pattern_results(results, start_time, output_file):
    """Analyze and report pattern results"""
    elapsed = time.time() - start_time
    tested = results.get('tested', 0)
    successful = len(results.get('successful', []))
    
    success_rate = (successful / tested * 100) if tested > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"[+] PATTERN BRUTEFORCE COMPLETED:")
    print(f"    Time elapsed: {elapsed:.2f}s")
    print(f"    Sequences tested: {tested}")
    print(f"    Successful: {successful}")
    print(f"    Success rate: {success_rate:.2f}%")
    
    if successful > 0:
        print(f"\n[+] SUCCESSFUL PATTERNS:")
        for pattern in results['successful'][:10]:
            print(f"    - {pattern}")
    
    if results.get('errors'):
        print(f"\n[!] Errors encountered: {len(results['errors'])}")

def analyze_fuzz_results(results, start_time, output_file):
    """Analyze and report fuzzing results"""
    elapsed = time.time() - start_time
    tested = results.get('tested', 0)
    crashes = len(results.get('crashes', []))
    interesting = len(results.get('interesting', []))
    
    print(f"\n{'='*60}")
    print(f"[+] FUZZING COMPLETED:")
    print(f"    Time elapsed: {elapsed:.2f}s")
    print(f"    Tests performed: {tested}")
    print(f"    Crashes detected: {crashes}")
    print(f"    Interesting responses: {interesting}")
    
    if crashes > 0:
        print(f"\n[!] CRASHES DETECTED (first 3):")
        for crash in results['crashes'][:3]:
            print(f"    - Iteration {crash.get('iteration', 'N/A')}:")
            print(f"      Data: {crash.get('data', 'N/A')[:64]}...")
    
    if output_file:
        print(f"[+] Results saved to: {output_file}")

def analyze_dictionary_results(results, start_time, output_file):
    """Analyze and report dictionary attack results"""
    elapsed = time.time() - start_time
    tested = results.get('tested', 0)
    successful = len(results.get('successful', []))
    
    success_rate = (successful / tested * 100) if tested > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"[+] DICTIONARY ATTACK COMPLETED:")
    print(f"    Time elapsed: {elapsed:.2f}s")
    print(f"    Words tested: {tested}")
    print(f"    Successful: {successful}")
    print(f"    Success rate: {success_rate:.2f}%")
    
    if successful > 0:
        print(f"\n[+] SUCCESSFUL WORDS:")
        for word in results['successful']:
            print(f"    - {word}")

def analyze_replay_results(results, start_time, output_file):
    """Analyze and report replay results"""
    elapsed = time.time() - start_time
    replayed = results.get('replayed', 0)
    successful = len(results.get('successful', []))
    
    success_rate = (successful / replayed * 100) if replayed > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"[+] REPLAY ATTACK COMPLETED:")
    print(f"    Time elapsed: {elapsed:.2f}s")
    print(f"    Attempts replayed: {replayed}")
    print(f"    Successful: {successful}")
    print(f"    Success rate: {success_rate:.2f}%")

def analyze_bruteforce_results(pattern):
    """Analyze brute-force results from file"""
    analysis = {
        'total_attempts': 0,
        'successful': 0,
        'success_rate': 0,
        'time_elapsed': 'Unknown',
        'successful_attempts': [],
        'statistics': {}
    }
    
    try:
        if not os.path.exists(pattern):
            print(f"[!] Results file not found: {pattern}")
            return None
        
        with open(pattern, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Simple analysis - count lines and look for success indicators
        lines = content.split('\n')
        analysis['total_attempts'] = len([l for l in lines if l.strip()])
        
        # Look for successful attempts
        success_lines = []
        for line in lines:
            if any(keyword in line.upper() for keyword in ['SUCCESS', 'MATCHED', 'FOUND', 'VALID']):
                success_lines.append(line.strip())
        
        analysis['successful'] = len(success_lines)
        analysis['successful_attempts'] = success_lines[:20]  # First 20
        
        if analysis['total_attempts'] > 0:
            analysis['success_rate'] = (analysis['successful'] / analysis['total_attempts']) * 100
        
        # Look for timestamp
        time_match = re.search(r'Timestamp:\s*(.+)', content)
        if time_match:
            analysis['time_elapsed'] = time_match.group(1)
        
        # Basic statistics
        analysis['statistics'] = {
            'file_size': f"{len(content)} bytes",
            'lines': len(lines),
            'success_density': f"{analysis['success_rate']:.1f}%",
        }
        
    except Exception as e:
        print(f"[!] Error analyzing results: {e}")
        return None
    
    return analysis

def load_bruteforce_session(pattern):
    """Load saved brute-force session"""
    session = {
        'type': 'scan',
        'remaining': [],
        'progress': 0,
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
    }
    
    try:
        if os.path.exists(pattern):
            with open(pattern, 'r', encoding='utf-8') as f:
                session = json.load(f)
            print(f"[+] Loaded session from {pattern}")
        else:
            print(f"[!] Session file not found: {pattern}")
    except Exception as e:
        print(f"[!] Error loading session: {e}")
    
    return session

def print_bruteforce_help():
    """Display bruteforce command help"""
    print("""
BRUTEFORCE Command Usage:
  bruteforce list                    - List available strategies and patterns
  bruteforce scan [pattern]          - Systematic address/value scanning
  bruteforce pattern <pattern>       - Pattern-based brute-force
  bruteforce fuzz [params]           - Fuzzing-based attack
  bruteforce dictionary <source>     - Dictionary-based attack
  bruteforce replay <file>           - Replay captured attempts
  bruteforce analyze <results>       - Analyze brute-force results
  bruteforce continue <session>      - Continue interrupted session

Pattern Examples:
  0x0000-0xFFFF     - Hexadecimal range
  000000-999999     - Numeric range
  common            - Built-in common values
  passwords         - Built-in password list

Strategies:
  basic      - Sequential linear search (thorough but slow)
  smart      - Heuristic optimization (balanced)
  aggressive - Parallel multi-threaded (fast but may miss)

Options:
  --threads <N>     - Number of parallel threads (default: 8)
  --rawmode         - Enable raw mode for deeper access
  --output <file>   - Save results to file
  --strategy <type> - Brute-force strategy

Examples:
  qslcl bruteforce scan 0x10000000-0x10001000
  qslcl bruteforce pattern 0x0000-0x00FF --threads 16
  qslcl bruteforce dictionary common --rawmode
  qslcl bruteforce fuzz iterations:5000 --output fuzz_results.txt
  qslcl bruteforce analyze previous_session.json

WARNINGS:
  - Brute-force operations may trigger device protections
  - Excessive scanning may cause device instability
  - Use rawmode only when necessary
  - Monitor device temperature during intensive operations
    """)