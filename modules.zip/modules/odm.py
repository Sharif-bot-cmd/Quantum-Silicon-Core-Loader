def cmd_odm(args=None):
    """
    Fully implemented ODM command with advanced features:
    - ODM-specific device configuration and customization
    - Hardware customization and branding
    - Manufacturing test modes and diagnostics
    - Supply chain management and provisioning
    - Custom firmware and feature management
    """
    if not args:
        print("[!] ODM: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'odm_subcommand', '').lower()
    odm_args = getattr(args, 'odm_args', [])
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)

    if not subcommand:
        print("[!] ODM: No subcommand specified")
        print_odm_help()
        return

    print(f"[*] ODM command: {subcommand} {odm_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['info', 'status', 'identity']:
            odm_info(dev, odm_args, verbose)
            
        elif subcommand in ['provision', 'setup', 'init']:
            odm_provision(dev, odm_args, force, verbose)
            
        elif subcommand in ['customize', 'brand', 'personalize']:
            odm_customize(dev, odm_args, force, verbose)
            
        elif subcommand in ['test', 'diagnostic', 'selftest']:
            odm_test(dev, odm_args, force, verbose)
            
        elif subcommand in ['calibrate', 'tune', 'adjust']:
            odm_calibrate(dev, odm_args, force, verbose)
            
        elif subcommand in ['feature', 'capability', 'toggle']:
            odm_feature(dev, odm_args, force, verbose)
            
        elif subcommand in ['region', 'locale', 'market']:
            odm_region(dev, odm_args, force, verbose)
            
        elif subcommand in ['security', 'lockdown', 'secure']:
            odm_security(dev, odm_args, force, verbose)
            
        elif subcommand in ['firmware', 'update', 'flash']:
            odm_firmware(dev, odm_args, force, verbose)
            
        elif subcommand in ['manufacturing', 'factory', 'production']:
            odm_manufacturing(dev, odm_args, force, verbose)
            
        elif subcommand in ['supplychain', 'logistics', 'tracking']:
            odm_supplychain(dev, odm_args, verbose)
            
        elif subcommand in ['unlock', 'enable', 'activate']:
            odm_unlock(dev, odm_args, force, verbose)
            
        elif subcommand in ['lock', 'disable', 'deactivate']:
            odm_lock(dev, odm_args, verbose)
            
        elif subcommand in ['reset', 'restore', 'defaults']:
            odm_reset(dev, odm_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_odm_help()
            
        else:
            print(f"[!] Unknown ODM subcommand: {subcommand}")
            print_odm_help()
            
    except Exception as e:
        print(f"[!] ODM operation failed: {e}")
        if verbose:
            import traceback
            traceback.print_exc()

# =============================================================================
# ODM SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def odm_info(dev, args, verbose=False):
    """Display ODM-specific device information"""
    print("[*] Querying ODM device information...")
    
    info = query_odm_info(dev, verbose)
    
    print(f"\n[+] ODM Device Information:")
    print(f"    Manufacturer: {info.get('manufacturer', 'Unknown')}")
    print(f"    Model: {info.get('model', 'Unknown')}")
    print(f"    SKU: {info.get('sku', 'Unknown')}")
    print(f"    Serial: {info.get('serial', 'Unknown')}")
    print(f"    HW Revision: {info.get('hw_revision', 'Unknown')}")
    print(f"    Production Date: {info.get('production_date', 'Unknown')}")
    print(f"    Region: {info.get('region', 'Unknown')}")
    print(f"    Carrier: {info.get('carrier', 'Unknown')}")
    
    # ODM-specific features
    features = info.get('features', [])
    if features:
        print(f"\n[+] ODM Features:")
        for feature in features:
            status = "✓" if feature.get('enabled', False) else "✗"
            print(f"    {status} {feature['name']:20} - {feature.get('description', '')}")
    
    # Customizations
    customizations = info.get('customizations', [])
    if customizations:
        print(f"\n[+] Device Customizations:")
        for custom in customizations:
            print(f"    {custom['type']:15}: {custom['value']}")

def odm_provision(dev, args, force=False, verbose=False):
    """Provision device for ODM manufacturing"""
    print("[*] Starting ODM provisioning...")
    
    if not force:
        print("[!] Provisioning will configure device for manufacturing.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Provisioning steps
    provisioning_steps = [
        "Initializing provisioning mode",
        "Setting manufacturing flags",
        "Configuring base parameters",
        "Installing ODM certificates",
        "Setting up secure elements",
        "Finalizing provisioning"
    ]
    
    for step in provisioning_steps:
        print(f"[*] {step}...")
        time.sleep(0.5)  # Reduced from 1 second for better UX
    
    try:
        # Build provisioning payload
        provision_payload = struct.pack("<B", 0x10)  # PROVISION command
        provision_payload += b"ODM_PROVISION"
        provision_payload += b'\x00' * 3  # Padding to align
        
        # Add provisioning parameters if provided
        if args:
            for arg in args:
                provision_payload += arg.encode('ascii')[:16].ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "ODM", provision_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] ODM provisioning completed successfully")
                if verbose:
                    print(f"    Response: {status}")
            else:
                print(f"[!] Provisioning failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Provisioning error: {e}")

def odm_customize(dev, args, force=False, verbose=False):
    """Apply ODM customizations and branding"""
    if not args:
        print("[!] Specify customization to apply")
        print("[*] Available: branding, bootlogo, bootanimation, sounds, themes")
        return
    
    customization_type = args[0].lower()
    customization_value = args[1] if len(args) > 1 else ""
    
    # Validate customization type
    valid_customizations = ['branding', 'bootlogo', 'bootanimation', 'sounds', 'themes']
    if customization_type not in valid_customizations:
        print(f"[!] Invalid customization type: {customization_type}")
        print(f"[*] Valid types: {', '.join(valid_customizations)}")
        return
    
    print(f"[*] Applying ODM customization: {customization_type}")
    
    if not force:
        print(f"[!] This will modify device {customization_type}.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        # Check if customization value is a file
        if customization_value and os.path.exists(customization_value):
            print(f"[*] Loading customization data from: {customization_value}")
            try:
                with open(customization_value, 'rb') as f:
                    custom_data = f.read()
                # Use file data as payload
                customize_payload = struct.pack("<B", 0x20)  # CUSTOMIZE command
                customize_payload += customization_type.encode('ascii').ljust(16, b'\x00')
                customize_payload += struct.pack("<I", len(custom_data))
                customize_payload += custom_data
            except Exception as file_error:
                print(f"[!] Failed to read customization file: {file_error}")
                return
        else:
            # Use string value
            customize_payload = struct.pack("<B", 0x20)  # CUSTOMIZE command
            customize_payload += customization_type.encode('ascii').ljust(16, b'\x00')
            
            if customization_value:
                customize_payload += customization_value.encode('ascii').ljust(32, b'\x00')
        
        resp = qslcl_dispatch(dev, "ODM", customize_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {customization_type} customization applied successfully")
            else:
                print(f"[!] Customization failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Customization error: {e}")

def odm_test(dev, args, force=False, verbose=False):
    """Run ODM manufacturing tests"""
    test_type = "QUICK"
    if args:
        test_type = args[0].upper()
    
    # Validate test type
    valid_test_types = ["QUICK", "FULL", "EXTENDED"]
    if test_type not in valid_test_types:
        print(f"[!] Invalid test type: {test_type}")
        print(f"[*] Valid types: {', '.join(valid_test_types)}")
        test_type = "QUICK"
    
    print(f"[*] Starting ODM {test_type} test suite...")
    
    if not force:
        print("[!] Manufacturing tests may take several minutes.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Test suites with realistic timings
    test_suites = {
        "QUICK": [
            ("Basic connectivity", 0.5),
            ("Memory test", 1.0),
            ("CPU validation", 0.5),
            ("Storage check", 1.0)
        ],
        "FULL": [
            ("Hardware diagnostics", 2.0),
            ("Sensor calibration", 1.5),
            ("Radio testing", 3.0),
            ("Display verification", 1.0),
            ("Audio testing", 1.5),
            ("Battery calibration", 2.0),
            ("Camera test", 1.0)
        ],
        "EXTENDED": [
            ("Burn-in test", 10.0),
            ("Stress testing", 5.0),
            ("Thermal validation", 3.0),
            ("Long-term reliability", 8.0),
            ("Environmental testing", 6.0)
        ]
    }
    
    tests = test_suites.get(test_type, test_suites["QUICK"])
    
    print(f"[*] Running {len(tests)} tests...\n")
    
    results = {"PASS": 0, "FAIL": 0}
    
    for test_name, test_duration in tests:
        print(f"    Testing: {test_name}...", end="", flush=True)
        
        try:
            # Send test command to device
            test_payload = struct.pack("<B", 0x30)  # TEST command
            test_payload += test_type.encode('ascii').ljust(8, b'\x00')
            test_payload += test_name.encode('ascii').ljust(32, b'\x00')
            
            resp = qslcl_dispatch(dev, "ODM", test_payload)
            
            # Simulate test duration
            time.sleep(test_duration)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    print(f" PASS")
                    results["PASS"] += 1
                else:
                    print(f" FAIL")
                    results["FAIL"] += 1
                    if verbose:
                        print(f"      Error: {status}")
            else:
                print(f" FAIL (no response)")
                results["FAIL"] += 1
                
        except Exception as e:
            print(f" FAIL (error: {e})")
            results["FAIL"] += 1
    
    print(f"\n[+] ODM test suite completed")
    print(f"    Results: {results['PASS']} passed, {results['FAIL']} failed")
    
    if results['FAIL'] > 0:
        print(f"[!] {results['FAIL']} tests failed - check device logs")
    else:
        print(f"[✓] All tests passed successfully")

def odm_calibrate(dev, args, force=False, verbose=False):
    """Calibrate ODM-specific hardware"""
    if not args:
        print("[!] Specify hardware to calibrate")
        print("[*] Available: display, touch, audio, sensors, camera, battery")
        return
    
    hardware = args[0].lower()
    
    # Validate hardware type
    valid_hardware = ['display', 'touch', 'audio', 'sensors', 'camera', 'battery']
    if hardware not in valid_hardware:
        print(f"[!] Invalid hardware type: {hardware}")
        print(f"[*] Valid types: {', '.join(valid_hardware)}")
        return
    
    print(f"[*] Starting {hardware} calibration...")
    
    if not force:
        print(f"[!] {hardware.capitalize()} calibration requires proper test equipment.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        calibrate_payload = struct.pack("<B", 0x40)  # CALIBRATE command
        calibrate_payload += hardware.encode('ascii').ljust(16, b'\x00')
        
        # Add calibration parameters if provided
        if len(args) > 1:
            for param in args[1:]:
                try:
                    # Try to parse as float or int
                    if '.' in param:
                        value = float(param)
                        calibrate_payload += struct.pack("<f", value)
                    else:
                        value = int(param)
                        calibrate_payload += struct.pack("<I", value)
                except ValueError:
                    calibrate_payload += param.encode('ascii').ljust(16, b'\x00')
        
        print(f"[*] Sending calibration command...")
        resp = qslcl_dispatch(dev, "ODM", calibrate_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {hardware} calibration completed")
                if verbose:
                    calibration_data = status["extra"]
                    if calibration_data:
                        print(f"    Calibration data: {calibration_data.hex()[:32]}...")
            else:
                print(f"[!] {hardware} calibration failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Calibration error: {e}")

def odm_feature(dev, args, force=False, verbose=False):
    """Enable/disable ODM-specific features"""
    if not args:
        print("[!] Specify feature to manage")
        print("[*] Available features: CUSTOM_BOOTANIMATION, BRANDED_SOUNDS, CUSTOM_THEME, EXTENDED_DIAGNOSTICS")
        return
    
    feature = args[0].upper()
    action = "ENABLE"
    if len(args) > 1:
        action = args[1].upper()
    
    if action not in ["ENABLE", "DISABLE", "TOGGLE"]:
        print(f"[!] Invalid action: {action}")
        print("[*] Valid actions: ENABLE, DISABLE, TOGGLE")
        return
    
    print(f"[*] {action} ODM feature: {feature}")
    
    if not force:
        print(f"[!] This will {action.lower()} {feature}.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        feature_payload = struct.pack("<B", 0x50)  # FEATURE command
        feature_payload += feature.encode('ascii').ljust(16, b'\x00')
        feature_payload += action.encode('ascii').ljust(8, b'\x00')
        
        resp = qslcl_dispatch(dev, "ODM", feature_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Feature {feature} {action.lower()}d successfully")
            else:
                print(f"[!] Feature operation failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Feature operation error: {e}")

def odm_region(dev, args, force=False, verbose=False):
    """Configure regional settings and compliance"""
    if not args:
        print("[!] Specify region or operation")
        print("[*] Available: set <region>, list, info")
        return
    
    operation = args[0].lower()
    
    if operation == "list":
        print("\n[+] Available Regions:")
        regions = ["NA", "EU", "ASIA", "CN", "JP", "KR", "IN", "LATAM", "MEA", "GLOBAL"]
        for region in regions:
            print(f"    {region}")
        return
    elif operation == "info":
        # Query current region
        try:
            region_payload = struct.pack("<B", 0x60)  # REGION command
            region_payload += b"GET" + b'\x00' * 13
            
            resp = qslcl_dispatch(dev, "ODM", region_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    region_data = status["extra"]
                    if region_data:
                        region_str = region_data.decode('ascii', errors='ignore').strip('\x00')
                        print(f"[+] Current region: {region_str}")
                else:
                    print(f"[!] Failed to get region info: {status}")
            else:
                print("[!] No response from device")
        except Exception as e:
            print(f"[!] Region info error: {e}")
            
    elif operation == "set" and len(args) > 1:
        region = args[1].upper()
        
        # Validate region
        valid_regions = ["NA", "EU", "ASIA", "CN", "JP", "KR", "IN", "LATAM", "MEA", "GLOBAL"]
        if region not in valid_regions:
            print(f"[!] Invalid region: {region}")
            print(f"[*] Valid regions: {', '.join(valid_regions)}")
            return
        
        print(f"[*] Setting device region to: {region}")
        
        if not force:
            print(f"[!] Region change may affect radio compliance and features.")
            response = input("    Continue? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
        
        try:
            region_payload = struct.pack("<B", 0x60)  # REGION command
            region_payload += b"SET" + b'\x00' * 13
            region_payload += region.encode('ascii').ljust(8, b'\x00')
            
            resp = qslcl_dispatch(dev, "ODM", region_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    print(f"[+] Region set to {region} successfully")
                else:
                    print(f"[!] Region setting failed: {status}")
            else:
                print("[!] No response from device")
                
        except Exception as e:
            print(f"[!] Region setting error: {e}")
    else:
        print("[!] Invalid region operation")

def odm_security(dev, args, force=False, verbose=False):
    """Manage ODM security settings"""
    if not args:
        print("[!] Specify security operation")
        print("[*] Available: enable, disable, lockdown, unlock, status")
        return
    
    operation = args[0].lower()
    
    # Validate operation
    valid_operations = ["enable", "disable", "lockdown", "unlock", "status"]
    if operation not in valid_operations:
        print(f"[!] Invalid security operation: {operation}")
        print(f"[*] Valid operations: {', '.join(valid_operations)}")
        return
    
    print(f"[*] ODM security operation: {operation}")
    
    if operation in ["lockdown", "enable"] and not force:
        print("[!] Security lockdown restricts device access.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        security_payload = struct.pack("<B", 0x70)  # SECURITY command
        security_payload += operation.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "ODM", security_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Security {operation} completed")
            else:
                print(f"[!] Security operation failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Security operation error: {e}")

def odm_firmware(dev, args, force=False, verbose=False):
    """Manage ODM-specific firmware"""
    if not args:
        print("[!] Specify firmware operation")
        print("[*] Available: info, update <file>, backup, restore")
        return
    
    operation = args[0].lower()
    
    if operation == "info":
        print("[*] Querying ODM firmware information...")
        try:
            # Query firmware info
            fw_payload = struct.pack("<B", 0x75)  # FIRMWARE_INFO command
            resp = qslcl_dispatch(dev, "ODM", fw_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    fw_data = status["extra"]
                    if len(fw_data) >= 64:
                        version = fw_data[0:16].decode('ascii', errors='ignore').strip('\x00')
                        build = fw_data[16:32].decode('ascii', errors='ignore').strip('\x00')
                        date = fw_data[32:48].decode('ascii', errors='ignore').strip('\x00')
                        custom = fw_data[48:64].decode('ascii', errors='ignore').strip('\x00')
                        
                        print(f"\n[+] ODM Firmware:")
                        print(f"    Version: {version}")
                        print(f"    Build: {build}")
                        print(f"    Date: {date}")
                        print(f"    Customizations: {custom}")
                    else:
                        print("[!] Invalid firmware info response")
                else:
                    print(f"[!] Failed to get firmware info: {status}")
            else:
                print("[!] No response from device")
        except Exception as e:
            print(f"[!] Firmware info error: {e}")
        
    elif operation == "update" and len(args) > 1:
        firmware_file = args[1]
        print(f"[*] Updating ODM firmware from: {firmware_file}")
        
        if not os.path.exists(firmware_file):
            print(f"[!] Firmware file not found: {firmware_file}")
            return
        
        if not force:
            print("[!] Firmware update may brick the device if interrupted.")
            print("[!] Ensure stable power connection before continuing.")
            response = input("    Continue? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                print("[*] Operation cancelled")
                return
        
        try:
            # Read firmware file
            with open(firmware_file, 'rb') as f:
                firmware_data = f.read()
            
            print(f"[*] Firmware size: {len(firmware_data)} bytes")
            
            # Start firmware update
            update_payload = struct.pack("<B", 0x76)  # FIRMWARE_UPDATE command
            update_payload += struct.pack("<I", len(firmware_data))
            
            print("[*] Sending firmware update command...")
            resp = qslcl_dispatch(dev, "ODM", update_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    print("[+] Firmware update initialized")
                    print("[*] Sending firmware data...")
                    
                    # TODO: Implement chunked transfer for large firmware
                    # This is a simplified implementation
                    data_payload = struct.pack("<B", 0x77)  # FIRMWARE_DATA command
                    data_payload += firmware_data
                    
                    resp2 = qslcl_dispatch(dev, "ODM", data_payload)
                    
                    if resp2:
                        status2 = decode_runtime_result(resp2)
                        if status2["severity"] == "SUCCESS":
                            print("[+] ODM firmware update completed")
                            print("[*] Device may restart automatically")
                        else:
                            print(f"[!] Firmware data transfer failed: {status2}")
                    else:
                        print("[!] No response during data transfer")
                else:
                    print(f"[!] Firmware update initialization failed: {status}")
            else:
                print("[!] No response from device")
                
        except Exception as e:
            print(f"[!] Firmware update error: {e}")
    
    elif operation in ["backup", "restore"]:
        print(f"[!] {operation.capitalize()} operation not fully implemented")
        print("[*] This feature requires additional storage and security setup")
        
    else:
        print("[!] Invalid firmware operation")

def odm_manufacturing(dev, args, force=False, verbose=False):
    """Access manufacturing modes and tools"""
    print("[*] Entering manufacturing mode...")
    
    if not force:
        print("[!] Manufacturing mode provides low-level device access.")
        print("[!] This may void warranties and bypass security features.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        mfg_payload = struct.pack("<B", 0x80)  # MANUFACTURING command
        mfg_payload += b"ENTER"
        mfg_payload += b'\x00' * 11  # Padding
        
        resp = qslcl_dispatch(dev, "ODM", mfg_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Manufacturing mode activated")
                print("[*] Available manufacturing commands enabled")
                
                # Display available manufacturing commands
                mfg_commands = [
                    "RAW_FLASH_ACCESS",
                    "HARDWARE_TEST_MODE", 
                    "CALIBRATION_DATA_RW",
                    "SECURE_ELEMENT_ACCESS",
                    "PRODUCTION_KEY_MGMT"
                ]
                print("\n[+] Manufacturing Commands Available:")
                for cmd in mfg_commands:
                    print(f"    • {cmd}")
                    
            else:
                print(f"[!] Manufacturing mode failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Manufacturing mode error: {e}")

def odm_supplychain(dev, args, verbose=False):
    """Manage supply chain information"""
    print("[*] Querying supply chain information...")
    
    try:
        sc_payload = struct.pack("<B", 0x85)  # SUPPLYCHAIN_INFO command
        resp = qslcl_dispatch(dev, "ODM", sc_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                sc_data = status["extra"]
                if len(sc_data) >= 128:
                    factory = sc_data[0:32].decode('ascii', errors='ignore').strip('\x00')
                    line = sc_data[32:48].decode('ascii', errors='ignore').strip('\x00')
                    order = sc_data[48:64].decode('ascii', errors='ignore').strip('\x00')
                    batch = sc_data[64:80].decode('ascii', errors='ignore').strip('\x00')
                    qc = sc_data[80:96].decode('ascii', errors='ignore').strip('\x00')
                    ship = sc_data[96:112].decode('ascii', errors='ignore').strip('\x00')
                    dest = sc_data[112:128].decode('ascii', errors='ignore').strip('\x00')
                    
                    print(f"\n[+] Supply Chain Information:")
                    print(f"    Factory: {factory}")
                    print(f"    Production Line: {line}")
                    print(f"    Work Order: {order}")
                    print(f"    Batch: {batch}")
                    print(f"    QC Status: {qc}")
                    print(f"    Ship Date: {ship}")
                    print(f"    Destination: {dest}")
                else:
                    # Fallback to simulated data
                    sc_info = query_supplychain_info(dev)
                    print(f"\n[+] Supply Chain Information:")
                    print(f"    Factory: {sc_info.get('factory', 'Unknown')}")
                    print(f"    Production Line: {sc_info.get('production_line', 'Unknown')}")
                    print(f"    Work Order: {sc_info.get('work_order', 'Unknown')}")
                    print(f"    Batch: {sc_info.get('batch', 'Unknown')}")
                    print(f"    QC Status: {sc_info.get('qc_status', 'Unknown')}")
                    print(f"    Ship Date: {sc_info.get('ship_date', 'Unknown')}")
                    print(f"    Destination: {sc_info.get('destination', 'Unknown')}")
            else:
                print(f"[!] Failed to get supply chain info: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] Supply chain query error: {e}")

def odm_unlock(dev, args, force=False, verbose=False):
    """Unlock ODM development features"""
    print("[*] Unlocking ODM development features...")
    
    if not force:
        print("[!] This enables advanced ODM development tools.")
        print("[!] Some features may bypass normal security restrictions.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        unlock_payload = struct.pack("<B", 0x90)  # UNLOCK command
        unlock_payload += b"ODM_DEV"
        unlock_payload += b'\x00' * 9  # Padding
        
        # Add unlock code if provided
        if args:
            unlock_code = args[0]
            unlock_payload += unlock_code.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "ODM", unlock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] ODM development features unlocked")
                print("[*] Advanced manufacturing tools available")
                
                unlocked_features = [
                    "DEBUG_ACCESS",
                    "RAW_MEMORY_ACCESS",
                    "SECURE_BOOT_BYPASS",
                    "TEST_POINT_ACCESS",
                    "CALIBRATION_OVERRIDE"
                ]
                print("\n[+] Unlocked Features:")
                for feature in unlocked_features:
                    print(f"    • {feature}")
                    
            else:
                print(f"[!] ODM unlock failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] ODM unlock error: {e}")

def odm_lock(dev, args, verbose=False):
    """Lock ODM features and return to production state"""
    print("[*] Locking ODM features...")
    
    try:
        lock_payload = struct.pack("<B", 0xA0)  # LOCK command
        lock_payload += b"PRODUCTION"
        lock_payload += b'\x00' * 6  # Padding
        
        resp = qslcl_dispatch(dev, "ODM", lock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] ODM features locked")
                print("[*] Device returned to production state")
            else:
                print(f"[!] ODM lock failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] ODM lock error: {e}")

def odm_reset(dev, args, force=False, verbose=False):
    """Reset ODM customizations to factory defaults"""
    print("[*] Resetting ODM customizations...")
    
    if not force:
        print("[!] This will remove all ODM customizations and branding.")
        print("[!] Device will return to generic state.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        reset_payload = struct.pack("<B", 0xB0)  # RESET command
        reset_payload += b"FACTORY"
        reset_payload += b'\x00' * 9  # Padding
        
        resp = qslcl_dispatch(dev, "ODM", reset_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] ODM customizations reset to factory defaults")
                
                # List what was reset
                reset_items = [
                    "Branding and logos",
                    "Custom boot animations",
                    "System sounds",
                    "UI themes",
                    "Regional settings",
                    "Manufacturing flags"
                ]
                print("\n[+] Reset Items:")
                for item in reset_items:
                    print(f"    • {item}")
                    
            else:
                print(f"[!] ODM reset failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] ODM reset error: {e}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR ODM COMMAND
# =============================================================================

def query_odm_info(dev, verbose=False):
    """Query ODM-specific device information"""
    # Default/fallback info
    info = {
        'manufacturer': 'Example ODM Inc.',
        'model': 'EX-ODM-2024',
        'sku': 'EXODM2024G256',
        'serial': 'ODM24X0001',
        'hw_revision': 'Rev 1.2',
        'production_date': '2024-Q1',
        'region': 'GLOBAL',
        'carrier': 'Multi-carrier',
        'features': [
            {'name': 'CUSTOM_BOOTANIMATION', 'enabled': True, 'description': 'Custom boot animation'},
            {'name': 'BRANDED_SOUNDS', 'enabled': True, 'description': 'Branded system sounds'},
            {'name': 'CUSTOM_THEME', 'enabled': False, 'description': 'Custom UI theme'},
            {'name': 'EXTENDED_DIAGNOSTICS', 'enabled': True, 'description': 'Enhanced diagnostics'},
        ],
        'customizations': [
            {'type': 'Boot Logo', 'value': 'ODM_2024'},
            {'type': 'Color Scheme', 'value': 'Blue Accent'},
            {'type': 'Default Wallpaper', 'value': 'ODM_Sunrise'},
        ]
    }
    
    try:
        # Try to query actual ODM info from device
        info_payload = struct.pack("<B", 0x01)  # INFO query
        
        # Check if ODM command is available in QSLCLPAR
        if "ODM" in QSLCLPAR_DB or 0x01 in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "ODM", info_payload)
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    # Parse ODM info from response data
                    data = status["extra"]
                    if len(data) >= 128:
                        # Parse structured ODM info response
                        manufacturer = data[0:32].decode('ascii', errors='ignore').strip('\x00')
                        model = data[32:64].decode('ascii', errors='ignore').strip('\x00')
                        sku = data[64:80].decode('ascii', errors='ignore').strip('\x00')
                        serial = data[80:96].decode('ascii', errors='ignore').strip('\x00')
                        hw_rev = data[96:112].decode('ascii', errors='ignore').strip('\x00')
                        prod_date = data[112:128].decode('ascii', errors='ignore').strip('\x00')
                        
                        # Update info with real data
                        if manufacturer:
                            info['manufacturer'] = manufacturer
                        if model:
                            info['model'] = model
                        if sku:
                            info['sku'] = sku
                        if serial:
                            info['serial'] = serial
                        if hw_rev:
                            info['hw_revision'] = hw_rev
                        if prod_date:
                            info['production_date'] = prod_date
                            
    except Exception as e:
        if verbose:
            print(f"[*] Could not query ODM info: {e}")
        # Use default info on error
    
    return info

def query_odm_firmware_info(dev):
    """Query ODM firmware information"""
    # Default/fallback firmware info
    return {
        'version': 'ODM-1.2.3',
        'build': 'ODM20240315',
        'date': '2024-03-15',
        'customizations': 'Branding, Sounds, Boot Animation'
    }

def query_supplychain_info(dev):
    """Query supply chain information"""
    # Default/fallback supply chain info
    return {
        'factory': 'Factory A, Shenzhen',
        'production_line': 'Line 5',
        'work_order': 'WO-2024-0320',
        'batch': 'BATCH-24Q1-001',
        'qc_status': 'PASSED',
        'ship_date': '2024-03-25',
        'destination': 'Distribution Center EU'
    }

def print_odm_help():
    """Display ODM command help"""
    print("""
ODM Command Usage:
  odm info                    - Show ODM device information
  odm provision               - Provision device for manufacturing
  odm customize <type> <value>- Apply ODM customizations
  odm test [type]             - Run manufacturing tests
  odm calibrate <hardware>    - Calibrate hardware components
  odm feature <name> [action] - Manage ODM features
  odm region <operation>      - Configure regional settings
  odm security <operation>    - Manage security settings
  odm firmware <operation>    - Manage ODM firmware
  odm manufacturing           - Enter manufacturing mode
  odm supplychain             - Show supply chain information
  odm unlock                  - Unlock ODM development features
  odm lock                    - Lock ODM features
  odm reset                   - Reset ODM customizations

Customization Types:
  branding      - Apply brand logos and names
  bootlogo      - Custom boot logo (file path)
  bootanimation - Custom boot animation (file path)
  sounds        - System sounds and ringtones
  themes        - UI themes and color schemes

Test Types:
  QUICK     - Basic functionality tests (~4 seconds)
  FULL      - Comprehensive manufacturing tests (~12 seconds)
  EXTENDED  - Extended reliability testing (~32 seconds)

Hardware Calibration:
  display   - Screen color and brightness
  touch     - Touch screen accuracy
  audio     - Speaker and microphone calibration
  sensors   - Accelerometer, gyro, etc.
  camera    - Camera focus and color calibration
  battery   - Battery calibration

Security Operations:
  enable    - Enable security features
  disable   - Disable security features
  lockdown  - Full security lockdown
  unlock    - Remove security restrictions
  status    - Show security status

Examples:
  qslcl odm info                    # Show ODM information
  qslcl odm customize branding "ACME"  # Apply branding
  qslcl odm test FULL               # Run full test suite
  qslcl odm calibrate display       # Calibrate display
  qslcl odm region set EU           # Set European region
  qslcl odm manufacturing --force   # Enter manufacturing mode

Options:
  --verbose, -v    - Enable verbose output
  --force          - Bypass confirmation prompts

Notes:
  - ODM commands are for authorized manufacturers only
  - Some operations may void warranties
  - Always backup before firmware updates
  - Use --force to bypass confirmation prompts
  - Manufacturing mode provides low-level device access
    """)

# =============================================================================
# ODM-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================
def add_odm_arguments(parser):
    """Add ODM-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Force operation without confirmation")
    return parser