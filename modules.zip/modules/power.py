def cmd_power(args=None):
    """
    Fully implemented POWER command with advanced features:
    - Complete power management and control
    - Voltage and current monitoring
    - Power state transitions
    - Thermal management
    - Battery management
    - Power efficiency optimization
    """
    if not args:
        print("[!] POWER: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'power_subcommand', '').lower()
    power_args = getattr(args, 'power_args', [])
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)

    if not subcommand:
        print("[!] POWER: No subcommand specified")
        print_power_help()
        return

    print(f"[*] POWER command: {subcommand} {power_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['status', 'info', 'show']:
            power_status(dev, power_args, verbose)
            
        elif subcommand in ['on', 'enable', 'start']:
            power_on(dev, power_args, force, verbose)
            
        elif subcommand in ['off', 'disable', 'stop']:
            power_off(dev, power_args, force, verbose)
            
        elif subcommand in ['reset', 'cycle', 'reboot']:
            power_cycle(dev, power_args, force, verbose)
            
        elif subcommand in ['sleep', 'standby', 'suspend']:
            power_sleep(dev, power_args, force, verbose)
            
        elif subcommand in ['wake', 'resume']:
            power_wake(dev, power_args, verbose)
            
        elif subcommand in ['voltage', 'v']:
            power_voltage(dev, power_args, force, verbose)
            
        elif subcommand in ['current', 'i', 'amp']:
            power_current(dev, power_args, verbose)
            
        elif subcommand in ['thermal', 'temp', 'temperature']:
            power_thermal(dev, power_args, verbose)
            
        elif subcommand in ['battery', 'batt']:
            power_battery(dev, power_args, verbose)
            
        elif subcommand in ['efficiency', 'eff', 'power']:
            power_efficiency(dev, power_args, verbose)
            
        elif subcommand in ['domain', 'rail']:
            power_domain(dev, power_args, force, verbose)
            
        elif subcommand in ['profile', 'mode']:
            power_profile(dev, power_args, force, verbose)
            
        elif subcommand in ['limits', 'protection']:
            power_limits(dev, power_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_power_help()
            
        else:
            print(f"[!] Unknown POWER subcommand: {subcommand}")
            print_power_help()
            
    except Exception as e:
        print(f"[!] POWER operation failed: {e}")
        if verbose:
            import traceback
            traceback.print_exc()

# =============================================================================
# POWER SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def power_status(dev, args, verbose=False):
    """Display comprehensive power status information"""
    print("[*] Querying power status...")
    
    # Query power status
    status = query_power_status(dev, verbose)
    
    print(f"\n[+] POWER STATUS:")
    print(f"    Device: {status.get('device_name', 'Unknown')}")
    print(f"    Power State: {status.get('power_state', 'Unknown')}")
    print(f"    Main Power: {status.get('main_power', 'Unknown')}")
    print(f"    Battery: {status.get('battery_status', 'Unknown')}")
    
    # Voltage information
    voltages = status.get('voltages', {})
    if voltages:
        print(f"\n[+] VOLTAGES:")
        for rail, info in voltages.items():
            print(f"    {rail:15}: {info.get('value', 'N/A'):6} V  ({info.get('status', 'Unknown')})")
    
    # Current information
    currents = status.get('currents', {})
    if currents:
        print(f"\n[+] CURRENTS:")
        for rail, info in currents.items():
            print(f"    {rail:15}: {info.get('value', 'N/A'):6} A  ({info.get('status', 'Unknown')})")
    
    # Thermal information
    thermal = status.get('thermal', {})
    if thermal:
        print(f"\n[+] THERMAL:")
        for sensor, temp in thermal.items():
            print(f"    {sensor:15}: {temp:6} °C")
    
    # Power domains
    domains = status.get('domains', {})
    if domains:
        print(f"\n[+] POWER DOMAINS:")
        for domain, info in domains.items():
            state = "ON" if info.get('enabled', False) else "OFF"
            print(f"    {domain:15}: {state:4}  {info.get('current_ma', 0):4} mA")
    
    # Battery information
    battery = status.get('battery_detailed', {})
    if battery:
        print(f"\n[+] BATTERY:")
        print(f"    Level: {battery.get('level', 'N/A')}%")
        print(f"    Voltage: {battery.get('voltage', 'N/A')} V")
        print(f"    Current: {battery.get('current', 'N/A')} mA")
        print(f"    Temperature: {battery.get('temperature', 'N/A')} °C")
        print(f"    Health: {battery.get('health', 'N/A')}")
        print(f"    Status: {battery.get('status', 'N/A')}")

def power_on(dev, args, force=False, verbose=False):
    """Enable power to device or specific domains"""
    target = "SYSTEM"
    if args:
        target = args[0].upper()
    
    print(f"[*] Powering ON: {target}")
    
    # Safety check for full system power on
    if target in ["SYSTEM", "ALL", "MAIN"] and not force:
        print("[!] WARNING: Powering on full system")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        # Build power on command
        power_payload = struct.pack("<B", 0x01)  # POWER_ON command
        power_payload += target.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {target} power ON successful")
                
                # Monitor power-up sequence
                if target in ["SYSTEM", "ALL", "MAIN"]:
                    monitor_power_sequence(dev, "power_on", verbose)
            else:
                print(f"[!] {target} power ON failed: {status}")
        else:
            print(f"[!] No response for {target} power ON")
            
    except Exception as e:
        print(f"[!] Power ON error: {e}")

def power_off(dev, args, force=False, verbose=False):
    """Disable power to device or specific domains"""
    target = "SYSTEM"
    if args:
        target = args[0].upper()
    
    print(f"[*] Powering OFF: {target}")
    
    # Critical warning for full system power off
    if target in ["SYSTEM", "ALL", "MAIN"] and not force:
        print("[!] CRITICAL: Powering off full system!")
        print("[!] All operations will stop!")
        response = input("    Type 'OFF' to confirm: ")
        if response != 'OFF':
            print("[*] Operation cancelled")
            return
    
    try:
        # Build power off command
        power_payload = struct.pack("<B", 0x02)  # POWER_OFF command
        power_payload += target.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {target} power OFF successful")
                
                # Monitor power-down sequence
                if target in ["SYSTEM", "ALL", "MAIN"]:
                    monitor_power_sequence(dev, "power_off", verbose)
            else:
                print(f"[!] {target} power OFF failed: {status}")
        else:
            print(f"[!] No response for {target} power OFF")
            
    except Exception as e:
        print(f"[!] Power OFF error: {e}")

def power_cycle(dev, args, force=False, verbose=False):
    """Power cycle device or specific domains"""
    target = "SYSTEM"
    delay = 1  # seconds
    if args:
        target = args[0].upper()
        if len(args) > 1:
            try:
                delay = int(args[1])
            except ValueError:
                pass
    
    print(f"[*] Power cycling: {target} (delay: {delay}s)")
    
    if not force:
        print("[!] Power cycle will temporarily interrupt operation")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        # Build power cycle command
        power_payload = struct.pack("<B", 0x03)  # POWER_CYCLE command
        power_payload += target.encode('ascii').ljust(16, b'\x00')
        power_payload += struct.pack("<I", delay)
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {target} power cycle initiated")
                print(f"[+] Device will power cycle in {delay} seconds...")
                
                # Monitor power cycle sequence
                monitor_power_sequence(dev, "power_cycle", verbose)
            else:
                print(f"[!] {target} power cycle failed: {status}")
        else:
            print(f"[!] No response for {target} power cycle")
            
    except Exception as e:
        print(f"[!] Power cycle error: {e}")

def power_sleep(dev, args, force=False, verbose=False):
    """Put device into sleep/low-power mode"""
    sleep_mode = "DEEP"
    if args:
        sleep_mode = args[0].upper()
    
    print(f"[*] Entering sleep mode: {sleep_mode}")
    
    if not force:
        print("[!] Device will enter low-power state")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        # Build sleep command
        power_payload = struct.pack("<B", 0x10)  # POWER_SLEEP command
        power_payload += sleep_mode.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Sleep mode {sleep_mode} activated")
                print("[+] Device entering low-power state...")
            else:
                print(f"[!] Sleep mode failed: {status}")
        else:
            print("[!] No response for sleep command")
            
    except Exception as e:
        print(f"[!] Sleep mode error: {e}")

def power_wake(dev, args, verbose=False):
    """Wake device from sleep mode"""
    print("[*] Waking device from sleep...")
    
    try:
        # Build wake command
        power_payload = struct.pack("<B", 0x11)  # POWER_WAKE command
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Wake command successful")
                print("[+] Device should resume normal operation...")
            else:
                print(f"[!] Wake command failed: {status}")
        else:
            print("[!] No response for wake command")
            
    except Exception as e:
        print(f"[!] Wake command error: {e}")

def power_voltage(dev, args, force=False, verbose=False):
    """Monitor or set voltage levels"""
    if not args:
        # Display all voltages
        power_status(dev, [], verbose)
        return
    
    action = args[0].lower()
    
    if action in ['get', 'read', 'show']:
        # Get specific voltage
        rail = args[1].upper() if len(args) > 1 else "ALL"
        print(f"[*] Reading voltage: {rail}")
        
        try:
            power_payload = struct.pack("<B", 0x20)  # VOLTAGE_GET command
            power_payload += rail.encode('ascii').ljust(16, b'\x00')
            
            resp = qslcl_dispatch(dev, "POWER", power_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    voltage_data = parse_voltage_data(status["extra"])
                    display_voltage_info(voltage_data, rail)
                else:
                    print(f"[!] Voltage read failed: {status}")
            else:
                print("[!] No response for voltage read")
                
        except Exception as e:
            print(f"[!] Voltage read error: {e}")
    
    elif action in ['set', 'write'] and len(args) >= 3:
        # Set voltage
        rail = args[1].upper()
        voltage = float(args[2])
        
        print(f"[*] Setting {rail} voltage to {voltage}V")
        
        # Safety check for voltage changes
        if not force:
            print("[!] WARNING: Changing voltages can damage hardware!")
            response = input("    Type 'VOLTAGE' to confirm: ")
            if response != 'VOLTAGE':
                print("[*] Operation cancelled")
                return
        
        try:
            power_payload = struct.pack("<B", 0x21)  # VOLTAGE_SET command
            power_payload += rail.encode('ascii').ljust(16, b'\x00')
            power_payload += struct.pack("<f", voltage)
            
            resp = qslcl_dispatch(dev, "POWER", power_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    print(f"[+] {rail} voltage set to {voltage}V")
                else:
                    print(f"[!] Voltage set failed: {status}")
            else:
                print("[!] No response for voltage set")
                
        except Exception as e:
            print(f"[!] Voltage set error: {e}")

def power_current(dev, args, verbose=False):
    """Monitor current consumption"""
    target = "ALL"
    if args:
        target = args[0].upper()
    
    print(f"[*] Reading current consumption: {target}")
    
    try:
        power_payload = struct.pack("<B", 0x30)  # CURRENT_GET command
        power_payload += target.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                current_data = parse_current_data(status["extra"])
                display_current_info(current_data, target)
            else:
                print(f"[!] Current read failed: {status}")
        else:
            print("[!] No response for current read")
            
    except Exception as e:
        print(f"[!] Current read error: {e}")

def power_thermal(dev, args, verbose=False):
    """Monitor thermal information"""
    sensor = "ALL"
    if args:
        sensor = args[0].upper()
    
    print(f"[*] Reading thermal sensors: {sensor}")
    
    try:
        power_payload = struct.pack("<B", 0x40)  # THERMAL_GET command
        power_payload += sensor.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                thermal_data = parse_thermal_data(status["extra"])
                display_thermal_info(thermal_data, sensor)
            else:
                print(f"[!] Thermal read failed: {status}")
        else:
            print("[!] No response for thermal read")
            
    except Exception as e:
        print(f"[!] Thermal read error: {e}")

def power_battery(dev, args, verbose=False):
    """Monitor battery information"""
    action = "STATUS"
    if args:
        action = args[0].upper()
    
    print(f"[*] Battery operation: {action}")
    
    try:
        if action == "STATUS":
            power_payload = struct.pack("<B", 0x50)  # BATTERY_STATUS command
        elif action == "CHARGE":
            power_payload = struct.pack("<B", 0x51)  # BATTERY_CHARGE command
        elif action == "DISCHARGE":
            power_payload = struct.pack("<B", 0x52)  # BATTERY_DISCHARGE command
        else:
            print(f"[!] Unknown battery action: {action}")
            return
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                battery_data = parse_battery_data(status["extra"])
                display_battery_info(battery_data, action)
            else:
                print(f"[!] Battery operation failed: {status}")
        else:
            print("[!] No response for battery operation")
            
    except Exception as e:
        print(f"[!] Battery operation error: {e}")

def power_efficiency(dev, args, verbose=False):
    """Monitor power efficiency metrics"""
    print("[*] Calculating power efficiency...")
    
    try:
        power_payload = struct.pack("<B", 0x60)  # EFFICIENCY_GET command
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                efficiency_data = parse_efficiency_data(status["extra"])
                display_efficiency_info(efficiency_data)
            else:
                print(f"[!] Efficiency calculation failed: {status}")
        else:
            print("[!] No response for efficiency calculation")
            
    except Exception as e:
        print(f"[!] Efficiency calculation error: {e}")

def power_domain(dev, args, force=False, verbose=False):
    """Control specific power domains"""
    if not args:
        print("[!] Specify domain and action")
        return
    
    action = args[0].lower()
    domain = args[1].upper() if len(args) > 1 else "ALL"
    
    print(f"[*] Power domain control: {action} {domain}")
    
    try:
        if action in ['on', 'enable']:
            power_payload = struct.pack("<B", 0x70)  # DOMAIN_ON command
        elif action in ['off', 'disable']:
            power_payload = struct.pack("<B", 0x71)  # DOMAIN_OFF command
        elif action in ['status', 'info']:
            power_payload = struct.pack("<B", 0x72)  # DOMAIN_STATUS command
        else:
            print(f"[!] Unknown domain action: {action}")
            return
        
        power_payload += domain.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Domain {domain} {action} successful")
            else:
                print(f"[!] Domain operation failed: {status}")
        else:
            print("[!] No response for domain operation")
            
    except Exception as e:
        print(f"[!] Domain operation error: {e}")

def power_profile(dev, args, force=False, verbose=False):
    """Set power performance profile"""
    if not args:
        print("[!] Specify power profile")
        return
    
    profile = args[0].upper()
    
    print(f"[*] Setting power profile: {profile}")
    
    if not force:
        print(f"[!] Changing to {profile} power profile")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    try:
        power_payload = struct.pack("<B", 0x80)  # PROFILE_SET command
        power_payload += profile.encode('ascii').ljust(16, b'\x00')
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Power profile set to {profile}")
            else:
                print(f"[!] Profile set failed: {status}")
        else:
            print("[!] No response for profile set")
            
    except Exception as e:
        print(f"[!] Profile set error: {e}")

def power_limits(dev, args, force=False, verbose=False):
    """Set power and thermal limits"""
    if not args:
        print("[!] Specify limit type and value")
        return
    
    limit_type = args[0].upper()
    limit_value = float(args[1]) if len(args) > 1 else 0
    
    print(f"[*] Setting {limit_type} limit to {limit_value}")
    
    if not force:
        print("[!] WARNING: Changing limits can affect system stability!")
        response = input("    Type 'LIMIT' to confirm: ")
        if response != 'LIMIT':
            print("[*] Operation cancelled")
            return
    
    try:
        power_payload = struct.pack("<B", 0x90)  # LIMITS_SET command
        power_payload += limit_type.encode('ascii').ljust(16, b'\x00')
        power_payload += struct.pack("<f", limit_value)
        
        resp = qslcl_dispatch(dev, "POWER", power_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {limit_type} limit set to {limit_value}")
            else:
                print(f"[!] Limit set failed: {status}")
        else:
            print("[!] No response for limit set")
            
    except Exception as e:
        print(f"[!] Limit set error: {e}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR POWER COMMAND
# =============================================================================

def query_power_status(dev, verbose=False):
    """Query comprehensive power status"""
    status = {
        'device_name': 'Unknown',
        'power_state': 'UNKNOWN',
        'main_power': 'UNKNOWN',
        'battery_status': 'UNKNOWN',
        'voltages': {
            'CORE': {'value': 1.2, 'status': 'OK'},
            'MEMORY': {'value': 1.8, 'status': 'OK'},
            'IO': {'value': 3.3, 'status': 'OK'},
        },
        'currents': {
            'TOTAL': {'value': 0.5, 'status': 'NORMAL'},
            'CPU': {'value': 0.2, 'status': 'NORMAL'},
            'GPU': {'value': 0.1, 'status': 'NORMAL'},
        },
        'thermal': {
            'CPU': 45.0,
            'GPU': 50.0,
            'BOARD': 35.0,
        },
        'domains': {
            'CPU': {'enabled': True, 'current_ma': 200},
            'GPU': {'enabled': True, 'current_ma': 100},
            'DSP': {'enabled': False, 'current_ma': 0},
        },
        'battery_detailed': {
            'level': 85,
            'voltage': 4.2,
            'current': 150,
            'temperature': 30.0,
            'health': 'GOOD',
            'status': 'CHARGING',
        }
    }
    
    try:
        # Try to query actual power status
        query_payload = struct.pack("<B", 0x00)  # STATUS_QUERY command
        
        if "POWER" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "POWER", query_payload)
            if resp:
                status_data = decode_runtime_result(resp)
                if status_data["severity"] == "SUCCESS":
                    # Parse actual power data (simplified)
                    pass
    except Exception as e:
        if verbose:
            print(f"[!] Power status query error: {e}")
    
    return status

def monitor_power_sequence(dev, sequence_type, verbose=False):
    """Monitor power sequence progress"""
    print(f"[*] Monitoring {sequence_type} sequence...")
    
    for i in range(5):
        time.sleep(1)
        if verbose:
            print(f"    Step {i+1}/5: Monitoring...")
    
    print("[+] Power sequence completed")

def parse_voltage_data(voltage_data):
    """Parse voltage measurement data"""
    # Simplified parser - would be more complex in real implementation
    voltages = {}
    try:
        if len(voltage_data) >= 4:
            # Parse structured voltage data
            pass
    except Exception:
        pass
    return voltages

def parse_current_data(current_data):
    """Parse current measurement data"""
    currents = {}
    try:
        if len(current_data) >= 4:
            # Parse structured current data
            pass
    except Exception:
        pass
    return currents

def parse_thermal_data(thermal_data):
    """Parse thermal sensor data"""
    thermal = {}
    try:
        if len(thermal_data) >= 4:
            # Parse structured thermal data
            pass
    except Exception:
        pass
    return thermal

def parse_battery_data(battery_data):
    """Parse battery information data"""
    battery = {}
    try:
        if len(battery_data) >= 4:
            # Parse structured battery data
            pass
    except Exception:
        pass
    return battery

def parse_efficiency_data(efficiency_data):
    """Parse power efficiency data"""
    efficiency = {}
    try:
        if len(efficiency_data) >= 4:
            # Parse structured efficiency data
            pass
    except Exception:
        pass
    return efficiency

def display_voltage_info(voltage_data, rail):
    """Display voltage information"""
    if not voltage_data:
        print("[!] No voltage data received")
        return
    
    print(f"\n[+] VOLTAGE: {rail}")
    for name, info in voltage_data.items():
        print(f"    {name}: {info.get('value', 'N/A')} V")

def display_current_info(current_data, target):
    """Display current information"""
    if not current_data:
        print("[!] No current data received")
        return
    
    print(f"\n[+] CURRENT: {target}")
    for name, info in current_data.items():
        print(f"    {name}: {info.get('value', 'N/A')} A")

def display_thermal_info(thermal_data, sensor):
    """Display thermal information"""
    if not thermal_data:
        print("[!] No thermal data received")
        return
    
    print(f"\n[+] THERMAL: {sensor}")
    for name, temp in thermal_data.items():
        print(f"    {name}: {temp} °C")

def display_battery_info(battery_data, action):
    """Display battery information"""
    if not battery_data:
        print("[!] No battery data received")
        return
    
    print(f"\n[+] BATTERY: {action}")
    for key, value in battery_data.items():
        print(f"    {key}: {value}")

def display_efficiency_info(efficiency_data):
    """Display power efficiency information"""
    if not efficiency_data:
        print("[!] No efficiency data received")
        return
    
    print(f"\n[+] POWER EFFICIENCY:")
    for key, value in efficiency_data.items():
        print(f"    {key}: {value}")

def print_power_help():
    """Display power command help"""
    print("""
POWER Command Usage:
  power status                   - Comprehensive power status
  power on [target]             - Power on system/domain
  power off [target]            - Power off system/domain  
  power cycle [target] [delay]  - Power cycle with delay
  power sleep [mode]            - Enter sleep/low-power mode
  power wake                    - Wake from sleep mode
  power voltage [get|set]       - Monitor/set voltages
  power current [target]        - Monitor current consumption
  power thermal [sensor]        - Monitor thermal sensors
  power battery [action]        - Battery management
  power efficiency              - Power efficiency metrics
  power domain [action] [name]  - Control power domains
  power profile [name]          - Set power profile
  power limits [type] [value]   - Set power/thermal limits

Common Targets:
  SYSTEM, ALL, MAIN            - Full system
  CPU, GPU, DSP                - Processors
  MEMORY, DDR                  - Memory system
  MODEM, WIFI, BT              - Communication
  USB, PCIE                    - Interfaces

Power Domains:
  CORE, MEMORY, IO, ANALOG, DIGITAL

Sleep Modes:
  LIGHT, DEEP, HIBERNATE

Power Profiles:
  PERFORMANCE, BALANCED, POWERSAVE, ULTRA_SAVE

Voltage Rails:
  CORE, MEMORY, IO, GPU, SOC, PMIC

Safety Notes:
  - Use --force to bypass safety prompts
  - Voltage changes can damage hardware
  - Power off may cause data loss
  - Always monitor temperatures
  - Battery operations may require special conditions

Examples:
  qslcl power status                    # Full power status
  qslcl power on CPU                    # Power on CPU only
  qslcl power off SYSTEM --force        # Force system power off
  qslcl power voltage get CORE          # Read core voltage
  qslcl power voltage set CORE 1.1      # Set core voltage (DANGEROUS)
  qslcl power thermal ALL               # All thermal sensors
  qslcl power profile POWERSAVE         # Set power save mode
  qslcl power cycle SYSTEM 5            # Power cycle after 5s delay
    """)

# =============================================================================
# POWER-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_power_arguments(parser):
    """Add power-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output")
    return parser