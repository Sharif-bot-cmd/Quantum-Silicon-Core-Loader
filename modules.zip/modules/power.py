def cmd_power(args):
    """
    Advanced POWER command handler for complete power management and control
    Supports power states, domains, sequencing, and advanced power features
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse POWER subcommand
    if not hasattr(args, 'power_subcommand') or not args.power_subcommand:
        return print("[!] POWER command requires subcommand (list, status, on, off, reset, domains, etc.)")
    
    subcmd = args.power_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_power_commands(dev)
    elif subcmd == "STATUS":
        return get_power_status(dev)
    elif subcmd == "ON":
        return power_on_domain(dev, args)
    elif subcmd == "OFF":
        return power_off_domain(dev, args)
    elif subcmd == "RESET":
        return power_reset_domain(dev, args)
    elif subcmd == "DOMAINS":
        return list_power_domains_detailed(dev)
    elif subcmd == "SEQUENCE":
        return control_power_sequence(dev, args)
    elif subcmd == "PROFILE":
        return manage_power_profiles(dev, args)
    elif subcmd == "MONITOR":
        return monitor_power_consumption(dev, args)
    elif subcmd == "WAKE":
        return control_wake_sources(dev, args)
    elif subcmd == "SLEEP":
        return control_sleep_states(dev, args)
    elif subcmd == "BATTERY":
        return handle_battery_operations(dev, args)
    elif subcmd == "THERMAL":
        return handle_thermal_management(dev, args)
    elif subcmd == "EFFICIENCY":
        return analyze_power_efficiency(dev, args)
    else:
        return handle_power_operation(dev, subcmd, args)

def list_available_power_commands(dev):
    """
    List all available POWER commands from QSLCL loader
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL POWER MANAGEMENT COMMANDS")
    print("="*60)
    
    power_found = []
    
    # Check QSLCLPAR for POWER commands
    print("\n[QSLCLPAR] Power Commands:")
    par_power = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "POWER", "PMIC", "PSHOLD", "RESET", "SHUTDOWN", "BOOT", "WAKE", 
        "SLEEP", "BATTERY", "THERMAL", "CLOCK", "DOMAIN", "RAIL"
    ])]
    for power_cmd in par_power:
        print(f"  • {power_cmd}")
        power_found.append(power_cmd)
    
    # Check QSLCLEND for power-related opcodes
    print("\n[QSLCLEND] Power Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["POWER", "PMIC", "RESET", "SHUTDOWN", "WAKE"]) or any(x in entry_str for x in ["PWR", "PMIC", "RST"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            power_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for power microservices
    print("\n[QSLCLVM5] Power Microservices:")
    vm5_power = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["POWER", "PMIC", "RESET"])]
    for power_cmd in vm5_power:
        print(f"  • {power_cmd}")
        power_found.append(f"VM5_{power_cmd}")
    
    # Check QSLCLIDX for power indices
    print("\n[QSLCLIDX] Power Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["POWER", "PMIC", "RESET"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                power_found.append(f"IDX_{name}")
    
    if not power_found:
        print("  No power commands found in loader")
    else:
        print(f"\n[*] Total power commands found: {len(power_found)}")
    
    print("\n[*] Common Power Operations Available:")
    print("  • STATUS      - Get comprehensive power status")
    print("  • ON          - Power on specific domain")
    print("  • OFF         - Power off specific domain") 
    print("  • RESET       - Reset power domain")
    print("  • DOMAINS     - List power domains with details")
    print("  • SEQUENCE    - Control power sequencing")
    print("  • PROFILE     - Manage power profiles")
    print("  • MONITOR     - Real-time power monitoring")
    print("  • WAKE        - Configure wake sources")
    print("  • SLEEP       - Control sleep states")
    print("  • BATTERY     - Battery management")
    print("  • THERMAL     - Thermal management")
    print("  • EFFICIENCY  - Power efficiency analysis")
    
    print("="*60)
    
    return True

def get_power_status(dev):
    """
    Get comprehensive power status of the device
    """
    print("[*] Getting comprehensive power status...")
    
    status_info = {}
    
    # Get power domain status
    print("\n[Power Domains Status]")
    domains_status = get_power_domains_status(dev)
    status_info["domains"] = domains_status
    
    # Get battery status
    print("\n[Battery Status]")
    battery_status = get_battery_status(dev)
    status_info["battery"] = battery_status
    
    # Get thermal status
    print("\n[Thermal Status]")
    thermal_status = get_thermal_status(dev)
    status_info["thermal"] = thermal_status
    
    # Get PMIC status
    print("\n[PMIC Status]")
    pmic_status = get_pmic_status(dev)
    status_info["pmic"] = pmic_status
    
    # Get wake/sleep status
    print("\n[Wake/Sleep Status]")
    wake_status = get_wake_sleep_status(dev)
    status_info["wake_sleep"] = wake_status
    
    # Display summary
    print("\n" + "="*50)
    print("[*] POWER STATUS SUMMARY")
    print("="*50)
    
    active_domains = sum(1 for domain in domains_status if domains_status[domain].get("state") == "ON")
    print(f"Active Domains: {active_domains}/{len(domains_status)}")
    
    if battery_status:
        batt_level = battery_status.get("level", "UNKNOWN")
        batt_health = battery_status.get("health", "UNKNOWN")
        print(f"Battery: {batt_level}%, Health: {batt_health}")
    
    if thermal_status:
        temp = thermal_status.get("temperature", "UNKNOWN")
        print(f"Temperature: {temp}")
    
    print("="*50)
    
    return status_info

def get_power_domains_status(dev):
    """
    Get status of all power domains
    """
    domains = get_power_domains_list(dev)
    domains_status = {}
    
    for domain in domains:
        # Try to get domain status
        payload = domain.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "POWER", b"STATUS\x00" + payload)
        
        state = "UNKNOWN"
        voltage = 0.0
        current = 0.0
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                if len(extra) >= 9:  # state(1) + voltage(4) + current(4)
                    state_byte = extra[0]
                    state = "ON" if state_byte == 1 else "OFF" if state_byte == 0 else "UNKNOWN"
                    voltage = struct.unpack("<f", extra[1:5])[0] if len(extra) >= 5 else 0.0
                    current = struct.unpack("<f", extra[5:9])[0] if len(extra) >= 9 else 0.0
        
        domains_status[domain] = {
            "state": state,
            "voltage": voltage,
            "current": current,
            "power": voltage * current if voltage and current else 0.0
        }
        
        power_str = f"{domains_status[domain]['power']:.2f}W" if domains_status[domain]['power'] > 0 else "N/A"
        print(f"  • {domain:<15} : {state:<8} {voltage:.2f}V {current:.2f}A {power_str}")
    
    return domains_status

def get_battery_status(dev):
    """
    Get battery status and information
    """
    battery_status = {}
    
    # Try battery status command
    resp = qslcl_dispatch(dev, "POWER", b"BATTERY_STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 16:
                # Parse battery data: level(1), voltage(4), current(4), capacity(4), health(1), temp(2)
                battery_status["level"] = extra[0]
                battery_status["voltage"] = struct.unpack("<f", extra[1:5])[0]
                battery_status["current"] = struct.unpack("<f", extra[5:9])[0]
                battery_status["capacity"] = struct.unpack("<f", extra[9:13])[0]
                battery_status["health"] = extra[13]
                battery_status["temperature"] = struct.unpack("<H", extra[14:16])[0] / 10.0  # Convert to °C
    
    if battery_status:
        health_map = {0: "UNKNOWN", 1: "GOOD", 2: "OVERHEAT", 3: "DEAD", 4: "OVER_VOLTAGE"}
        health = health_map.get(battery_status.get("health", 0), "UNKNOWN")
        
        print(f"  • Level     : {battery_status.get('level', 0)}%")
        print(f"  • Voltage   : {battery_status.get('voltage', 0):.2f}V")
        print(f"  • Current   : {battery_status.get('current', 0):.2f}A")
        print(f"  • Capacity  : {battery_status.get('capacity', 0):.0f}mAh")
        print(f"  • Health    : {health}")
        print(f"  • Temp      : {battery_status.get('temperature', 0):.1f}°C")
    else:
        print("  • Battery status: Not available")
    
    return battery_status

def get_thermal_status(dev):
    """
    Get thermal status and temperatures
    """
    thermal_status = {}
    
    # Try thermal status command
    resp = qslcl_dispatch(dev, "POWER", b"THERMAL_STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 2:
                thermal_status["temperature"] = struct.unpack("<H", extra[0:2])[0] / 10.0  # Convert to °C
    
    if thermal_status:
        temp = thermal_status.get("temperature", 0)
        status = "NORMAL" if temp < 60 else "WARM" if temp < 80 else "HOT" if temp < 95 else "CRITICAL"
        print(f"  • Temperature : {temp:.1f}°C [{status}]")
    else:
        print("  • Thermal status: Not available")
    
    return thermal_status

def get_pmic_status(dev):
    """
    Get PMIC (Power Management IC) status
    """
    pmic_status = {}
    
    # Try PMIC status command
    resp = qslcl_dispatch(dev, "POWER", b"PMIC_STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 4:
                pmic_status["chip_id"] = struct.unpack("<I", extra[0:4])[0]
    
    if pmic_status:
        print(f"  • PMIC Chip ID: 0x{pmic_status.get('chip_id', 0):08X}")
    else:
        print("  • PMIC status: Not available")
    
    return pmic_status

def get_wake_sleep_status(dev):
    """
    Get wake and sleep status
    """
    wake_status = {}
    
    # Try wake/sleep status command
    resp = qslcl_dispatch(dev, "POWER", b"WAKE_STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 1:
                wake_status["state"] = "AWAKE" if extra[0] == 1 else "SLEEP"
    
    if wake_status:
        print(f"  • Device State: {wake_status.get('state', 'UNKNOWN')}")
    else:
        print("  • Wake/Sleep status: Not available")
    
    return wake_status

def get_power_domains_list(dev):
    """
    Get list of power domains
    """
    # Common power domains
    common_domains = [
        "VDD_CPU", "VDD_CPU_BIG", "VDD_CPU_LITTLE", "VDD_GPU", "VDD_DDR",
        "VDD_CORE", "VDD_MEM", "VDD_IO", "VDD_AON", "VDD_RF", "VDD_MODEM",
        "VDD_PLL", "VDD_USB", "VDD_SRAM", "VDD_ANALOG", "VDD_DIGITAL",
        "VDD_DISPLAY", "VDD_CAMERA", "VDD_AUDIO", "VDD_SENSORS"
    ]
    
    # Try to get domains from device
    resp = qslcl_dispatch(dev, "POWER", b"DOMAINS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            try:
                domain_list = extra.decode('utf-8', errors='ignore').split('\x00')
                return [d.strip() for d in domain_list if d.strip()]
            except:
                pass
    
    return common_domains

def power_on_domain(dev, args):
    """
    Power on specific power domain
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return print("[!] POWER ON requires domain name")
    
    domain = args.power_args[0].upper()
    
    print(f"[*] Powering ON domain: {domain}")
    
    # Safety confirmation for critical domains
    critical_domains = ["VDD_CPU", "VDD_GPU", "VDD_DDR", "VDD_CORE"]
    if domain in critical_domains:
        confirm = input(f"!! CONFIRM POWER ON {domain} (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Power ON cancelled")
            return False
    
    # Execute power on
    payload = domain.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "POWER", b"ON\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {domain} powered ON successfully")
            
            # Verify power state
            time.sleep(0.5)
            domains_status = get_power_domains_status(dev)
            if domain in domains_status and domains_status[domain].get("state") == "ON":
                print(f"[✓] {domain} power verification: ON")
            else:
                print(f"[!] {domain} power verification failed")
            
            return True
        else:
            print(f"[!] Failed to power ON {domain}: {status}")
            return False
    
    print(f"[!] No power ON command available for {domain}")
    return False

def power_off_domain(dev, args):
    """
    Power off specific power domain
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return print("[!] POWER OFF requires domain name")
    
    domain = args.power_args[0].upper()
    
    print(f"[!] WARNING: Powering OFF domain: {domain}")
    print("[!] This may cause device instability or data loss!")
    
    confirm = input(f"!! CONFIRM POWER OFF {domain} (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Power OFF cancelled")
        return False
    
    # Execute power off
    payload = domain.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "POWER", b"OFF\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {domain} powered OFF successfully")
            return True
        else:
            print(f"[!] Failed to power OFF {domain}: {status}")
            return False
    
    print(f"[!] No power OFF command available for {domain}")
    return False

def power_reset_domain(dev, args):
    """
    Reset specific power domain
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return print("[!] POWER RESET requires domain name")
    
    domain = args.power_args[0].upper()
    
    print(f"[*] Resetting power domain: {domain}")
    
    # Execute power reset
    payload = domain.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "POWER", b"RESET\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {domain} reset successfully")
            
            # Wait for domain to stabilize
            time.sleep(1)
            
            # Verify reset
            domains_status = get_power_domains_status(dev)
            if domain in domains_status and domains_status[domain].get("state") == "ON":
                print(f"[✓] {domain} is back ONLINE after reset")
            else:
                print(f"[!] {domain} may be OFFLINE after reset")
            
            return True
        else:
            print(f"[!] Failed to reset {domain}: {status}")
            return False
    
    print(f"[!] No power RESET command available for {domain}")
    return False

def list_power_domains_detailed(dev):
    """
    List power domains with detailed information
    """
    print("[*] Scanning power domains with detailed information...")
    
    domains = get_power_domains_list(dev)
    domains_status = get_power_domains_status(dev)
    
    print(f"\n[*] Found {len(domains)} power domains:")
    print("=" * 70)
    print(f"{'Domain':<20} {'State':<8} {'Voltage':<8} {'Current':<8} {'Power':<10} {'Status'}")
    print("-" * 70)
    
    total_power = 0.0
    for domain in domains:
        status = domains_status.get(domain, {})
        state = status.get("state", "UNKNOWN")
        voltage = status.get("voltage", 0.0)
        current = status.get("current", 0.0)
        power = status.get("power", 0.0)
        total_power += power
        
        power_str = f"{power:.2f}W" if power > 0 else "N/A"
        status_indicator = "✓" if state == "ON" and power > 0 else "○" if state == "ON" else "✗"
        
        print(f"{domain:<20} {state:<8} {voltage:.2f}V {current:.2f}A {power_str:<10} {status_indicator}")
    
    print("-" * 70)
    print(f"{'TOTAL':<20} {'':<8} {'':<8} {'':<8} {total_power:.2f}W")
    print("=" * 70)
    
    return True

def control_power_sequence(dev, args):
    """
    Control power sequencing and timing
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return print_power_sequence_help()
    
    action = args.power_args[0].upper()
    
    if action == "LIST":
        return list_power_sequences(dev)
    elif action == "START":
        return start_power_sequence(dev, args)
    elif action == "STOP":
        return stop_power_sequence(dev, args)
    elif action == "CONFIGURE":
        return configure_power_sequence(dev, args)
    else:
        return handle_power_sequence_action(dev, action, args)

def list_power_sequences(dev):
    """
    List available power sequences
    """
    print("[*] Available power sequences:")
    
    common_sequences = [
        "BOOT_SEQUENCE", "SHUTDOWN_SEQUENCE", "SLEEP_SEQUENCE", 
        "WAKE_SEQUENCE", "RESET_SEQUENCE", "LOW_POWER_SEQUENCE"
    ]
    
    for seq in common_sequences:
        print(f"  • {seq}")
    
    return True

def start_power_sequence(dev, args):
    """
    Start a power sequence
    """
    if len(args.power_args) < 2:
        return print("[!] SEQUENCE START requires sequence name")
    
    sequence = args.power_args[1].upper()
    
    print(f"[*] Starting power sequence: {sequence}")
    
    payload = sequence.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "POWER", b"SEQUENCE_START\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Power sequence '{sequence}' started successfully")
            return True
        else:
            print(f"[!] Failed to start power sequence: {status}")
            return False
    
    print(f"[!] No power sequence control available")
    return False

def manage_power_profiles(dev, args):
    """
    Manage power profiles (performance, efficiency, etc.)
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return list_power_profiles(dev)
    
    action = args.power_args[0].upper()
    
    if action == "LIST":
        return list_power_profiles(dev)

    elif action == "SET":
        if len(args.power_args) < 2:
            return print("[!] PROFILE SET requires profile name")
        profile = args.power_args[1].upper()
        return set_power_profile(dev, profile)

    elif action == "ACTIVE":
        return get_active_power_profile(dev)

    else:
        # FIXED: fully complete argument name and closing parenthesis
        return handle_power_profile_action(dev, action, args)

def list_power_profiles(dev):
    """
    List available power profiles
    """
    print("[*] Available power profiles:")
    
    common_profiles = [
        "PERFORMANCE", "BALANCED", "POWER_SAVE", "ULTRA_SAVE",
        "GAMING", "BENCHMARK", "THERMAL", "DEFAULT", "EFFICIENCY"
    ]
    
    for profile in common_profiles:
        print(f"  • {profile}")
    
    return True

def set_power_profile(dev, profile):
    """
    Set active power profile
    """
    print(f"[*] Setting power profile to: {profile}")
    
    payload = profile.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "POWER", b"PROFILE_SET\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Power profile set to '{profile}'")
            return True
        else:
            print(f"[!] Failed to set power profile: {status}")
            return False
    
    print(f"[!] No power profile control available")
    return False

def monitor_power_consumption(dev, args):
    """
    Real-time power consumption monitoring
    """
    duration = 30  # Default 30 seconds
    interval = 1   # Default 1 second
    
    if hasattr(args, 'power_args'):
        if len(args.power_args) > 0:
            try:
                duration = int(args.power_args[0])
            except:
                pass
        if len(args.power_args) > 1:
            try:
                interval = float(args.power_args[1])
            except:
                pass
    
    print(f"[*] Starting power monitoring for {duration} seconds...")
    print("[*] Press Ctrl+C to stop early")
    
    start_time = time.time()
    end_time = start_time + duration
    
    try:
        while time.time() < end_time:
            elapsed = time.time() - start_time
            print(f"\n[*] Time: {elapsed:5.1f}s")
            print("-" * 50)
            
            domains_status = get_power_domains_status(dev)
            total_power = sum(status.get("power", 0) for status in domains_status.values())
            
            print(f"Total Power: {total_power:.2f}W")
            
            # Show top power consumers
            power_consumers = [(domain, status.get("power", 0)) for domain, status in domains_status.items() if status.get("power", 0) > 0]
            power_consumers.sort(key=lambda x: x[1], reverse=True)
            
            for domain, power in power_consumers[:5]:  # Top 5 consumers
                percentage = (power / total_power * 100) if total_power > 0 else 0
                print(f"  {domain:<15} : {power:6.2f}W ({percentage:5.1f}%)")
            
            time.sleep(interval)
            
    except KeyboardInterrupt:
        print("\n[*] Power monitoring stopped by user")
    
    print("[*] Power monitoring completed")
    return True

def control_wake_sources(dev, args):
    """
    Configure wake sources and wake-up triggers
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return list_wake_sources(dev)
    
    action = args.power_args[0].upper()
    
    if action == "LIST":
        return list_wake_sources(dev)
    elif action == "ENABLE":
        return enable_wake_source(dev, args)
    elif action == "DISABLE":
        return disable_wake_source(dev, args)
    else:
        return handle_wake_source_action(dev, action, args)

def list_wake_sources(dev):
    """
    List available wake sources
    """
    print("[*] Available wake sources:")
    
    common_wake_sources = [
        "RTC_ALARM", "POWER_BUTTON", "USB_CONNECT", "USB_DISCONNECT",
        "CHARGER_CONNECT", "CHARGER_DISCONNECT", "GPIO_TRIGGER",
        "ACCELEROMETER", "GYROSCOPE", "PROXIMITY", "TOUCH_SCREEN"
    ]
    
    for source in common_wake_sources:
        print(f"  • {source}")
    
    return True

def control_sleep_states(dev, args):
    """
    Control sleep states and low-power modes
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return list_sleep_states(dev)
    
    action = args.power_args[0].upper()
    
    if action == "LIST":
        return list_sleep_states(dev)
    elif action == "ENTER":
        return enter_sleep_state(dev, args)
    elif action == "EXIT":
        return exit_sleep_state(dev, args)
    else:
        return handle_sleep_state_action(dev, action, args)

def list_sleep_states(dev):
    """
    List available sleep states
    """
    print("[*] Available sleep states:")
    
    common_sleep_states = [
        "ACTIVE", "IDLE", "STANDBY", "SUSPEND", "HIBERNATE", "DEEP_SLEEP"
    ]
    
    for state in common_sleep_states:
        print(f"  • {state}")
    
    return True

def handle_battery_operations(dev, args):
    """
    Handle battery-related operations
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return get_battery_status(dev)
    
    action = args.power_args[0].upper()
    
    if action == "STATUS":
        return get_battery_status(dev)
    elif action == "CALIBRATE":
        return calibrate_battery(dev)
    elif action == "RESET":
        return reset_battery_stats(dev)
    else:
        return handle_battery_action(dev, action, args)

def handle_thermal_management(dev, args):
    """
    Handle thermal management operations
    """
    if not hasattr(args, 'power_args') or not args.power_args:
        return get_thermal_status(dev)
    
    action = args.power_args[0].upper()
    
    if action == "STATUS":
        return get_thermal_status(dev)
    elif action == "LIMIT":
        return set_thermal_limit(dev, args)
    elif action == "CONTROL":
        return control_thermal_management(dev, args)
    else:
        return handle_thermal_action(dev, action, args)

def analyze_power_efficiency(dev, args):
    """
    Analyze power efficiency and provide recommendations
    """
    print("[*] Analyzing power efficiency...")
    
    # Get current power status
    domains_status = get_power_domains_status(dev)
    total_power = sum(status.get("power", 0) for status in domains_status.values())
    
    print(f"\n[*] Power Efficiency Analysis")
    print("=" * 50)
    print(f"Total Power Consumption: {total_power:.2f}W")
    
    # Identify inefficient domains
    inefficient_domains = []
    for domain, status in domains_status.items():
        power = status.get("power", 0)
        if power > 0.5:  # Domains consuming more than 0.5W
            inefficient_domains.append((domain, power))
    
    if inefficient_domains:
        print("\n[!] High Power Consumers:")
        for domain, power in sorted(inefficient_domains, key=lambda x: x[1], reverse=True):
            print(f"  • {domain}: {power:.2f}W")
    
    # Provide recommendations
    print("\n[✓] Power Efficiency Recommendations:")
    print("  • Consider using POWER SAVE profile for better efficiency")
    print("  • Disable unused power domains")
    print("  • Enable dynamic voltage and frequency scaling")
    print("  • Use appropriate sleep states when idle")
    
    return True

def handle_power_operation(dev, operation, args):
    """
    Handle other power operations
    """
    print(f"[*] Executing power operation: {operation}")
    
    # Build operation parameters
    params = build_power_operation_params(operation, args)
    
    # Try different operation strategies
    strategies = [
        try_direct_power_operation,
        try_par_power_command,
        try_end_power_opcode,
        try_vm5_power_service,
        try_idx_power_command,
    ]
    
    for strategy in strategies:
        success = strategy(dev, operation, params)
        if success is not None:
            return success
    
    print(f"[!] Failed to execute power operation: {operation}")
    return False

def build_power_operation_params(operation, args):
    """
    Build parameters for power operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'power_args'):
        for arg in args.power_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

# Strategy implementations (similar to voltage commands)
def try_direct_power_operation(dev, operation, params):
    resp = qslcl_dispatch(dev, "POWER", operation.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {operation} executed successfully")
        return True
    return None

def try_par_power_command(dev, operation, params):
    if operation in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, operation, params)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLPAR")
            return True
    return None

def try_end_power_opcode(dev, operation, params):
    opcode = sum(operation.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLEND opcode 0x{opcode:02X}")
            return True
    return None

def try_vm5_power_service(dev, operation, params):
    if operation in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[operation]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLVM5")
            return True
    return None

def try_idx_power_command(dev, operation, params):
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == operation:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
            resp = qslcl_dispatch(dev, "IDX", pkt)
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {operation} executed via QSLCLIDX {name}")
                return True
    return None

# Placeholder functions for unimplemented features
def print_power_sequence_help():
    print("[*] Power sequence commands:")
    print("  sequence list                    - List available sequences")
    print("  sequence start <name>           - Start power sequence")
    print("  sequence stop <name>            - Stop power sequence")
    print("  sequence configure <name> <cfg> - Configure power sequence")
    return False

def stop_power_sequence(dev, args):
    print("[*] Power sequence stop not yet implemented")
    return False

def configure_power_sequence(dev, args):
    print("[*] Power sequence configuration not yet implemented")
    return False

def handle_power_sequence_action(dev, action, args):
    print(f"[*] Power sequence action '{action}' not yet implemented")
    return False

def get_active_power_profile(dev):
    print("[*] Active power profile query not yet implemented")
    return False

def handle_power_profile_action(dev, action, args):
    print(f"[*] Power profile action '{action}' not yet implemented")
    return False

def enable_wake_source(dev, args):
    print("[*] Wake source enable not yet implemented")
    return False

def disable_wake_source(dev, args):
    print("[*] Wake source disable not yet implemented")
    return False

def handle_wake_source_action(dev, action, args):
    print(f"[*] Wake source action '{action}' not yet implemented")
    return False

def enter_sleep_state(dev, args):
    print("[*] Enter sleep state not yet implemented")
    return False

def exit_sleep_state(dev, args):
    print("[*] Exit sleep state not yet implemented")
    return False

def handle_sleep_state_action(dev, action, args):
    print(f"[*] Sleep state action '{action}' not yet implemented")
    return False

def calibrate_battery(dev):
    print("[*] Battery calibration not yet implemented")
    return False

def reset_battery_stats(dev):
    print("[*] Battery stats reset not yet implemented")
    return False

def handle_battery_action(dev, action, args):
    print(f"[*] Battery action '{action}' not yet implemented")
    return False

def set_thermal_limit(dev, args):
    print("[*] Thermal limit setting not yet implemented")
    return False

def control_thermal_management(dev, args):
    print("[*] Thermal management control not yet implemented")
    return False

def handle_thermal_action(dev, action, args):
    print(f"[*] Thermal action '{action}' not yet implemented")
    return False

# Update the argument parser in main() function
def update_power_parser(sub):
    """
    Update the POWER command parser with new subcommands
    """
    power_parser = sub.add_parser("power", help="Power management and control commands")
    power_parser.add_argument("power_subcommand", help="Power subcommand (list, status, on, off, reset, domains, sequence, profile, monitor, wake, sleep, battery, thermal, efficiency)")
    power_parser.add_argument("power_args", nargs="*", help="Additional arguments for power command")
    power_parser.set_defaults(func=cmd_power)