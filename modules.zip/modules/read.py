def cmd_read(args=None):
    """
    UPDATED READ command for QSLCL v1.2.5:
    - Fixed import issues
    - Uses consolidated QSLCLCMD system (not QSLCLPAR)
    - Matches new partition detection in qslcl.py
    - Compatible with new target resolution functions
    """

    if not args:
        print("[!] READ: No arguments provided")
        return 1

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    
    # Auto load qslcl.bin if specified
    if hasattr(args, 'loader') and args.loader:
        auto_loader_if_needed(args, dev)

    target = getattr(args, 'target', '')
    output_file = getattr(args, 'output', '')
    size_arg = getattr(args, 'size', None)
    chunk_size = getattr(args, 'chunk_size', 65536)
    no_verify = getattr(args, 'no_verify', False)
    format_type = getattr(args, 'format', 'raw')
    scan_mode = getattr(args, 'scan', False)
    auto_detect = getattr(args, 'auto_detect', True)
    resume_mode = getattr(args, 'resume', False)

    if not target:
        print("[!] READ: No target specified")
        return 1

    print(f"[*] READ command: target={target}")

    # =========================================================================
    # 1. ENHANCED TARGET RESOLUTION
    # =========================================================================
    partitions = load_partitions(dev) if auto_detect else []
    memory_regions = detect_memory_regions(dev) if auto_detect else []
    
    # Use the new unified target resolver
    target_info = resolve_target(target, partitions, memory_regions, dev)
    
    if not target_info:
        print(f"[!] Could not resolve target: {target}")
        
        # Show available partitions for reference
        if partitions:
            print("\n[*] Available partitions:")
            for part in partitions:
                print(f"    {part['name']:<12}  off=0x{part['offset']:08X}  size=0x{part['size']:08X}")
        
        # Show memory regions
        if memory_regions:
            print("\n[*] Available memory regions:")
            for region in memory_regions:
                print(f"    {region['name']:<12}  start=0x{region['start']:016X}  size=0x{region['size']:08X}")
        
        return 1

    address = target_info['address']
    max_possible_size = target_info['size']
    partition_info = target_info.get('partition_info')
    region_info = target_info.get('region_info')
    
    print(f"[+] Target resolved:")
    print(f"    Address: 0x{address:08X}")
    print(f"    Maximum size: 0x{max_possible_size:08X}")
    
    if partition_info:
        print(f"    Partition: {partition_info['name']}")
        print(f"    Partition offset: 0x{partition_info['offset']:08X}")
        print(f"    Partition size: 0x{partition_info['size']:08X}")
    
    if region_info:
        print(f"    Memory region: {region_info['name']}")
        if 'permissions' in region_info:
            print(f"    Permissions: {region_info['permissions']}")

    # =========================================================================
    # 2. SIZE DETERMINATION WITH SAFETY CHECKS
    # =========================================================================
    if size_arg is not None:
        if isinstance(size_arg, (int, float)):
            size = int(size_arg)
        else:
            size = parse_size_string(str(size_arg))
        
        # Safety check: don't exceed available space
        if max_possible_size > 0 and size > max_possible_size:
            print(f"[!] Warning: Requested size 0x{size:08X} exceeds available 0x{max_possible_size:08X}")
            print(f"[*] Truncating to 0x{max_possible_size:08X}")
            size = max_possible_size
    else:
        # Use maximum available size
        size = max_possible_size
        if size > 0:
            print(f"[*] Using maximum available size: 0x{size:08X}")
        else:
            print("[!] Cannot determine size, please specify --size")
            return 1

    if size <= 0:
        print("[!] Invalid size specified")
        return 1

    # =========================================================================
    # 3. OUTPUT FILE HANDLING WITH FORMAT SUPPORT
    # =========================================================================
    # Get output from either --output or positional arg
    output_given = False
    
    if output_file:
        output_given = True
    elif hasattr(args, 'arg2') and args.arg2:
        output_file = args.arg2
        output_given = True
    
    if not output_given:
        # Generate automatic output filename
        if partition_info:
            base_name = partition_info['name']
        elif region_info:
            base_name = region_info['name']
        else:
            base_name = f"0x{address:08X}"
        
        if format_type == 'raw':
            output_file = f"{base_name}.bin"
        elif format_type == 'hex':
            output_file = f"{base_name}.hex"
        elif format_type == 'json':
            output_file = f"{base_name}.json"
        else:
            output_file = f"{base_name}.bin"
        
        print(f"[*] Auto-generated output: {output_file}")

    # Check if output file exists
    if os.path.exists(output_file) and not resume_mode:
        response = input(f"[!] File {output_file} exists. Overwrite? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return 0

    # =========================================================================
    # 4. SCAN MODE (EXPLORATORY READING)
    # =========================================================================
    if scan_mode:
        return run_scan_mode(dev, address, size, output_file, chunk_size)

    # =========================================================================
    # 5. RESUME MODE HANDLING
    # =========================================================================
    start_offset = 0
    if resume_mode and os.path.exists(output_file):
        start_offset = os.path.getsize(output_file)
        if start_offset > 0:
            print(f"[*] Resuming from offset 0x{start_offset:08X}")
            if start_offset >= size:
                print("[*] File already complete, nothing to do")
                return 0

    # =========================================================================
    # 6. READ OPERATION WITH IMPROVED ERROR HANDLING
    # =========================================================================
    print(f"[*] Reading 0x{size:08X} bytes from 0x{address:08X} -> {output_file}")
    print(f"[*] Chunk size: 0x{chunk_size:08X}")
    
    try:
        mode = 'ab' if resume_mode else 'wb'
        with open(output_file, mode) as f:
            bytes_read = start_offset
            retry_count = 0
            max_retries = 5
            consecutive_failures = 0
            max_consecutive_failures = 10
            
            # Handle zero size gracefully
            if size == 0:
                print("[!] Size is zero, nothing to read")
                return 0
            
            with ProgressBar(size, prefix='Reading', suffix='Complete', length=50) as progress:
                # Update progress for already read data
                if start_offset > 0:
                    progress.update(start_offset)
                
                while bytes_read < size:
                    chunk_addr = address + bytes_read
                    remaining = size - bytes_read
                    current_chunk = min(chunk_size, remaining)
                    
                    # Skip if chunk size is 0 (shouldn't happen)
                    if current_chunk <= 0:
                        break
                    
                    try:
                        # Build read payload: address + size
                        read_payload = struct.pack("<II", chunk_addr, current_chunk)
                        
                        # Dispatch using QSLCLCMD system
                        resp = qslcl_dispatch(dev, "READ", read_payload, timeout=10.0)
                        
                        if resp:
                            # Parse response using RTF system
                            status = decode_runtime_result(resp)
                            
                            if status["severity"] == "SUCCESS":
                                data = status.get("extra", b"")
                                actual_len = len(data)
                                
                                if actual_len > 0:
                                    # Handle partial reads
                                    if actual_len < current_chunk:
                                        print(f"[!] Short read: requested {current_chunk}, got {actual_len}")
                                    
                                    f.write(data)
                                    bytes_read += actual_len
                                    progress.update(actual_len)
                                    
                                    # Reset failure counters on success
                                    retry_count = 0
                                    consecutive_failures = 0
                                    
                                    # Flush periodically
                                    if bytes_read % (chunk_size * 10) == 0:
                                        f.flush()
                                else:
                                    print(f"[!] Empty response at 0x{chunk_addr:08X}")
                                    consecutive_failures += 1
                            else:
                                print(f"[!] Read error at 0x{chunk_addr:08X}: {status.get('name', 'Unknown')}")
                                retry_count += 1
                                consecutive_failures += 1
                        else:
                            print(f"[!] No response at 0x{chunk_addr:08X}")
                            retry_count += 1
                            consecutive_failures += 1
                        
                        # Handle retries with exponential backoff
                        if consecutive_failures > 0:
                            if retry_count >= max_retries:
                                print(f"[!] Max retries exceeded at 0x{chunk_addr:08X}")
                                break
                            
                            # Exponential backoff
                            backoff = 0.5 * (2 ** retry_count)
                            print(f"[*] Retrying in {backoff:.2f}s (attempt {retry_count+1}/{max_retries})")
                            time.sleep(backoff)
                        
                        # Check for too many consecutive failures
                        if consecutive_failures >= max_consecutive_failures:
                            print(f"[!] Too many consecutive failures, aborting")
                            break
                            
                    except KeyboardInterrupt:
                        print("\n[!] READ interrupted by user")
                        f.flush()
                        print(f"[*] Saved {bytes_read} bytes to {output_file}")
                        return 0
                    except Exception as e:
                        print(f"[!] Read exception at 0x{chunk_addr:08X}: {e}")
                        retry_count += 1
                        consecutive_failures += 1
                        
                        if retry_count >= max_retries:
                            print(f"[!] Max retries exceeded due to exceptions")
                            break
                        
                        time.sleep(1.0)  # Longer pause for exceptions

        # =========================================================================
        # 7. POST-READ PROCESSING
        # =========================================================================
        if bytes_read > 0:
            # Format conversion if requested
            if format_type != 'raw':
                convert_to_format(output_file, format_type)
            
            # Verification (if enabled)
            if not no_verify:
                verify_read_operation(output_file, bytes_read)
            
            # Final summary
            print_read_summary(address, bytes_read, size, output_file, partition_info)
            return 0
        else:
            print("[!] READ failed: No data read")
            # Clean up empty file
            if os.path.exists(output_file) and os.path.getsize(output_file) == 0:
                os.remove(output_file)
            return 1

    except Exception as e:
        print(f"[!] READ operation failed: {e}")
        import traceback
        traceback.print_exc()
        # Clean up on failure
        if os.path.exists(output_file) and os.path.getsize(output_file) == 0:
            os.remove(output_file)
        return 1


# =============================================================================
# SUPPORTING FUNCTIONS
# =============================================================================

def run_scan_mode(dev, start_address, size, output_file, chunk_size):
    """Run in scan mode for exploratory reading"""
    print("[*] SCAN MODE: Reading with pattern detection")
    
    patterns = {
        b'ANDROID!': 'Android boot image',
        b'\x7fELF': 'ELF executable',
        b'MZ': 'Windows executable',
        b'APFS': 'Apple File System',
        b'HFS': 'Hierarchical File System',
        b'BM': 'BMP image',
        b'\xFF\xD8\xFF': 'JPEG image',
        b'PK\x03\x04': 'ZIP archive',
    }
    
    found_items = []
    
    try:
        from qslcl import qslcl_dispatch, decode_runtime_result, ProgressBar
    except ImportError:
        print("[!] Failed to import required functions for scan mode")
        return found_items
    
    try:
        with open(output_file, 'wb') as f:
            bytes_read = 0
            
            with ProgressBar(size, prefix='Scanning', suffix='Complete', length=50) as progress:
                while bytes_read < size:
                    chunk_addr = start_address + bytes_read
                    remaining = size - bytes_read
                    current_chunk = min(chunk_size, remaining)
                    
                    if current_chunk <= 0:
                        break
                    
                    # Read chunk
                    read_payload = struct.pack("<II", chunk_addr, current_chunk)
                    resp = qslcl_dispatch(dev, "READ", read_payload)
                    
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            data = status.get("extra", b"")
                            if data:
                                f.write(data)
                                
                                # Scan for patterns
                                for pattern, description in patterns.items():
                                    if pattern in data:
                                        offset_in_chunk = data.find(pattern)
                                        absolute_offset = bytes_read + offset_in_chunk
                                        found_items.append({
                                            'pattern': pattern,
                                            'description': description,
                                            'offset': start_address + absolute_offset,
                                            'chunk_offset': offset_in_chunk
                                        })
                                
                                bytes_read += len(data)
                                progress.update(len(data))
    
    except Exception as e:
        print(f"[!] Scan mode failed: {e}")
    
    # Report findings
    if found_items:
        print(f"\n[*] Found {len(found_items)} interesting patterns:")
        for item in found_items:
            print(f"    {item['description']} at 0x{item['offset']:08X}")
    
    print(f"\n[+] Scan completed: {bytes_read} bytes written to {output_file}")
    return found_items


def convert_to_format(input_file, format_type):
    """Convert raw binary to requested format"""
    if not os.path.exists(input_file):
        return
    
    print(f"[*] Converting to {format_type.upper()} format...")
    
    try:
        with open(input_file, 'rb') as f:
            data = f.read()
        
        if format_type == 'hex':
            output_file = input_file.replace('.bin', '.hex')
            with open(output_file, 'w') as f:
                for i in range(0, len(data), 16):
                    chunk = data[i:i+16]
                    hex_str = ' '.join(f'{b:02X}' for b in chunk)
                    ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
                    f.write(f"{i:08X}: {hex_str:<48} |{ascii_str}|\n")
            print(f"[+] Hex dump saved to {output_file}")
        
        elif format_type == 'json':
            output_file = input_file.replace('.bin', '.json')
            import json
            file_info = {
                'size': len(data),
                'sha256': hashlib.sha256(data).hexdigest(),
                'first_16_bytes': data[:16].hex() if len(data) >= 16 else '',
                'magic_numbers': []
            }
            
            # Detect common magic numbers
            magic_patterns = [
                (b'ANDROID!', 'Android boot image'),
                (b'\x7fELF', 'ELF executable'),
                (b'MZ', 'Windows PE executable'),
                (b'APFS', 'Apple File System'),
                (b'HFS', 'Hierarchical File System'),
            ]
            
            for magic, description in magic_patterns:
                if magic in data[:64]:  # Check first 64 bytes
                    file_info['magic_numbers'].append({
                        'magic': magic.hex(),
                        'description': description
                    })
            
            with open(output_file, 'w') as f:
                json.dump(file_info, f, indent=2)
            print(f"[+] JSON metadata saved to {output_file}")
        
        elif format_type == 'disasm':
            print("[!] Disassembly format requires capstone library")
            print("[*] Install: pip install capstone")
            print("[*] Skipping disassembly conversion")
    
    except Exception as e:
        print(f"[!] Format conversion failed: {e}")


def verify_read_operation(output_file, expected_bytes):
    """Verify read operation integrity"""
    if not os.path.exists(output_file):
        print("[!] Verification failed: Output file missing")
        return False
    
    file_size = os.path.getsize(output_file)
    
    if file_size != expected_bytes:
        print(f"[!] Verification failed: expected {expected_bytes}, got {file_size} bytes")
        if file_size < expected_bytes:
            print(f"    Missing: {expected_bytes - file_size} bytes")
        else:
            print(f"    Extra: {file_size - expected_bytes} bytes")
        return False
    
    print(f"[+] Verification passed: {file_size} bytes read")
    
    # Calculate checksum
    try:
        with open(output_file, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        print(f"[+] SHA256: {file_hash}")
    except Exception as e:
        print(f"[!] Failed to calculate checksum: {e}")
    
    # Check for null data
    try:
        with open(output_file, 'rb') as f:
            sample_size = min(4096, file_size)
            sample = f.read(sample_size)
            if sample:
                null_count = sample.count(b'\x00')
                null_percent = (null_count / len(sample)) * 100
                
                if null_percent > 90:
                    print(f"[!] Warning: High null content ({null_percent:.1f}%) - may be uninitialized memory")
                elif null_percent < 10:
                    print(f"[+] Low null content ({null_percent:.1f}%) - likely valid data")
    except:
        pass
    
    return True

def print_read_summary(address, bytes_read, requested_size, output_file, partition_info=None):
    """Print comprehensive read summary"""
    print(f"\n{'='*60}")
    print(f"[+] READ completed successfully!")
    print(f"{'='*60}")
    print(f"    Source address: 0x{address:08X}")
    
    if partition_info:
        print(f"    Partition: {partition_info['name']}")
        offset_in_partition = address - partition_info['offset']
        if offset_in_partition > 0:
            print(f"    Offset in partition: 0x{offset_in_partition:08X}")
    
    print(f"    Bytes read: 0x{bytes_read:08X} ({bytes_read:,} bytes)")
    print(f"    Requested: 0x{requested_size:08X} ({requested_size:,} bytes)")
    
    if bytes_read < requested_size:
        completion = (bytes_read / requested_size) * 100
        print(f"    Completion: {completion:.1f}%")
        print(f"    Missing: {requested_size - bytes_read:,} bytes")
    elif bytes_read > requested_size:
        print(f"    Warning: Read more than requested!")
    
    if os.path.exists(output_file):
        file_size = os.path.getsize(output_file)
        print(f"    Output file: {output_file}")
        print(f"    File size: {file_size:,} bytes")
        
        # Show file info
        if file_size >= 16:
            try:
                with open(output_file, 'rb') as f:
                    first_bytes = f.read(16)
                    print(f"    First 16 bytes: {first_bytes.hex().upper()}")
                    
                    # Try to interpret as ASCII
                    ascii_str = ''.join(chr(b) if 32 <= b < 127 else '.' for b in first_bytes)
                    print(f"    ASCII preview: '{ascii_str}'")
            except:
                pass
    else:
        print(f"    Warning: Output file {output_file} not found!")
    
    print(f"{'='*60}")