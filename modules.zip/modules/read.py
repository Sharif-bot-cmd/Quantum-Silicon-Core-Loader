def cmd_read(args=None):
    """
    Fully implemented READ command with advanced features:
    - Partition name resolution
    - Address parsing (hex, decimal, expressions)
    - Auto-size detection
    - Progress tracking
    - Error recovery
    - Output file handling
    """
    if not args:
        print("[!] READ: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    target = getattr(args, 'target', '')
    output_file = getattr(args, 'output', '')
    size_arg = getattr(args, 'size', None)
    chunk_size = getattr(args, 'chunk_size', 65536)
    no_verify = getattr(args, 'no_verify', False)

    if not target:
        print("[!] READ: No target specified")
        return

    print(f"[*] READ command: target={target}")

    # =========================================================================
    # 1. TARGET RESOLUTION
    # =========================================================================
    address = 0
    auto_size = False

    # Check if target is a partition name
    partitions = load_partitions(dev)
    partition_info = None
    
    for part in partitions:
        if part['name'].lower() == target.lower():
            partition_info = part
            address = part['offset']
            if not size_arg:
                size_arg = part['size']
                auto_size = True
            print(f"[+] Target is partition: {part['name']} (0x{address:08X}, size: 0x{size_arg:08X})")
            break

    # If not a partition, parse as address
    if not partition_info:
        try:
            # Handle address expressions
            if '+' in target:
                # Partition+offset format (e.g., "boot+0x1000")
                part_name, offset_str = target.split('+', 1)
                for part in partitions:
                    if part['name'].lower() == part_name.lower():
                        offset = parse_address(offset_str)
                        address = part['offset'] + offset
                        partition_info = part
                        print(f"[+] Target: {part_name}+{offset_str} = 0x{address:08X}")
                        break
                if not partition_info:
                    print(f"[!] Unknown partition: {part_name}")
                    return
            else:
                # Raw address
                address = parse_address(target)
                print(f"[+] Target address: 0x{address:08X}")
        except ValueError as e:
            print(f"[!] Invalid address format: {target} - {e}")
            return

    # =========================================================================
    # 2. SIZE DETERMINATION
    # =========================================================================
    if not size_arg and not auto_size:
        # Auto-detect size for partitions, otherwise use safe default
        if partition_info:
            size = partition_info['size']
            print(f"[*] Using partition size: 0x{size:08X}")
        else:
            # For raw addresses, read 1 sector by default
            sector_size = get_sector_size(dev)
            size = sector_size
            print(f"[*] Using default size (1 sector): 0x{size:08X}")
    else:
        size = size_arg

    # Convert size to integer if it's a string
    if isinstance(size, str):
        size = parse_size_string(size)

    if size <= 0:
        print("[!] Invalid size specified")
        return

    # =========================================================================
    # 3. OUTPUT FILE HANDLING
    # =========================================================================
    if not output_file:
        # Generate automatic output filename
        if partition_info:
            output_file = f"{partition_info['name']}.bin"
        else:
            output_file = f"dump_0x{address:08X}.bin"
        print(f"[*] Auto-generated output: {output_file}")

    # Check if output file exists
    if os.path.exists(output_file):
        response = input(f"[!] File {output_file} exists. Overwrite? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return

    # =========================================================================
    # 4. READ OPERATION
    # =========================================================================
    print(f"[*] Reading 0x{size:08X} bytes from 0x{address:08X} -> {output_file}")
    
    try:
        with open(output_file, 'wb') as f:
            bytes_read = 0
            retry_count = 0
            max_retries = 3
            
            with ProgressBar(size, prefix='Reading', suffix='Complete', length=50) as progress:
                while bytes_read < size:
                    chunk_addr = address + bytes_read
                    remaining = size - bytes_read
                    current_chunk = min(chunk_size, remaining)
                    
                    try:
                        # Build READ command
                        read_payload = struct.pack("<II", chunk_addr, current_chunk)
                        
                        if "READ" in QSLCLPAR_DB:
                            resp = qslcl_dispatch(dev, "READ", read_payload)
                        else:
                            # Fallback to generic read
                            cmd = f"READ 0x{chunk_addr:08X} 0x{current_chunk:04X}"
                            resp = qslcl_dispatch(dev, "READ", cmd.encode())
                        
                        if resp:
                            status = decode_runtime_result(resp)
                            if status["severity"] == "SUCCESS":
                                data = status["extra"]
                                if len(data) > 0:
                                    f.write(data)
                                    bytes_read += len(data)
                                    progress.update(len(data))
                                    retry_count = 0  # Reset retry counter on success
                                else:
                                    print(f"[!] Empty response at 0x{chunk_addr:08X}")
                                    retry_count += 1
                            else:
                                print(f"[!] Read error at 0x{chunk_addr:08X}: {status}")
                                retry_count += 1
                        else:
                            print(f"[!] No response at 0x{chunk_addr:08X}")
                            retry_count += 1
                        
                        # Handle retries
                        if retry_count >= max_retries:
                            print(f"[!] Max retries exceeded at 0x{chunk_addr:08X}")
                            break
                            
                    except Exception as e:
                        print(f"[!] Read exception at 0x{chunk_addr:08X}: {e}")
                        retry_count += 1
                        if retry_count >= max_retries:
                            break
                        time.sleep(0.1)  # Brief pause before retry

        # =========================================================================
        # 5. VERIFICATION (if enabled)
        # =========================================================================
        if not no_verify and bytes_read > 0:
            print("[*] Verifying read operation...")
            file_size = os.path.getsize(output_file)
            if file_size == bytes_read:
                print(f"[+] Verification passed: {file_size} bytes read")
                
                # Calculate checksum
                with open(output_file, 'rb') as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
                print(f"[+] SHA256: {file_hash}")
            else:
                print(f"[!] Verification failed: expected {bytes_read}, got {file_size} bytes")

        # =========================================================================
        # 6. FINAL SUMMARY
        # =========================================================================
        if bytes_read > 0:
            print(f"\n[+] READ completed successfully!")
            print(f"    Address: 0x{address:08X}")
            print(f"    Size: 0x{bytes_read:08X} ({bytes_read} bytes)")
            print(f"    Output: {output_file}")
            print(f"    Success rate: {bytes_read/size*100:.1f}%")
            
            # Show first few bytes for verification
            if bytes_read >= 16:
                with open(output_file, 'rb') as f:
                    first_bytes = f.read(16)
                print(f"    First 16 bytes: {first_bytes.hex().upper()}")
        else:
            print("[!] READ failed: No data read")
            # Clean up empty file
            if os.path.exists(output_file):
                os.remove(output_file)

    except Exception as e:
        print(f"[!] READ operation failed: {e}")
        # Clean up on failure
        if os.path.exists(output_file):
            os.remove(output_file)

# =============================================================================
# SUPPORTING FUNCTIONS FOR READ COMMAND
# =============================================================================

def parse_address(addr_str):
    """Parse address string (hex, decimal, or expression)"""
    addr_str = str(addr_str).strip().lower()
    
    # Remove common prefixes
    if addr_str.startswith('0x'):
        return int(addr_str, 16)
    elif addr_str.startswith('$'):
        return int(addr_str[1:], 16)
    else:
        # Try decimal first, then hex
        try:
            return int(addr_str)
        except ValueError:
            return int(addr_str, 16)

def parse_size_string(size_str):
    """Parse size string with units (e.g., '4K', '1M', '0x1000')"""
    size_str = str(size_str).strip().upper()
    
    # Hex format
    if size_str.startswith('0X'):
        return int(size_str, 16)
    
    # Size with units
    units = {'K': 1024, 'M': 1024*1024, 'G': 1024*1024*1024}
    if size_str[-1] in units:
        number = size_str[:-1]
        unit = size_str[-1]
        return int(number) * units[unit]
    
    # Plain decimal
    return int(size_str)

def load_partitions(dev):
    """Enhanced partition loading with actual device query"""
    global PARTITION_CACHE
    
    # Return cached partitions if available
    if PARTITION_CACHE:
        return PARTITION_CACHE
    
    partitions = []
    
    try:
        # Try to get partitions from device
        if "GETVAR" in QSLCLPAR_DB:
            # Query partition table
            resp = qslcl_dispatch(dev, "GETVAR", b"partitions")
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    # Parse partition data from response
                    partition_data = parse_partition_table(status["extra"])
                    if partition_data:
                        partitions = partition_data
                        print(f"[+] Loaded {len(partitions)} partitions from device")
        
        # If no partitions from device, use fallback
        if not partitions:
            partitions = [
                {"name": "boot", "offset": 0x880000, "size": 0x400000},
                {"name": "system", "offset": 0xC80000, "size": 0x8000000},
                {"name": "recovery", "offset": 0x88C80000, "size": 0x400000},
                {"name": "cache", "offset": 0x90C80000, "size": 0x4000000},
                {"name": "userdata", "offset": 0x94C80000, "size": 0x40000000},
                {"name": "misc", "offset": 0x88000000, "size": 0x100000},
                {"name": "persist", "offset": 0x88100000, "size": 0x2000000},
            ]
            print("[*] Using fallback partition table")
    
    except Exception as e:
        print(f"[!] Partition loading failed: {e}")
        # Return minimal fallback
        partitions = [
            {"name": "boot", "offset": 0x880000, "size": 0x400000},
        ]
    
    PARTITION_CACHE = partitions
    return partitions

def parse_partition_table(data):
    """Parse partition table from binary data"""
    partitions = []
    
    if not data or len(data) < 16:
        return partitions
    
    try:
        # Simple partition table format: name(16) + offset(4) + size(4)
        pos = 0
        while pos + 24 <= len(data):
            name = data[pos:pos+16].decode('ascii', errors='ignore').rstrip('\x00')
            offset = struct.unpack("<I", data[pos+16:pos+20])[0]
            size = struct.unpack("<I", data[pos+20:pos+24])[0]
            
            if name and offset > 0 and size > 0:
                partitions.append({
                    "name": name,
                    "offset": offset,
                    "size": size
                })
            
            pos += 24
            
    except Exception as e:
        print(f"[!] Partition table parse error: {e}")
    
    return partitions