def cmd_verify(args):
    """
    Advanced VERIFY command handler for comprehensive system verification and validation
    Supports firmware verification, integrity checks, signature validation, and security audits
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse VERIFY subcommand
    if not hasattr(args, 'verify_subcommand') or not args.verify_subcommand:
        return print("[!] VERIFY command requires subcommand (list, integrity, signature, checksum, security, etc.)")
    
    subcmd = args.verify_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_verify_commands(dev)
    elif subcmd == "INTEGRITY":
        return verify_system_integrity(dev, args)
    elif subcmd == "SIGNATURE":
        return verify_signatures(dev, args)
    elif subcmd == "CHECKSUM":
        return verify_checksums(dev, args)
    elif subcmd == "SECURITY":
        return verify_security_policies(dev, args)
    elif subcmd == "BOOT":
        return verify_boot_components(dev, args)
    elif subcmd == "FIRMWARE":
        return verify_firmware_integrity(dev, args)
    elif subcmd == "PARTITION":
        return verify_partition_integrity(dev, args)
    elif subcmd == "MEMORY":
        return verify_memory_integrity(dev, args)
    elif subcmd == "CERTIFICATE":
        return verify_certificates(dev, args)
    elif subcmd == "AUTHENTICATION":
        return verify_authentication(dev, args)
    elif subcmd == "COMPREHENSIVE":
        return run_comprehensive_verification(dev, args)
    elif subcmd == "REPORT":
        return generate_verification_report(dev, args)
    else:
        return handle_verification_operation(dev, subcmd, args)

def list_available_verify_commands(dev):
    """
    List all available VERIFY commands from QSLCL loader
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL VERIFICATION COMMANDS")
    print("="*60)
    
    verify_found = []
    
    # Check QSLCLPAR for VERIFY commands
    print("\n[QSLCLPAR] Verify Commands:")
    par_verify = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "VERIFY", "VALIDATE", "CHECK", "INTEGRITY", "SIGNATURE", 
        "CHECKSUM", "AUTHENTICATE", "CERTIFICATE", "SECURE", "HASH"
    ])]
    for verify_cmd in par_verify:
        print(f"  • {verify_cmd}")
        verify_found.append(verify_cmd)
    
    # Check QSLCLEND for verify-related opcodes
    print("\n[QSLCLEND] Verify Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["VERIFY", "VALIDATE", "CHECK", "INTEGRITY"]) or any(x in entry_str for x in ["VERIFY", "CHECK"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            verify_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for verify microservices
    print("\n[QSLCLVM5] Verify Microservices:")
    vm5_verify = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["VERIFY", "VALIDATE", "CHECK"])]
    for verify_cmd in vm5_verify:
        print(f"  • {verify_cmd}")
        verify_found.append(f"VM5_{verify_cmd}")
    
    # Check QSLCLIDX for verify indices
    print("\n[QSLCLIDX] Verify Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["VERIFY", "VALIDATE", "CHECK"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                verify_found.append(f"IDX_{name}")
    
    if not verify_found:
        print("  No verify commands found in loader")
    else:
        print(f"\n[*] Total verify commands found: {len(verify_found)}")
    
    print("\n[*] Common Verification Operations Available:")
    print("  • INTEGRITY     - System integrity verification")
    print("  • SIGNATURE     - Digital signature validation")
    print("  • CHECKSUM      - Checksum and hash verification")
    print("  • SECURITY      - Security policy verification")
    print("  • BOOT          - Boot component verification")
    print("  • FIRMWARE      - Firmware integrity check")
    print("  • PARTITION     - Partition table verification")
    print("  • MEMORY        - Memory integrity check")
    print("  • CERTIFICATE   - Certificate chain validation")
    print("  • AUTHENTICATION- Authentication mechanism verification")
    print("  • COMPREHENSIVE - Complete system verification")
    print("  • REPORT        - Generate verification report")
    
    print("="*60)
    
    return True

def verify_system_integrity(dev, args):
    """
    Verify system integrity across multiple components
    """
    print("[*] Starting system integrity verification...")
    
    verification_results = {}
    
    # Verify bootloader integrity
    print("\n[1/6] Verifying bootloader integrity...")
    bootloader_result = verify_bootloader_integrity(dev)
    verification_results["bootloader"] = bootloader_result
    print(f"  Bootloader: {'PASS' if bootloader_result else 'FAIL'}")
    
    # Verify partition table integrity
    print("\n[2/6] Verifying partition table integrity...")
    partition_result = verify_partition_table_integrity(dev)
    verification_results["partition_table"] = partition_result
    print(f"  Partition Table: {'PASS' if partition_result else 'FAIL'}")
    
    # Verify critical partitions
    print("\n[3/6] Verifying critical partitions...")
    critical_partitions = verify_critical_partitions(dev)
    verification_results["critical_partitions"] = critical_partitions
    print(f"  Critical Partitions: {len([p for p in critical_partitions if critical_partitions[p]])}/{len(critical_partitions)} passed")
    
    # Verify firmware integrity
    print("\n[4/6] Verifying firmware integrity...")
    firmware_result = verify_firmware_components(dev)
    verification_results["firmware"] = firmware_result
    print(f"  Firmware: {'PASS' if firmware_result else 'FAIL'}")
    
    # Verify security mechanisms
    print("\n[5/6] Verifying security mechanisms...")
    security_result = verify_security_integrity(dev)
    verification_results["security"] = security_result
    print(f"  Security: {'PASS' if security_result else 'FAIL'}")
    
    # Verify memory integrity
    print("\n[6/6] Verifying memory integrity...")
    memory_result = verify_memory_regions(dev)
    verification_results["memory"] = memory_result
    print(f"  Memory: {'PASS' if memory_result else 'FAIL'}")
    
    # Generate summary
    print("\n" + "="*50)
    print("[*] SYSTEM INTEGRITY VERIFICATION SUMMARY")
    print("="*50)
    
    total_checks = len(verification_results)
    passed_checks = sum(1 for result in verification_results.values() if result is True or (isinstance(result, dict) and all(result.values())))
    
    for check, result in verification_results.items():
        status = "PASS" if (result is True or (isinstance(result, dict) and all(result.values()))) else "FAIL"
        print(f"  • {check.replace('_', ' ').title():<20} : {status}")
    
    print(f"\n  Overall Integrity: {passed_checks}/{total_checks} checks passed")
    
    if passed_checks == total_checks:
        print("[✓] SYSTEM INTEGRITY: VERIFIED")
        return True
    else:
        print("[!] SYSTEM INTEGRITY: COMPROMISED")
        return False

def verify_bootloader_integrity(dev):
    """
    Verify bootloader integrity and authenticity
    """
    try:
        # Read bootloader regions
        bootloader_regions = [
            (0x00000000, 0x00100000, "Primary Bootloader"),
            (0x00100000, 0x00200000, "Secondary Bootloader"),
            (0x88000000, 0x88100000, "Boot Partition")
        ]
        
        for start, end, description in bootloader_regions:
            # Calculate checksum of bootloader region
            size = end - start
            payload = struct.pack("<Q I", start, min(size, 65536))  # Read first 64KB for verification
            resp = qslcl_dispatch(dev, "READ", payload)
            
            if not resp:
                print(f"    [!] Failed to read {description}")
                return False
            
            status = decode_runtime_result(resp)
            if status.get("severity") != "SUCCESS":
                print(f"    [!] Read failed for {description}")
                return False
            
            data = status.get("extra", b"")
            if not data:
                print(f"    [!] Empty data for {description}")
                return False
            
            # Calculate simple checksum
            checksum = sum(data) & 0xFFFFFFFF
            print(f"    [✓] {description}: 0x{checksum:08X}")
        
        return True
        
    except Exception as e:
        print(f"    [!] Bootloader verification error: {e}")
        return False

def verify_partition_table_integrity(dev):
    """
    Verify partition table integrity
    """
    try:
        # Read GPT header (LBA 0)
        payload = struct.pack("<Q I", 0, 512)
        resp = qslcl_dispatch(dev, "READ", payload)
        
        if not resp:
            return False
        
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            return False
        
        data = status.get("extra", b"")
        if len(data) < 512:
            return False
        
        # Check for valid GPT signature
        if data[0x200:0x208] == b"EFI PART":
            print("    [✓] GPT Signature: Valid")
            
            # Verify GPT header checksum
            header_checksum = struct.unpack("<I", data[0x210:0x214])[0]
            print(f"    [✓] GPT Header Checksum: 0x{header_checksum:08X}")
            return True
        else:
            print("    [!] GPT Signature: Invalid")
            return False
            
    except Exception as e:
        print(f"    [!] Partition table verification error: {e}")
        return False

def verify_critical_partitions(dev):
    """
    Verify integrity of critical partitions
    """
    critical_partitions = {
        "boot": "Boot partition",
        "recovery": "Recovery partition", 
        "system": "System partition",
        "vendor": "Vendor partition"
    }
    
    results = {}
    
    for part_name, description in critical_partitions.items():
        try:
            addr, size = resolve_partition(part_name)
            if addr and size:
                # Read first sector for basic verification
                payload = struct.pack("<Q I", addr, 512)
                resp = qslcl_dispatch(dev, "READ", payload)
                
                if resp:
                    status = decode_runtime_result(resp)
                    if status.get("severity") == "SUCCESS":
                        data = status.get("extra", b"")
                        if data and data != b"\x00" * len(data):
                            results[part_name] = True
                            print(f"    [✓] {description}: Accessible")
                            continue
            
            results[part_name] = False
            print(f"    [!] {description}: Inaccessible")
            
        except:
            results[part_name] = False
            print(f"    [!] {description}: Not found")
    
    return results

def verify_firmware_components(dev):
    """
    Verify firmware component integrity
    """
    try:
        # Try firmware verification command
        resp = qslcl_dispatch(dev, "VERIFY", b"FIRMWARE\x00")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print("    [✓] Firmware verification: Signed and valid")
                return True
        
        # Fallback: Check common firmware regions
        firmware_regions = [
            (0x40000000, 0x40100000, "Modem Firmware"),
            (0x41000000, 0x41100000, "DSP Firmware"),
            (0x42000000, 0x42100000, "GPU Firmware")
        ]
        
        for start, end, description in firmware_regions:
            payload = struct.pack("<Q I", start, 4096)
            resp = qslcl_dispatch(dev, "READ", payload)
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    data = status.get("extra", b"")
                    if data and data != b"\x00" * len(data):
                        print(f"    [✓] {description}: Present")
        
        return True
        
    except Exception as e:
        print(f"    [!] Firmware verification error: {e}")
        return False

def verify_security_integrity(dev):
    """
    Verify security mechanism integrity
    """
    try:
        # Check secure boot status
        resp = qslcl_dispatch(dev, "VERIFY", b"SECURE_BOOT\x00")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print("    [✓] Secure Boot: Enabled and valid")
                return True
        
        # Check verified boot status
        resp = qslcl_dispatch(dev, "VERIFY", b"VERIFIED_BOOT\x00")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print("    [✓] Verified Boot: Enabled and valid")
                return True
        
        print("    [!] Security mechanisms: Not verified")
        return False
        
    except Exception as e:
        print(f"    [!] Security verification error: {e}")
        return False

def verify_memory_regions(dev):
    """
    Verify memory region integrity
    """
    try:
        # Test critical memory regions
        test_regions = [
            (0x80000000, 4096, "Kernel Memory"),
            (0x81000000, 4096, "System Memory"),
            (0x82000000, 4096, "Driver Memory")
        ]
        
        for addr, size, description in test_regions:
            payload = struct.pack("<Q I", addr, size)
            resp = qslcl_dispatch(dev, "READ", payload)
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    print(f"    [✓] {description}: Accessible")
        
        return True
        
    except Exception as e:
        print(f"    [!] Memory verification error: {e}")
        return False

def verify_signatures(dev, args):
    """
    Verify digital signatures of system components
    """
    print("[*] Starting digital signature verification...")
    
    target_component = None
    if hasattr(args, 'verify_args') and args.verify_args:
        target_component = args.verify_args[0].upper()
    
    signature_results = {}
    
    components_to_verify = [
        "BOOTLOADER", "KERNEL", "RECOVERY", "SYSTEM", "VENDOR",
        "MODEM", "DSP", "GPU", "BOOT", "TRUSTZONE"
    ]
    
    if target_component and target_component in components_to_verify:
        components_to_verify = [target_component]
    
    for component in components_to_verify:
        print(f"\n[*] Verifying {component} signature...")
        
        payload = component.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"SIGNATURE\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                signature_results[component] = True
                print(f"  [✓] {component}: Signature valid")
                
                # Extract signature details if available
                extra = status.get("extra", b"")
                if extra:
                    try:
                        sig_info = extra.decode('utf-8', errors='ignore')
                        print(f"       Details: {sig_info}")
                    except:
                        print(f"       Signature hash: {extra.hex()[:32]}...")
            else:
                signature_results[component] = False
                print(f"  [!] {component}: Signature invalid - {status.get('name', 'UNKNOWN')}")
        else:
            signature_results[component] = False
            print(f"  [!] {component}: No signature verification available")
    
    # Summary
    valid_signatures = sum(signature_results.values())
    total_signatures = len(signature_results)
    
    print(f"\n[*] Signature Verification Summary: {valid_signatures}/{total_signatures} valid")
    
    if valid_signatures == total_signatures:
        print("[✓] ALL SIGNATURES VERIFIED")
        return True
    else:
        print("[!] SOME SIGNATURES INVALID")
        return False

def verify_checksums(dev, args):
    """
    Verify checksums and hashes of system components
    """
    print("[*] Starting checksum verification...")
    
    target_component = None
    hash_type = "SHA256"  # Default hash type
    
    if hasattr(args, 'verify_args') and args.verify_args:
        target_component = args.verify_args[0].upper()
        if len(args.verify_args) > 1:
            hash_type = args.verify_args[1].upper()
    
    checksum_results = {}
    
    # Supported hash types
    supported_hashes = ["CRC32", "MD5", "SHA1", "SHA256", "SHA512"]
    if hash_type not in supported_hashes:
        print(f"[!] Unsupported hash type: {hash_type}")
        print(f"[*] Supported: {', '.join(supported_hashes)}")
        hash_type = "SHA256"
    
    components_to_verify = [
        "BOOTLOADER", "KERNEL", "RECOVERY", "DTB", "RAMDISK"
    ]
    
    if target_component and target_component in components_to_verify:
        components_to_verify = [target_component]
    
    for component in components_to_verify:
        print(f"\n[*] Calculating {hash_type} for {component}...")
        
        payload = component.encode() + b"\x00" + hash_type.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"CHECKSUM\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                if extra:
                    checksum_results[component] = extra.hex()
                    print(f"  [✓] {component}: {extra.hex()}")
                else:
                    checksum_results[component] = "UNKNOWN"
                    print(f"  [!] {component}: No checksum returned")
            else:
                checksum_results[component] = "FAILED"
                print(f"  [!] {component}: Checksum calculation failed")
        else:
            checksum_results[component] = "UNAVAILABLE"
            print(f"  [!] {component}: No checksum verification available")
    
    # Save checksums to file if requested
    if hasattr(args, 'verify_args') and len(args.verify_args) > 2 and args.verify_args[2] == "save":
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"checksums_{timestamp}.txt"
        with open(filename, "w") as f:
            f.write(f"Checksum Verification Report - {timestamp}\n")
            f.write(f"Hash Type: {hash_type}\n")
            f.write("="*50 + "\n")
            for component, checksum in checksum_results.items():
                f.write(f"{component}: {checksum}\n")
        print(f"\n[✓] Checksums saved to: {filename}")
    
    return len([c for c in checksum_results.values() if c not in ["FAILED", "UNAVAILABLE"]]) > 0

def verify_security_policies(dev, args):
    """
    Verify security policies and configurations
    """
    print("[*] Starting security policy verification...")
    
    policy_results = {}
    
    # Check various security policies
    security_checks = [
        ("SECURE_BOOT", "Secure Boot Policy"),
        ("VERIFIED_BOOT", "Verified Boot Policy"),
        ("DM_VERITY", "DM-Verity Enforcement"),
        ("SELINUX", "SELinux Policy"),
        ("ENCRYPTION", "Data Encryption"),
        ("KASLR", "Kernel ASLR"),
        ("PAN", "Privileged Access Never"),
        ("PXN", "Privileged Execute Never")
    ]
    
    for policy_code, policy_name in security_checks:
        print(f"\n[*] Checking {policy_name}...")
        
        payload = policy_code.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"SECURITY\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                policy_results[policy_code] = True
                extra = status.get("extra", b"")
                if extra:
                    try:
                        policy_status = extra.decode('utf-8', errors='ignore')
                        print(f"  [✓] {policy_name}: {policy_status}")
                    except:
                        print(f"  [✓] {policy_name}: Enabled")
            else:
                policy_results[policy_code] = False
                print(f"  [!] {policy_name}: Not enforced - {status.get('name', 'UNKNOWN')}")
        else:
            policy_results[policy_code] = None
            print(f"  [?] {policy_name}: Check not available")
    
    # Security score calculation
    enforced_policies = sum(1 for result in policy_results.values() if result is True)
    total_checks = len([result for result in policy_results.values() if result is not None])
    
    security_score = (enforced_policies / total_checks * 100) if total_checks > 0 else 0
    
    print(f"\n[*] Security Policy Summary:")
    print(f"    Enforced Policies: {enforced_policies}/{total_checks}")
    print(f"    Security Score: {security_score:.1f}%")
    
    if security_score >= 80:
        print("[✓] SECURITY: STRONG")
    elif security_score >= 60:
        print("[~] SECURITY: MODERATE")
    else:
        print("[!] SECURITY: WEAK")
    
    return security_score >= 60

def verify_boot_components(dev, args):
    """
    Verify boot components and boot chain
    """
    print("[*] Starting boot component verification...")
    
    boot_results = {}
    
    boot_components = [
        ("PBL", "Primary Bootloader"),
        ("SBL", "Secondary Bootloader"),
        ("ABOOT", "Android Bootloader"),
        ("TZ", "TrustZone"),
        ("RPM", "Resource Power Manager"),
        ("HLOS", "High-Level OS Kernel")
    ]
    
    for component_code, component_name in boot_components:
        print(f"\n[*] Verifying {component_name}...")
        
        payload = component_code.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"BOOT\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                boot_results[component_code] = True
                extra = status.get("extra", b"")
                
                # Extract version information if available
                if extra:
                    try:
                        version_info = extra.decode('utf-8', errors='ignore')
                        print(f"  [✓] {component_name}: Valid - {version_info}")
                    except:
                        print(f"  [✓] {component_name}: Valid")
            else:
                boot_results[component_code] = False
                print(f"  [!] {component_name}: Invalid - {status.get('name', 'UNKNOWN')}")
        else:
            boot_results[component_code] = None
            print(f"  [?] {component_name}: Verification not available")
    
    # Boot chain validation
    valid_components = sum(1 for result in boot_results.values() if result is True)
    print(f"\n[*] Boot Chain Validation: {valid_components}/{len(boot_components)} components valid")
    
    if valid_components == len(boot_components):
        print("[✓] BOOT CHAIN: FULLY VERIFIED")
        return True
    else:
        print("[!] BOOT CHAIN: POTENTIALLY COMPROMISED")
        return False

def verify_firmware_integrity(dev, args):
    """
    Verify firmware integrity across all components
    """
    print("[*] Starting firmware integrity verification...")
    
    firmware_results = {}
    
    firmware_components = [
        ("MODEM", "Modem Firmware"),
        ("DSP", "Digital Signal Processor"),
        ("GPU", "Graphics Processor"),
        ("WLAN", "Wireless LAN"),
        ("BT", "Bluetooth"),
        ("NFC", "Near Field Communication"),
        ("GPS", "Global Positioning System"),
        ("SENSORS", "Sensor Hub")
    ]
    
    for component_code, component_name in firmware_components:
        print(f"\n[*] Verifying {component_name} firmware...")
        
        payload = component_code.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"FIRMWARE\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                firmware_results[component_code] = True
                extra = status.get("extra", b"")
                
                if len(extra) >= 4:
                    # Assume first 4 bytes are version info
                    version = struct.unpack("<I", extra[:4])[0]
                    print(f"  [✓] {component_name}: Valid (v{version})")
                else:
                    print(f"  [✓] {component_name}: Valid")
            else:
                firmware_results[component_code] = False
                print(f"  [!] {component_name}: Corrupted - {status.get('name', 'UNKNOWN')}")
        else:
            firmware_results[component_code] = None
            print(f"  [?] {component_name}: Verification not available")
    
    valid_firmware = sum(1 for result in firmware_results.values() if result is True)
    print(f"\n[*] Firmware Integrity: {valid_firmware}/{len(firmware_components)} components valid")
    
    return valid_firmware >= len(firmware_components) * 0.8  # 80% threshold

def verify_partition_integrity(dev, args):
    """
    Verify partition integrity and structure
    """
    print("[*] Starting partition integrity verification...")
    
    if hasattr(args, 'verify_args') and args.verify_args:
        specific_partition = args.verify_args[0].lower()
        return verify_single_partition(dev, specific_partition)
    
    # Verify all partitions
    partitions = load_partitions(dev)
    partition_results = {}
    
    for partition in partitions:
        part_name = partition["name"]
        print(f"\n[*] Verifying partition: {part_name}")
        
        result = verify_single_partition(dev, part_name)
        partition_results[part_name] = result
    
    valid_partitions = sum(partition_results.values())
    print(f"\n[*] Partition Integrity: {valid_partitions}/{len(partitions)} partitions valid")
    
    return valid_partitions == len(partitions)

def verify_single_partition(dev, partition_name):
    """
    Verify a single partition's integrity
    """
    try:
        addr, size = resolve_partition(partition_name)
        if not addr or not size:
            print(f"  [!] {partition_name}: Cannot resolve address")
            return False
        
        # Read partition header
        payload = struct.pack("<Q I", addr, min(size, 4096))
        resp = qslcl_dispatch(dev, "READ", payload)
        
        if not resp:
            print(f"  [!] {partition_name}: Read failed")
            return False
        
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            print(f"  [!] {partition_name}: Read error")
            return False
        
        data = status.get("extra", b"")
        if not data:
            print(f"  [!] {partition_name}: Empty data")
            return False
        
        # Basic partition validation
        if data == b"\x00" * len(data):
            print(f"  [!] {partition_name}: Appears erased")
            return False
        
        print(f"  [✓] {partition_name}: Structurally valid")
        return True
        
    except Exception as e:
        print(f"  [!] {partition_name}: Verification error - {e}")
        return False

def verify_memory_integrity(dev, args):
    """
    Verify memory integrity and test memory regions
    """
    print("[*] Starting memory integrity verification...")
    
    # Test critical memory regions
    memory_regions = [
        (0x80000000, 0x1000, "Kernel Code"),
        (0x81000000, 0x1000, "System Data"),
        (0x82000000, 0x1000, "Driver Space"),
        (0x83000000, 0x1000, "User Space")
    ]
    
    memory_results = {}
    
    for addr, size, description in memory_regions:
        print(f"\n[*] Testing {description} (0x{addr:08X})...")
        
        # Test read access
        payload = struct.pack("<Q I", addr, size)
        resp = qslcl_dispatch(dev, "READ", payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                memory_results[description] = True
                data = status.get("extra", b"")
                print(f"  [✓] {description}: Readable ({len(data)} bytes)")
            else:
                memory_results[description] = False
                print(f"  [!] {description}: Read failed")
        else:
            memory_results[description] = False
            print(f"  [!] {description}: No response")
    
    # Memory integrity score
    accessible_regions = sum(memory_results.values())
    print(f"\n[*] Memory Integrity: {accessible_regions}/{len(memory_regions)} regions accessible")
    
    return accessible_regions == len(memory_regions)

def verify_certificates(dev, args):
    """
    Verify certificate chains and PKI infrastructure
    """
    print("[*] Starting certificate verification...")
    
    certificate_results = {}
    
    certificate_types = [
        "BOOT", "SYSTEM", "VENDOR", "MODEM", "OEM", "PLATFORM"
    ]
    
    for cert_type in certificate_types:
        print(f"\n[*] Verifying {cert_type} certificates...")
        
        payload = cert_type.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"CERTIFICATE\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                certificate_results[cert_type] = True
                extra = status.get("extra", b"")
                
                if extra:
                    try:
                        cert_info = extra.decode('utf-8', errors='ignore')
                        print(f"  [✓] {cert_type}: Valid - {cert_info}")
                    except:
                        print(f"  [✓] {cert_type}: Valid")
            else:
                certificate_results[cert_type] = False
                print(f"  [!] {cert_type}: Invalid - {status.get('name', 'UNKNOWN')}")
        else:
            certificate_results[cert_type] = None
            print(f"  [?] {cert_type}: Verification not available")
    
    valid_certificates = sum(1 for result in certificate_results.values() if result is True)
    print(f"\n[*] Certificate Verification: {valid_certificates}/{len(certificate_types)} valid")
    
    return valid_certificates == len(certificate_types)

def verify_authentication(dev, args):
    """
    Verify authentication mechanisms and credentials
    """
    print("[*] Starting authentication verification...")
    
    auth_results = {}
    
    auth_methods = [
        "BOOTLOADER", "SYSTEM", "RECOVERY", "FASTBOOT", "EDL"
    ]
    
    for auth_method in auth_methods:
        print(f"\n[*] Testing {auth_method} authentication...")
        
        payload = auth_method.encode() + b"\x00"
        resp = qslcl_dispatch(dev, "VERIFY", b"AUTHENTICATION\x00" + payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                auth_results[auth_method] = True
                print(f"  [✓] {auth_method}: Authentication successful")
            else:
                auth_results[auth_method] = False
                print(f"  [!] {auth_method}: Authentication failed - {status.get('name', 'UNKNOWN')}")
        else:
            auth_results[auth_method] = None
            print(f"  [?] {auth_method}: Authentication test not available")
    
    successful_auth = sum(1 for result in auth_results.values() if result is True)
    print(f"\n[*] Authentication Summary: {successful_auth}/{len(auth_methods)} methods successful")
    
    return successful_auth > 0

def run_comprehensive_verification(dev, args):
    """
    Run comprehensive system verification covering all aspects
    """
    print("[*] Starting COMPREHENSIVE system verification...")
    print("[*] This may take several minutes...\n")
    
    comprehensive_results = {}
    
    # Run all verification types
    verification_functions = [
        ("System Integrity", verify_system_integrity),
        ("Digital Signatures", verify_signatures),
        ("Security Policies", verify_security_policies),
        ("Boot Components", verify_boot_components),
        ("Firmware Integrity", verify_firmware_integrity),
        ("Partition Integrity", verify_partition_integrity),
        ("Memory Integrity", verify_memory_integrity),
        ("Certificate Chain", verify_certificates),
        ("Authentication", verify_authentication)
    ]
    
    for verification_name, verification_func in verification_functions:
        print(f"\n{'='*60}")
        print(f"[*] RUNNING: {verification_name}")
        print('='*60)
        
        try:
            result = verification_func(dev, args)
            comprehensive_results[verification_name] = result
            print(f"\n[*] {verification_name}: {'PASS' if result else 'FAIL'}")
        except Exception as e:
            print(f"\n[!] {verification_name}: ERROR - {e}")
            comprehensive_results[verification_name] = False
        
        time.sleep(1)  # Brief pause between tests
    
    # Generate comprehensive report
    print(f"\n{'='*60}")
    print("[*] COMPREHENSIVE VERIFICATION COMPLETE")
    print('='*60)
    
    total_tests = len(comprehensive_results)
    passed_tests = sum(comprehensive_results.values())
    success_rate = (passed_tests / total_tests) * 100
    
    print(f"\nVerification Results:")
    for test_name, result in comprehensive_results.items():
        status = "PASS" if result else "FAIL"
        print(f"  • {test_name:<25} : {status}")
    
    print(f"\nOverall Success Rate: {success_rate:.1f}% ({passed_tests}/{total_tests})")
    
    if success_rate >= 90:
        print("[✓] SYSTEM VERIFICATION: EXCELLENT")
    elif success_rate >= 75:
        print("[~] SYSTEM VERIFICATION: GOOD")
    elif success_rate >= 60:
        print("[!] SYSTEM VERIFICATION: FAIR")
    else:
        print("[!] SYSTEM VERIFICATION: POOR")
    
    return success_rate >= 75

def generate_verification_report(dev, args):
    """
    Generate detailed verification report
    """
    print("[*] Generating comprehensive verification report...")
    
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    report_data = {
        "timestamp": timestamp,
        "device_info": get_device_info_for_report(dev),
        "verification_results": {}
    }
    
    # Run verifications and collect results
    verification_functions = [
        ("system_integrity", verify_system_integrity),
        ("signatures", verify_signatures),
        ("security_policies", verify_security_policies),
        ("boot_components", verify_boot_components)
    ]
    
    for verification_id, verification_func in verification_functions:
        try:
            result = verification_func(dev, args)
            report_data["verification_results"][verification_id] = result
        except Exception as e:
            report_data["verification_results"][verification_id] = f"ERROR: {e}"
    
    # Save report to file
    filename = f"verification_report_{time.strftime('%Y%m%d_%H%M%S')}.json"
    try:
        import json
        with open(filename, 'w') as f:
            json.dump(report_data, f, indent=2)
        print(f"[✓] Verification report saved to: {filename}")
        return True
    except Exception as e:
        print(f"[!] Failed to save report: {e}")
        return False

def get_device_info_for_report(dev):
    """
    Get device information for verification report
    """
    device_info = {}
    
    try:
        # Get basic device info
        resp = qslcl_dispatch(dev, "GETINFO", b"")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                extra = status.get("extra", b"")
                device_info["device_info"] = extra.decode('utf-8', errors='ignore')[:100] + "..."
    except:
        pass
    
    return device_info

def handle_verification_operation(dev, operation, args):
    """
    Handle other verification operations
    """
    print(f"[*] Executing verification operation: {operation}")
    
    # Build operation parameters
    params = build_verification_params(operation, args)
    
    # Try different verification strategies
    strategies = [
        try_direct_verification,
        try_par_verification_command,
        try_end_verification_opcode,
        try_vm5_verification_service,
        try_idx_verification_command,
    ]
    
    for strategy in strategies:
        success = strategy(dev, operation, params)
        if success is not None:
            return success
    
    print(f"[!] Failed to execute verification operation: {operation}")
    return False

def build_verification_params(operation, args):
    """
    Build parameters for verification operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'verify_args'):
        for arg in args.verify_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

# Strategy implementations
def try_direct_verification(dev, operation, params):
    resp = qslcl_dispatch(dev, "VERIFY", operation.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {operation} verification successful")
        return True
    return None

def try_par_verification_command(dev, operation, params):
    if operation in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, operation, params)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} verified via QSLCLPAR")
            return True
    return None

def try_end_verification_opcode(dev, operation, params):
    opcode = sum(operation.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} verified via QSLCLEND opcode 0x{opcode:02X}")
            return True
    return None

def try_vm5_verification_service(dev, operation, params):
    if operation in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[operation]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} verified via QSLCLVM5")
            return True
    return None

def try_idx_verification_command(dev, operation, params):
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == operation:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
            resp = qslcl_dispatch(dev, "IDX", pkt)
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {operation} verified via QSLCLIDX {name}")
                return True
    return None

# Update the argument parser in main() function
def update_verify_parser(sub):
    """
    Update the VERIFY command parser with new subcommands
    """
    verify_parser = sub.add_parser("verify", help="System verification and validation commands")
    verify_parser.add_argument("verify_subcommand", help="Verify subcommand (list, integrity, signature, checksum, security, boot, firmware, partition, memory, certificate, authentication, comprehensive, report)")
    verify_parser.add_argument("verify_args", nargs="*", help="Additional arguments for verify command")
    verify_parser.set_defaults(func=cmd_verify)