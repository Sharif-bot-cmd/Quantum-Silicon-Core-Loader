def cmd_reset(args=None):
    """
    Fully implemented RESET command with advanced features:
    - Multiple reset types (soft, hard, force, domain-specific)
    - Safe reboot sequences and timing control
    - Pre-reset validation and safety checks
    - Post-reset verification and monitoring
    - Custom reset sequences and patterns
    """
    if not args:
        print("[!] RESET: No arguments provided")
        print_reset_help()
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'reset_subcommand', '').lower()
    reset_args = getattr(args, 'reset_args', [])
    force_reset = getattr(args, 'force_reset', False)
    
    # Extract optional delay and timeout parameters from reset_args or args
    delay = 0
    timeout = 30
    
    # Check if delay/timeout are in reset_args
    if reset_args:
        for i, arg in enumerate(reset_args):
            if arg == '--delay' and i + 1 < len(reset_args):
                try:
                    delay = int(reset_args[i + 1])
                except ValueError:
                    pass
            elif arg == '--timeout' and i + 1 < len(reset_args):
                try:
                    timeout = int(reset_args[i + 1])
                except ValueError:
                    pass
    
    # Also check args attributes
    if hasattr(args, 'delay'):
        delay = args.delay
    if hasattr(args, 'timeout'):
        timeout = args.timeout

    if not subcommand:
        print("[!] RESET: No subcommand specified")
        print_reset_help()
        return

    print(f"[*] RESET command: {subcommand} {reset_args}")

    # =========================================================================
    # 1. SUBCOMMAND DISPATCH
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'types']:
            reset_list(dev, reset_args)
            
        elif subcommand in ['soft', 'warm', 'normal']:
            reset_soft(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['hard', 'cold', 'full']:
            reset_hard(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['force', 'emergency', 'panic']:
            reset_force(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['domain', 'subsystem']:
            reset_domain(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['recovery', 'recovery-mode']:
            reset_recovery(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['factory', 'wipe', 'clean']:
            reset_factory(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['bootloader', 'download', 'edl']:
            reset_bootloader(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['pmic', 'power']:
            reset_pmic(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['watchdog', 'wdt']:
            reset_watchdog(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['custom', 'sequence']:
            reset_custom(dev, reset_args, force_reset, delay, timeout)
            
        elif subcommand in ['help', '?']:
            print_reset_help()
            
        else:
            print(f"[!] Unknown RESET subcommand: {subcommand}")
            print_reset_help()
            
    except Exception as e:
        print(f"[!] RESET operation failed: {e}")
        import traceback
        traceback.print_exc()

# =============================================================================
# RESET SUBCOMMAND IMPLEMENTATIONS
# =============================================================================

def reset_list(dev, args):
    """List available reset types and capabilities"""
    print("[*] Querying reset capabilities...")
    
    capabilities = query_reset_capabilities(dev)
    
    print(f"\n[+] RESET Capabilities:")
    print(f"    Device: {capabilities.get('device_name', 'Unknown')}")
    print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
    print(f"    Reset Support: {capabilities.get('reset_support', 'Basic')}")
    
    # List available reset types
    reset_types = capabilities.get('reset_types', [])
    if reset_types:
        print(f"\n[+] Available Reset Types:")
        for reset_type in reset_types:
            safety = reset_type.get('safety', 'UNKNOWN')
            safety_icon = "🟢" if safety == 'SAFE' else "🟡" if safety == 'WARNING' else "🔴"
            print(f"    {safety_icon} {reset_type['name']:15} - {reset_type.get('description', '')}")
    
    # List reset domains
    domains = capabilities.get('reset_domains', [])
    if domains:
        print(f"\n[+] Reset Domains:")
        for domain in domains:
            print(f"    {domain['name']:20} - {domain.get('description', '')}")

def reset_soft(dev, args, force=False, delay=0, timeout=30):
    """Perform soft reset (warm reboot)"""
    print("[*] Preparing SOFT reset...")
    
    # Safety checks
    if not force:
        print("[!] Soft reset will reboot the device.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print("[*] Initiating SOFT reset...")
    
    try:
        # Build soft reset command
        reset_payload = struct.pack("<B", 0x01)  # SOFT_RESET command
        reset_payload += struct.pack("<I", timeout)  # Timeout
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            # Fallback to direct command
            cmd_payload = b"SOFT_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Soft reset command accepted")
                print("[+] Device should reboot shortly...")
                monitor_reset_progress(dev, timeout, "soft")
            else:
                print(f"[!] Soft reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Reset may have occurred (device unresponsive)")
            
    except Exception as e:
        print(f"[!] Soft reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_hard(dev, args, force=False, delay=0, timeout=30):
    """Perform hard reset (cold reboot)"""
    print("[*] Preparing HARD reset...")
    
    # Safety warning
    if not force:
        print("[!] WARNING: Hard reset may cause data loss!")
        print("[!] Unsaved data will be lost!")
        response = input("    Type 'HARD' to continue: ")
        if response != 'HARD':
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print("[*] Initiating HARD reset...")
    
    try:
        # Build hard reset command
        reset_payload = struct.pack("<B", 0x02)  # HARD_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"HARD_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Hard reset command accepted")
                print("[+] Device will power cycle...")
                monitor_reset_progress(dev, timeout, "hard")
            else:
                print(f"[!] Hard reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Reset likely occurred (device unresponsive)")
            
    except Exception as e:
        print(f"[!] Hard reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_force(dev, args, force=False, delay=0, timeout=30):
    """Perform force reset (emergency reboot)"""
    print("[*] Preparing FORCE reset...")
    
    # Critical warning
    if not force:
        print("[!] CRITICAL WARNING: Force reset is aggressive!")
        print("[!] May cause hardware damage or data corruption!")
        print("[!] Use only as last resort!")
        response = input("    Type 'FORCE' to continue: ")
        if response != 'FORCE':
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print("[*] Initiating FORCE reset...")
    
    try:
        # Build force reset command
        reset_payload = struct.pack("<B", 0x03)  # FORCE_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"FORCE_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Force reset command accepted")
                print("[+] Emergency reboot initiated...")
                monitor_reset_progress(dev, timeout, "force")
            else:
                print(f"[!] Force reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Force reset likely occurred")
            
    except Exception as e:
        print(f"[!] Force reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_domain(dev, args, force=False, delay=0, timeout=30):
    """Reset specific subsystem or domain"""
    if not args:
        print("[!] Specify domain to reset")
        print("[*] Available domains: CPU, GPU, DSP, MODEM, WIFI, BT, USB, PCIE, MEMORY")
        return
    
    # Extract domain from args (handle if args is a list)
    if isinstance(args, list) and len(args) > 0:
        domain = args[0].upper()
        domain_args = args[1:] if len(args) > 1 else []
    else:
        domain = str(args).upper()
        domain_args = []
    
    print(f"[*] Preparing {domain} domain reset...")
    
    # Safety check for critical domains
    critical_domains = ['CPU', 'MEMORY', 'MODEM']
    if domain in critical_domains and not force:
        print(f"[!] WARNING: Resetting {domain} may cause system instability!")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print(f"[*] Resetting {domain} domain...")
    
    try:
        # Build domain reset command
        reset_payload = struct.pack("<B", 0x10)  # DOMAIN_RESET command
        reset_payload += domain.encode('ascii').ljust(8, b'\x00')
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"DOMAIN_RESET " + domain.encode('ascii') + b" " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] {domain} domain reset successful")
                print(f"[+] Subsystem should restart...")
            else:
                print(f"[!] {domain} domain reset failed: {status}")
        else:
            print(f"[!] No response for {domain} reset")
            
    except Exception as e:
        print(f"[!] {domain} domain reset error: {e}")

def reset_recovery(dev, args, force=False, delay=0, timeout=30):
    """Reboot into recovery mode"""
    print("[*] Preparing RECOVERY mode reboot...")
    
    if not force:
        print("[!] Device will boot into recovery mode.")
        print("[!] Normal system boot will not occur.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print("[*] Initiating recovery mode reboot...")
    
    try:
        # Build recovery reset command
        reset_payload = struct.pack("<B", 0x20)  # RECOVERY_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"RECOVERY_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Recovery mode reboot initiated")
                print("[+] Device should boot into recovery...")
                monitor_reset_progress(dev, timeout, "recovery")
            else:
                print(f"[!] Recovery reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Recovery reboot may have occurred")
            
    except Exception as e:
        print(f"[!] Recovery reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_factory(dev, args, force=False, delay=0, timeout=30):
    """Perform factory reset (wipe user data)"""
    print("[*] Preparing FACTORY RESET...")
    
    # Critical warning - this wipes data!
    if not force:
        print("[!] ⚠️  CRITICAL WARNING: FACTORY RESET WILL WIPE ALL USER DATA!")
        print("[!] ⚠️  All apps, settings, and personal data will be ERASED!")
        print("[!] ⚠️  This operation is IRREVERSIBLE!")
        response = input("    Type 'WIPE' to confirm factory reset: ")
        if response != 'WIPE':
            print("[*] Operation cancelled")
            return
    
    # Additional confirmation for factory reset
    print("[!] Are you ABSOLUTELY sure?")
    response = input("    Type 'FACTORY' for final confirmation: ")
    if response != 'FACTORY':
        print("[*] Factory reset cancelled")
        return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before factory reset...")
        time.sleep(delay)
        print("[*] LAST CHANCE: Ctrl+C to cancel in 3 seconds...")
        try:
            time.sleep(3)
        except KeyboardInterrupt:
            print("\n[*] Factory reset CANCELLED by user")
            return
    
    print("[*] Initiating FACTORY RESET...")
    
    try:
        # Build factory reset command
        reset_payload = struct.pack("<B", 0x30)  # FACTORY_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"FACTORY_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Factory reset initiated")
                print("[+] Device will wipe data and reboot...")
                print("[+] This may take several minutes...")
                monitor_reset_progress(dev, timeout, "factory")
            else:
                print(f"[!] Factory reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Factory reset may have started")
            
    except Exception as e:
        print(f"[!] Factory reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_bootloader(dev, args, force=False, delay=0, timeout=30):
    """Reboot into bootloader/download mode"""
    print("[*] Preparing BOOTLOADER mode reboot...")
    
    if not force:
        print("[!] Device will boot into bootloader mode.")
        print("[!] Normal system boot will not occur.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before reset...")
        time.sleep(delay)
    
    print("[*] Initiating bootloader mode reboot...")
    
    try:
        # Build bootloader reset command
        reset_payload = struct.pack("<B", 0x40)  # BOOTLOADER_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"BOOTLOADER_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Bootloader mode reboot initiated")
                print("[+] Device should enter download mode...")
                monitor_reset_progress(dev, timeout, "bootloader")
            else:
                print(f"[!] Bootloader reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Bootloader reboot may have occurred")
            
    except Exception as e:
        print(f"[!] Bootloader reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_pmic(dev, args, force=False, delay=0, timeout=30):
    """Reset PMIC (Power Management IC)"""
    print("[*] Preparing PMIC reset...")
    
    # Critical warning
    if not force:
        print("[!] WARNING: PMIC reset controls power hardware!")
        print("[!] Incorrect use may damage device!")
        response = input("    Type 'PMIC' to continue: ")
        if response != 'PMIC':
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before PMIC reset...")
        time.sleep(delay)
    
    print("[*] Initiating PMIC reset...")
    
    try:
        # Build PMIC reset command
        reset_payload = struct.pack("<B", 0x50)  # PMIC_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"PMIC_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] PMIC reset initiated")
                print("[+] Power management system resetting...")
            else:
                print(f"[!] PMIC reset failed: {status}")
        else:
            print("[!] No response from device")
            
    except Exception as e:
        print(f"[!] PMIC reset error: {e}")

def reset_watchdog(dev, args, force=False, delay=0, timeout=30):
    """Trigger watchdog reset"""
    print("[*] Preparing WATCHDOG reset...")
    
    if not force:
        print("[!] Watchdog reset will reboot the device.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before watchdog reset...")
        time.sleep(delay)
    
    print("[*] Triggering watchdog reset...")
    
    try:
        # Build watchdog reset command
        reset_payload = struct.pack("<B", 0x60)  # WATCHDOG_RESET command
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"WATCHDOG_RESET " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Watchdog trigger accepted")
                print("[+] Device will reset when watchdog times out...")
                monitor_reset_progress(dev, timeout, "watchdog")
            else:
                print(f"[!] Watchdog reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Watchdog may have triggered")
            
    except Exception as e:
        print(f"[!] Watchdog reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

def reset_custom(dev, args, force=False, delay=0, timeout=30):
    """Execute custom reset sequence"""
    if not args:
        print("[!] Specify custom reset sequence")
        print("[*] Format: <command>[:parameter] [<command>[:parameter]] ...")
        return
    
    # Extract sequence from args
    if isinstance(args, list):
        sequence = " ".join(args)
    else:
        sequence = str(args)
        
    print(f"[*] Preparing CUSTOM reset sequence: {sequence}")
    
    if not force:
        print("[!] Custom reset sequences can be unpredictable.")
        response = input("    Continue? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return
    
    # Pre-reset actions
    if delay > 0:
        print(f"[*] Waiting {delay} seconds before custom reset...")
        time.sleep(delay)
    
    print("[*] Executing custom reset sequence...")
    
    try:
        # Build custom reset command
        reset_payload = struct.pack("<B", 0x70)  # CUSTOM_RESET command
        reset_payload += sequence.encode('ascii').ljust(64, b'\x00')
        reset_payload += struct.pack("<I", timeout)
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", reset_payload)
        else:
            cmd_payload = b"CUSTOM_RESET " + sequence.encode('ascii') + b" " + struct.pack("<I", timeout)
            resp = qslcl_dispatch(dev, "RESET", cmd_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Custom reset sequence executed")
                print("[+] Device should reset according to sequence...")
                monitor_reset_progress(dev, timeout, "custom")
            else:
                print(f"[!] Custom reset failed: {status}")
        else:
            print("[!] No response from device")
            print("[+] Custom reset may have occurred")
            
    except Exception as e:
        print(f"[!] Custom reset error: {e}")
        print("[+] Reset may have occurred (communication lost)")

# =============================================================================
# SUPPORTING FUNCTIONS FOR RESET COMMAND
# =============================================================================

def query_reset_capabilities(dev):
    """Query device reset capabilities"""
    capabilities = {
        'device_name': 'Unknown',
        'architecture': 'Unknown',
        'reset_support': 'Basic',
        'reset_types': [
            {'name': 'SOFT', 'description': 'Warm reboot', 'safety': 'SAFE'},
            {'name': 'HARD', 'description': 'Cold reboot', 'safety': 'WARNING'},
            {'name': 'FORCE', 'description': 'Emergency reset', 'safety': 'DANGEROUS'},
            {'name': 'RECOVERY', 'description': 'Recovery mode boot', 'safety': 'SAFE'},
            {'name': 'FACTORY', 'description': 'Factory reset (ERASES DATA)', 'safety': 'DANGEROUS'},
            {'name': 'BOOTLOADER', 'description': 'Download/EDL mode', 'safety': 'WARNING'},
            {'name': 'DOMAIN', 'description': 'Subsystem reset', 'safety': 'VARIABLE'},
        ],
        'reset_domains': [
            {'name': 'CPU', 'description': 'Processor subsystem'},
            {'name': 'GPU', 'description': 'Graphics processor'},
            {'name': 'DSP', 'description': 'Digital signal processor'},
            {'name': 'MODEM', 'description': 'Cellular modem'},
            {'name': 'WIFI', 'description': 'Wireless network'},
            {'name': 'BT', 'description': 'Bluetooth'},
            {'name': 'USB', 'description': 'USB controller'},
            {'name': 'MEMORY', 'description': 'Memory controller'},
            {'name': 'PCIE', 'description': 'PCI Express controller'},
        ]
    }
    
    try:
        # Try to query actual capabilities
        query_payload = struct.pack("<B", 0x00)  # CAPABILITIES query
        
        if "RESET" in QSLCLPAR_DB:
            resp = qslcl_dispatch(dev, "RESET", query_payload)
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    # Parse capability data
                    extra = status.get("extra", b"")
                    if len(extra) >= 4:
                        # Parse device name if available
                        try:
                            name_len = extra[0]
                            if name_len > 0 and name_len <= len(extra) - 1:
                                capabilities['device_name'] = extra[1:1+name_len].decode('ascii', errors='ignore')
                        except:
                            pass
        else:
            # Try generic query
            resp = qslcl_dispatch(dev, "GETINFO", b"CAPABILITIES")
            if resp:
                status = decode_runtime_result(resp)
                if "reset" in status.get("name", "").lower():
                    capabilities['reset_support'] = "Extended"
                    
    except Exception:
        pass
    
    return capabilities

def monitor_reset_progress(dev, timeout, reset_type):
    """Monitor reset progress and wait for device recovery"""
    print(f"[*] Monitoring reset progress (timeout: {timeout}s)...")
    
    start_time = time.time()
    check_interval = 2  # Check every 2 seconds
    
    # Adjust timeout for different reset types
    if reset_type == "factory":
        timeout = max(timeout, 120)  # Factory reset takes longer
    elif reset_type == "custom":
        timeout = max(timeout, 60)  # Custom reset might take longer
    
    while time.time() - start_time < timeout:
        elapsed = time.time() - start_time
        remaining = timeout - elapsed
        
        print(f"    Waiting for device... {remaining:.0f}s remaining")
        
        try:
            if reset_type == "factory":
                # Factory reset takes longer
                time.sleep(10)
                print("[*] Factory reset in progress... This may take several minutes")
                # Continue monitoring
            else:
                # Quick check if device is responsive
                time.sleep(check_interval)
                
                # Try to scan for devices
                from qslcl import scan_all
                devs = scan_all()
                if devs:
                    print("[+] Device detected after reset")
                    return True
                    
        except KeyboardInterrupt:
            print("\n[*] Reset monitoring interrupted by user")
            return False
        except Exception:
            # Communication failed, device probably still resetting
            pass
    
    if time.time() - start_time >= timeout:
        print(f"[!] Reset monitoring timeout after {timeout} seconds")
        print("[*] Device may still be resetting or may need manual intervention")
    else:
        print("[+] Reset monitoring completed")
    
    return False

def print_reset_help():
    """Display reset command help"""
    print("""
RESET Command Usage:
  reset list                    - List available reset types
  reset soft                    - Soft reset (warm reboot)
  reset hard                    - Hard reset (cold reboot)
  reset force                   - Force reset (emergency)
  reset domain <name>           - Reset specific subsystem
  reset recovery                - Reboot to recovery mode
  reset factory                 - Factory reset (WIPES DATA!)
  reset bootloader              - Reboot to bootloader mode
  reset pmic                    - Reset power management IC
  reset watchdog                - Trigger watchdog reset
  reset custom <sequence>       - Custom reset sequence

Common Domains:
  CPU       - Processor subsystem
  GPU       - Graphics processor  
  DSP       - Digital signal processor
  MODEM     - Cellular modem
  WIFI      - Wireless network
  BT        - Bluetooth
  USB       - USB controller
  MEMORY    - Memory controller
  PCIE      - PCI Express

Safety Levels:
  🟢 SAFE      - Normal reboot, no data loss
  🟡 WARNING   - May cause data loss, user confirmation
  🔴 DANGEROUS - Risk of damage, requires explicit confirmation

Options:
  --force-reset    - Bypass confirmation prompts (DANGEROUS)
  --delay <sec>    - Delay before reset in seconds
  --timeout <sec>  - Reset monitoring timeout

Examples:
  qslcl reset soft                    # Normal reboot
  qslcl reset hard --force-reset      # Force hard reset
  qslcl reset domain CPU              # Reset CPU only
  qslcl reset recovery --delay 5      # Reboot to recovery after 5s
  qslcl reset factory --force-reset   # DANGEROUS: Factory reset

WARNINGS:
  - Factory reset ERASES ALL USER DATA
  - Force reset may damage hardware
  - Always save work before resetting
  - Some resets may require manual intervention to recover
    """)

# =============================================================================
# RESET-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_reset_arguments(parser):
    """Add reset-specific arguments to argument parser"""
    parser.add_argument("--delay", type=int, default=0,
                       help="Delay before reset in seconds")
    parser.add_argument("--timeout", type=int, default=30,
                       help="Reset monitoring timeout in seconds")
    return parser