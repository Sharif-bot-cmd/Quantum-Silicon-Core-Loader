def cmd_reset(args):
    """
    Advanced RESET command handler for comprehensive system reset operations
    Supports various reset types: soft, hard, force, domain-specific, and recovery resets
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse RESET subcommand
    if not hasattr(args, 'reset_subcommand') or not args.reset_subcommand:
        return print("[!] RESET command requires subcommand (list, soft, hard, force, domain, recovery, etc.)")
    
    subcmd = args.reset_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_reset_commands(dev)
    elif subcmd == "SOFT":
        return perform_soft_reset(dev, args)
    elif subcmd == "HARD":
        return perform_hard_reset(dev, args)
    elif subcmd == "FORCE":
        return perform_force_reset(dev, args)
    elif subcmd == "DOMAIN":
        return reset_specific_domain(dev, args)
    elif subcmd == "RECOVERY":
        return perform_recovery_reset(dev, args)
    elif subcmd == "FACTORY":
        return perform_factory_reset(dev, args)
    elif subcmd == "BOOTLOADER":
        return reset_to_bootloader(dev, args)
    elif subcmd == "EDL":
        return reset_to_edl_mode(dev, args)
    elif subcmd == "PMIC":
        return perform_pmic_reset(dev, args)
    elif subcmd == "WATCHDOG":
        return trigger_watchdog_reset(dev, args)
    elif subcmd == "CUSTOM":
        return perform_custom_reset(dev, args)
    elif subcmd == "SEQUENCE":
        return execute_reset_sequence(dev, args)
    else:
        return handle_reset_operation(dev, subcmd, args)

def list_available_reset_commands(dev):
    """
    List all available RESET commands from QSLCL loader
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL RESET COMMANDS")
    print("="*60)
    
    reset_found = []
    
    # Check QSLCLPAR for RESET commands
    print("\n[QSLCLPAR] Reset Commands:")
    par_reset = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "RESET", "REBOOT", "RESTART", "SHUTDOWN", "BOOT", "RECOVERY",
        "FACTORY", "PMIC", "WATCHDOG", "DOMAIN"
    ])]
    for reset_cmd in par_reset:
        print(f"  • {reset_cmd}")
        reset_found.append(reset_cmd)
    
    # Check QSLCLEND for reset-related opcodes
    print("\n[QSLCLEND] Reset Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["RESET", "REBOOT", "RESTART"]) or any(x in entry_str for x in ["RST", "REBOOT"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            reset_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for reset microservices
    print("\n[QSLCLVM5] Reset Microservices:")
    vm5_reset = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["RESET", "REBOOT", "RESTART"])]
    for reset_cmd in vm5_reset:
        print(f"  • {reset_cmd}")
        reset_found.append(f"VM5_{reset_cmd}")
    
    # Check QSLCLIDX for reset indices
    print("\n[QSLCLIDX] Reset Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["RESET", "REBOOT", "RESTART"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                reset_found.append(f"IDX_{name}")
    
    if not reset_found:
        print("  No reset commands found in loader")
    else:
        print(f"\n[*] Total reset commands found: {len(reset_found)}")
    
    print("\n[*] Common Reset Operations Available:")
    print("  • SOFT        - Graceful software reset")
    print("  • HARD        - Hardware-level reset")
    print("  • FORCE       - Force reset (bypass safeguards)")
    print("  • DOMAIN      - Reset specific power domain")
    print("  • RECOVERY    - Reset to recovery mode")
    print("  • FACTORY     - Factory reset (wipe user data)")
    print("  • BOOTLOADER  - Reset to bootloader/fastboot")
    print("  • EDL         - Reset to EDL/Download mode")
    print("  • PMIC        - PMIC (Power Management IC) reset")
    print("  • WATCHDOG    - Trigger watchdog reset")
    print("  • CUSTOM      - Custom reset with parameters")
    print("  • SEQUENCE    - Execute reset sequence")
    
    print("="*60)
    
    return True

def perform_soft_reset(dev, args):
    """
    Perform graceful software reset
    """
    print("[*] Initiating SOFT reset (graceful shutdown and restart)...")
    
    # Safety confirmation
    if not getattr(args, 'force_reset', False):
        confirm = input("!! Confirm SOFT reset? This will restart the device. (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] SOFT reset cancelled")
            return False
    
    print("[*] Sending shutdown signals to services...")
    
    # Try graceful reset command first
    reset_params = struct.pack("<B", 0x01)  # Soft reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] SOFT reset command accepted")
            print("[*] Device should restart gracefully...")
            
            # Monitor for device restart
            monitor_reset_progress(dev, "SOFT")
            return True
        else:
            print(f"[!] SOFT reset failed: {status}")
            return False
    
    # Fallback to generic reset
    print("[*] Using fallback reset method...")
    return perform_generic_reset(dev, "SOFT")

def perform_hard_reset(dev, args):
    """
    Perform hardware-level reset
    """
    print("[!] WARNING: Initiating HARD reset (immediate hardware restart)...")
    print("[!] This may cause data loss or corruption!")
    
    # Safety confirmation
    confirm = input("!! CONFIRM HARD RESET - THIS IS DESTRUCTIVE! (type 'HARD-RESET' to continue): ").strip().upper()
    if confirm != "HARD-RESET":
        print("[*] HARD reset cancelled")
        return False
    
    print("[*] Triggering hardware reset sequence...")
    
    # Hard reset parameters
    reset_params = struct.pack("<B", 0x02)  # Hard reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] HARD reset command accepted")
            print("[!] Device resetting immediately...")
            
            # Immediate disconnect expected
            time.sleep(1)
            print("[*] Device should be resetting now...")
            return True
        else:
            print(f"[!] HARD reset failed: {status}")
            return False
    
    # Try PMIC hard reset as fallback
    return perform_pmic_hard_reset(dev)

def perform_force_reset(dev, args):
    """
    Perform force reset (bypass all safeguards)
    """
    print("[!] DANGER: Initiating FORCE reset (bypass all safeguards)...")
    print("[!] THIS MAY BRICK THE DEVICE OR CAUSE PERMANENT DAMAGE!")
    
    # Extreme safety confirmation
    confirm = input("!! CONFIRM FORCE RESET - EXTREMELY DANGEROUS! (type 'FORCE-RESET' to continue): ").strip().upper()
    if confirm != "FORCE-RESET":
        print("[*] FORCE reset cancelled")
        return False
    
    print("[*] Bypassing safety mechanisms...")
    print("[*] Triggering force reset sequence...")
    
    # Force reset parameters
    reset_params = struct.pack("<B", 0xFF)  # Force reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] FORCE reset command accepted")
            print("[!] Device force reset in progress...")
            
            # Monitor with shorter timeout
            monitor_reset_progress(dev, "FORCE", timeout=5)
            return True
        else:
            print(f"[!] FORCE reset failed: {status}")
            return False
    
    # Ultimate fallback - try multiple reset methods
    return perform_emergency_reset(dev)

def reset_specific_domain(dev, args):
    """
    Reset specific power domain or subsystem
    """
    if not hasattr(args, 'reset_args') or not args.reset_args:
        return list_resettable_domains(dev)
    
    domain = args.reset_args[0].upper()
    
    print(f"[*] Preparing to reset domain: {domain}")
    
    # Get domain information
    domains_info = get_resettable_domains(dev)
    if domain not in domains_info:
        print(f"[!] Unknown domain: {domain}")
        print("[*] Available domains:")
        for avail_domain in domains_info:
            print(f"  • {avail_domain}")
        return False
    
    domain_info = domains_info[domain]
    print(f"[*] Domain type: {domain_info.get('type', 'UNKNOWN')}")
    
    # Safety confirmation for critical domains
    critical_domains = ["CPU", "GPU", "DDR", "MODEM", "TZ"]
    if domain in critical_domains:
        confirm = input(f"!! Confirm reset of critical domain {domain}? (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Domain reset cancelled")
            return False
    
    # Execute domain reset
    reset_params = struct.pack("<B", 0x10) + domain.encode() + b"\x00"  # Domain reset code + domain name
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Domain {domain} reset successfully")
            
            # Wait for domain to stabilize
            time.sleep(2)
            print(f"[*] Domain {domain} should be operational now")
            return True
        else:
            print(f"[!] Domain {domain} reset failed: {status}")
            return False
    
    print(f"[!] No domain reset capability for {domain}")
    return False

def list_resettable_domains(dev):
    """
    List all resettable power domains and subsystems
    """
    print("[*] Resettable domains and subsystems:")
    
    domains_info = get_resettable_domains(dev)
    
    for domain, info in domains_info.items():
        domain_type = info.get('type', 'UNKNOWN')
        critical = " (CRITICAL)" if info.get('critical', False) else ""
        print(f"  • {domain:<15} : {domain_type}{critical}")
    
    return True

def get_resettable_domains(dev):
    """
    Get information about resettable domains
    """
    # Common resettable domains
    domains = {
        "CPU": {"type": "Processor", "critical": True},
        "GPU": {"type": "Graphics", "critical": False},
        "DDR": {"type": "Memory", "critical": True},
        "MODEM": {"type": "Cellular", "critical": False},
        "WLAN": {"type": "Wireless", "critical": False},
        "BT": {"type": "Bluetooth", "critical": False},
        "GPS": {"type": "Navigation", "critical": False},
        "AUDIO": {"type": "Audio", "critical": False},
        "DISPLAY": {"type": "Display", "critical": False},
        "CAMERA": {"type": "Camera", "critical": False},
        "SENSORS": {"type": "Sensors", "critical": False},
        "TZ": {"type": "TrustZone", "critical": True},
        "USB": {"type": "USB", "critical": False},
    }
    
    # Try to get domains from device
    resp = qslcl_dispatch(dev, "RESET", b"DOMAINS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            try:
                # Parse domain list from response
                domain_list = extra.decode('utf-8', errors='ignore').split('\x00')
                custom_domains = {}
                for domain_entry in domain_list:
                    if ':' in domain_entry:
                        domain, domain_type = domain_entry.split(':', 1)
                        custom_domains[domain.strip().upper()] = {"type": domain_type.strip(), "critical": "CRITICAL" in domain_type.upper()}
                if custom_domains:
                    domains.update(custom_domains)
            except:
                pass
    
    return domains

def perform_recovery_reset(dev, args):
    """
    Reset device to recovery mode
    """
    print("[*] Initiating recovery mode reset...")
    
    # Safety confirmation
    if not getattr(args, 'force_reset', False):
        confirm = input("!! Reset to recovery mode? This will boot to recovery. (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Recovery reset cancelled")
            return False
    
    print("[*] Configuring boot parameters for recovery...")
    
    # Recovery reset parameters
    reset_params = struct.pack("<B", 0x20)  # Recovery reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Recovery reset command accepted")
            print("[*] Device should boot to recovery mode...")
            
            monitor_reset_progress(dev, "RECOVERY")
            return True
        else:
            print(f"[!] Recovery reset failed: {status}")
            return False
    
    # Fallback: Use boot mode setting
    return set_boot_mode(dev, "RECOVERY")

def perform_factory_reset(dev, args):
    """
    Perform factory reset (wipe user data)
    """
    print("[!] WARNING: Initiating FACTORY RESET...")
    print("[!] THIS WILL ERASE ALL USER DATA AND SETTINGS!")
    print("[!] THIS ACTION CANNOT BE UNDONE!")
    
    # Extreme safety confirmation
    confirm = input("!! CONFIRM FACTORY RESET - ALL DATA WILL BE LOST! (type 'FACTORY-RESET' to continue): ").strip().upper()
    if confirm != "FACTORY-RESET":
        print("[*] Factory reset cancelled")
        return False
    
    # Additional warning
    print("\n[!] FINAL WARNING:")
    print("[!] - All apps, photos, and personal data will be erased")
    print("[!] - Device will be restored to original factory state")
    print("[!] - This process may take several minutes")
    
    final_confirm = input("!! TYPE 'ERASE-EVERYTHING' TO PROCEED: ").strip().upper()
    if final_confirm != "ERASE-EVERYTHING":
        print("[*] Factory reset cancelled")
        return False
    
    print("[*] Starting factory reset process...")
    print("[*] Wiping user data partition...")
    
    # Factory reset parameters
    reset_params = struct.pack("<B", 0x30)  # Factory reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Factory reset command accepted")
            print("[*] Device is wiping data and will reboot...")
            print("[*] This may take 2-10 minutes...")
            
            # Extended monitoring for factory reset
            monitor_reset_progress(dev, "FACTORY", timeout=120)
            return True
        else:
            print(f"[!] Factory reset failed: {status}")
            return False
    
    print("[!] No factory reset capability available")
    return False

def reset_to_bootloader(dev, args):
    """
    Reset device to bootloader/fastboot mode
    """
    print("[*] Initiating bootloader reset...")
    
    # Safety confirmation
    if not getattr(args, 'force_reset', False):
        confirm = input("!! Reset to bootloader mode? (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Bootloader reset cancelled")
            return False
    
    print("[*] Configuring boot parameters for bootloader...")
    
    # Bootloader reset parameters
    reset_params = struct.pack("<B", 0x40)  # Bootloader reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Bootloader reset command accepted")
            print("[*] Device should boot to bootloader/fastboot mode...")
            
            monitor_reset_progress(dev, "BOOTLOADER")
            return True
        else:
            print(f"[!] Bootloader reset failed: {status}")
            return False
    
    # Fallback: Use boot mode setting
    return set_boot_mode(dev, "BOOTLOADER")

def reset_to_edl_mode(dev, args):
    """
    Reset device to EDL (Emergency Download) mode
    """
    print("[*] Initiating EDL mode reset...")
    
    # Safety confirmation
    confirm = input("!! Reset to EDL mode? This is for advanced debugging. (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] EDL reset cancelled")
        return False
    
    print("[*] Configuring for EDL mode...")
    
    # EDL reset parameters
    reset_params = struct.pack("<B", 0x50)  # EDL reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] EDL reset command accepted")
            print("[*] Device should enter EDL/download mode...")
            print("[*] Use EDL tools to communicate with device")
            
            monitor_reset_progress(dev, "EDL")
            return True
        else:
            print(f"[!] EDL reset failed: {status}")
            return False
    
    # Fallback: Use test point method (if available)
    return trigger_edl_testpoint(dev)

def perform_pmic_reset(dev, args):
    """
    Perform PMIC (Power Management IC) reset
    """
    print("[*] Initiating PMIC reset...")
    print("[*] This resets the power management controller")
    
    # PMIC reset parameters
    reset_params = struct.pack("<B", 0x60)  # PMIC reset code
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] PMIC reset command accepted")
            print("[*] Power management IC is resetting...")
            
            # PMIC reset is usually fast
            time.sleep(3)
            print("[*] PMIC reset complete")
            return True
        else:
            print(f"[!] PMIC reset failed: {status}")
            return False
    
    # Fallback: Direct PMIC register write
    return perform_pmic_register_reset(dev)

def trigger_watchdog_reset(dev, args):
    """
    Trigger watchdog timer reset
    """
    print("[*] Configuring watchdog timer for reset...")
    
    timeout = 5  # Default 5 second timeout
    if hasattr(args, 'reset_args') and args.reset_args:
        try:
            timeout = int(args.reset_args[0])
            if timeout < 1 or timeout > 60:
                print("[!] Timeout must be between 1-60 seconds")
                timeout = 5
        except:
            pass
    
    print(f"[*] Watchdog will trigger reset in {timeout} seconds...")
    
    # Watchdog reset parameters
    reset_params = struct.pack("<BI", 0x70, timeout)  # Watchdog reset code + timeout
    resp, origin = qslclidx_or_dispatch(dev, "RESET", reset_params)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Watchdog configured")
            print(f"[*] Device will reset in {timeout} seconds...")
            print("[*] Counting down...")
            
            # Countdown
            for i in range(timeout, 0, -1):
                print(f"    {i}...")
                time.sleep(1)
            
            print("[!] Watchdog should have triggered reset by now")
            return True
        else:
            print(f"[!] Watchdog configuration failed: {status}")
            return False
    
    print("[!] No watchdog reset capability available")
    return False

def perform_custom_reset(dev, args):
    """
    Perform custom reset with specific parameters
    """
    if not hasattr(args, 'reset_args') or len(args.reset_args) < 1:
        return print("[!] CUSTOM reset requires parameters")
    
    reset_type = args.reset_args[0].upper()
    custom_params = b""
    
    # Parse custom parameters
    if len(args.reset_args) > 1:
        for param in args.reset_args[1:]:
            try:
                if param.startswith("0x"):
                    # Hex value
                    if len(param) > 4:
                        custom_params += struct.pack("<I", int(param, 16))
                    else:
                        custom_params += struct.pack("<B", int(param, 16))
                elif param.isdigit():
                    # Decimal value
                    custom_params += struct.pack("<I", int(param))
                else:
                    # String parameter
                    custom_params += param.encode() + b"\x00"
            except:
                custom_params += param.encode() + b"\x00"
    
    print(f"[*] Performing custom reset: {reset_type}")
    if custom_params:
        print(f"[*] Custom parameters: {custom_params.hex()}")
    
    # Custom reset command
    payload = reset_type.encode() + b"\x00" + custom_params
    resp, origin = qslclidx_or_dispatch(dev, "RESET", payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Custom reset executed successfully")
            return True
        else:
            print(f"[!] Custom reset failed: {status}")
            return False
    
    print(f"[!] Custom reset type '{reset_type}' not supported")
    return False

def execute_reset_sequence(dev, args):
    """
    Execute a predefined reset sequence
    """
    if not hasattr(args, 'reset_args') or not args.reset_args:
        return list_reset_sequences(dev)
    
    sequence_name = args.reset_args[0].upper()
    
    print(f"[*] Executing reset sequence: {sequence_name}")
    
    # Get sequence steps
    sequence = get_reset_sequence(sequence_name)
    if not sequence:
        print(f"[!] Unknown reset sequence: {sequence_name}")
        return False
    
    print(f"[*] Sequence has {len(sequence)} steps")
    
    # Safety confirmation for complex sequences
    if len(sequence) > 3:
        confirm = input(f"!! Execute {len(sequence)}-step reset sequence? (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Reset sequence cancelled")
            return False
    
    # Execute sequence steps
    success_count = 0
    for step_num, (step_name, step_params) in enumerate(sequence, 1):
        print(f"\n[{step_num}/{len(sequence)}] Executing: {step_name}")
        
        resp, origin = qslclidx_or_dispatch(dev, "RESET", step_params)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"    [✓] {step_name}: Success")
                success_count += 1
                time.sleep(1)  # Brief pause between steps
            else:
                print(f"    [!] {step_name}: Failed - {status}")
        else:
            print(f"    [!] {step_name}: No response")
    
    print(f"\n[*] Reset sequence completed: {success_count}/{len(sequence)} steps successful")
    return success_count == len(sequence)

def list_reset_sequences(dev):
    """
    List available reset sequences
    """
    print("[*] Available reset sequences:")
    
    sequences = {
        "BOOT_RECOVERY": "Reset to recovery with cleanup",
        "FACTORY_CLEAN": "Complete factory reset with verification",
        "SOFTWARE_REPAIR": "Software repair sequence",
        "HARDWARE_RESET": "Complete hardware reset sequence",
        "EMERGENCY": "Emergency recovery sequence"
    }
    
    for seq_name, seq_desc in sequences.items():
        print(f"  • {seq_name:<20} : {seq_desc}")
    
    return True

def get_reset_sequence(sequence_name):
    """
    Get steps for a specific reset sequence
    """
    sequences = {
        "BOOT_RECOVERY": [
            ("SOFT_RESET", b"\x01"),
            ("CLEAN_CACHES", b"\x81"),
            ("BOOT_RECOVERY", b"\x20")
        ],
        "FACTORY_CLEAN": [
            ("BACKUP_CONFIG", b"\x82"),
            ("WIPE_DATA", b"\x30"),
            ("CLEAN_CACHES", b"\x81"),
            ("SOFT_RESET", b"\x01")
        ],
        "SOFTWARE_REPAIR": [
            ("VERIFY_SYSTEM", b"\x83"),
            ("REPAIR_PARTITIONS", b"\x84"),
            ("SOFT_RESET", b"\x01")
        ]
    }
    
    return sequences.get(sequence_name)

def monitor_reset_progress(dev, reset_type, timeout=30):
    """
    Monitor device after reset command
    """
    print(f"[*] Monitoring reset progress ({reset_type})...")
    
    start_time = time.time()
    check_interval = 2  # Check every 2 seconds
    
    print("[*] Waiting for device to respond...")
    
    while time.time() - start_time < timeout:
        try:
            # Try to ping the device
            resp = qslcl_dispatch(dev, "PING", b"")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    print("[✓] Device is responsive after reset")
                    return True
            
            print(".", end="", flush=True)
            time.sleep(check_interval)
            
        except:
            # Device might be temporarily unavailable during reset
            print(".", end="", flush=True)
            time.sleep(check_interval)
    
    print(f"\n[!] Device did not respond within {timeout} seconds")
    print("[*] Reset may have completed - check device manually")
    return False

def perform_generic_reset(dev, reset_type):
    """
    Fallback generic reset implementation
    """
    print(f"[*] Using generic reset for {reset_type}...")
    
    resp = qslcl_dispatch(dev, "RESET", b"")
    if resp:
        status = decode_runtime_result(resp)
        _decode_and_show(resp, reset_type + " RESET", 0, origin="GENERIC")
        return status.get("severity") == "SUCCESS"
    
    return False

def perform_pmic_hard_reset(dev):
    """
    Fallback PMIC hard reset implementation
    """
    print("[*] Attempting PMIC hard reset...")
    
    # Try PMIC reset command
    resp = qslcl_dispatch(dev, "PMIC_RESET", b"")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] PMIC hard reset executed")
            return True
    
    return False

def perform_emergency_reset(dev):
    """
    Ultimate emergency reset fallback
    """
    print("[*] Executing emergency reset procedures...")
    
    # Try multiple reset methods
    emergency_methods = [
        ("PS_HOLD_RESET", b"\xFD"),
        ("PMIC_FORCE_RESET", b"\xFE"),
        ("HARDWARE_RESET", b"\xFF")
    ]
    
    for method_name, method_params in emergency_methods:
        print(f"[*] Trying {method_name}...")
        resp, origin = qslclidx_or_dispatch(dev, "RESET", method_params)
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {method_name} successful")
                return True
    
    print("[!] All emergency reset methods failed")
    return False

def set_boot_mode(dev, mode):
    """
    Fallback: Set boot mode instead of direct reset
    """
    print(f"[*] Setting boot mode to {mode}...")
    
    payload = mode.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "BOOT_MODE", payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Boot mode set to {mode}")
            # Still need to reset to apply
            return perform_soft_reset(dev, type('args', (), {'force_reset': True})())
    
    return False

def trigger_edl_testpoint(dev):
    """
    Fallback: Trigger EDL via test point method
    """
    print("[*] Attempting EDL test point method...")
    
    # This would typically involve shorting test points
    # For software, we try to force EDL mode
    resp = qslcl_dispatch(dev, "FORCE_EDL", b"")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] EDL mode forced")
            return True
    
    return False

def perform_pmic_register_reset(dev):
    """
    Fallback: Direct PMIC register reset
    """
    print("[*] Performing PMIC register reset...")
    
    # Write to PMIC reset register (varies by platform)
    resp = qslcl_dispatch(dev, "PMIC_WRITE", struct.pack("<HH", 0x1000, 0x01))
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] PMIC register reset executed")
            return True
    
    return False

def handle_reset_operation(dev, operation, args):
    """
    Handle other reset operations
    """
    print(f"[*] Executing reset operation: {operation}")
    
    # Build operation parameters
    params = build_reset_params(operation, args)
    
    # Try different reset strategies
    strategies = [
        try_direct_reset_operation,
        try_par_reset_command,
        try_end_reset_opcode,
        try_vm5_reset_service,
        try_idx_reset_command,
    ]
    
    for strategy in strategies:
        success = strategy(dev, operation, params)
        if success is not None:
            return success
    
    print(f"[!] Failed to execute reset operation: {operation}")
    return False

def build_reset_params(operation, args):
    """
    Build parameters for reset operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'reset_args'):
        for arg in args.reset_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

# Strategy implementations
def try_direct_reset_operation(dev, operation, params):
    resp = qslcl_dispatch(dev, "RESET", operation.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    _decode_and_show(resp, operation + " RESET", 0, origin="DIRECT")
    return status.get("severity") == "SUCCESS"

def try_par_reset_command(dev, operation, params):
    if operation in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, operation, params)
        status = decode_runtime_result(resp)
        _decode_and_show(resp, operation + " RESET", 0, origin="PAR")
        return status.get("severity") == "SUCCESS"
    return None

def try_end_reset_opcode(dev, operation, params):
    opcode = sum(operation.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        _decode_and_show(resp, operation + " RESET", 0, origin="ENGINE")
        return status.get("severity") == "SUCCESS"
    return None

def try_vm5_reset_service(dev, operation, params):
    if operation in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[operation]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        _decode_and_show(resp, operation + " RESET", 0, origin="VM5")
        return status.get("severity") == "SUCCESS"
    return None

def try_idx_reset_command(dev, operation, params):
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == operation:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
            resp = qslcl_dispatch(dev, "IDX", pkt)
            status = decode_runtime_result(resp)
            _decode_and_show(resp, operation + " RESET", 0, origin="IDX")
            return status.get("severity") == "SUCCESS"
    return None

def _decode_and_show(resp, operation, addr, origin="UNKNOWN"):
    """
    Enhanced decode and show function for reset operations
    """
    if not resp:
        print(f"[!] {operation} via {origin}: No response")
        return None
    
    result = decode_runtime_result(resp)
    
    sev = result.get("severity", "UNKNOWN")
    name = result.get("name", "UNKNOWN")
    extra = result.get("extra", b"")
    
    msg = f"{operation} @ 0x{addr:08X} ({origin}) → {name}"
    
    if sev == "SUCCESS":
        print(f"[✓] {msg}")
        if extra:
            print(f"    Additional info: {extra.hex()}")
    elif sev == "WARNING":
        print(f"[~] {msg}")
        if extra:
            print(f"    Warning details: {extra.hex()}")
    else:
        print(f"[✗] {msg}")
        if extra:
            print(f"    Error details: {extra.hex()}")
    
    return result if sev in ("SUCCESS", "WARNING") else None

# Update the argument parser in main() function
def update_reset_parser(sub):
    """
    Update the RESET command parser with new subcommands
    """
    reset_parser = sub.add_parser("reset", help="System reset and restart commands")
    reset_parser.add_argument("reset_subcommand", help="Reset subcommand (list, soft, hard, force, domain, recovery, factory, bootloader, edl, pmic, watchdog, custom, sequence)")
    reset_parser.add_argument("reset_args", nargs="*", help="Additional arguments for reset command")
    reset_parser.add_argument("--force-reset", action="store_true", help="Bypass confirmation prompts")
    reset_parser.set_defaults(func=cmd_reset)