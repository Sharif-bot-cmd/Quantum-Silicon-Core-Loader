def cmd_poke(args=None):
    """
    Fully implemented POKE command with advanced features:
    - Multiple value formats (hex, decimal, strings, expressions)
    - Flexible data type handling
    - Memory region validation
    - Safety checks and confirmation
    - Pre-write readback and post-write verification
    - Bit-level operations
    
    Updated for QSLCL v1.2.0 compatibility
    """
    if not args:
        print("[!] POKE: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    address_str = getattr(args, 'address', '')
    value_str = getattr(args, 'value', '')
    data_type = getattr(args, 'data_type', 'auto')
    size = getattr(args, 'size', 4)
    force = getattr(args, 'force', False)
    no_verify = getattr(args, 'no_verify', False)
    bit_operation = getattr(args, 'bit_op', None)  

    if not address_str:
        print("[!] POKE: No address specified")
        return

    if not value_str:
        print("[!] POKE: No value specified")
        return

    print(f"[*] POKE command: address={address_str}, value={value_str}")

    # =========================================================================
    # 1. ADDRESS RESOLUTION AND VALIDATION
    # =========================================================================
    try:
        # Use QSLCL's resolve_target instead of custom resolve_address
        partitions = load_partitions(dev)
        memory_regions = detect_memory_regions(dev)
        
        resolved = resolve_target(address_str, partitions, memory_regions, dev)
        if not resolved:
            print(f"[!] Could not resolve address: {address_str}")
            return
        
        address = resolved['address']
        region_info = "Unknown"
        
        if resolved.get('partition_info'):
            region_info = f"Partition: {resolved['partition_info']['name']}"
        elif resolved.get('region_info'):
            region_info = f"Region: {resolved['region_info']['name']}"
        
        print(f"[+] Resolved address: 0x{address:08X}")
        print(f"[+] Memory region: {region_info}")
        
    except Exception as e:
        print(f"[!] Address resolution failed: {e}")
        # Fallback to direct address parsing
        try:
            address = parse_address(address_str)
            print(f"[+] Using direct address: 0x{address:08X}")
            region_info = "Direct address (no region detection)"
        except Exception as e2:
            print(f"[!] Fallback address parsing also failed: {e2}")
            return

    # =========================================================================
    # 2. VALUE PROCESSING AND DATA TYPE DETERMINATION
    # =========================================================================
    try:
        if data_type == 'auto':
            data_type = auto_detect_poke_type(value_str, size)
            print(f"[+] Auto-detected data type: {data_type}")

        # Process value based on data type
        write_data, actual_size, value_description = process_poke_value(value_str, data_type, size)
        
        if write_data is None:
            print(f"[!] Failed to process value: {value_str} as {data_type}")
            return

        print(f"[+] Value: {value_description}")
        print(f"[+] Data size: {actual_size} bytes")
        print(f"[+] Raw bytes: {write_data.hex()}")

    except Exception as e:
        print(f"[!] Value processing failed: {e}")
        traceback.print_exc()
        return

    # =========================================================================
    # 3. SAFETY CHECKS AND CONFIRMATION
    # =========================================================================
    # Check for critical memory regions
    critical_regions = [
        'boot', 'system', 'recovery', 'bootloader', 'aboot', 
        'sbl', 'tz', 'partition', 'GPT'
    ]
    
    region_lower = region_info.lower()
    is_critical = any(critical_region in region_lower for critical_region in critical_regions)
    
    if is_critical and not force:
        print(f"\n[!] WARNING: Writing to critical memory region!")
        print(f"[!] Address: 0x{address:08X}")
        print(f"[!] Region: {region_info}")
        print(f"[!] This may BRICK your device!")
        
        response = input("    Type 'BRICK' to confirm: ")
        if response != 'BRICK':
            print("[*] Operation cancelled")
            return

    # Check alignment
    if actual_size > 1:
        if address % actual_size != 0:
            print(f"[!] Warning: Unaligned write (address 0x{address:08X}, size {actual_size})")
            if not force:
                response = input("    Continue anyway? (y/N): ")
                if response.lower() not in ('y', 'yes'):
                    print("[*] Operation cancelled")
                    return

    # Show operation summary
    print(f"\n[*] POKE OPERATION SUMMARY:")
    print(f"    Address: 0x{address:08X}")
    print(f"    Region: {region_info}")
    print(f"    Data type: {data_type}")
    print(f"    Value: {value_description}")
    print(f"    Size: {actual_size} bytes")
    print(f"    Raw: {write_data.hex()}")

    if not force:
        response = input("\n[*] Confirm write operation? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return

    # =========================================================================
    # 4. PRE-WRITE READBACK (OPTIONAL)
    # =========================================================================
    original_data = None
    if not no_verify:
        print(f"\n[*] Reading original data...")
        try:
            # Use QSLCL's read dispatch
            read_payload = struct.pack("<II", address, actual_size)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    original_data = status["extra"]
                    if len(original_data) >= actual_size:
                        print(f"[+] Original data: {original_data[:actual_size].hex()}")
                        
                        # Interpret original value
                        orig_value = interpret_data(original_data[:actual_size], data_type)
                        print(f"[+] Original value: {orig_value}")
                    else:
                        print(f"[!] Short readback: got {len(original_data)} bytes")
                else:
                    print(f"[!] Readback failed: {status}")
            else:
                print("[!] No readback response")
                
        except Exception as e:
            print(f"[!] Readback failed: {e}")
            if not force:
                response = input("    Continue without readback? (y/N): ")
                if response.lower() not in ('y', 'yes'):
                    print("[*] Operation cancelled")
                    return

    # =========================================================================
    # 5. BIT-LEVEL OPERATIONS
    # =========================================================================
    if bit_operation and original_data and len(original_data) >= actual_size:
        print(f"[*] Performing bit operation: {bit_operation}")
        try:
            current_value = int.from_bytes(original_data[:actual_size], 'little')
            new_value = int.from_bytes(write_data, 'little')
            
            bit_operation = bit_operation.upper()
            if bit_operation == 'AND':
                result_value = current_value & new_value
                operation_desc = f"AND (0x{current_value:X} & 0x{new_value:X})"
            elif bit_operation == 'OR':
                result_value = current_value | new_value
                operation_desc = f"OR (0x{current_value:X} | 0x{new_value:X})"
            elif bit_operation == 'XOR':
                result_value = current_value ^ new_value
                operation_desc = f"XOR (0x{current_value:X} ^ 0x{new_value:X})"
            else:
                print(f"[!] Unknown bit operation: {bit_operation}")
                return
                
            write_data = result_value.to_bytes(actual_size, 'little')
            print(f"[+] Bit operation: {operation_desc} = 0x{result_value:X}")
            print(f"[+] New data: {write_data.hex()}")
            
        except Exception as e:
            print(f"[!] Bit operation failed: {e}")
            return

    # =========================================================================
    # 6. WRITE OPERATION
    # =========================================================================
    print(f"\n[*] Writing {actual_size} bytes to 0x{address:08X}...")
    
    try:
        # Build write command using QSLCL POKE format
        # Format: <address (4 bytes)> <size (4 bytes)> <data>
        write_header = struct.pack("<II", address, actual_size)
        write_payload = write_header + write_data
        
        # Try POKE command first (from QSLCLCMD)
        if "POKE" in QSLCLCMD_DB:
            print("[*] Using QSLCLCMD POKE command")
            resp = qslcl_dispatch(dev, "POKE", write_payload)
        elif "WRITE" in QSLCLCMD_DB:
            print("[*] Using QSLCLCMD WRITE command")
            resp = qslcl_dispatch(dev, "WRITE", write_payload)
        else:
            # Generic fallback - use direct command format
            print("[*] Using fallback write method")
            cmd = f"WRITE 0x{address:08X} 0x{actual_size:04X}"
            full_payload = cmd.encode() + b' ' + write_data
            resp = qslcl_dispatch(dev, "WRITE", full_payload)

        if not resp:
            print("[!] No response from write command")
            return

        status = decode_runtime_result(resp)
        if status["severity"] != "SUCCESS":
            print(f"[!] Write failed: {status}")
            return

        print("[+] Write command accepted")

    except Exception as e:
        print(f"[!] Write operation failed: {e}")
        traceback.print_exc()
        return

    # =========================================================================
    # 7. POST-WRITE VERIFICATION
    # =========================================================================
    if not no_verify:
        print(f"\n[*] Verifying write...")
        time.sleep(0.1)  # Brief delay for write to complete
        
        try:
            read_payload = struct.pack("<II", address, actual_size)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    verify_data = status["extra"]
                    if len(verify_data) >= actual_size:
                        verify_data = verify_data[:actual_size]
                        
                        if verify_data == write_data:
                            print("[+] Verification PASSED")
                            verify_value = interpret_data(verify_data, data_type)
                            print(f"[+] Verified value: {verify_value}")
                        else:
                            print("[!] Verification FAILED")
                            print(f"    Expected: {write_data.hex()}")
                            print(f"    Got: {verify_data.hex()}")
                            
                            # Calculate differences
                            differences = []
                            for i in range(min(len(write_data), len(verify_data))):
                                if write_data[i] != verify_data[i]:
                                    differences.append(f"byte {i}: 0x{write_data[i]:02X} != 0x{verify_data[i]:02X}")
                            
                            if differences:
                                print(f"    Differences: {', '.join(differences[:5])}")
                                if len(differences) > 5:
                                    print(f"    ... and {len(differences) - 5} more")
                    else:
                        print(f"[!] Verification read too short: {len(verify_data)} bytes")
                else:
                    print(f"[!] Verification read failed: {status}")
            else:
                print("[!] No verification response")
                
        except Exception as e:
            print(f"[!] Verification failed: {e}")

    # =========================================================================
    # 8. FINAL SUMMARY
    # =========================================================================
    print(f"\n[+] POKE operation completed!")
    print(f"    Address: 0x{address:08X}")
    print(f"    Region: {region_info}")
    print(f"    Data type: {data_type}")
    print(f"    Value: {value_description}")
    print(f"    Size: {actual_size} bytes")
    
    if original_data is not None and len(original_data) >= actual_size:
        old_value = interpret_data(original_data[:actual_size], data_type)
        new_value = interpret_data(write_data, data_type)
        print(f"    Changed: {old_value} → {new_value}")

    if bit_operation:
        print(f"    Bit operation: {bit_operation.upper()}")

# =============================================================================
# SUPPORTING FUNCTIONS FOR POKE COMMAND
# =============================================================================

def auto_detect_poke_type(value_str, size):
    """Auto-detect data type for poke operation"""
    value_str = str(value_str).strip().lower()
    
    # Check for string indicators
    if (value_str.startswith('"') and value_str.endswith('"')) or \
       (value_str.startswith("'") and value_str.endswith("'")):
        return 'string'
    
    # Check for hex string (even length, hex chars only)
    clean_hex = value_str.replace(' ', '').replace('0x', '')
    if re.match(r'^[0-9a-f]+$', clean_hex):
        hex_len = len(clean_hex)
        if hex_len % 2 == 0:  # Valid hex string
            return 'hex'
    
    # Check for float indicators
    if '.' in value_str or 'e' in value_str or 'nan' in value_str or 'inf' in value_str:
        if size == 4:
            return 'float'
        elif size == 8:
            return 'double'
    
    # Default based on size
    if size == 1:
        return 'uint8'
    elif size == 2:
        return 'uint16'
    elif size == 4:
        return 'uint32'
    elif size == 8:
        return 'uint64'
    else:
        return 'hex'

def process_poke_value(value_str, data_type, size):
    """Process value string into bytes based on data type"""
    value_str = str(value_str).strip()
    
    try:
        if data_type in ['uint8', 'int8', 'char']:
            return process_integer_value(value_str, 1, data_type)
            
        elif data_type in ['uint16', 'int16', 'short']:
            return process_integer_value(value_str, 2, data_type)
            
        elif data_type in ['uint32', 'int32', 'int']:
            return process_integer_value(value_str, 4, data_type)
            
        elif data_type in ['uint64', 'int64', 'long']:
            return process_integer_value(value_str, 8, data_type)
            
        elif data_type == 'float':
            return process_float_value(value_str)
            
        elif data_type == 'double':
            return process_double_value(value_str)
            
        elif data_type == 'string':
            return process_string_value(value_str, size)
            
        elif data_type == 'hex':
            return process_hex_value(value_str, size)
            
        else:
            # Default to 32-bit integer
            return process_integer_value(value_str, 4, 'uint32')
            
    except Exception as e:
        print(f"[!] Value processing error: {e}")
        traceback.print_exc()
        return None, 0, "Error"

def process_integer_value(value_str, size, data_type):
    """Process integer value with proper signing"""
    value_str = value_str.strip()
    
    # Handle expressions
    try:
        # First try to use parse_address from qslcl
        from qslcl import parse_address
        
        if any(op in value_str for op in ['+', '-', '*', '/', '<<', '>>', '&', '|', '^', '(', ')']):
            # Safe expression evaluation
            expr = value_str.replace(' ', '')
            # Check if it's a safe expression (only numbers and operators)
            if re.match(r'^[0-9\+\-\*/<>&|^\(\)\sxXa-fA-F]+$', expr):
                # Replace hex notation
                expr = expr.replace('0x', '0x')
                # Use safe evaluation with limited scope
                value = safe_eval_expression(expr)
            else:
                # Fallback to parse_address for complex expressions
                value = parse_address(value_str)
        else:
            value = parse_address(value_str)
    except (ImportError, Exception):
        # Final fallback
        try:
            value = int(value_str, 0)
        except:
            value = 0
    
    # Apply signing
    if data_type.startswith('int'):
        # Signed integer
        if size == 1:
            value_bytes = struct.pack('<b', value)
            desc = f"{struct.unpack('<b', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 2:
            value_bytes = struct.pack('<h', value)
            desc = f"{struct.unpack('<h', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 4:
            value_bytes = struct.pack('<i', value)
            desc = f"{struct.unpack('<i', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 8:
            value_bytes = struct.pack('<q', value)
            desc = f"{struct.unpack('<q', value_bytes)[0]} (0x{value_bytes.hex()})"
        else:
            value_bytes = value.to_bytes(size, 'little', signed=True)
            desc = f"{value} (0x{value_bytes.hex()})"
    else:
        # Unsigned integer
        if size == 1:
            value_bytes = struct.pack('<B', value & 0xFF)
            desc = f"{struct.unpack('<B', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 2:
            value_bytes = struct.pack('<H', value & 0xFFFF)
            desc = f"{struct.unpack('<H', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 4:
            value_bytes = struct.pack('<I', value & 0xFFFFFFFF)
            desc = f"{struct.unpack('<I', value_bytes)[0]} (0x{value_bytes.hex()})"
        elif size == 8:
            value_bytes = struct.pack('<Q', value & 0xFFFFFFFFFFFFFFFF)
            desc = f"{struct.unpack('<Q', value_bytes)[0]} (0x{value_bytes.hex()})"
        else:
            value_bytes = value.to_bytes(size, 'little')
            desc = f"{value} (0x{value_bytes.hex()})"
    
    return value_bytes, size, desc

def safe_eval_expression(expr):
    """Safely evaluate a mathematical expression"""
    # Remove dangerous functions
    safe_dict = {
        'abs': abs,
        'round': round,
        'int': int,
        'float': float,
        'hex': hex,
        'bin': bin,
        'oct': oct,
    }
    
    # Only allow mathematical operations
    allowed_chars = set('0123456789abcdefABCDEFxX.+-*/<>()&|^~% ')
    if not all(c in allowed_chars for c in expr):
        raise ValueError("Expression contains unsafe characters")
    
    # Convert hex literals to decimal
    def hex_to_dec(match):
        return str(int(match.group(0), 16))
    
    expr = re.sub(r'0x[0-9a-fA-F]+', hex_to_dec, expr)
    
    # Replace bitwise operators with Python equivalents
    expr = expr.replace('<<', '<<')
    expr = expr.replace('>>', '>>')
    expr = expr.replace('&', '&')
    expr = expr.replace('|', '|')
    expr = expr.replace('^', '^')
    
    try:
        # Evaluate with limited scope
        result = eval(expr, {"__builtins__": {}}, safe_dict)
        return int(result)
    except Exception as e:
        raise ValueError(f"Expression evaluation failed: {e}")

def process_float_value(value_str):
    """Process floating point value"""
    value_str = value_str.strip().lower()
    
    if value_str == 'nan':
        value = float('nan')
    elif value_str == 'inf' or value_str == '+inf':
        value = float('inf')
    elif value_str == '-inf':
        value = float('-inf')
    else:
        value = float(value_str)
    
    data = struct.pack('<f', value)
    desc = f"{value} (0x{data.hex()})"
    return data, 4, desc

def process_double_value(value_str):
    """Process double precision floating point value"""
    value_str = value_str.strip().lower()
    
    if value_str == 'nan':
        value = float('nan')
    elif value_str == 'inf' or value_str == '+inf':
        value = float('inf')
    elif value_str == '-inf':
        value = float('-inf')
    else:
        value = float(value_str)
    
    data = struct.pack('<d', value)
    desc = f"{value} (0x{data.hex()})"
    return data, 8, desc

def process_string_value(value_str, size):
    """Process string value"""
    # Remove quotes if present
    if value_str.startswith('"') and value_str.endswith('"'):
        value_str = value_str[1:-1]
    elif value_str.startswith("'") and value_str.endswith("'"):
        value_str = value_str[1:-1]
    
    # Unescape special characters
    value_str = bytes(value_str, 'utf-8').decode('unicode_escape')
    
    # Encode as UTF-8
    data = value_str.encode('utf-8')
    
    # Truncate or pad to specified size
    if size > 0:
        if len(data) > size:
            data = data[:size]
        else:
            data = data.ljust(size, b'\x00')
    else:
        size = len(data)
    
    # Escape special characters for display
    display_str = value_str.replace('\n', '\\n').replace('\t', '\\t').replace('\r', '\\r')
    desc = f'"{display_str}"'
    
    return data, size, desc

def process_hex_value(value_str, size):
    """Process hex string value"""
    # Clean the hex string
    clean_hex = value_str.replace(' ', '').replace(':', '').replace('-', '').replace('0x', '')
    
    # Pad if odd length
    if len(clean_hex) % 2 != 0:
        clean_hex = '0' + clean_hex
    
    # Convert to bytes
    try:
        data = bytes.fromhex(clean_hex)
    except ValueError:
        # If it's not valid hex, treat as integer
        try:
            value = int(clean_hex, 16)
            data = value.to_bytes((max(size, 1) + 7) // 8, 'little')
        except:
            data = b'\x00'
    
    # Truncate or pad to specified size
    if size > 0:
        if len(data) > size:
            data = data[:size]
        else:
            data = data.ljust(size, b'\x00')
    else:
        size = len(data)
    
    desc = f"0x{data.hex()}"
    return data, size, desc

def interpret_data(data, data_type):
    """Interpret bytes as the specified data type for display"""
    try:
        if not data:
            return "No data"
            
        if data_type in ['uint8', 'int8', 'char']:
            if len(data) < 1:
                return "Insufficient data"
            if data_type == 'uint8':
                return f"0x{data[0]:02X} ({struct.unpack('<B', data[:1])[0]})"
            else:
                return f"0x{data[0]:02X} ({struct.unpack('<b', data[:1])[0]})"
                
        elif data_type in ['uint16', 'int16', 'short']:
            if len(data) < 2:
                return "Insufficient data"
            if data_type == 'uint16':
                value = struct.unpack('<H', data[:2])[0]
                return f"0x{value:04X} ({value})"
            else:
                value = struct.unpack('<h', data[:2])[0]
                return f"0x{value & 0xFFFF:04X} ({value})"
                
        elif data_type in ['uint32', 'int32', 'int']:
            if len(data) < 4:
                return "Insufficient data"
            if data_type == 'uint32':
                value = struct.unpack('<I', data[:4])[0]
                return f"0x{value:08X} ({value})"
            else:
                value = struct.unpack('<i', data[:4])[0]
                return f"0x{value & 0xFFFFFFFF:08X} ({value})"
                
        elif data_type in ['uint64', 'int64', 'long']:
            if len(data) < 8:
                return "Insufficient data"
            if data_type == 'uint64':
                value = struct.unpack('<Q', data[:8])[0]
                return f"0x{value:016X} ({value})"
            else:
                value = struct.unpack('<q', data[:8])[0]
                return f"0x{value & 0xFFFFFFFFFFFFFFFF:016X} ({value})"
                
        elif data_type == 'float':
            if len(data) < 4:
                return "Insufficient data"
            value = struct.unpack('<f', data[:4])[0]
            return f"{value} (0x{data[:4].hex()})"
            
        elif data_type == 'double':
            if len(data) < 8:
                return "Insufficient data"
            value = struct.unpack('<d', data[:8])[0]
            return f"{value} (0x{data[:8].hex()})"
            
        elif data_type == 'string':
            # Find null terminator
            null_pos = data.find(b'\x00')
            if null_pos != -1:
                string_data = data[:null_pos]
            else:
                string_data = data
            try:
                string = string_data.decode('utf-8', errors='replace')
                # Escape special characters for display
                string = string.replace('\n', '\\n').replace('\t', '\\t').replace('\r', '\\r')
                return f'"{string}"'
            except:
                return f"0x{data.hex()}"
                
        else:
            return f"0x{data.hex()}"
            
    except Exception as e:
        return f"Interpretation error: {e}"

# =============================================================================
# POKE-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================
def add_poke_arguments(parser):
    """Add poke-specific arguments to argument parser"""
    parser.add_argument("--bit-op", choices=['AND', 'OR', 'XOR', 'and', 'or', 'xor'],
                       help="Bitwise operation to perform")
    parser.add_argument("--no-verify", action="store_true",
                       help="Skip readback verification")
    parser.add_argument("--force", action="store_true",
                       help="Skip safety checks (DANGEROUS)")
    return parser