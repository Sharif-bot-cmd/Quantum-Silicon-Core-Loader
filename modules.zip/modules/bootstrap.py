def cmd_bootstrap(args=None):
    """Bootstrap management command"""
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    
    if not QSLCLBST_DB:
        print("[!] No QSLCLBST bootstrap configurations found in loader")
        return
    
    print("[*] QSLCL Bootstrap Manager v5.0")
    print(f"[*] Found {len(QSLCLBST_DB)//2} bootstrap configurations")
    
    # List available bootstrap configurations
    bootstrap_archs = [arch for arch in QSLCLBST_DB.keys() if not arch.startswith('offset_')]
    
    if not bootstrap_archs:
        print("[!] No bootstrap architectures found")
        return
    
    print("\n[*] Available bootstrap configurations:")
    for arch in bootstrap_archs:
        bst_info = QSLCLBST_DB[arch]
        print(f"  {arch:12} -> Entry: 0x{bst_info['entry_point']:08X}, "
              f"Secure: {bst_info['secure_mode']}, "
              f"CRC: {'VALID' if bst_info['crc_valid'] else 'INVALID'}")
    
    # If specific architecture requested, execute it
    if hasattr(args, 'architecture') and args.architecture:
        target_arch = args.architecture.upper()
        if target_arch in QSLCLBST_DB:
            print(f"\n[*] Executing bootstrap for {target_arch}...")
            return execute_bootstrap(dev, target_arch)
        else:
            print(f"[!] Bootstrap configuration for {target_arch} not found")
            return
    
    print("\n[*] Use --architecture <arch> to execute specific bootstrap")

def execute_bootstrap(dev, architecture):
    """Execute specific bootstrap configuration"""
    if architecture not in QSLCLBST_DB:
        print(f"[!] Bootstrap configuration for {architecture} not found")
        return False
    
    bst_info = QSLCLBST_DB[architecture]
    
    print(f"[*] Executing {architecture} bootstrap:")
    print(f"    Entry Point: 0x{bst_info['entry_point']:08X}")
    print(f"    Secure Mode: {bst_info['secure_mode']}")
    print(f"    Code Size: {bst_info['code_size']} bytes")
    print(f"    Architecture: {bst_info['arch_name']}")
    
    # Build bootstrap execution packet
    bootstrap_packet = b"QSLCLBST" + struct.pack("<I", bst_info['entry_point'])
    
    # Send bootstrap execution command
    try:
        resp = qslcl_dispatch(dev, "BOOTSTRAP", bootstrap_packet, timeout=5.0)
        if resp:
            status = decode_runtime_result(resp)
            print(f"[*] Bootstrap execution: {status}")
            return status.get("severity") == "SUCCESS"
        else:
            print("[!] No response from bootstrap execution")
            return False
    except Exception as e:
        print(f"[!] Bootstrap execution failed: {e}")
        return False

def verify_bootstrap_integrity(architecture=None):
    """Verify bootstrap integrity for specific or all architectures"""
    if not QSLCLBST_DB:
        print("[!] No bootstrap configurations found")
        return False
    
    if architecture:
        if architecture in QSLCLBST_DB:
            bst_info = QSLCLBST_DB[architecture]
            print(f"[*] Verifying {architecture} bootstrap:")
            print(f"    CRC Valid: {bst_info['crc_valid']}")
            print(f"    Stored CRC: 0x{bst_info['stored_crc']:08X}")
            print(f"    Calculated CRC: 0x{bst_info['calculated_crc']:08X}")
            return bst_info['crc_valid']
        else:
            print(f"[!] Bootstrap configuration for {architecture} not found")
            return False
    else:
        # Verify all bootstrap configurations
        all_valid = True
        bootstrap_archs = [arch for arch in QSLCLBST_DB.keys() if not arch.startswith('offset_')]
        
        print("[*] Verifying all bootstrap configurations:")
        for arch in bootstrap_archs:
            bst_info = QSLCLBST_DB[arch]
            status = "VALID" if bst_info['crc_valid'] else "INVALID"
            print(f"    {arch:12} -> {status}")
            if not bst_info['crc_valid']:
                all_valid = False
        
        return all_valid