def cmd_dump(args=None):
    """
    Fully implemented DUMP command with advanced features:
    - Smart memory region detection and handling
    - Multiple output formats and compression
    - Resume support for interrupted operations
    - Integrity verification with checksums
    - Progress tracking with ETA
    - Error recovery and retry mechanisms
    """
    if not args:
        print("[!] DUMP: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    address_str = getattr(args, 'address', '')
    size_str = getattr(args, 'size', '')
    output_path = getattr(args, 'output', '')
    chunk_size = getattr(args, 'chunk_size', 4096)
    verify = getattr(args, 'verify', False)
    compress = getattr(args, 'compress', False)
    resume = getattr(args, 'resume', False)
    retries = getattr(args, 'retries', 3)
    verbose = getattr(args, 'verbose', False)

    if not address_str:
        print("[!] DUMP: No address specified")
        return

    print(f"[*] DUMP command: address={address_str}, size={size_str}")

    # =========================================================================
    # 1. ADDRESS RESOLUTION AND SIZE DETERMINATION
    # =========================================================================
    try:
        address = resolve_address(address_str, dev)
        if address is None:
            print(f"[!] Could not resolve address: {address_str}")
            return
        
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Detect memory region
        region_info = detect_memory_region(address, dev)
        print(f"[+] Memory region: {region_info}")
        
    except Exception as e:
        print(f"[!] Address resolution failed: {e}")
        return

    # Determine dump size
    dump_size = 0
    if size_str:
        try:
            dump_size = parse_size_string(size_str)
        except ValueError as e:
            print(f"[!] Invalid size format: {size_str} - {e}")
            return
    else:
        # Auto-detect size based on region
        dump_size = auto_detect_dump_size(address, dev)
        if dump_size == 0:
            print("[!] Could not auto-detect dump size, specify --size")
            return
        print(f"[+] Auto-detected size: 0x{dump_size:08X} ({dump_size} bytes)")

    if dump_size <= 0:
        print("[!] Invalid dump size")
        return

    # =========================================================================
    # 2. OUTPUT FILE HANDLING
    # =========================================================================
    if not output_path:
        # Generate automatic output filename
        output_path = generate_dump_filename(address, dump_size, region_info)
        print(f"[+] Auto-generated output: {output_path}")

    # Handle resume operation
    existing_size = 0
    if resume and os.path.exists(output_path):
        existing_size = os.path.getsize(output_path)
        if existing_size > 0:
            print(f"[+] Resuming from existing file: {existing_size} bytes")
            if existing_size >= dump_size:
                print("[!] File already complete, use different output path")
                return
            address += existing_size
            dump_size -= existing_size
            print(f"[+] Resuming from: 0x{address:08X}, remaining: 0x{dump_size:08X}")

    # Check output directory
    output_dir = os.path.dirname(output_path) or '.'
    if not os.path.exists(output_dir):
        try:
            os.makedirs(output_dir, exist_ok=True)
            print(f"[+] Created output directory: {output_dir}")
        except Exception as e:
            print(f"[!] Cannot create output directory: {e}")
            return

    # Check disk space
    if not check_disk_space(output_dir, dump_size):
        print("[!] Insufficient disk space for dump")
        return

    # =========================================================================
    # 3. DUMP OPERATION PREPARATION
    # =========================================================================
    print(f"\n[*] DUMP OPERATION SUMMARY:")
    print(f"    Source: 0x{address:08X} ({region_info})")
    print(f"    Size: 0x{dump_size:08X} ({dump_size} bytes, {dump_size/1024/1024:.2f} MB)")
    print(f"    Output: {output_path}")
    print(f"    Chunk size: 0x{chunk_size:08X}")
    print(f"    Resume: {'Yes' if resume else 'No'}")
    print(f"    Verify: {'Yes' if verify else 'No'}")
    print(f"    Compress: {'Yes' if compress else 'No'}")

    # Calculate estimated time
    estimated_time = estimate_dump_time(dump_size, chunk_size)
    print(f"    Estimated time: {estimated_time}")

    if not resume and os.path.exists(output_path):
        response = input(f"\n[!] Output file exists: {output_path}. Overwrite? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return

    # =========================================================================
    # 4. DUMP OPERATION EXECUTION
    # =========================================================================
    print(f"\n[*] Starting dump operation...")
    
    bytes_dumped = 0
    total_chunks = (dump_size + chunk_size - 1) // chunk_size
    failed_chunks = []
    read_errors = 0
    start_time = time.time()
    
    # Open output file
    try:
        mode = 'ab' if resume and existing_size > 0 else 'wb'
        with open(output_path, mode) as output_file:
            
            with ProgressBar(dump_size, prefix='Dumping', suffix='Complete', length=50) as progress:
                chunk_num = 0
                
                while bytes_dumped < dump_size:
                    current_address = address + bytes_dumped
                    remaining = dump_size - bytes_dumped
                    current_chunk_size = min(chunk_size, remaining)
                    chunk_num += 1
                    
                    # Update progress with ETA
                    if bytes_dumped > 0:
                        elapsed = time.time() - start_time
                        speed = bytes_dumped / elapsed
                        eta = (dump_size - bytes_dumped) / speed if speed > 0 else 0
                        progress.suffix = f'ETA: {format_time(eta)} | {format_speed(speed)}'
                    
                    # Read chunk from device
                    chunk_data, read_success = read_memory_chunk(
                        dev, current_address, current_chunk_size, retries, verbose
                    )
                    
                    if read_success and chunk_data:
                        # Write to file
                        output_file.write(chunk_data)
                        output_file.flush()  # Ensure data is written to disk
                        
                        bytes_dumped += len(chunk_data)
                        progress.update(len(chunk_data))
                        
                        if verbose and chunk_num % 100 == 0:
                            print(f"\n[*] Progress: {chunk_num}/{total_chunks} chunks, {bytes_dumped}/{dump_size} bytes")
                            
                    else:
                        # Read failed
                        read_errors += 1
                        failed_chunks.append((current_address, current_chunk_size))
                        
                        if verbose:
                            print(f"\n[!] Read failed at 0x{current_address:08X}, size 0x{current_chunk_size:04X}")
                        
                        # Write zeros for failed chunk to maintain file alignment
                        zero_chunk = b'\x00' * current_chunk_size
                        output_file.write(zero_chunk)
                        bytes_dumped += current_chunk_size
                        progress.update(current_chunk_size)
                        
                        # Check if we should abort due to too many errors
                        if read_errors > retries * 3:
                            print(f"\n[!] Too many read errors, aborting dump")
                            break

    except Exception as e:
        print(f"\n[!] Dump operation failed: {e}")
        return

    # =========================================================================
    # 5. POST-DUMP PROCESSING
    # =========================================================================
    end_time = time.time()
    total_time = end_time - start_time
    actual_speed = bytes_dumped / total_time if total_time > 0 else 0
    
    print(f"\n[*] Dump operation completed")
    print(f"    Total time: {format_time(total_time)}")
    print(f"    Average speed: {format_speed(actual_speed)}")
    print(f"    Bytes dumped: {bytes_dumped}/{dump_size} ({bytes_dumped/dump_size*100:.1f}%)")
    print(f"    Read errors: {read_errors}")
    print(f"    Failed chunks: {len(failed_chunks)}")

    # Handle failed chunks
    if failed_chunks:
        print(f"\n[!] Failed chunks ({len(failed_chunks)}):")
        for i, (chunk_addr, chunk_size) in enumerate(failed_chunks[:10]):  # Show first 10
            print(f"    {i+1:3d}. 0x{chunk_addr:08X} - 0x{chunk_addr+chunk_size:08X} (0x{chunk_size:04X} bytes)")
        if len(failed_chunks) > 10:
            print(f"    ... and {len(failed_chunks) - 10} more")

    # =========================================================================
    # 6. INTEGRITY VERIFICATION
    # =========================================================================
    if verify and bytes_dumped > 0:
        print(f"\n[*] Verifying dump integrity...")
        verify_success = verify_dump_integrity(dev, address, output_path, bytes_dumped, chunk_size, verbose)
        
        if verify_success:
            print("[+] Integrity verification PASSED")
        else:
            print("[!] Integrity verification FAILED")

    # =========================================================================
    # 7. COMPRESSION (IF REQUESTED)
    # =========================================================================
    if compress and bytes_dumped > 0:
        print(f"\n[*] Compressing dump file...")
        compressed_path = output_path + '.gz'
        
        try:
            with open(output_path, 'rb') as f_in:
                with gzip.open(compressed_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            original_size = os.path.getsize(output_path)
            compressed_size = os.path.getsize(compressed_path)
            ratio = (1 - compressed_size / original_size) * 100
            
            print(f"[+] Compression completed:")
            print(f"    Original: {original_size} bytes")
            print(f"    Compressed: {compressed_size} bytes")
            print(f"    Compression ratio: {ratio:.1f}%")
            print(f"    Output: {compressed_path}")
            
            # Option to remove original
            response = input("\n[*] Remove original uncompressed file? (y/N): ")
            if response.lower() in ('y', 'yes'):
                os.remove(output_path)
                print("[+] Original file removed")
                
        except Exception as e:
            print(f"[!] Compression failed: {e}")

    # =========================================================================
    # 8. FINAL SUMMARY AND METADATA
    # =========================================================================
    print(f"\n[+] DUMP OPERATION COMPLETED!")
    print(f"    Output file: {output_path}")
    print(f"    File size: {bytes_dumped} bytes ({bytes_dumped/1024/1024:.2f} MB)")
    print(f"    Success rate: {bytes_dumped/dump_size*100:.1f}%")
    
    # Calculate and display checksum
    if bytes_dumped > 0 and os.path.exists(output_path):
        file_hash = calculate_file_hash(output_path)
        print(f"    SHA256: {file_hash}")
        
        # Save metadata
        metadata_path = output_path + '.meta'
        save_dump_metadata(metadata_path, address, dump_size, bytes_dumped, 
                          file_hash, region_info, failed_chunks)
        print(f"    Metadata: {metadata_path}")

    if failed_chunks:
        print(f"    WARNING: {len(failed_chunks)} chunks failed to read")
        print(f"    Use --resume to retry failed areas")

# =============================================================================
# SUPPORTING FUNCTIONS FOR DUMP COMMAND
# =============================================================================

def auto_detect_dump_size(address, dev):
    """Auto-detect appropriate dump size based on memory region"""
    partitions = load_partitions(dev)
    
    # Check if address is within a partition
    for part in partitions:
        if part['offset'] <= address < part['offset'] + part['size']:
            # Dump entire partition from the given address
            return part['offset'] + part['size'] - address
    
    # Common region sizes
    if 0x00000000 <= address < 0x01000000:
        return 0x01000000 - address  # First 16MB
    elif 0x10000000 <= address < 0x11000000:
        return 0x01000000  # Common peripheral region size
    elif 0x80000000 <= address < 0x90000000:
        return 0x10000000  # Common DRAM region size
    else:
        # Default to 16MB for unknown regions
        return 0x01000000

def generate_dump_filename(address, size, region_info):
    """Generate automatic filename for dump"""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    
    # Extract region name if available
    region_name = "memory"
    if "Partition:" in region_info:
        region_name = region_info.split(":")[1].strip().split(" ")[0].lower()
    elif "Memory:" in region_info:
        region_name = region_info.split(":")[1].strip().split(" ")[0].lower()
    
    # Format size for filename
    if size >= 1024*1024*1024:
        size_str = f"{size/1024/1024/1024:.1f}G"
    elif size >= 1024*1024:
        size_str = f"{size/1024/1024:.1f}M"
    elif size >= 1024:
        size_str = f"{size/1024:.1f}K"
    else:
        size_str = f"{size}B"
    
    filename = f"dump_{region_name}_0x{address:08X}_{size_str}_{timestamp}.bin"
    return filename

def check_disk_space(directory, required_size):
    """Check if there's enough disk space for the dump"""
    try:
        stat = shutil.disk_usage(directory)
        free_space = stat.free
        # Require 10% extra space for overhead
        required_with_overhead = required_size * 1.1
        
        if free_space < required_with_overhead:
            print(f"[!] Insufficient disk space:")
            print(f"    Required: {required_with_overhead/1024/1024:.1f} MB")
            print(f"    Available: {free_space/1024/1024:.1f} MB")
            return False
        return True
    except Exception as e:
        print(f"[!] Cannot check disk space: {e}")
        return True  # Continue anyway

def estimate_dump_time(size, chunk_size):
    """Estimate dump operation time"""
    # Base assumption: 100KB/s for slow devices, 1MB/s for fast ones
    base_speed = 100 * 1024  # 100 KB/s
    estimated_seconds = size / base_speed
    
    # Adjust for chunk size (larger chunks are generally faster)
    speed_multiplier = min(chunk_size / 4096, 10)  # Cap at 10x speedup
    estimated_seconds /= speed_multiplier
    
    return format_time(estimated_seconds)

def format_time(seconds):
    """Format seconds into human-readable time"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"

def format_speed(bytes_per_second):
    """Format bytes per second into human-readable speed"""
    if bytes_per_second >= 1024*1024:
        return f"{bytes_per_second/1024/1024:.1f} MB/s"
    elif bytes_per_second >= 1024:
        return f"{bytes_per_second/1024:.1f} KB/s"
    else:
        return f"{bytes_per_second:.1f} B/s"

def read_memory_chunk(dev, address, size, max_retries=3, verbose=False):
    """Read a chunk of memory with retry logic"""
    for attempt in range(max_retries + 1):
        try:
            read_payload = struct.pack("<II", address, size)
            
            if "READ" in QSLCLPAR_DB:
                resp = qslcl_dispatch(dev, "READ", read_payload)
            elif "DUMP" in QSLCLPAR_DB:
                resp = qslcl_dispatch(dev, "DUMP", read_payload)
            else:
                # Fallback
                cmd = f"READ 0x{address:08X} 0x{size:04X}"
                resp = qslcl_dispatch(dev, "READ", cmd.encode())
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    chunk_data = status["extra"]
                    if len(chunk_data) == size:
                        return chunk_data, True
                    elif len(chunk_data) > 0:
                        # Partial read, pad with zeros
                        padded_data = chunk_data.ljust(size, b'\x00')
                        if verbose:
                            print(f"[!] Partial read at 0x{address:08X}: got {len(chunk_data)}/{size} bytes")
                        return padded_data, True
                    else:
                        if verbose:
                            print(f"[!] Empty read at 0x{address:08X}")
                else:
                    if verbose and attempt == max_retries:
                        print(f"[!] Read error at 0x{address:08X}: {status}")
            else:
                if verbose and attempt == max_retries:
                    print(f"[!] No response at 0x{address:08X}")
                    
        except Exception as e:
            if verbose and attempt == max_retries:
                print(f"[!] Read exception at 0x{address:08X}: {e}")
        
        # Wait before retry (exponential backoff)
        if attempt < max_retries:
            time.sleep(0.1 * (2 ** attempt))
    
    return None, False

def verify_dump_integrity(dev, base_address, file_path, expected_size, chunk_size, verbose=False):
    """Verify dump integrity by reading back and comparing"""
    verified_bytes = 0
    errors = 0
    
    try:
        with open(file_path, 'rb') as f:
            with ProgressBar(expected_size, prefix='Verify', suffix='Complete', length=50) as progress:
                file_pos = 0
                
                while file_pos < expected_size:
                    current_address = base_address + file_pos
                    remaining = expected_size - file_pos
                    current_chunk_size = min(chunk_size, remaining)
                    
                    # Read from file
                    file_data = f.read(current_chunk_size)
                    if not file_data:
                        break
                    
                    # Skip verification for zero-filled chunks (likely read errors)
                    if all(b == 0 for b in file_data):
                        file_pos += len(file_data)
                        progress.update(len(file_data))
                        continue
                    
                    # Read from device for comparison
                    device_data, success = read_memory_chunk(dev, current_address, len(file_data), 1, False)
                    
                    if success and device_data:
                        if device_data == file_data:
                            verified_bytes += len(file_data)
                        else:
                            errors += 1
                            if verbose:
                                mismatches = sum(1 for i in range(len(file_data)) 
                                              if file_data[i] != device_data[i])
                                print(f"\n[!] Verify error at 0x{current_address:08X}: {mismatches}/{len(file_data)} bytes mismatch")
                    
                    file_pos += len(file_data)
                    progress.update(len(file_data))
        
        success_rate = verified_bytes / expected_size * 100 if expected_size > 0 else 0
        if verbose:
            print(f"\n[*] Verification results: {verified_bytes}/{expected_size} bytes ({success_rate:.1f}%), {errors} errors")
        
        return errors == 0 and verified_bytes == expected_size
        
    except Exception as e:
        print(f"[!] Integrity verification failed: {e}")
        return False

def calculate_file_hash(file_path):
    """Calculate SHA256 hash of file"""
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            # Read in chunks to handle large files
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    except Exception as e:
        return f"Hash error: {e}"

def save_dump_metadata(metadata_path, address, expected_size, actual_size, file_hash, region_info, failed_chunks):
    """Save dump operation metadata"""
    metadata = {
        'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
        'base_address': f"0x{address:08X}",
        'expected_size': expected_size,
        'actual_size': actual_size,
        'file_hash': file_hash,
        'region_info': region_info,
        'failed_chunks_count': len(failed_chunks),
        'failed_chunks': [
            {
                'address': f"0x{addr:08X}",
                'size': size
            } for addr, size in failed_chunks
        ]
    }
    
    try:
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
    except Exception as e:
        print(f"[!] Failed to save metadata: {e}")
