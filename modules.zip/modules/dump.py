def cmd_dump(args):
    """
    Advanced memory dumping with comprehensive features
    Supports intelligent region detection, compression, verification, and resume capabilities
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Enhanced argument parsing with more options
    if not hasattr(args, 'address') or not args.address:
        return print("[!] DUMP requires address/partition and output file")
    
    # Parse target (could be address, partition, or region name)
    target = args.address
    
    # Parse size with support for human-readable formats
    dump_size = parse_size_argument(args.size) if hasattr(args, 'size') and args.size else 0
    
    # Parse output path
    out_path = args.output if hasattr(args, 'output') and args.output else f"dump_{int(time.time())}.bin"
    
    # Handle different dump modes
    if target.upper() in ["PARTITIONS", "ALL"]:
        return dump_all_partitions(dev, out_path, args)
    elif target.upper() == "MEMORY":
        return dump_memory_regions(dev, out_path, args)
    elif target.upper() == "BOOT":
        return dump_boot_components(dev, out_path, args)
    elif target.upper() == "FIRMWARE":
        return dump_firmware_regions(dev, out_path, args)
    elif is_partition_name(target):
        return dump_partition(dev, target, out_path, args)
    elif is_region_name(target):
        return dump_region(dev, target, out_path, args)
    else:
        # Assume it's a raw address
        return dump_address_range(dev, target, dump_size, out_path, args)

def parse_size_argument(size_str):
    """
    Parse size argument with support for human-readable formats
    """
    if not size_str:
        return 0
    
    size_str = size_str.upper().strip()
    
    # Handle hex format
    if size_str.startswith("0X"):
        return int(size_str, 16)
    
    # Handle size suffixes
    multipliers = {
        'K': 1024,
        'M': 1024 * 1024,
        'G': 1024 * 1024 * 1024,
        'KB': 1024,
        'MB': 1024 * 1024,
        'GB': 1024 * 1024 * 1024
    }
    
    for suffix, multiplier in multipliers.items():
        if size_str.endswith(suffix):
            num_part = size_str[:-len(suffix)]
            try:
                return int(float(num_part) * multiplier)
            except ValueError:
                break
    
    # Default to decimal
    try:
        return int(size_str)
    except ValueError:
        print(f"[!] Invalid size format: {size_str}")
        return 0

def is_partition_name(name):
    """
    Check if the target is a partition name
    """
    common_partitions = [
        "boot", "recovery", "system", "vendor", "userdata", "cache",
        "modem", "persist", "misc", "frp", "devinfo", "metadata"
    ]
    return name.lower() in common_partitions

def is_region_name(name):
    """
    Check if the target is a known memory region
    """
    common_regions = [
        "kernel", "ramdisk", "dtb", "bootloader", "trustzone",
        "modem_fw", "dsp_fw", "gpu_fw", "efuse", "otp"
    ]
    return name.lower() in common_regions

def dump_address_range(dev, address_str, size, out_path, args):
    """
    Dump a specific address range
    """
    try:
        start_addr = int(address_str, 16) if address_str.startswith("0x") else int(address_str)
    except ValueError:
        print(f"[!] Invalid address format: {address_str}")
        return False
    
    if size <= 0:
        print("[!] Size must be specified for address dumping")
        return False
    
    print(f"[*] Dumping memory range: 0x{start_addr:08X} - 0x{start_addr + size:08X} ({size} bytes)")
    
    return perform_dump(dev, start_addr, size, out_path, args, "Memory Range")

def dump_partition(dev, partition_name, out_path, args):
    """
    Dump a specific partition
    """
    print(f"[*] Dumping partition: {partition_name}")
    
    try:
        # Load partition table
        parts = load_partitions(dev)
        partition_info = None
        
        for part in parts:
            if part['name'].lower() == partition_name.lower():
                partition_info = part
                break
        
        if not partition_info:
            print(f"[!] Partition '{partition_name}' not found")
            # Try to scan GPT
            scan_gpt(dev)
            parts = load_partitions(dev)
            for part in parts:
                if part['name'].lower() == partition_name.lower():
                    partition_info = part
                    break
        
        if not partition_info:
            print(f"[!] Cannot find partition '{partition_name}'")
            return False
        
        start_addr = partition_info['offset']
        size = partition_info['size']
        
        print(f"[*] Partition found: 0x{start_addr:08X} - 0x{start_addr + size:08X} ({size} bytes)")
        
        return perform_dump(dev, start_addr, size, out_path, args, f"Partition: {partition_name}")
        
    except Exception as e:
        print(f"[!] Error accessing partition '{partition_name}': {e}")
        return False

def dump_region(dev, region_name, out_path, args):
    """
    Dump a known memory region
    """
    region_name = region_name.lower()
    print(f"[*] Dumping region: {region_name}")
    
    # Define common memory regions
    region_map = {
        "kernel": (0x80000000, 0x01000000),  # 16MB kernel region
        "ramdisk": (0x81000000, 0x00800000),  # 8MB ramdisk
        "dtb": (0x81800000, 0x00100000),      # 1MB device tree
        "bootloader": (0x00000000, 0x00200000), # 2MB bootloader
        "trustzone": (0x0E000000, 0x00200000), # 2MB trustzone
        "modem_fw": (0x40000000, 0x01000000), # 16MB modem
        "dsp_fw": (0x41000000, 0x00800000),   # 8MB DSP
        "gpu_fw": (0x42000000, 0x00400000),   # 4MB GPU
        "efuse": (0x0005C000, 0x00001000),    # 4KB efuse
        "otp": (0x00060000, 0x00002000),      # 8KB OTP
    }
    
    if region_name not in region_map:
        print(f"[!] Unknown region: {region_name}")
        print(f"[*] Available regions: {', '.join(region_map.keys())}")
        return False
    
    start_addr, size = region_map[region_name]
    return perform_dump(dev, start_addr, size, out_path, args, f"Region: {region_name}")

def dump_all_partitions(dev, out_dir, args):
    """
    Dump all available partitions
    """
    print("[*] Dumping all partitions...")
    
    # Create output directory
    import os
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    
    # Load partitions
    parts = load_partitions(dev)
    if not parts:
        print("[!] No partitions found")
        return False
    
    success_count = 0
    total_size = 0
    
    print(f"[*] Found {len(parts)} partitions")
    
    for part in parts:
        part_name = part['name']
        part_file = os.path.join(out_dir, f"{part_name}.img")
        
        print(f"\n[*] Dumping {part_name}...")
        
        if perform_dump(dev, part['offset'], part['size'], part_file, args, f"Partition: {part_name}"):
            success_count += 1
            total_size += part['size']
    
    print(f"\n[✓] Partition dump complete: {success_count}/{len(parts)} partitions")
    print(f"[*] Total size: {total_size} bytes ({total_size / (1024*1024):.2f} MB)")
    
    return success_count > 0

def dump_memory_regions(dev, out_dir, args):
    """
    Dump common memory regions
    """
    print("[*] Dumping memory regions...")
    
    import os
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    
    regions = [
        ("kernel", 0x80000000, 0x01000000),
        ("ramdisk", 0x81000000, 0x00800000),
        ("dtb", 0x81800000, 0x00100000),
        ("bootloader", 0x00000000, 0x00200000),
        ("modem_fw", 0x40000000, 0x01000000),
    ]
    
    success_count = 0
    
    for region_name, start_addr, size in regions:
        region_file = os.path.join(out_dir, f"{region_name}.bin")
        print(f"\n[*] Dumping {region_name}...")
        
        if perform_dump(dev, start_addr, size, region_file, args, f"Region: {region_name}"):
            success_count += 1
    
    print(f"\n[✓] Memory region dump complete: {success_count}/{len(regions)} regions")
    return success_count > 0

def dump_boot_components(dev, out_dir, args):
    """
    Dump boot-related components
    """
    print("[*] Dumping boot components...")
    
    import os
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    
    boot_components = [
        ("pbl", 0x00000000, 0x00040000),      # Primary Bootloader
        ("sbl", 0x00040000, 0x00080000),      # Secondary Bootloader
        ("aboot", 0x000C0000, 0x00100000),    # Android Bootloader
        ("tz", 0x0E000000, 0x00200000),       # TrustZone
        ("rpm", 0x0E200000, 0x00040000),      # Resource Power Manager
    ]
    
    success_count = 0
    
    for comp_name, start_addr, size in boot_components:
        comp_file = os.path.join(out_dir, f"{comp_name}.bin")
        print(f"\n[*] Dumping {comp_name}...")
        
        if perform_dump(dev, start_addr, size, comp_file, args, f"Boot: {comp_name}"):
            success_count += 1
    
    print(f"\n[✓] Boot component dump complete: {success_count}/{len(boot_components)} components")
    return success_count > 0

def dump_firmware_regions(dev, out_dir, args):
    """
    Dump firmware regions
    """
    print("[*] Dumping firmware regions...")
    
    import os
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    
    firmware_regions = [
        ("modem", 0x40000000, 0x01000000),
        ("dsp", 0x41000000, 0x00800000),
        ("gpu", 0x42000000, 0x00400000),
        ("wlan", 0x43000000, 0x00200000),
        ("bt", 0x43100000, 0x00100000),
    ]
    
    success_count = 0
    
    for fw_name, start_addr, size in firmware_regions:
        fw_file = os.path.join(out_dir, f"{fw_name}_fw.bin")
        print(f"\n[*] Dumping {fw_name} firmware...")
        
        if perform_dump(dev, start_addr, size, fw_file, args, f"Firmware: {fw_name}"):
            success_count += 1
    
    print(f"\n[✓] Firmware dump complete: {success_count}/{len(firmware_regions)} regions")
    return success_count > 0

def perform_dump(dev, start_addr, size, out_path, args, description=""):
    """
    Core dumping function with advanced features
    """
    # Get sector size and align addresses
    sector = get_sector_size(dev)
    aligned_addr = start_addr & ~(sector - 1)
    aligned_end = align_up(start_addr + size, sector)
    total_size = aligned_end - aligned_addr
    
    print(f"[*] {description}")
    print(f"    Address: 0x{start_addr:08X} - 0x{start_addr + size:08X}")
    print(f"    Aligned: 0x{aligned_addr:08X} - 0x{aligned_end:08X}")
    print(f"    Size: {size} bytes (aligned: {total_size} bytes)")
    print(f"    Sector size: {sector} bytes")
    
    # Check for resume capability
    resume_offset = 0
    if getattr(args, 'resume', False) and os.path.exists(out_path):
        resume_offset = os.path.getsize(out_path)
        if resume_offset > 0:
            print(f"[*] Resuming from offset: {resume_offset} bytes")
            aligned_addr += resume_offset
            total_size -= resume_offset
    
    # Check available space
    if not check_disk_space(out_path, total_size):
        print("[!] Insufficient disk space")
        return False
    
    # Open output file
    try:
        mode = "ab" if resume_offset > 0 else "wb"
        f = open(out_path, mode)
    except Exception as e:
        print(f"[!] Cannot open output file: {e}")
        return False
    
    # Dump configuration
    chunk_size = getattr(args, 'chunk_size', 4096)
    verify_dump = getattr(args, 'verify', False)
    compress_dump = getattr(args, 'compress', False)
    max_retries = getattr(args, 'retries', 3)
    
    print(f"[*] Chunk size: {chunk_size} bytes")
    print(f"[*] Verification: {'Enabled' if verify_dump else 'Disabled'}")
    print(f"[*] Compression: {'Enabled' if compress_dump else 'Disabled'}")
    
    # Initialize progress tracking
    current = aligned_addr
    bytes_written = resume_offset
    start_time = time.time()
    retry_count = 0
    
    # Create checksum for verification
    import hashlib
    dump_hash = hashlib.sha256() if verify_dump else None
    
    print("\n[*] Starting dump...")
    
    try:
        while current < aligned_end and retry_count < max_retries:
            req_size = min(chunk_size, aligned_end - current)
            
            # Read data from device
            data = read_memory_chunk(dev, current, req_size, args)
            
            if data is None:
                retry_count += 1
                print(f"\n[!] Read failed at 0x{current:08X}, retry {retry_count}/{max_retries}")
                time.sleep(1)
                continue
            
            # Reset retry count on successful read
            retry_count = 0
            
            # Update checksum
            if dump_hash:
                dump_hash.update(data)
            
            # Write to file
            f.write(data)
            f.flush()  # Ensure data is written to disk
            
            # Update progress
            bytes_written += len(data)
            elapsed = time.time() - start_time
            speed = bytes_written / elapsed if elapsed > 0 else 0
            
            # Progress display
            progress = (bytes_written * 100.0) / total_size
            eta = (total_size - bytes_written) / speed if speed > 0 else 0
            
            print(f"\r[*] Progress: {progress:5.1f}% | {bytes_written}/{total_size} bytes | "
                  f"{speed/1024:.1f} KB/s | ETA: {eta:.1f}s", end="")
            
            current += req_size
        
        print()  # New line after progress
        
        if retry_count >= max_retries:
            print(f"\n[!] Too many consecutive read failures, aborting")
            f.close()
            return False
        
        # Finalize dump
        f.close()
        
        # Post-dump operations
        if verify_dump:
            print("[*] Verifying dump integrity...")
            if verify_dump_integrity(out_path, dump_hash):
                print("[✓] Dump verification passed")
            else:
                print("[!] Dump verification failed")
        
        if compress_dump:
            print("[*] Compressing dump...")
            compressed_path = compress_dump_file(out_path)
            if compressed_path:
                print(f"[✓] Compressed dump saved to: {compressed_path}")
        
        # Generate dump info
        generate_dump_info(out_path, start_addr, size, description, dump_hash)
        
        elapsed_total = time.time() - start_time
        avg_speed = total_size / elapsed_total if elapsed_total > 0 else 0
        
        print(f"\n[✓] Dump complete: {out_path}")
        print(f"    Total time: {elapsed_total:.1f}s")
        print(f"    Average speed: {avg_speed/1024:.1f} KB/s")
        print(f"    Final size: {bytes_written} bytes")
        
        return True
        
    except Exception as e:
        print(f"\n[!] Dump failed: {e}")
        f.close()
        return False

def read_memory_chunk(dev, address, size, args):
    """
    Read a chunk of memory with error handling and optimization
    """
    payload = struct.pack("<Q I", address, size)
    
    # Try different read methods in order of preference
    read_methods = [
        ("IDX", lambda: qslclidx_or_dispatch(dev, "READ", payload)),
        ("PAR", lambda: (qslcl_dispatch(dev, "READ", payload), "PAR")),
        ("ENGINE", lambda: (qslcl_dispatch(dev, "ENGINE", b"READ" + payload), "ENGINE")),
    ]
    
    for method_name, read_func in read_methods:
        try:
            resp, origin = read_func()
            
            if not resp:
                continue
            
            status = decode_runtime_result(resp)
            
            if status.get("severity") == "SUCCESS":
                data = status.get("extra", b"")
                if data and len(data) == size:
                    return data
                elif data and len(data) > 0:
                    # Pad or truncate to expected size
                    if len(data) < size:
                        data += b"\x00" * (size - len(data))
                    else:
                        data = data[:size]
                    return data
            
        except Exception as e:
            if getattr(args, 'verbose', False):
                print(f"[!] {method_name} read failed: {e}")
            continue
    
    return None

def check_disk_space(file_path, required_size):
    """
    Check if there's enough disk space for the dump
    """
    import os
    import shutil
    
    # Get the directory of the output file
    directory = os.path.dirname(os.path.abspath(file_path))
    
    # Get disk usage statistics
    try:
        total, used, free = shutil.disk_usage(directory)
        
        # Check if we have enough space (with 10% margin)
        if free < required_size * 1.1:
            print(f"[!] Insufficient disk space: {free} bytes available, {required_size} bytes required")
            return False
        
        return True
        
    except Exception as e:
        print(f"[!] Could not check disk space: {e}")
        return True  # Continue anyway

def verify_dump_integrity(file_path, expected_hash):
    """
    Verify the integrity of the dumped file
    """
    import hashlib
    
    if not expected_hash:
        return True
    
    try:
        with open(file_path, "rb") as f:
            file_hash = hashlib.sha256()
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                file_hash.update(chunk)
        
        return file_hash.hexdigest() == expected_hash.hexdigest()
        
    except Exception as e:
        print(f"[!] Verification error: {e}")
        return False

def compress_dump_file(file_path):
    """
    Compress the dump file using gzip
    """
    import gzip
    import os
    
    try:
        compressed_path = file_path + ".gz"
        
        with open(file_path, 'rb') as f_in:
            with gzip.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        # Calculate compression ratio
        original_size = os.path.getsize(file_path)
        compressed_size = os.path.getsize(compressed_path)
        ratio = (compressed_size / original_size) * 100
        
        print(f"    Compression: {original_size} -> {compressed_size} bytes ({ratio:.1f}%)")
        
        return compressed_path
        
    except Exception as e:
        print(f"[!] Compression failed: {e}")
        return None

def generate_dump_info(file_path, start_addr, size, description, file_hash):
    """
    Generate a metadata file with dump information
    """
    import os
    import json
    
    info_file = file_path + ".info"
    
    try:
        info = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "description": description,
            "start_address": f"0x{start_addr:08X}",
            "size": size,
            "file_size": os.path.getsize(file_path),
            "hash_sha256": file_hash.hexdigest() if file_hash else "N/A",
            "sector_size": get_sector_size(dev) if 'dev' in locals() else "Unknown"
        }
        
        with open(info_file, 'w') as f:
            json.dump(info, f, indent=2)
        
        print(f"[*] Dump info saved to: {info_file}")
        
    except Exception as e:
        print(f"[!] Could not generate dump info: {e}")

def update_dump_parser(sub):
    """
    Update the DUMP command parser with enhanced options
    """
    dump_parser = sub.add_parser("dump", help="Advanced memory dumping with multiple modes")
    dump_parser.add_argument("address", help="Address, partition name, or region to dump")
    dump_parser.add_argument("size", nargs="?", help="Size to dump (bytes, K, M, G, or hex with 0x)")
    dump_parser.add_argument("output", nargs="?", help="Output file or directory path")
    
    # Enhanced options
    dump_parser.add_argument("--chunk-size", type=int, default=4096, help="Read chunk size (default: 4096)")
    dump_parser.add_argument("--verify", action="store_true", help="Verify dump integrity with SHA256")
    dump_parser.add_argument("--compress", action="store_true", help="Compress dump with gzip")
    dump_parser.add_argument("--resume", action="store_true", help="Resume interrupted dump")
    dump_parser.add_argument("--retries", type=int, default=3, help="Max retries for failed reads")
    dump_parser.add_argument("--verbose", action="store_true", help="Verbose output")
    
    dump_parser.set_defaults(func=cmd_dump)
