def cmd_dump(args=None):
    """
    Fully implemented DUMP command with advanced features:
    - Smart memory region detection and handling
    - Multiple output formats and compression
    - Resume support for interrupted operations
    - Integrity verification with checksums
    - Progress tracking with ETA
    - Error recovery and retry mechanisms
    UPDATED for QSLCL v1.2.5 consolidated system
    """
    if not args:
        print("[!] DUMP: No arguments provided")
        return 1

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    address_str = getattr(args, 'address', '')
    size_str = getattr(args, 'size', '')
    output_path = getattr(args, 'output', '')
    chunk_size = getattr(args, 'chunk_size', 4096)
    verify = getattr(args, 'verify', False)
    compress = getattr(args, 'compress', False)
    resume = getattr(args, 'resume', False)
    retries = getattr(args, 'retries', 3)
    verbose = getattr(args, 'verbose', False)

    if not address_str:
        print("[!] DUMP: No address specified")
        return 1

    print(f"[*] DUMP command: address={address_str}, size={size_str}")

    # =========================================================================
    # 1. ADDRESS RESOLUTION AND SIZE DETERMINATION
    # =========================================================================
    try:
        partitions = load_partitions(dev)
        memory_regions = detect_memory_regions(dev)
        
        resolved = resolve_target(address_str, partitions, memory_regions, dev)
        if resolved is None:
            print(f"[!] Could not resolve target: {address_str}")
            return 1
            
        address = resolved['address']
        max_available_size = resolved.get('size', 0)
        region_info = resolved.get('region_info', {})
        partition_info = resolved.get('partition_info', {})
        
        print(f"[+] Resolved address: 0x{address:08X}")
        
        # Format region info for display
        if region_info:
            region_display = f"Memory: {region_info.get('name', 'unknown')} (0x{region_info.get('start', 0):08X}-0x{region_info.get('end', 0):08X})"
        elif partition_info:
            region_display = f"Partition: {partition_info.get('name', 'unknown')} (0x{partition_info.get('offset', 0):08X}-0x{partition_info.get('offset', 0)+partition_info.get('size', 0):08X})"
        else:
            region_display = "Raw address"
            
        print(f"[+] {region_display}")
        print(f"[+] Maximum available size: 0x{max_available_size:08X} ({max_available_size} bytes)")
        
    except Exception as e:
        print(f"[!] Address resolution failed: {e}")
        # Try direct parsing as fallback
        try:
            address = parse_address(address_str)
            print(f"[+] Parsed direct address: 0x{address:08X}")
            region_display = "Raw address (direct)"
            max_available_size = 0  # Unknown
        except Exception as e2:
            print(f"[!] Direct address parsing also failed: {e2}")
            return 1

    # Determine dump size
    dump_size = 0
    if size_str:
        try:
            dump_size = parse_size_string(size_str)
            print(f"[+] Using specified size: 0x{dump_size:08X} ({dump_size} bytes)")
        except (ValueError, Exception) as e:
            print(f"[!] Invalid size format: {size_str} - {e}")
            return 1
    else:
        # Use maximum available size
        dump_size = max_available_size
        if dump_size == 0:
            print("[!] Could not determine dump size. Please specify --size")
            return 1
            
        print(f"[+] Using auto-detected size: 0x{dump_size:08X} ({dump_size} bytes, {dump_size/1024/1024:.2f} MB)")

    if dump_size <= 0:
        print("[!] Invalid dump size (must be > 0)")
        return 1

    # Safety check: prevent dumping too much
    MAX_DUMP_SIZE = 4 * 1024 * 1024 * 1024  # 4GB max
    if dump_size > MAX_DUMP_SIZE:
        print(f"[!] Dump size too large: {dump_size} bytes ({dump_size/1024/1024/1024:.2f} GB)")
        print(f"[!] Maximum allowed: {MAX_DUMP_SIZE} bytes")
        response = input("[?] Continue anyway? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return 1

    # =========================================================================
    # 2. OUTPUT FILE HANDLING
    # =========================================================================
    if not output_path:
        # Generate automatic output filename
        output_path = generate_dump_filename(address, dump_size, region_display)
        print(f"[+] Auto-generated output: {output_path}")

    # Handle resume operation
    existing_size = 0
    if resume and os.path.exists(output_path):
        try:
            existing_size = os.path.getsize(output_path)
            if existing_size > 0:
                print(f"[+] Resuming from existing file: {existing_size} bytes")
                if existing_size >= dump_size:
                    print("[!] File already complete, use different output path")
                    return 1
                address += existing_size
                dump_size -= existing_size
                print(f"[+] Resuming from: 0x{address:08X}, remaining: 0x{dump_size:08X}")
        except Exception as e:
            print(f"[!] Error checking existing file: {e}")
            existing_size = 0

    # Check output directory
    output_dir = os.path.dirname(output_path) or '.'
    if not os.path.exists(output_dir):
        try:
            os.makedirs(output_dir, exist_ok=True)
            print(f"[+] Created output directory: {output_dir}")
        except Exception as e:
            print(f"[!] Cannot create output directory: {e}")
            return 1

    # Check disk space
    if not check_disk_space(output_dir, dump_size):
        print("[!] Insufficient disk space for dump")
        return 1

    # =========================================================================
    # 3. DUMP OPERATION PREPARATION
    # =========================================================================
    print(f"\n[*] DUMP OPERATION SUMMARY:")
    print(f"    Source: 0x{address:08X} ({region_display})")
    print(f"    Size: 0x{dump_size:08X} ({dump_size} bytes, {dump_size/1024/1024:.2f} MB)")
    print(f"    Output: {output_path}")
    print(f"    Chunk size: 0x{chunk_size:08X}")
    print(f"    Resume: {'Yes' if resume and existing_size > 0 else 'No'}")
    print(f"    Verify: {'Yes' if verify else 'No'}")
    print(f"    Compress: {'Yes' if compress else 'No'}")
    print(f"    Retries: {retries}")

    # Calculate estimated time
    estimated_time = estimate_dump_time(dump_size, chunk_size)
    print(f"    Estimated time: {estimated_time}")

    if not resume and os.path.exists(output_path):
        response = input(f"\n[!] Output file exists: {output_path}. Overwrite? (y/N): ")
        if response.lower() not in ('y', 'yes'):
            print("[*] Operation cancelled")
            return 1

    # =========================================================================
    # 4. DUMP OPERATION EXECUTION
    # =========================================================================
    print(f"\n[*] Starting dump operation...")
    
    bytes_dumped = 0
    total_chunks = (dump_size + chunk_size - 1) // chunk_size
    failed_chunks = []
    read_errors = 0
    start_time = time.time()
    
    # Open output file
    try:
        mode = 'ab' if resume and existing_size > 0 else 'wb'
        with open(output_path, mode) as output_file:
            
            # Create progress bar
            with ProgressBar(dump_size, prefix='Dumping', suffix='Complete', length=50) as progress:
                chunk_num = 0
                
                while bytes_dumped < dump_size:
                    current_address = address + bytes_dumped
                    remaining = dump_size - bytes_dumped
                    current_chunk_size = min(chunk_size, remaining)
                    chunk_num += 1
                    
                    # Update progress with ETA
                    if bytes_dumped > 0:
                        elapsed = time.time() - start_time
                        speed = bytes_dumped / elapsed if elapsed > 0 else 0
                        eta = (dump_size - bytes_dumped) / speed if speed > 0 else 0
                        progress.suffix = f'ETA: {format_time(eta)} | {format_speed(speed)}'
                    
                    # Read chunk from device
                    chunk_data, read_success = read_memory_chunk(
                        dev, current_address, current_chunk_size, retries, verbose
                    )
                    
                    if read_success and chunk_data:
                        # Write to file
                        output_file.write(chunk_data)
                        output_file.flush()  # Ensure data is written to disk
                        
                        bytes_dumped += len(chunk_data)
                        progress.update(len(chunk_data))
                        
                        if verbose and chunk_num % 100 == 0:
                            print(f"\n[*] Progress: {chunk_num}/{total_chunks} chunks, {bytes_dumped}/{dump_size} bytes")
                            
                    else:
                        # Read failed
                        read_errors += 1
                        failed_chunks.append((current_address, current_chunk_size))
                        
                        if verbose:
                            print(f"\n[!] Read failed at 0x{current_address:08X}, size 0x{current_chunk_size:04X}")
                        
                        # Write zeros for failed chunk to maintain file alignment
                        zero_chunk = b'\x00' * current_chunk_size
                        output_file.write(zero_chunk)
                        output_file.flush()
                        bytes_dumped += current_chunk_size
                        progress.update(current_chunk_size)
                        
                        # Check if we should abort due to too many errors
                        if read_errors > retries * 3:
                            print(f"\n[!] Too many read errors ({read_errors}), aborting dump")
                            break

    except KeyboardInterrupt:
        print(f"\n\n[!] Dump interrupted by user at {bytes_dumped}/{dump_size} bytes")
        print(f"[*] Partial dump saved to: {output_path}")
        return 1
    except Exception as e:
        print(f"\n[!] Dump operation failed: {e}")
        traceback.print_exc()
        return 1

    # =========================================================================
    # 5. POST-DUMP PROCESSING
    # =========================================================================
    end_time = time.time()
    total_time = end_time - start_time
    actual_speed = bytes_dumped / total_time if total_time > 0 else 0
    
    print(f"\n[*] Dump operation completed")
    print(f"    Total time: {format_time(total_time)}")
    print(f"    Average speed: {format_speed(actual_speed)}")
    print(f"    Bytes dumped: {bytes_dumped}/{dump_size} ({bytes_dumped/dump_size*100:.1f}%)")
    print(f"    Read errors: {read_errors}")
    print(f"    Failed chunks: {len(failed_chunks)}")

    # Handle failed chunks
    if failed_chunks:
        print(f"\n[!] Failed chunks ({len(failed_chunks)}):")
        for i, (chunk_addr, chunk_size_val) in enumerate(failed_chunks[:10]):  # Show first 10
            print(f"    {i+1:3d}. 0x{chunk_addr:08X} - 0x{chunk_addr+chunk_size_val:08X} (0x{chunk_size_val:04X} bytes)")
        if len(failed_chunks) > 10:
            print(f"    ... and {len(failed_chunks) - 10} more")

    # =========================================================================
    # 6. INTEGRITY VERIFICATION
    # =========================================================================
    if verify and bytes_dumped > 0:
        print(f"\n[*] Verifying dump integrity...")
        verify_success = verify_dump_integrity(dev, address - existing_size if resume else address, 
                                             output_path, bytes_dumped + existing_size, 
                                             chunk_size, verbose)
        
        if verify_success:
            print("[+] Integrity verification PASSED")
        else:
            print("[!] Integrity verification FAILED")

    # =========================================================================
    # 7. COMPRESSION (IF REQUESTED)
    # =========================================================================
    final_output_path = output_path
    if compress and bytes_dumped > 0:
        print(f"\n[*] Compressing dump file...")
        compressed_path = output_path + '.gz'
        
        try:
            with open(output_path, 'rb') as f_in:
                with gzip.open(compressed_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            original_size = os.path.getsize(output_path)
            compressed_size = os.path.getsize(compressed_path)
            ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
            
            print(f"[+] Compression completed:")
            print(f"    Original: {original_size} bytes")
            print(f"    Compressed: {compressed_size} bytes")
            print(f"    Compression ratio: {ratio:.1f}%")
            print(f"    Output: {compressed_path}")
            
            # Update final output path
            final_output_path = compressed_path
            
            # Option to remove original
            response = input("\n[*] Remove original uncompressed file? (y/N): ")
            if response.lower() in ('y', 'yes'):
                os.remove(output_path)
                print("[+] Original file removed")
                
        except Exception as e:
            print(f"[!] Compression failed: {e}")

    # =========================================================================
    # 8. FINAL SUMMARY AND METADATA
    # =========================================================================
    print(f"\n[+] DUMP OPERATION COMPLETED!")
    print(f"    Output file: {final_output_path}")
    print(f"    File size: {bytes_dumped + existing_size} bytes ({(bytes_dumped + existing_size)/1024/1024:.2f} MB)")
    print(f"    Success rate: {(bytes_dumped - len(failed_chunks) * chunk_size)/dump_size*100:.1f}%")
    
    # Calculate and display checksum
    if os.path.exists(final_output_path):
        file_hash = calculate_file_hash(final_output_path)
        print(f"    SHA256: {file_hash}")
        
        # Save metadata
        metadata_path = final_output_path + '.meta'
        save_dump_metadata(metadata_path, address - existing_size if resume else address, 
                          dump_size + existing_size, bytes_dumped + existing_size, 
                          file_hash, region_display, failed_chunks)
        print(f"    Metadata: {metadata_path}")

    if failed_chunks:
        print(f"    WARNING: {len(failed_chunks)} chunks failed to read")
        print(f"    Use --resume to retry failed areas")

    return 0

# =============================================================================
# SUPPORTING FUNCTIONS FOR DUMP COMMAND (FIXED)
# =============================================================================

def generate_dump_filename(address, size, region_info):
    """Generate automatic filename for dump"""
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    
    # Extract region name if available
    region_name = "memory"
    if "Partition:" in region_info:
        region_name = region_info.split(":")[1].strip().split(" ")[0].lower()
    elif "Memory:" in region_info:
        region_name = region_info.split(":")[1].strip().split(" ")[0].lower()
    
    # Clean region name for filename
    region_name = re.sub(r'[^a-z0-9_-]', '_', region_name)
    
    # Format size for filename
    if size >= 1024*1024*1024:
        size_str = f"{size/1024/1024/1024:.1f}G"
    elif size >= 1024*1024:
        size_str = f"{size/1024/1024:.1f}M"
    elif size >= 1024:
        size_str = f"{size/1024:.1f}K"
    else:
        size_str = f"{size}B"
    
    filename = f"dump_{region_name}_0x{address:08X}_{size_str}_{timestamp}.bin"
    return filename

def check_disk_space(directory, required_size):
    """Check if there's enough disk space for the dump"""
    try:
        stat = shutil.disk_usage(directory)
        free_space = stat.free
        # Require 10% extra space for overhead
        required_with_overhead = required_size * 1.1
        
        if free_space < required_with_overhead:
            print(f"[!] Insufficient disk space:")
            print(f"    Required: {required_with_overhead/1024/1024:.1f} MB")
            print(f"    Available: {free_space/1024/1024:.1f} MB")
            return False
        return True
    except Exception as e:
        print(f"[!] Cannot check disk space: {e}")
        return True  # Continue anyway

def estimate_dump_time(size, chunk_size):
    """Estimate dump operation time"""
    # Base assumption: 100KB/s for slow devices, 1MB/s for fast ones
    base_speed = 100 * 1024  # 100 KB/s
    estimated_seconds = size / base_speed
    
    # Adjust for chunk size (larger chunks are generally faster)
    speed_multiplier = min(chunk_size / 4096, 10)  # Cap at 10x speedup
    estimated_seconds /= speed_multiplier
    
    return format_time(estimated_seconds)

def format_time(seconds):
    """Format seconds into human-readable time"""
    if seconds < 0.1:
        return "<0.1s"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"

def format_speed(bytes_per_second):
    """Format bytes per second into human-readable speed"""
    if bytes_per_second <= 0:
        return "0 B/s"
    elif bytes_per_second >= 1024*1024*1024:
        return f"{bytes_per_second/1024/1024/1024:.2f} GB/s"
    elif bytes_per_second >= 1024*1024:
        return f"{bytes_per_second/1024/1024:.2f} MB/s"
    elif bytes_per_second >= 1024:
        return f"{bytes_per_second/1024:.2f} KB/s"
    else:
        return f"{bytes_per_second:.1f} B/s"

def read_memory_chunk(dev, address, size, max_retries=3, verbose=False):
    """Read a chunk of memory with retry logic using QSLCLCMD system"""
    try:
        from qslcl import qslcl_dispatch, decode_runtime_result, QSLCLCMD_DB
    except ImportError:
        return None, False
    
    for attempt in range(max_retries + 1):
        try:
            # Build payload for READ command
            # Format: address (4 bytes) + size (4 bytes) + optional flags (4 bytes)
            read_payload = struct.pack("<III", address, size, 0x00)
            
            # Try READ command through QSLCLCMD system
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                # Check if response is a valid runtime result
                result = decode_runtime_result(resp)
                
                if result.get("severity") == "SUCCESS":
                    # Success - extract data from extra field
                    extra_data = result.get("extra", b"")
                    if len(extra_data) == size:
                        return extra_data, True
                    elif len(extra_data) > 0:
                        # Partial read, pad with zeros
                        padded_data = extra_data.ljust(size, b'\x00')
                        if verbose:
                            print(f"[!] Partial read at 0x{address:08X}: got {len(extra_data)}/{size} bytes")
                        return padded_data, True
                elif verbose:
                    print(f"[!] Read error at 0x{address:08X}: {result.get('name', 'Unknown error')}")
                    
        except KeyboardInterrupt:
            raise  # Re-raise keyboard interrupt
        except Exception as e:
            if verbose and attempt == max_retries:
                print(f"[!] Read exception at 0x{address:08X}: {e}")
        
        # Wait before retry (exponential backoff)
        if attempt < max_retries:
            time.sleep(0.1 * (2 ** attempt))
    
    return None, False

def verify_dump_integrity(dev, base_address, file_path, expected_size, chunk_size, verbose=False):
    """Verify dump integrity by reading back and comparing"""
    verified_bytes = 0
    errors = 0
    
    try:
        with open(file_path, 'rb') as f:
            # Create progress bar for verification
            try:
                from qslcl import ProgressBar
                with ProgressBar(expected_size, prefix='Verify', suffix='Complete', length=50) as progress:
                    file_pos = 0
                    
                    while file_pos < expected_size:
                        current_address = base_address + file_pos
                        remaining = expected_size - file_pos
                        current_chunk_size = min(chunk_size, remaining)
                        
                        # Read from file
                        file_data = f.read(current_chunk_size)
                        if not file_data:
                            break
                        
                        # Skip verification for zero-filled chunks (likely read errors)
                        if all(b == 0 for b in file_data):
                            file_pos += len(file_data)
                            progress.update(len(file_data))
                            continue
                        
                        # Read from device for comparison
                        device_data, success = read_memory_chunk(dev, current_address, len(file_data), 1, False)
                        
                        if success and device_data:
                            if device_data == file_data:
                                verified_bytes += len(file_data)
                            else:
                                errors += 1
                                if verbose:
                                    mismatches = sum(1 for i in range(len(file_data)) 
                                                  if file_data[i] != device_data[i])
                                    print(f"\n[!] Verify error at 0x{current_address:08X}: {mismatches}/{len(file_data)} bytes mismatch")
                        
                        file_pos += len(file_data)
                        progress.update(len(file_data))
            except ImportError:
                # Fallback if ProgressBar not available
                print("[*] Verifying dump integrity...")
                chunk_count = 0
                while True:
                    file_data = f.read(chunk_size)
                    if not file_data:
                        break
                    chunk_count += 1
                    if chunk_count % 100 == 0:
                        print(f"[*] Verified {chunk_count} chunks...")
        
        success_rate = verified_bytes / expected_size * 100 if expected_size > 0 else 0
        if verbose:
            print(f"\n[*] Verification results: {verified_bytes}/{expected_size} bytes ({success_rate:.1f}%), {errors} errors")
        
        return errors == 0 and verified_bytes == expected_size
        
    except Exception as e:
        print(f"[!] Integrity verification failed: {e}")
        return False

def calculate_file_hash(file_path):
    """Calculate SHA256 hash of file"""
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path, "rb") as f:
            # Read in chunks to handle large files
            for chunk in iter(lambda: f.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    except Exception as e:
        return f"Hash error: {e}"

def save_dump_metadata(metadata_path, address, expected_size, actual_size, file_hash, region_info, failed_chunks):
    """Save dump operation metadata"""
    metadata = {
        'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
        'base_address': f"0x{address:08X}",
        'expected_size': expected_size,
        'actual_size': actual_size,
        'file_hash': file_hash,
        'region_info': region_info,
        'failed_chunks_count': len(failed_chunks),
        'failed_chunks': [
            {
                'address': f"0x{addr:08X}",
                'size': size_val
            } for addr, size_val in failed_chunks
        ]
    }
    
    try:
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
    except Exception as e:
        print(f"[!] Failed to save metadata: {e}")