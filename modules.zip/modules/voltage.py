def cmd_voltage(args=None):
    """
    Fully implemented VOLTAGE command with advanced features:
    - Multi-rail voltage monitoring and control
    - PMIC (Power Management IC) register access
    - Voltage scaling and dynamic adjustment
    - Power domain management
    - Safety limits and validation
    - Real-time power monitoring
    """
    if args is None:
        print("[!] VOLTAGE: No arguments provided")
        print_voltage_help()
        return 1

    # Import required functions locally to avoid circular imports
    try:
        from main import scan_all, auto_loader_if_needed, qslcl_dispatch, decode_runtime_result
    except ImportError:
        # Fallback to global imports
        pass

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return 1

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'voltage_subcommand', '').lower() if hasattr(args, 'voltage_subcommand') else ''
    voltage_args = getattr(args, 'voltage_args', []) if hasattr(args, 'voltage_args') else []
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)

    if not subcommand:
        print("[!] VOLTAGE: No subcommand specified")
        print_voltage_help()
        return 1

    print(f"[*] VOLTAGE command: {subcommand} {voltage_args if voltage_args else ''}")

    # =========================================================================
    # SUBCOMMAND DISPATCH WITH ERROR HANDLING
    # =========================================================================
    try:
        if subcommand in ['list', 'ls', 'rails']:
            return voltage_list(dev, voltage_args, verbose)
            
        elif subcommand in ['read', 'get', 'measure']:
            return voltage_read(dev, voltage_args, verbose)
            
        elif subcommand in ['set', 'write', 'adjust']:
            return voltage_set(dev, voltage_args, force, verbose)
            
        elif subcommand in ['monitor', 'watch', 'log']:
            return voltage_monitor(dev, voltage_args, verbose)
            
        elif subcommand in ['scale', 'vscale', 'dvs']:
            return voltage_scale(dev, voltage_args, force, verbose)
            
        elif subcommand in ['limits', 'range', 'spec']:
            return voltage_limits(dev, voltage_args, verbose)
            
        elif subcommand in ['calibrate', 'cal']:
            return voltage_calibrate(dev, voltage_args, force, verbose)
            
        elif subcommand in ['reset', 'default', 'normal']:
            return voltage_reset(dev, voltage_args, force, verbose)
            
        elif subcommand in ['pmic', 'register', 'reg']:
            return voltage_pmic(dev, voltage_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_voltage_help()
            return 0
            
        else:
            print(f"[!] Unknown VOLTAGE subcommand: {subcommand}")
            print_voltage_help()
            return 1
            
    except KeyboardInterrupt:
        print("\n[*] VOLTAGE command interrupted by user")
        return 130  # Standard interrupt exit code
        
    except Exception as e:
        print(f"[!] VOLTAGE operation failed: {e}")
        import traceback
        if verbose:
            traceback.print_exc()
        return 1

# =============================================================================
# FIX 3: ENHANCED VOLTAGE LIST WITH BETTER ERROR HANDLING
# =============================================================================
def voltage_list(dev, args, verbose=False):
    """List available voltage rails and power domains"""
    print("[*] Querying voltage rail information...")
    
    try:
        capabilities = query_voltage_capabilities(dev, verbose)
        
        if not capabilities:
            print("[!] Failed to query voltage capabilities")
            return 1
        
        print(f"\n[+] Voltage System Overview:")
        print(f"    PMIC: {capabilities.get('pmic_name', 'Unknown')}")
        print(f"    Architecture: {capabilities.get('architecture', 'Unknown')}")
        print(f"    Voltage Control: {capabilities.get('voltage_control', 'Basic')}")
        
        # List voltage rails
        voltage_rails = capabilities.get('voltage_rails', [])
        if voltage_rails:
            print(f"\n[+] Voltage Rails ({len(voltage_rails)} total):")
            for i, rail in enumerate(voltage_rails, 1):
                status = "✓" if rail.get('enabled', False) else "✗"
                current_uv = rail.get('current_uv', 0)
                target_uv = rail.get('target_uv', 0)
                current_v = current_uv / 1000000.0 if current_uv > 0 else 0.0
                
                # Format output
                line = f"    {i:2d}. {status} {rail['name']:15} {current_v:6.3f}V"
                
                if target_uv > 0 and abs(target_uv - current_uv) > 1000:  # 1mV difference
                    target_v = target_uv / 1000000.0
                    line += f" (target: {target_v:.3f}V)"
                
                if rail.get('description'):
                    line += f" - {rail['description']}"
                
                print(line)
        else:
            print("[!] No voltage rails detected")
            return 1
        
        # List power domains
        power_domains = capabilities.get('power_domains', [])
        if power_domains:
            print(f"\n[+] Power Domains ({len(power_domains)} total):")
            for i, domain in enumerate(power_domains, 1):
                state = domain.get('state', 'UNKNOWN')
                state_icon = {
                    'ON': '🟢',
                    'OFF': '🔴',
                    'STANDBY': '🟡',
                    'SLEEP': '💤'
                }.get(state, '❓')
                
                print(f"    {i:2d}. {state_icon} {domain['name']:20} - {domain.get('description', '')}")
        
        return 0
        
    except Exception as e:
        print(f"[!] Failed to list voltage information: {e}")
        return 1

# =============================================================================
# FIX 4: IMPROVED VOLTAGE READ WITH VALIDATION
# =============================================================================
def voltage_read(dev, args, verbose=False):
    """Read current voltage values"""
    try:
        if not args:
            # Read all voltages
            print("[*] Reading all voltage rails...")
            return read_all_voltages(dev, verbose)
        
        rail_name = args[0].upper()
        
        # Validate rail name
        if not rail_name or len(rail_name) > 16:
            print(f"[!] Invalid rail name: {rail_name}")
            return 1
        
        print(f"[*] Reading voltage: {rail_name}")
        
        # Build read command with proper error handling
        try:
            read_payload = struct.pack("<B", 0x10)  # READ_VOLTAGE command
            read_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
        except UnicodeEncodeError:
            print(f"[!] Invalid characters in rail name: {rail_name}")
            return 1
        
        resp = qslcl_dispatch(dev, "VOLTAGE", read_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                voltage_data = parse_voltage_data(status["extra"])
                if voltage_data.get('voltage_uv', -1) >= 0:
                    display_voltage_reading(rail_name, voltage_data)
                    return 0
                else:
                    print(f"[!] Invalid voltage data received for {rail_name}")
                    return 1
            else:
                print(f"[!] Voltage read failed: {status.get('name', 'Unknown error')}")
                return 1
        else:
            print("[!] No response from device")
            return 1
            
    except Exception as e:
        print(f"[!] Voltage read error: {e}")
        return 1

# =============================================================================
# FIX 5: SAFER VOLTAGE SET WITH ENHANCED VALIDATION
# =============================================================================
def voltage_set(dev, args, force=False, verbose=False):
    """Set voltage to specific value"""
    try:
        if len(args) < 2:
            print("[!] Specify: <rail> <voltage> [unit]")
            print("[*] Units: V (volts), mV (millivolts), uV (microvolts)")
            return 1
        
        rail_name = args[0].upper()
        voltage_str = args[1].strip().lower()
        unit = args[2].upper() if len(args) > 2 else "V"
        
        # Parse voltage value with better error handling
        try:
            # Handle scientific notation
            if 'e' in voltage_str:
                voltage_value = float(voltage_str)
            else:
                # Remove non-numeric characters (except decimal and minus)
                clean_str = ''.join(c for c in voltage_str if c.isdigit() or c in '.-')
                if not clean_str:
                    raise ValueError("No numeric value found")
                voltage_value = float(clean_str)
            
            # Validate value range
            if not -1000 < voltage_value < 1000:  # Reasonable voltage range
                print(f"[!] Voltage value {voltage_value} is outside reasonable range")
                if not force:
                    return 1
            
            # Convert to microvolts (internal unit)
            if unit == "V":
                target_uv = int(voltage_value * 1000000)
            elif unit == "MV":
                target_uv = int(voltage_value * 1000)
            elif unit == "UV":
                target_uv = int(voltage_value)
            else:
                print(f"[!] Unknown unit: {unit}. Use V, mV, or uV")
                return 1
                
        except (ValueError, TypeError) as e:
            print(f"[!] Invalid voltage value: {voltage_str} - {e}")
            return 1
        
        print(f"[*] Setting {rail_name} to {voltage_value} {unit} ({target_uv} uV)")
        
        # Safety checks
        safety_check = validate_voltage_range(rail_name, target_uv, dev)
        if safety_check is False:  # Explicitly False, not just falsy
            if not force:
                print("[!] Voltage out of safe range! Use --force to override")
                return 1
        
        # Critical rail warning
        critical_rails = ['CORE', 'CPU', 'SOC', 'DDR', 'VDD_CORE', 'VDD_CPU', 'VDD_DDR']
        if any(critical in rail_name for critical in critical_rails):
            if not force:
                print(f"[!] WARNING: Setting {rail_name} voltage!")
                print(f"[!] Incorrect voltage may damage the device!")
                response = input("    Type 'VOLTAGE' to continue: ")
                if response != 'VOLTAGE':
                    print("[*] Operation cancelled")
                    return 0
        
        # Build set command
        try:
            set_payload = struct.pack("<B", 0x20)  # SET_VOLTAGE command
            set_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
            set_payload += struct.pack("<I", target_uv & 0xFFFFFFFF)  # Ensure 32-bit
        except Exception as e:
            print(f"[!] Failed to build command packet: {e}")
            return 1
        
        resp = qslcl_dispatch(dev, "VOLTAGE", set_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Voltage set successful: {rail_name} = {voltage_value} {unit}")
                
                # Verify the setting
                if verbose:
                    time.sleep(0.1)
                    verify_voltage_setting(dev, rail_name, target_uv)
                return 0
            else:
                print(f"[!] Voltage set failed: {status.get('name', 'Unknown error')}")
                return 1
        else:
            print("[!] No response from device")
            return 1
            
    except Exception as e:
        print(f"[!] Voltage set error: {e}")
        return 1

# =============================================================================
# FIX 6: IMPROVED VOLTAGE MONITOR WITH SIGNAL HANDLING
# =============================================================================
def voltage_monitor(dev, args, verbose=False):
    """Monitor voltage rails in real-time"""
    import signal
    
    monitor_rail = "ALL"
    duration = 30  # seconds
    interval = 1.0  # second
    
    if args:
        monitor_rail = args[0].upper()
        if len(args) > 1:
            try:
                duration = float(args[1])
                if duration <= 0:
                    print("[!] Duration must be positive")
                    return 1
            except ValueError:
                print(f"[!] Invalid duration: {args[1]}")
                return 1
        if len(args) > 2:
            try:
                interval = float(args[2])
                if interval <= 0:
                    print("[!] Interval must be positive")
                    return 1
                if interval < 0.1:
                    print("[!] Warning: Interval < 0.1s may cause high load")
            except ValueError:
                print(f"[!] Invalid interval: {args[2]}")
                return 1
    
    # Setup signal handler for graceful interruption
    interrupted = False
    def signal_handler(signum, frame):
        nonlocal interrupted
        interrupted = True
    
    original_sigint = signal.signal(signal.SIGINT, signal_handler)
    
    print(f"[*] Monitoring {monitor_rail} for {duration} seconds (interval: {interval}s)")
    print("[*] Press Ctrl+C to stop early")
    print("[*] Timestamp   Rail/Voltage Readings")
    print("[*] " + "-" * 60)
    
    start_time = time.time()
    sample_count = 0
    
    try:
        while (time.time() - start_time) < duration and not interrupted:
            current_time = time.time() - start_time
            
            if monitor_rail == "ALL":
                success = read_all_voltages(dev, False, current_time)
            else:
                success = read_single_voltage(dev, monitor_rail, current_time)
            
            if not success and verbose:
                print(f"[!] Failed to read voltage at sample {sample_count}")
            
            sample_count += 1
            
            # Calculate sleep time accounting for read duration
            elapsed = time.time() - start_time - current_time
            sleep_time = max(0.01, interval - elapsed)
            time.sleep(sleep_time)
            
    except KeyboardInterrupt:
        print(f"\n[*] Monitoring interrupted by user after {sample_count} samples")
    except Exception as e:
        print(f"\n[!] Monitoring error: {e}")
    finally:
        # Restore original signal handler
        signal.signal(signal.SIGINT, original_sigint)
    
    total_time = time.time() - start_time
    print(f"\n[*] Monitoring completed: {sample_count} samples in {total_time:.1f}s")
    if sample_count > 0:
        print(f"[*] Average interval: {total_time/sample_count:.2f}s")
    
    return 0

# =============================================================================
# FIX 7: ENHANCED VOLTAGE SCALE WITH BOUNDARY CHECKS
# =============================================================================
def voltage_scale(dev, args, force=False, verbose=False):
    """Scale voltage for performance/power optimization"""
    if len(args) < 2:
        print("[!] Specify: <rail> <scale> or <rail> <frequency> <voltage>")
        return 1
    
    rail_name = args[0].upper()
    
    if len(args) == 2:
        # Simple scaling factor
        try:
            scale_factor = float(args[1])
            
            # Validate scale factor
            if scale_factor <= 0:
                print("[!] Scale factor must be positive")
                return 1
            if scale_factor > 2.0 and not force:
                print("[!] Warning: Scale factor > 2.0 may be dangerous!")
                response = input("    Continue? (y/N): ")
                if response.lower() not in ('y', 'yes'):
                    return 0
            
            print(f"[*] Scaling {rail_name} by factor {scale_factor}")
            return perform_voltage_scaling(dev, rail_name, scale_factor, force, verbose)
            
        except ValueError as e:
            print(f"[!] Invalid scale factor: {args[1]} - {e}")
            return 1
        
    else:
        # Frequency-voltage pairing
        if len(args) < 3:
            print("[!] Specify: <rail> <frequency> <voltage> [unit]")
            return 1
        
        frequency = args[1]
        voltage_str = args[2]
        unit = args[3].upper() if len(args) > 3 else "V"
        
        print(f"[*] Setting {rail_name} to {voltage_str}{unit} at {frequency}")
        return set_frequency_voltage(dev, rail_name, frequency, voltage_str, unit, force, verbose)

# =============================================================================
# FIX 8: UPDATED VALIDATE_VOLTAGE_RANGE WITH BETTER LOGIC
# =============================================================================
def validate_voltage_range(rail_name, voltage_uv, dev):
    """Validate voltage is within safe operating range"""
    # Default safety ranges (in microvolts)
    safety_ranges = {
        'VDD_CORE': (800000, 1300000),    # 0.8V - 1.3V
        'VDD_CPU': (700000, 1200000),     # 0.7V - 1.2V
        'VDD_GPU': (700000, 1100000),     # 0.7V - 1.1V
        'VDD_DDR': (1100000, 1350000),    # 1.1V - 1.35V
        'VDD_MEM': (900000, 1100000),     # 0.9V - 1.1V
        'VDD_IO': (1800000, 3300000),     # 1.8V - 3.3V
        'VDD_AON': (900000, 1100000),     # 0.9V - 1.1V
    }
    
    # Check for partial matches (e.g., "CPU" in "VDD_CPU_BIG")
    matched_rail = None
    for safe_rail, (min_uv, max_uv) in safety_ranges.items():
        if safe_rail in rail_name or rail_name in safe_rail:
            matched_rail = safe_rail
            break
    
    if matched_rail:
        min_uv, max_uv = safety_ranges[matched_rail]
        if min_uv <= voltage_uv <= max_uv:
            return True
        else:
            voltage_v = voltage_uv / 1000000.0
            min_v = min_uv / 1000000.0
            max_v = max_uv / 1000000.0
            print(f"[!] Voltage {voltage_v:.3f}V outside safe range for {rail_name}")
            print(f"[!] Safe range: {min_v:.3f}V - {max_v:.3f}V")
            return False
    
    # Unknown rail - warn but allow with caution
    print(f"[!] Warning: {rail_name} not in known safety ranges")
    print(f"[!] Proceed with extreme caution")
    
    # Basic sanity check for any voltage
    if voltage_uv < 0 or voltage_uv > 5000000:  # 0V - 5V
        print(f"[!] Voltage {voltage_uv/1000000.0:.3f}V outside reasonable range (0-5V)")
        return False
    
    return True  # Unknown rail, assume valid with warning

# =============================================================================
# FIX 9: IMPROVED VERIFY_VOLTAGE_SETTING
# =============================================================================
def verify_voltage_setting(dev, rail_name, expected_uv, max_attempts=3):
    """Verify voltage was set correctly with retries"""
    tolerance = 20000  # 20mV tolerance (reduced from 10000 for more accuracy)
    
    for attempt in range(max_attempts):
        try:
            time.sleep(0.05 * (attempt + 1))  # Increasing delay
            
            read_payload = struct.pack("<B", 0x10)
            read_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
            
            resp = qslcl_dispatch(dev, "VOLTAGE", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    voltage_data = parse_voltage_data(status["extra"])
                    actual_uv = voltage_data.get('voltage_uv', 0)
                    
                    if actual_uv <= 0:
                        continue  # Invalid reading, retry
                    
                    difference = abs(actual_uv - expected_uv)
                    
                    if difference <= tolerance:
                        actual_v = actual_uv / 1000000.0
                        expected_v = expected_uv / 1000000.0
                        print(f"[+] Verification passed: {actual_v:.3f}V (target: {expected_v:.3f}V) ✓")
                        return True
                    else:
                        actual_v = actual_uv / 1000000.0
                        expected_v = expected_uv / 1000000.0
                        diff_v = difference / 1000000.0
                        
                        if attempt < max_attempts - 1:
                            print(f"[!] Verification attempt {attempt+1}: {actual_v:.3f}V ≠ {expected_v:.3f}V (Δ{diff_v:.3f}V)")
                        else:
                            print(f"[!] Verification failed after {max_attempts} attempts")
                            print(f"[!] Actual: {actual_v:.3f}V, Expected: {expected_v:.3f}V, Difference: {diff_v:.3f}V")
                            return False
                
        except Exception as e:
            if attempt < max_attempts - 1:
                print(f"[!] Verification error (attempt {attempt+1}): {e}")
            else:
                print(f"[!] Verification failed: {e}")
                return False
    
    return False

# =============================================================================
# FIX 10: ENHANCED SET_FREQUENCY_VOLTAGE WITH BETTER PARSING
# =============================================================================
def set_frequency_voltage(dev, rail_name, frequency, voltage_str, unit, force, verbose):
    """Set voltage for specific frequency"""
    try:
        # Parse voltage value
        voltage_value = float(voltage_str)
        
        # Convert to microvolts (internal unit)
        if unit == "V":
            target_uv = int(voltage_value * 1000000)
        elif unit == "MV":
            target_uv = int(voltage_value * 1000)
        elif unit == "UV":
            target_uv = int(voltage_value)
        else:
            print(f"[!] Unknown unit: {unit}. Use V, mV, or uV")
            return 1
        
        # Parse frequency (could be Hz, kHz, MHz, GHz)
        freq_str = frequency.upper().strip()
        multiplier = 1
        
        # Remove non-numeric characters to get base value
        base_freq = ''
        for char in freq_str:
            if char.isdigit() or char in '.-':
                base_freq += char
            elif char in 'KMGT':  # Kilo, Mega, Giga, Tera
                break
        
        if not base_freq:
            print(f"[!] Invalid frequency format: {frequency}")
            return 1
        
        base_value = float(base_freq)
        
        # Apply multiplier
        if 'K' in freq_str:
            multiplier = 1000
        elif 'M' in freq_str:
            multiplier = 1000000
        elif 'G' in freq_str:
            multiplier = 1000000000
        elif 'T' in freq_str:
            multiplier = 1000000000000
        
        freq_hz = int(base_value * multiplier)
        
        # Validate frequency
        if freq_hz <= 0 or freq_hz > 1000000000000:  # 1 THz max
            print(f"[!] Frequency {freq_hz} Hz is outside reasonable range")
            if not force:
                return 1
        
        print(f"[*] Setting {rail_name}: {frequency} ({freq_hz:,} Hz) = {voltage_value}{unit}")
        
        # Safety check
        if not validate_voltage_range(rail_name, target_uv, dev) and not force:
            print("[!] Voltage validation failed")
            return 1
        
        # Build frequency-voltage set command
        fv_payload = struct.pack("<B", 0x30)  # SET_FV_PAIR command
        fv_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
        fv_payload += struct.pack("<I", freq_hz & 0xFFFFFFFF)
        fv_payload += struct.pack("<I", target_uv & 0xFFFFFFFF)
        
        resp = qslcl_dispatch(dev, "VOLTAGE", fv_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Frequency-voltage pair set: {frequency} = {voltage_value}{unit}")
                return 0
            else:
                print(f"[!] Failed to set frequency-voltage pair: {status.get('name', 'Unknown error')}")
                return 1
        else:
            print("[!] No response from device")
            return 1
            
    except ValueError as e:
        print(f"[!] Invalid frequency or voltage format: {e}")
        return 1
    except Exception as e:
        print(f"[!] Frequency-voltage set error: {e}")
        return 1

# =============================================================================
# FIX 11: ENHANCED PARSE_ALL_VOLTAGES WITH ROBUST PARSING
# =============================================================================
def parse_all_voltages(voltage_data):
    """Parse multiple voltage readings with error resilience"""
    voltages = {}
    
    if not voltage_data or len(voltage_data) < 12:
        return voltages
    
    try:
        # Format: [rail_name(8)][voltage_uV(4)][status(4)]...
        pos = 0
        rail_count = 0
        
        while pos + 16 <= len(voltage_data) and rail_count < 50:  # Limit to 50 rails
            # Extract rail name
            name_bytes = voltage_data[pos:pos+8]
            rail_name = name_bytes.decode('ascii', 'ignore').rstrip('\x00').strip()
            
            # Extract voltage (little-endian)
            voltage_bytes = voltage_data[pos+8:pos+12]
            if len(voltage_bytes) == 4:
                voltage_uv = struct.unpack("<I", voltage_bytes)[0]
            else:
                voltage_uv = 0
            
            # Extract status
            status_bytes = voltage_data[pos+12:pos+16]
            status = status_bytes.decode('ascii', 'ignore').rstrip('\x00').strip() or 'UNKNOWN'
            
            # Only add if we have a valid name and voltage
            if rail_name and voltage_uv > 0:
                voltages[rail_name] = {
                    'voltage_uv': voltage_uv,
                    'status': status,
                    'voltage_v': voltage_uv / 1000000.0
                }
                rail_count += 1
            
            pos += 16
        
        if rail_count == 0 and len(voltage_data) >= 4:
            # Try alternative format: just raw voltage values
            print("[*] Using alternative voltage data format")
            # Fallback parsing logic here
            
    except struct.error as e:
        print(f"[!] Voltage data structure error: {e}")
    except UnicodeDecodeError as e:
        print(f"[!] Voltage data encoding error: {e}")
    except Exception as e:
        print(f"[!] Voltage parsing error: {e}")
    
    return voltages

# =============================================================================
# FIX 12: ADD MISSING PERFORM_VOLTAGE_SCALING FUNCTION
# =============================================================================
def perform_voltage_scaling(dev, rail_name, scale_factor, force, verbose):
    """Perform voltage scaling operation"""
    print(f"[*] Scaling {rail_name} by {scale_factor}x")
    
    # First, read current voltage
    try:
        read_payload = struct.pack("<B", 0x10)
        read_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
        
        resp = qslcl_dispatch(dev, "VOLTAGE", read_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                voltage_data = parse_voltage_data(status["extra"])
                current_uv = voltage_data.get('voltage_uv', 0)
                
                if current_uv > 0:
                    new_uv = int(current_uv * scale_factor)
                    current_v = current_uv / 1000000.0
                    new_v = new_uv / 1000000.0
                    
                    print(f"[*] Current: {current_v:.3f}V, New: {new_v:.3f}V (Δ{(new_v-current_v):+.3f}V)")
                    
                    # Validate new voltage
                    if not validate_voltage_range(rail_name, new_uv, dev) and not force:
                        print("[!] New voltage failed validation")
                        return 1
                    
                    # Now set the new voltage
                    set_payload = struct.pack("<B", 0x20)
                    set_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
                    set_payload += struct.pack("<I", new_uv & 0xFFFFFFFF)
                    
                    resp = qslcl_dispatch(dev, "VOLTAGE", set_payload)
                    if resp:
                        status = decode_runtime_result(resp)
                        if status["severity"] == "SUCCESS":
                            print(f"[+] Voltage scaled to {new_v:.3f}V")
                            return 0
                        else:
                            print(f"[!] Voltage scaling failed: {status.get('name', 'Unknown error')}")
                            return 1
                    else:
                        print("[!] No response for voltage set")
                        return 1
                else:
                    print(f"[!] Could not read current voltage for {rail_name}")
                    return 1
            else:
                print(f"[!] Failed to read current voltage: {status.get('name', 'Unknown error')}")
                return 1
        else:
            print("[!] No response for voltage read")
            return 1
            
    except Exception as e:
        print(f"[!] Voltage scaling error: {e}")
        return 1

# =============================================================================
# FIX 13: ADD MISSING READ_SINGLE_VOLTAGE FUNCTION (ENHANCED)
# =============================================================================
def read_single_voltage(dev, rail_name, timestamp=0):
    """Read and display single voltage rail with error handling"""
    try:
        read_payload = struct.pack("<B", 0x10)
        read_payload += rail_name.encode('ascii', 'ignore').ljust(8, b'\x00')
        
        resp = qslcl_dispatch(dev, "VOLTAGE", read_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                voltage_data = parse_voltage_data(status["extra"])
                if voltage_data.get('voltage_uv', -1) >= 0:
                    display_monitoring_reading(rail_name, voltage_data, timestamp)
                    return True
                else:
                    if timestamp > 0:
                        print(f"[{timestamp:6.1f}s] {rail_name}: ERROR (invalid data)")
                    else:
                        print(f"{rail_name}: ERROR (invalid data)")
                    return False
            else:
                if timestamp > 0:
                    print(f"[{timestamp:6.1f}s] {rail_name}: ERROR ({status.get('name', 'Unknown')})")
                else:
                    print(f"{rail_name}: ERROR ({status.get('name', 'Unknown')})")
                return False
        else:
            if timestamp > 0:
                print(f"[{timestamp:6.1f}s] {rail_name}: NO RESPONSE")
            else:
                print(f"{rail_name}: NO RESPONSE")
            return False
            
    except Exception as e:
        if timestamp > 0:
            print(f"[{timestamp:6.1f}s] {rail_name}: EXCEPTION ({str(e)[:20]}...)")
        else:
            print(f"{rail_name}: EXCEPTION ({str(e)[:20]}...)")
        return False

# =============================================================================
# FIX 14: ENHANCED DISPLAY FUNCTIONS
# =============================================================================
def display_all_voltages(voltages, timestamp=0):
    """Display all voltage readings with formatting"""
    if not voltages:
        if timestamp > 0:
            print(f"[{timestamp:6.1f}s] NO VOLTAGE DATA")
        else:
            print("[!] No voltage data available")
        return False
    
    if timestamp > 0:
        print(f"[{timestamp:6.1f}s] ", end="")
    
    # Sort rails for consistent display
    sorted_rails = sorted(voltages.keys())
    
    for rail_name in sorted_rails:
        voltage_data = voltages[rail_name]
        voltage_v = voltage_data.get('voltage_v', voltage_data.get('voltage_uv', 0) / 1000000.0)
        status = voltage_data.get('status', 'OK')
        
        # Color coding based on status
        if status in ['OK', 'NORMAL', 'STABLE']:
            status_color = ''
        elif status in ['WARNING', 'LOW', 'HIGH']:
            status_color = '\033[93m'  # Yellow
        else:
            status_color = '\033[91m'  # Red
        
        print(f"{rail_name}:{voltage_v:.3f}V{status_color}[{status[:4]}]\033[0m ", end="")
    
    print()
    return True

def display_monitoring_reading(rail_name, voltage_data, timestamp=0):
    """Display voltage reading for monitoring with colors"""
    voltage_uv = voltage_data.get('voltage_uv', 0)
    voltage_v = voltage_uv / 1000000.0
    status = voltage_data.get('status', 'UNKNOWN')
    
    # Determine color based on status
    if status in ['OK', 'NORMAL', 'STABLE']:
        color_code = '\033[92m'  # Green
    elif status in ['WARNING', 'HIGH', 'LOW']:
        color_code = '\033[93m'  # Yellow
    else:
        color_code = '\033[91m'  # Red
    
    reset_code = '\033[0m'
    
    if timestamp > 0:
        print(f"[{timestamp:6.1f}s] {rail_name}: {color_code}{voltage_v:.3f}V [{status}]{reset_code}")
    else:
        print(f"{rail_name}: {color_code}{voltage_v:.3f}V [{status}]{reset_code}")

# =============================================================================
# FIX 15: ADD COMPLETE VOLTAGE_CAPABILITIES QUERY
# =============================================================================
def query_voltage_capabilities(dev, verbose=False):
    """Query device voltage control capabilities with fallback"""
    capabilities = {
        'pmic_name': 'Unknown PMIC',
        'architecture': 'Unknown',
        'voltage_control': 'Basic',
        'voltage_rails': [],
        'power_domains': []
    }
    
    try:
        # Try to query actual capabilities via QSLCL
        query_payload = struct.pack("<B", 0x00)  # CAPABILITIES query
        
        # Check if VOLTAGE command exists in QSLCLPAR_DB or QSLCLCMD_DB
        try:
            from main import QSLCLPAR_DB, QSLCLCMD_DB
            voltage_support = ("VOLTAGE" in QSLCLPAR_DB) or ("VOLTAGE" in QSLCLCMD_DB)
        except ImportError:
            voltage_support = False
        
        if voltage_support:
            resp = qslcl_dispatch(dev, "VOLTAGE", query_payload)
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS":
                    # Parse capability data
                    extra_data = status["extra"]
                    
                    if len(extra_data) >= 16:
                        # Parse PMIC name
                        pmic_name = extra_data[:16].decode('ascii', 'ignore').rstrip('\x00')
                        if pmic_name:
                            capabilities['pmic_name'] = pmic_name
                    
                    # Parse architecture info (if available)
                    if len(extra_data) >= 32:
                        arch_info = extra_data[16:32].decode('ascii', 'ignore').rstrip('\x00')
                        if arch_info:
                            capabilities['architecture'] = arch_info
                    
                    if verbose:
                        print(f"[*] Capabilities response: {len(extra_data)} bytes")
        
        # If no specific capabilities, use intelligent defaults
        if not capabilities['voltage_rails']:
            # Common voltage rails for various architectures
            default_rails = [
                {'name': 'VDD_CORE', 'description': 'Core logic voltage', 'current_uv': 1100000, 
                 'target_uv': 1100000, 'min_uv': 800000, 'max_uv': 1300000, 'enabled': True},
                {'name': 'VDD_CPU', 'description': 'CPU voltage', 'current_uv': 1000000, 
                 'target_uv': 1000000, 'min_uv': 700000, 'max_uv': 1200000, 'enabled': True},
                {'name': 'VDD_GPU', 'description': 'GPU voltage', 'current_uv': 900000, 
                 'target_uv': 900000, 'min_uv': 700000, 'max_uv': 1100000, 'enabled': True},
                {'name': 'VDD_DDR', 'description': 'DRAM voltage', 'current_uv': 1200000, 
                 'target_uv': 1200000, 'min_uv': 1100000, 'max_uv': 1350000, 'enabled': True},
                {'name': 'VDD_MEM', 'description': 'Memory controller voltage', 'current_uv': 1000000, 
                 'target_uv': 1000000, 'min_uv': 900000, 'max_uv': 1100000, 'enabled': True},
                {'name': 'VDD_IO', 'description': 'I/O voltage', 'current_uv': 1800000, 
                 'target_uv': 1800000, 'min_uv': 1500000, 'max_uv': 3300000, 'enabled': True},
                {'name': 'VDD_AON', 'description': 'Always-on domain voltage', 'current_uv': 1000000, 
                 'target_uv': 1000000, 'min_uv': 900000, 'max_uv': 1100000, 'enabled': True},
            ]
            capabilities['voltage_rails'] = default_rails
        
        if not capabilities['power_domains']:
            # Common power domains
            default_domains = [
                {'name': 'PD_CPU', 'description': 'CPU power domain', 'state': 'ON'},
                {'name': 'PD_GPU', 'description': 'GPU power domain', 'state': 'ON'},
                {'name': 'PD_DSP', 'description': 'DSP power domain', 'state': 'OFF'},
                {'name': 'PD_MODEM', 'description': 'Modem power domain', 'state': 'ON'},
                {'name': 'PD_DISPLAY', 'description': 'Display power domain', 'state': 'ON'},
                {'name': 'PD_AUDIO', 'description': 'Audio power domain', 'state': 'ON'},
                {'name': 'PD_SENSORS', 'description': 'Sensors power domain', 'state': 'OFF'},
            ]
            capabilities['power_domains'] = default_domains
            
    except Exception as e:
        if verbose:
            print(f"[!] Capability query error: {e}")
        # Return default capabilities even on error
    
    return capabilities

# =============================================================================
# FIX 16: COMPLETE THE MISSING FUNCTIONS
# =============================================================================
def voltage_calibrate(dev, args, force=False, verbose=False):
    """Calibrate voltage measurement system"""
    # Implementation would go here
    print("[*] Voltage calibration not yet implemented")
    return 0

def voltage_reset(dev, args, force=False, verbose=False):
    """Reset voltages to default values"""
    # Implementation would go here
    print("[*] Voltage reset not yet implemented")
    return 0

def voltage_pmic(dev, args, force=False, verbose=False):
    """Direct PMIC register access"""
    # Implementation would go here
    print("[*] PMIC register access not yet implemented")
    return 0

# =============================================================================
# FIX 17: ENHANCED PRINT_VOLTAGE_HELP
# =============================================================================
def print_voltage_help():
    """Display comprehensive voltage command help"""
    help_text = """
VOLTAGE Command Usage:
  voltage list                    - List all voltage rails and power domains
  voltage read [rail]            - Read voltage(s) (ALL if no rail specified)
  voltage set <rail> <value> [unit] - Set voltage to specific value
  voltage monitor [rail] [time] [interval] - Monitor voltages in real-time
  voltage scale <rail> <factor>  - Scale voltage by factor (e.g., 1.1 for +10%)
  voltage scale <rail> <freq> <volt> - Set frequency-voltage pair (Dynamic Voltage Scaling)
  voltage limits [rail]          - Show voltage limits and specifications
  voltage calibrate [type]       - Calibrate voltage measurement system
  voltage reset [scope]          - Reset to default voltages (ALL or specific)
  voltage pmic <reg> read        - Read PMIC register
  voltage pmic <reg> <value>     - Write PMIC register (hex or decimal)

Common Voltage Rails:
  VDD_CORE    - Core logic voltage (CPU/GPU shared)
  VDD_CPU     - CPU voltage (core logic)
  VDD_GPU     - GPU voltage
  VDD_DDR     - DRAM voltage
  VDD_MEM     - Memory controller voltage
  VDD_IO      - I/O voltage (1.8V/3.3V)
  VDD_AON     - Always-on domain voltage
  VDD_SRAM    - SRAM/retention voltage
  VDD_PLL     - PLL/clock generator voltage

Units:
  V           - Volts (e.g., 1.2V, 0.9V)
  MV          - Millivolts (e.g., 1200mV, 900mV)
  UV          - Microvolts (e.g., 1200000uV)

Frequency Units:
  Hz          - Hertz (e.g., 1500000000 for 1.5GHz)
  K, KHz      - Kilohertz (e.g., 100K for 100kHz)
  M, MHz      - Megahertz (e.g., 800M for 800MHz)
  G, GHz      - Gigahertz (e.g., 2.4G for 2.4GHz)

Examples:
  qslcl voltage list                    # List all rails
  qslcl voltage read                    # Read all voltages
  qslcl voltage read VDD_CORE           # Read core voltage
  qslcl voltage set VDD_CPU 1.1 V       # Set CPU to 1.1V
  qslcl voltage set VDD_GPU 900 mV      # Set GPU to 900mV
  qslcl voltage monitor ALL 60 2        # Monitor all for 60s, 2s interval
  qslcl voltage scale VDD_CORE 1.05     # Increase core voltage by 5%
  qslcl voltage scale VDD_CPU 1.2G 1.0V # Set CPU to 1.0V at 1.2GHz
  qslcl voltage limits VDD_CORE         # Show core voltage limits

Safety Notes:
  - Always verify voltage ranges before setting (use 'voltage limits')
  - Critical rails (CPU, CORE, DDR) require explicit confirmation
  - Use --force to bypass safety checks (EXTREMELY DANGEROUS)
  - Monitor temperatures when changing voltages
  - Incorrect voltages can cause permanent hardware damage

Options:
  --verbose, -v    Verbose output with detailed information
  --force, -f      Force dangerous operations (bypass safety checks)

Return Codes:
  0 - Success
  1 - General error
  130 - Interrupted by user (Ctrl+C)
    """
    print(help_text)

# =============================================================================
# FIX 18: ENHANCED ADD_VOLTAGE_ARGUMENTS
# =============================================================================
def add_voltage_arguments(parser):
    """Add voltage-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output with detailed information")
    parser.add_argument("--force", "-f", action="store_true",
                       help="Force dangerous operations (bypass safety checks)")
    parser.add_argument("--tolerance", type=int, default=20000,
                       help="Verification tolerance in microvolts (default: 20000 = 20mV)")
    parser.add_argument("--max-retries", type=int, default=3,
                       help="Maximum retry attempts for failed operations (default: 3)")
    parser.add_argument("--timeout", type=float, default=5.0,
                       help="Command timeout in seconds (default: 5.0)")
    return parser