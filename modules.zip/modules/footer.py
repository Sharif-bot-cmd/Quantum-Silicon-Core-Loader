def cmd_footer(args=None):
    """
    Fully implemented FOOTER command with advanced features:
    - Comprehensive footer analysis and validation
    - Multiple footer types and formats
    - Cryptographic verification and integrity checking
    - Metadata extraction and interpretation
    - Cross-referencing and pattern recognition
    """
    if not args:
        print("[!] FOOTER: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    footer_type = getattr(args, 'footer_type', 'STANDARD').upper()
    footer_args = getattr(args, 'footer_args', [])
    show_raw = getattr(args, 'raw', False)
    show_extended = getattr(args, 'extended', False)
    show_verbose = getattr(args, 'verbose', False)
    show_crc = getattr(args, 'crc', False)
    show_metadata = getattr(args, 'metadata', False)
    show_all = getattr(args, 'all', False)
    validate = getattr(args, 'validate', False)
    show_hex = getattr(args, 'hex', False)
    show_structured = getattr(args, 'structured', False)
    show_json = getattr(args, 'json', False)
    save_file = getattr(args, 'save', None)

    # If show_all is set, enable all display options
    if show_all:
        show_raw = show_extended = show_verbose = show_crc = show_metadata = True

    print(f"[*] FOOTER command: type={footer_type}")

    # =========================================================================
    # 1. FOOTER DATA ACQUISITION
    # =========================================================================
    print(f"[*] Acquiring footer data...")
    
    footer_data = None
    footer_info = {}

    try:
        # Try different methods to get footer data
        if "FOOTER" in QSLCLPAR_DB:
            # Use dedicated FOOTER command
            footer_payload = struct.pack("<B", footer_type_to_code(footer_type))
            resp = qslcl_dispatch(dev, "FOOTER", footer_payload)
        else:
            # Fallback to generic read
            footer_addr = determine_footer_address(footer_type, dev)
            if footer_addr:
                read_payload = struct.pack("<II", footer_addr, 512)  # Read 512 bytes for footer
                resp = qslcl_dispatch(dev, "READ", read_payload)
            else:
                resp = None

        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                footer_data = status["extra"]
                print(f"[+] Footer data acquired: {len(footer_data)} bytes")
            else:
                print(f"[!] Footer acquisition failed: {status}")
                return
        else:
            print("[!] No response from footer command")
            return

    except Exception as e:
        print(f"[!] Footer acquisition error: {e}")
        return

    if not footer_data:
        print("[!] No footer data received")
        return

    # =========================================================================
    # 2. FOOTER PARSING AND ANALYSIS
    # =========================================================================
    print(f"[*] Analyzing footer structure...")
    
    # Parse footer based on type
    if footer_type == "STANDARD":
        footer_info = parse_standard_footer(footer_data, show_verbose)
    elif footer_type == "EXTENDED":
        footer_info = parse_extended_footer(footer_data, show_verbose)
    elif footer_type == "SECURITY":
        footer_info = parse_security_footer(footer_data, show_verbose)
    elif footer_type == "BOOT":
        footer_info = parse_boot_footer(footer_data, show_verbose)
    elif footer_type == "LOADER":
        footer_info = parse_loader_footer(footer_data, show_verbose)
    elif footer_type == "DEBUG":
        footer_info = parse_debug_footer(footer_data, show_verbose)
    elif footer_type == "AUDIT":
        footer_info = parse_audit_footer(footer_data, show_verbose)
    elif footer_type == "ALL":
        footer_info = parse_all_footers(footer_data, show_verbose)
    else:
        print(f"[!] Unknown footer type: {footer_type}")
        return

    # =========================================================================
    # 3. INTEGRITY VERIFICATION
    # =========================================================================
    if validate:
        print(f"[*] Validating footer integrity...")
        validation_results = validate_footer_integrity(footer_data, footer_type, footer_info)
        footer_info['validation'] = validation_results

    # =========================================================================
    # 4. DATA DISPLAY AND OUTPUT
    # =========================================================================
    print(f"\n[+] FOOTER ANALYSIS RESULTS:")
    print(f"    Type: {footer_type}")
    print(f"    Size: {len(footer_data)} bytes")
    print(f"    Magic: {footer_info.get('magic', 'Not found')}")

    # Display raw data if requested
    if show_raw:
        print(f"\n[*] RAW FOOTER DATA:")
        print(hexdump(footer_data, 16))

    # Display structured information
    if show_structured or not show_raw:
        display_structured_footer(footer_info, footer_type)

    # Display extended information
    if show_extended:
        display_extended_footer_info(footer_info, footer_type)

    # Display CRC information
    if show_crc:
        display_crc_info(footer_data, footer_info)

    # Display metadata
    if show_metadata:
        display_footer_metadata(footer_info)

    # Display validation results
    if validate and 'validation' in footer_info:
        display_validation_results(footer_info['validation'])

    # =========================================================================
    # 5. JSON OUTPUT
    # =========================================================================
    if show_json:
        import json
        json_output = {
            'footer_type': footer_type,
            'data_size': len(footer_data),
            'analysis': footer_info
        }
        print(f"\n[*] JSON OUTPUT:")
        print(json.dumps(json_output, indent=2, default=str))

    # =========================================================================
    # 6. FILE SAVING
    # =========================================================================
    if save_file:
        try:
            with open(save_file, 'wb') as f:
                f.write(footer_data)
            print(f"\n[+] Footer data saved to: {save_file}")
            
            # Also save analysis if JSON mode
            if show_json:
                analysis_file = save_file + '.json'
                with open(analysis_file, 'w') as f:
                    json.dump(json_output, f, indent=2, default=str)
                print(f"[+] Footer analysis saved to: {analysis_file}")
                
        except Exception as e:
            print(f"[!] Failed to save footer data: {e}")

    # =========================================================================
    # 7. SECURITY ASSESSMENT
    # =========================================================================
    if footer_type in ["SECURITY", "BOOT", "LOADER"]:
        print(f"\n[*] SECURITY ASSESSMENT:")
        security_assessment = assess_footer_security(footer_info, footer_type)
        for assessment in security_assessment:
            print(f"    {assessment}")

    print(f"\n[+] Footer analysis completed")

# =============================================================================
# FOOTER PARSING FUNCTIONS
# =============================================================================

def footer_type_to_code(footer_type):
    """Convert footer type string to command code"""
    type_codes = {
        'STANDARD': 0x01,
        'EXTENDED': 0x02,
        'SECURITY': 0x03,
        'BOOT': 0x04,
        'LOADER': 0x05,
        'DEBUG': 0x06,
        'AUDIT': 0x07,
        'ALL': 0xFF
    }
    return type_codes.get(footer_type, 0x01)

def determine_footer_address(footer_type, dev):
    """Determine memory address for footer type"""
    # Common footer locations
    footer_addresses = {
        'STANDARD': 0xFFFF0000,
        'EXTENDED': 0xFFFF1000,
        'SECURITY': 0xFFFF2000,
        'BOOT': 0xFFFF3000,
        'LOADER': 0xFFFF4000,
        'DEBUG': 0xFFFF5000,
        'AUDIT': 0xFFFF6000
    }
    return footer_addresses.get(footer_type, 0xFFFF0000)

def parse_standard_footer(data, verbose=False):
    """Parse standard system footer"""
    info = {}
    
    try:
        if len(data) >= 64:
            # Parse standard footer structure
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['version'] = struct.unpack('<I', data[8:12])[0]
            info['timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['checksum'] = struct.unpack('<I', data[16:20])[0]
            info['data_size'] = struct.unpack('<I', data[20:24])[0]
            info['flags'] = struct.unpack('<I', data[24:28])[0]
            
            # Parse human-readable timestamp
            if info['timestamp'] > 0:
                info['timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                       time.localtime(info['timestamp']))
            
            # Parse flags
            info['flags_parsed'] = parse_footer_flags(info['flags'])
            
            if verbose:
                info['raw_data'] = data.hex()
                
    except Exception as e:
        info['parse_error'] = str(e)
        
    return info

def parse_extended_footer(data, verbose=False):
    """Parse extended footer with additional fields"""
    info = parse_standard_footer(data, verbose)
    
    try:
        if len(data) >= 128:
            # Extended fields
            info['build_id'] = data[32:48].hex()
            info['hw_compatibility'] = struct.unpack('<I', data[48:52])[0]
            info['sw_compatibility'] = struct.unpack('<I', data[52:56])[0]
            info['reserved'] = data[56:64].hex()
            
            # Vendor-specific fields
            info['vendor_data'] = data[64:128].hex()
            
    except Exception as e:
        info['extended_parse_error'] = str(e)
        
    return info

def parse_security_footer(data, verbose=False):
    """Parse security footer with cryptographic information"""
    info = {}
    
    try:
        if len(data) >= 256:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['security_version'] = struct.unpack('<I', data[8:12])[0]
            info['crypto_algo'] = struct.unpack('<I', data[12:16])[0]
            info['hash_type'] = struct.unpack('<I', data[16:20])[0]
            info['signature_type'] = struct.unpack('<I', data[20:24])[0]
            
            # Cryptographic data
            info['hash'] = data[32:64].hex()  # SHA256
            info['signature'] = data[64:128].hex()  # RSA signature
            info['public_key'] = data[128:256].hex()  # Public key
            
            # Parse crypto algorithms
            info['crypto_algo_name'] = {
                0x01: 'AES-128',
                0x02: 'AES-256', 
                0x03: 'RSA-2048',
                0x04: 'RSA-4096',
                0x05: 'ECDSA-P256'
            }.get(info['crypto_algo'], 'UNKNOWN')
            
            info['hash_type_name'] = {
                0x01: 'SHA-256',
                0x02: 'SHA-384',
                0x03: 'SHA-512'
            }.get(info['hash_type'], 'UNKNOWN')
            
    except Exception as e:
        info['security_parse_error'] = str(e)
        
    return info

def parse_boot_footer(data, verbose=False):
    """Parse boot process footer"""
    info = {}
    
    try:
        if len(data) >= 128:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['boot_version'] = struct.unpack('<I', data[8:12])[0]
            info['boot_timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['boot_source'] = struct.unpack('<I', data[16:20])[0]
            info['boot_reason'] = struct.unpack('<I', data[20:24])[0]
            info['boot_counter'] = struct.unpack('<I', data[24:28])[0]
            info['last_boot_status'] = struct.unpack('<I', data[28:32])[0]
            
            # Boot source interpretation
            info['boot_source_name'] = {
                0x00: 'POWER_ON',
                0x01: 'SOFT_RESET',
                0x02: 'WATCHDOG',
                0x03: 'RECOVERY',
                0x04: 'BOOTLOADER',
                0x05: 'CRASH'
            }.get(info['boot_source'], 'UNKNOWN')
            
            # Boot reason interpretation
            info['boot_reason_name'] = {
                0x00: 'NORMAL',
                0x01: 'UPDATE',
                0x02: 'FACTORY_RESET',
                0x03: 'SECURITY_VIOLATION',
                0x04: 'HARDWARE_FAILURE'
            }.get(info['boot_reason'], 'UNKNOWN')
            
            # Last boot status
            info['last_boot_status_name'] = {
                0x00: 'SUCCESS',
                0x01: 'FAILED',
                0x02: 'CRASHED',
                0x03: 'WATCHDOG'
            }.get(info['last_boot_status'], 'UNKNOWN')
            
            if info['boot_timestamp'] > 0:
                info['boot_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                            time.localtime(info['boot_timestamp']))
                
    except Exception as e:
        info['boot_parse_error'] = str(e)
        
    return info

def parse_loader_footer(data, verbose=False):
    """Parse loader footer information"""
    info = {}
    
    try:
        if len(data) >= 256:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['loader_version'] = struct.unpack('<I', data[8:12])[0]
            info['loader_timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['loader_checksum'] = struct.unpack('<I', data[16:20])[0]
            info['loader_size'] = struct.unpack('<I', data[20:24])[0]
            info['entry_point'] = struct.unpack('<I', data[24:28])[0]
            info['load_address'] = struct.unpack('<I', data[28:32])[0]
            
            # Architecture information
            info['architecture'] = struct.unpack('<I', data[32:36])[0]
            info['architecture_name'] = {
                0x00: 'ARM32',
                0x01: 'ARM64', 
                0x02: 'x86',
                0x03: 'x64',
                0x04: 'MIPS',
                0x05: 'RISCV'
            }.get(info['architecture'], 'UNKNOWN')
            
            if info['loader_timestamp'] > 0:
                info['loader_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                              time.localtime(info['loader_timestamp']))
                
    except Exception as e:
        info['loader_parse_error'] = str(e)
        
    return info

def parse_debug_footer(data, verbose=False):
    """Parse debug footer with diagnostic information"""
    info = {}
    
    try:
        if len(data) >= 512:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['debug_version'] = struct.unpack('<I', data[8:12])[0]
            info['debug_timestamp'] = struct.unpack('<I', data[12:16])[0]
            
            # Debug counters
            info['exception_count'] = struct.unpack('<I', data[16:20])[0]
            info['watchdog_resets'] = struct.unpack('<I', data[20:24])[0]
            info['memory_errors'] = struct.unpack('<I', data[24:28])[0]
            info['io_errors'] = struct.unpack('<I', data[28:32])[0]
            
            # Last error information
            info['last_error_code'] = struct.unpack('<I', data[32:36])[0]
            info['last_error_address'] = struct.unpack('<I', data[36:40])[0]
            info['last_error_timestamp'] = struct.unpack('<I', data[40:44])[0]
            
            # Debug flags
            info['debug_flags'] = struct.unpack('<I', data[44:48])[0]
            info['debug_flags_parsed'] = parse_debug_flags(info['debug_flags'])
            
            if info['debug_timestamp'] > 0:
                info['debug_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                             time.localtime(info['debug_timestamp']))
            if info['last_error_timestamp'] > 0:
                info['last_error_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                  time.localtime(info['last_error_timestamp']))
                
    except Exception as e:
        info['debug_parse_error'] = str(e)
        
    return info

def parse_audit_footer(data, verbose=False):
    """Parse audit footer with security events"""
    info = {}
    
    try:
        if len(data) >= 1024:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['audit_version'] = struct.unpack('<I', data[8:12])[0]
            info['audit_timestamp'] = struct.unpack('<I', data[12:16])[0]
            
            # Security event counters
            info['auth_failures'] = struct.unpack('<I', data[16:20])[0]
            info['access_denied'] = struct.unpack('<I', data[20:24])[0]
            info['integrity_failures'] = struct.unpack('<I', data[24:28])[0]
            info['tamper_events'] = struct.unpack('<I', data[28:32])[0]
            
            # Last security event
            info['last_security_event'] = struct.unpack('<I', data[32:36])[0]
            info['last_event_timestamp'] = struct.unpack('<I', data[36:40])[0]
            info['last_event_details'] = data[40:72].decode('ascii', errors='ignore').rstrip('\x00')
            
            # Security state
            info['security_state'] = struct.unpack('<I', data[72:76])[0]
            info['security_state_name'] = {
                0x00: 'SECURE',
                0x01: 'WARNING',
                0x02: 'COMPROMISED',
                0x03: 'TAMPERED'
            }.get(info['security_state'], 'UNKNOWN')
            
            if info['audit_timestamp'] > 0:
                info['audit_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                             time.localtime(info['audit_timestamp']))
            if info['last_event_timestamp'] > 0:
                info['last_event_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                  time.localtime(info['last_event_timestamp']))
                
    except Exception as e:
        info['audit_parse_error'] = str(e)
        
    return info

def parse_all_footers(data, verbose=False):
    """Parse all footer types from combined data"""
    info = {}
    
    # Try to parse as each type and see which one fits best
    parsers = [
        ('STANDARD', parse_standard_footer),
        ('EXTENDED', parse_extended_footer),
        ('SECURITY', parse_security_footer),
        ('BOOT', parse_boot_footer),
        ('LOADER', parse_loader_footer),
        ('DEBUG', parse_debug_footer),
        ('AUDIT', parse_audit_footer)
    ]
    
    best_match = None
    best_score = 0
    
    for name, parser in parsers:
        try:
            result = parser(data, verbose)
            score = calculate_footer_match_score(result)
            if score > best_score:
                best_score = score
                best_match = (name, result)
        except:
            continue
    
    if best_match:
        info['detected_type'] = best_match[0]
        info['match_confidence'] = best_score
        info.update(best_match[1])
    else:
        info['detected_type'] = 'UNKNOWN'
        info['match_confidence'] = 0
        
    return info

# =============================================================================
# SUPPORTING FUNCTIONS FOR FOOTER ANALYSIS
# =============================================================================

def parse_footer_flags(flags):
    """Parse footer flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'VALIDATED',
        0x00000002: 'SIGNED',
        0x00000004: 'ENCRYPTED',
        0x00000008: 'COMPRESSED',
        0x00000010: 'DEBUG_ENABLED',
        0x00000020: 'PRODUCTION',
        0x00000040: 'DEVELOPMENT',
        0x00000080: 'TEST_BUILD'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def parse_debug_flags(flags):
    """Parse debug flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'LOG_ENABLED',
        0x00000002: 'TRACE_ENABLED',
        0x00000004: 'PROFILING',
        0x00000008: 'MEMORY_DEBUG',
        0x00000010: 'ASSERT_ENABLED',
        0x00000020: 'BREAK_ON_ERROR',
        0x00000040: 'METRICS_ENABLED'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def calculate_footer_match_score(footer_info):
    """Calculate how well the parsed data matches expected footer structure"""
    score = 0
    
    # Check for magic signature
    if 'magic' in footer_info and footer_info['magic']:
        if any(sig in footer_info['magic'] for sig in ['QSLCL', 'BOOT', 'SECURE', 'DEBUG']):
            score += 50
    
    # Check for valid timestamps
    if 'timestamp' in footer_info and 0 < footer_info['timestamp'] < 2000000000:
        score += 20
    
    # Check for valid version numbers
    if 'version' in footer_info and 0 < footer_info['version'] < 0xFFFF:
        score += 15
    
    # Check for valid sizes
    if 'data_size' in footer_info and 0 < footer_info['data_size'] < 0x1000000:
        score += 15
    
    return score

def validate_footer_integrity(data, footer_type, info):
    """Validate footer integrity and checksums"""
    validation = {}
    
    try:
        # Calculate CRC32 of the data
        calculated_crc = zlib.crc32(data) & 0xFFFFFFFF
        
        # Check if footer has embedded checksum
        if 'checksum' in info:
            embedded_crc = info['checksum']
            validation['crc_match'] = (calculated_crc == embedded_crc)
            validation['calculated_crc'] = f"0x{calculated_crc:08X}"
            validation['embedded_crc'] = f"0x{embedded_crc:08X}"
        else:
            validation['calculated_crc'] = f"0x{calculated_crc:08X}"
        
        # Validate magic signature
        if 'magic' in info and info['magic']:
            expected_magics = {
                'STANDARD': 'QSLCL',
                'SECURITY': 'SECURE',
                'BOOT': 'BOOT',
                'LOADER': 'LOADER',
                'DEBUG': 'DEBUG',
                'AUDIT': 'AUDIT'
            }
            expected_magic = expected_magics.get(footer_type, '')
            validation['magic_valid'] = expected_magic in info['magic']
        
        # Validate timestamps
        if 'timestamp' in info:
            current_time = time.time()
            validation['timestamp_valid'] = (0 < info['timestamp'] < current_time + 86400)  # Within 1 day in future
        
        validation['overall_valid'] = all(v for k, v in validation.items() if k.endswith('_valid'))
        
    except Exception as e:
        validation['validation_error'] = str(e)
    
    return validation

def hexdump(data, bytes_per_line=16):
    """Create hex dump of data"""
    result = []
    for i in range(0, len(data), bytes_per_line):
        chunk = data[i:i+bytes_per_line]
        hex_part = ' '.join(f'{b:02x}' for b in chunk)
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        result.append(f"{i:08x}: {hex_part:<48} |{ascii_part}|")
    return '\n'.join(result)

def display_structured_footer(info, footer_type):
    """Display structured footer information"""
    print(f"\n[*] STRUCTURED FOOTER INFORMATION:")
    
    # Basic information
    if 'magic' in info:
        print(f"    Magic: {info['magic']}")
    if 'version' in info:
        print(f"    Version: 0x{info['version']:08X}")
    if 'timestamp_human' in info:
        print(f"    Timestamp: {info['timestamp_human']}")
    elif 'timestamp' in info:
        print(f"    Timestamp: 0x{info['timestamp']:08X}")
    
    # Type-specific information
    if footer_type == 'SECURITY':
        if 'crypto_algo_name' in info:
            print(f"    Crypto Algorithm: {info['crypto_algo_name']}")
        if 'hash_type_name' in info:
            print(f"    Hash Type: {info['hash_type_name']}")
    
    elif footer_type == 'BOOT':
        if 'boot_source_name' in info:
            print(f"    Boot Source: {info['boot_source_name']}")
        if 'boot_reason_name' in info:
            print(f"    Boot Reason: {info['boot_reason_name']}")
        if 'boot_counter' in info:
            print(f"    Boot Count: {info['boot_counter']}")
    
    elif footer_type == 'LOADER':
        if 'architecture_name' in info:
            print(f"    Architecture: {info['architecture_name']}")
        if 'entry_point' in info:
            print(f"    Entry Point: 0x{info['entry_point']:08X}")
    
    elif footer_type == 'DEBUG':
        if 'exception_count' in info:
            print(f"    Exceptions: {info['exception_count']}")
        if 'watchdog_resets' in info:
            print(f"    Watchdog Resets: {info['watchdog_resets']}")
    
    elif footer_type == 'AUDIT':
        if 'security_state_name' in info:
            print(f"    Security State: {info['security_state_name']}")
        if 'auth_failures' in info:
            print(f"    Auth Failures: {info['auth_failures']}")

def display_extended_footer_info(info, footer_type):
    """Display extended footer information"""
    print(f"\n[*] EXTENDED FOOTER INFORMATION:")
    
    # Display all numeric fields
    for key, value in info.items():
        if isinstance(value, int) and key not in ['magic', 'timestamp_human']:
            print(f"    {key:20}: 0x{value:08X} ({value})")
        elif isinstance(value, list) and key.endswith('_parsed'):
            print(f"    {key:20}: {', '.join(value)}")

def display_crc_info(data, info):
    """Display CRC and checksum information"""
    print(f"\n[*] CRC AND CHECKSUM INFORMATION:")
    
    calculated_crc = zlib.crc32(data) & 0xFFFFFFFF
    print(f"    Calculated CRC32: 0x{calculated_crc:08X}")
    
    if 'checksum' in info:
        embedded_crc = info['checksum']
        match = "✓" if calculated_crc == embedded_crc else "✗"
        print(f"    Embedded Checksum: 0x{embedded_crc:08X} {match}")
        if calculated_crc != embedded_crc:
            print(f"    [!] CHECKSUM MISMATCH - Data may be corrupted!")

def display_footer_metadata(info):
    """Display footer metadata"""
    print(f"\n[*] FOOTER METADATA:")
    
    # Count fields by type
    int_fields = sum(1 for v in info.values() if isinstance(v, int))
    str_fields = sum(1 for v in info.values() if isinstance(v, str))
    list_fields = sum(1 for v in info.values() if isinstance(v, list))
    
    print(f"    Total fields: {len(info)}")
    print(f"    Integer fields: {int_fields}")
    print(f"    String fields: {str_fields}")
    print(f"    List fields: {list_fields}")
    
    # Show parse errors if any
    error_fields = [k for k in info.keys() if k.endswith('_error')]
    if error_fields:
        print(f"    Parse errors: {len(error_fields)}")
        for error_field in error_fields:
            print(f"      - {error_field}: {info[error_field]}")

def display_validation_results(validation):
    """Display validation results"""
    print(f"\n[*] VALIDATION RESULTS:")
    
    for key, value in validation.items():
        if key.endswith('_valid'):
            status = "PASS" if value else "FAIL"
            icon = "✓" if value else "✗"
            print(f"    {icon} {key:20}: {status}")
        elif not key.endswith('_error'):
            print(f"    {key:20}: {value}")
    
    if 'overall_valid' in validation:
        overall_status = "VALID" if validation['overall_valid'] else "INVALID"
        overall_icon = "✓" if validation['overall_valid'] else "✗"
        print(f"    {overall_icon} OVERALL: {overall_status}")

def assess_footer_security(info, footer_type):
    """Assess footer security posture"""
    assessments = []
    
    if footer_type == "SECURITY":
        if 'crypto_algo_name' in info:
            if info['crypto_algo_name'] in ['AES-128', 'RSA-2048']:
                assessments.append("🟡 Cryptographic algorithm may be weak")
            elif info['crypto_algo_name'] in ['AES-256', 'RSA-4096', 'ECDSA-P256']:
                assessments.append("🟢 Strong cryptographic algorithm")
        
        if 'hash' in info and len(info['hash']) == 64:  # SHA256
            assessments.append("🟢 Strong hash algorithm (SHA-256)")
    
    elif footer_type == "BOOT":
        if 'boot_source_name' in info and info['boot_source_name'] == 'CRASH':
            assessments.append("🔴 Last boot was due to crash")
        if 'last_boot_status_name' in info and info['last_boot_status_name'] != 'SUCCESS':
            assessments.append("🟡 Previous boot had issues")
    
    elif footer_type == "AUDIT":
        if 'security_state_name' in info:
            if info['security_state_name'] in ['COMPROMISED', 'TAMPERED']:
                assessments.append("🔴 SECURITY COMPROMISE DETECTED")
            elif info['security_state_name'] == 'WARNING':
                assessments.append("🟡 Security warnings present")
        
        if 'tamper_events' in info and info['tamper_events'] > 0:
            assessments.append("🔴 Tamper events detected")
    
    if not assessments:
        assessments.append("🟢 No obvious security issues detected")
    
    return assessments
