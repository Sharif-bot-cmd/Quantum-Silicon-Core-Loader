def cmd_footer(args=None):
    """
    Fully implemented FOOTER command with advanced features:
    - Comprehensive footer analysis and validation
    - Multiple footer types and formats
    - Cryptographic verification and integrity checking
    - Metadata extraction and interpretation
    - Cross-referencing and pattern recognition
    """
    if not args:
        print("[!] FOOTER: No arguments provided")
        return None

    # Safely get attributes with defaults
    footer_type = getattr(args, 'footer_type', 'STANDARD')
    if footer_type:
        footer_type = footer_type.upper()
    else:
        footer_type = 'STANDARD'
        
    footer_args = getattr(args, 'footer_args', [])
    show_raw = getattr(args, 'raw', False)
    show_extended = getattr(args, 'extended', False)
    show_verbose = getattr(args, 'verbose', False)
    show_crc = getattr(args, 'crc', False)
    show_metadata = getattr(args, 'metadata', False)
    show_all = getattr(args, 'all', False)
    validate = getattr(args, 'validate', False)
    show_hex = getattr(args, 'hex', False)
    show_structured = getattr(args, 'structured', False)
    show_json = getattr(args, 'json', False)
    save_file = getattr(args, 'save', None)

    # If show_all is set, enable all display options
    if show_all:
        show_raw = show_extended = show_verbose = show_crc = show_metadata = True

    print(f"[*] FOOTER command: type={footer_type}")

    # =========================================================================
    # 0. DEVICE DETECTION
    # =========================================================================
    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return None

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    # =========================================================================
    # 1. FOOTER DATA ACQUISITION
    # =========================================================================
    print(f"[*] Acquiring footer data...")
    
    footer_data = None
    footer_info = {}

    try:
        # Try different methods to get footer data
        # First try dedicated FOOTER command via QSLCLCMD
        if "FOOTER" in QSLCLCMD_DB:
            # Use dedicated FOOTER command
            footer_payload = struct.pack("<B", footer_type_to_code(footer_type))
            resp = qslcl_dispatch(dev, "FOOTER", footer_payload)
        else:
            # Fallback to generic read at footer address
            footer_addr = determine_footer_address(footer_type, dev)
            if footer_addr:
                read_payload = struct.pack("<II", footer_addr, 512)  # Read 512 bytes for footer
                resp = qslcl_dispatch(dev, "READ", read_payload)
            else:
                resp = None

        if resp:
            status = decode_runtime_result(resp)
            if status and status.get("severity") == "SUCCESS":
                footer_data = status.get("extra", b"")
                if not footer_data and len(resp) > 2:
                    # Some devices return data directly in response
                    footer_data = resp[2:] if len(resp) > 2 else resp
                print(f"[+] Footer data acquired: {len(footer_data)} bytes")
            else:
                print(f"[!] Footer acquisition failed: {status}")
                # Try direct read as fallback
                footer_addr = determine_footer_address(footer_type, dev)
                if footer_addr:
                    print(f"[*] Trying direct read at 0x{footer_addr:08X}...")
                    read_payload = struct.pack("<II", footer_addr, 512)
                    resp2 = qslcl_dispatch(dev, "READ", read_payload)
                    if resp2:
                        status2 = decode_runtime_result(resp2)
                        if status2 and status2.get("severity") == "SUCCESS":
                            footer_data = status2.get("extra", b"")
                            print(f"[+] Direct read successful: {len(footer_data)} bytes")
                        else:
                            print(f"[!] Direct read also failed")
                            return None
        else:
            print("[!] No response from footer command")
            return None

    except Exception as e:
        print(f"[!] Footer acquisition error: {e}")
        traceback.print_exc()
        return None

    if not footer_data or len(footer_data) < 8:
        print(f"[!] No footer data received or data too small ({len(footer_data) if footer_data else 0} bytes)")
        return None

    # =========================================================================
    # 2. FOOTER PARSING AND ANALYSIS
    # =========================================================================
    print(f"[*] Analyzing footer structure...")
    
    # Parse footer based on type
    if footer_type == "STANDARD":
        footer_info = parse_standard_footer(footer_data, show_verbose)
    elif footer_type == "EXTENDED":
        footer_info = parse_extended_footer(footer_data, show_verbose)
    elif footer_type == "SECURITY":
        footer_info = parse_security_footer(footer_data, show_verbose)
    elif footer_type == "BOOT":
        footer_info = parse_boot_footer(footer_data, show_verbose)
    elif footer_type == "LOADER":
        footer_info = parse_loader_footer(footer_data, show_verbose)
    elif footer_type == "DEBUG":
        footer_info = parse_debug_footer(footer_data, show_verbose)
    elif footer_type == "AUDIT":
        footer_info = parse_audit_footer(footer_data, show_verbose)
    elif footer_type == "ALL":
        footer_info = parse_all_footers(footer_data, show_verbose)
    else:
        print(f"[!] Unknown footer type: {footer_type}")
        return None

    # =========================================================================
    # 3. INTEGRITY VERIFICATION
    # =========================================================================
    if validate:
        print(f"[*] Validating footer integrity...")
        validation_results = validate_footer_integrity(footer_data, footer_type, footer_info)
        footer_info['validation'] = validation_results

    # =========================================================================
    # 4. DATA DISPLAY AND OUTPUT
    # =========================================================================
    print(f"\n[+] FOOTER ANALYSIS RESULTS:")
    print(f"    Type: {footer_type}")
    print(f"    Size: {len(footer_data)} bytes")
    
    if 'magic' in footer_info and footer_info['magic']:
        print(f"    Magic: {footer_info['magic']}")
    elif 'magic' in footer_info:
        print(f"    Magic: Not found (empty)")
    else:
        print(f"    Magic: Field not parsed")

    # Display raw data if requested
    if show_raw or show_hex:
        print(f"\n[*] RAW FOOTER DATA:")
        print(hexdump(footer_data, 16))

    # Display structured information
    if show_structured or not (show_raw or show_hex):
        display_structured_footer(footer_info, footer_type)

    # Display extended information
    if show_extended:
        display_extended_footer_info(footer_info, footer_type)

    # Display CRC information
    if show_crc:
        display_crc_info(footer_data, footer_info)

    # Display metadata
    if show_metadata:
        display_footer_metadata(footer_info)

    # Display validation results
    if validate and 'validation' in footer_info:
        display_validation_results(footer_info['validation'])

    # =========================================================================
    # 5. JSON OUTPUT
    # =========================================================================
    if show_json:
        json_output = {
            'footer_type': footer_type,
            'data_size': len(footer_data),
            'analysis': footer_info
        }
        print(f"\n[*] JSON OUTPUT:")
        print(json.dumps(json_output, indent=2, default=str))

    # =========================================================================
    # 6. FILE SAVING
    # =========================================================================
    if save_file:
        try:
            with open(save_file, 'wb') as f:
                f.write(footer_data)
            print(f"\n[+] Footer data saved to: {save_file}")
            
            # Also save analysis if JSON mode
            if show_json:
                analysis_file = save_file + '.json'
                with open(analysis_file, 'w') as f:
                    json.dump(json_output, f, indent=2, default=str)
                print(f"[+] Footer analysis saved to: {analysis_file}")
                
        except Exception as e:
            print(f"[!] Failed to save footer data: {e}")

    # =========================================================================
    # 7. SECURITY ASSESSMENT
    # =========================================================================
    if footer_type in ["SECURITY", "BOOT", "LOADER", "AUDIT"]:
        print(f"\n[*] SECURITY ASSESSMENT:")
        security_assessment = assess_footer_security(footer_info, footer_type)
        for assessment in security_assessment:
            print(f"    {assessment}")

    print(f"\n[+] Footer analysis completed")
    return footer_info

# =============================================================================
# FOOTER PARSING FUNCTIONS
# =============================================================================

def footer_type_to_code(footer_type):
    """Convert footer type string to command code"""
    type_codes = {
        'STANDARD': 0x01,
        'EXTENDED': 0x02,
        'SECURITY': 0x03,
        'BOOT': 0x04,
        'LOADER': 0x05,
        'DEBUG': 0x06,
        'AUDIT': 0x07,
        'ALL': 0xFF
    }
    return type_codes.get(footer_type, 0x01)

def determine_footer_address(footer_type, dev=None):
    """Determine memory address for footer type"""
    # Common footer locations (these are typical addresses)
    footer_addresses = {
        'STANDARD': 0xFFFF0000,
        'EXTENDED': 0xFFFF1000,
        'SECURITY': 0xFFFF2000,
        'BOOT': 0xFFFF3000,
        'LOADER': 0xFFFF4000,
        'DEBUG': 0xFFFF5000,
        'AUDIT': 0xFFFF6000,
        'ALL': 0xFFFF0000  # Start with standard for ALL type
    }
    return footer_addresses.get(footer_type, 0xFFFF0000)

def parse_standard_footer(data, verbose=False):
    """Parse standard system footer"""
    info = {}
    
    try:
        if len(data) >= 64:
            # Parse standard footer structure
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['version'] = struct.unpack('<I', data[8:12])[0]
            info['timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['checksum'] = struct.unpack('<I', data[16:20])[0]
            info['data_size'] = struct.unpack('<I', data[20:24])[0]
            info['flags'] = struct.unpack('<I', data[24:28])[0]
            
            # Parse human-readable timestamp
            if info['timestamp'] > 0:
                try:
                    info['timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                           time.localtime(info['timestamp']))
                except (ValueError, OverflowError):
                    info['timestamp_human'] = "Invalid timestamp"
            
            # Parse flags
            info['flags_parsed'] = parse_footer_flags(info['flags'])
            
            if verbose:
                info['raw_data'] = data.hex()
        else:
            info['error'] = f"Data too small ({len(data)} bytes), need at least 64 bytes"
                
    except Exception as e:
        info['parse_error'] = str(e)
        info['error'] = f"Parse error: {e}"
        
    return info

def parse_extended_footer(data, verbose=False):
    """Parse extended footer with additional fields"""
    info = parse_standard_footer(data, verbose)
    
    try:
        if len(data) >= 128:
            # Extended fields
            info['build_id'] = data[32:48].hex()
            info['hw_compatibility'] = struct.unpack('<I', data[48:52])[0]
            info['sw_compatibility'] = struct.unpack('<I', data[52:56])[0]
            info['reserved'] = data[56:64].hex()
            
            # Vendor-specific fields
            info['vendor_data'] = data[64:128].hex()
        else:
            if 'error' not in info:
                info['error'] = f"Extended data too small ({len(data)} bytes), need at least 128 bytes"
            
    except Exception as e:
        info['extended_parse_error'] = str(e)
        
    return info

def parse_security_footer(data, verbose=False):
    """Parse security footer with cryptographic information"""
    info = {}
    
    try:
        if len(data) >= 256:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['security_version'] = struct.unpack('<I', data[8:12])[0]
            info['crypto_algo'] = struct.unpack('<I', data[12:16])[0]
            info['hash_type'] = struct.unpack('<I', data[16:20])[0]
            info['signature_type'] = struct.unpack('<I', data[20:24])[0]
            
            # Cryptographic data
            info['hash'] = data[32:64].hex()  # SHA256
            info['signature'] = data[64:128].hex()  # RSA signature
            info['public_key'] = data[128:256].hex()  # Public key
            
            # Parse crypto algorithms
            crypto_algo_map = {
                0x01: 'AES-128',
                0x02: 'AES-256', 
                0x03: 'RSA-2048',
                0x04: 'RSA-4096',
                0x05: 'ECDSA-P256',
                0x06: 'ECDSA-P384',
                0x07: 'ECDSA-P521',
                0x08: 'SHA-256',
                0x09: 'SHA-384',
                0x0A: 'SHA-512',
                0x0B: 'HMAC-SHA256'
            }
            info['crypto_algo_name'] = crypto_algo_map.get(info['crypto_algo'], f'UNKNOWN (0x{info["crypto_algo"]:08X})')
            
            hash_type_map = {
                0x01: 'SHA-256',
                0x02: 'SHA-384',
                0x03: 'SHA-512',
                0x04: 'SHA3-256',
                0x05: 'SHA3-384',
                0x06: 'SHA3-512'
            }
            info['hash_type_name'] = hash_type_map.get(info['hash_type'], f'UNKNOWN (0x{info["hash_type"]:08X})')
            
            signature_type_map = {
                0x01: 'RSA-PKCS1',
                0x02: 'RSA-PSS',
                0x03: 'ECDSA',
                0x04: 'EdDSA',
                0x05: 'DSA'
            }
            info['signature_type_name'] = signature_type_map.get(info['signature_type'], f'UNKNOWN (0x{info["signature_type"]:08X})')
        else:
            info['error'] = f"Security data too small ({len(data)} bytes), need at least 256 bytes"
            
    except Exception as e:
        info['security_parse_error'] = str(e)
        info['error'] = f"Security parse error: {e}"
        
    return info

def parse_boot_footer(data, verbose=False):
    """Parse boot process footer"""
    info = {}
    
    try:
        if len(data) >= 128:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['boot_version'] = struct.unpack('<I', data[8:12])[0]
            info['boot_timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['boot_source'] = struct.unpack('<I', data[16:20])[0]
            info['boot_reason'] = struct.unpack('<I', data[20:24])[0]
            info['boot_counter'] = struct.unpack('<I', data[24:28])[0]
            info['last_boot_status'] = struct.unpack('<I', data[28:32])[0]
            
            # Boot source interpretation
            boot_source_map = {
                0x00: 'POWER_ON',
                0x01: 'SOFT_RESET',
                0x02: 'WATCHDOG',
                0x03: 'RECOVERY',
                0x04: 'BOOTLOADER',
                0x05: 'CRASH',
                0x06: 'SLEEP_WAKE',
                0x07: 'THERMAL_SHUTDOWN',
                0x08: 'LOW_BATTERY',
                0x09: 'USER_REQUEST',
                0x0A: 'SECURITY_EVENT',
                0x0B: 'FIRMWARE_UPDATE'
            }
            info['boot_source_name'] = boot_source_map.get(info['boot_source'], f'UNKNOWN (0x{info["boot_source"]:08X})')
            
            # Boot reason interpretation
            boot_reason_map = {
                0x00: 'NORMAL',
                0x01: 'UPDATE',
                0x02: 'FACTORY_RESET',
                0x03: 'SECURITY_VIOLATION',
                0x04: 'HARDWARE_FAILURE',
                0x05: 'SOFTWARE_FAILURE',
                0x06: 'WATCHDOG_TIMEOUT',
                0x07: 'THERMAL_OVERHEAT',
                0x08: 'BATTERY_CRITICAL',
                0x09: 'USER_INITIATED',
                0x0A: 'AUTO_TEST'
            }
            info['boot_reason_name'] = boot_reason_map.get(info['boot_reason'], f'UNKNOWN (0x{info["boot_reason"]:08X})')
            
            # Last boot status
            boot_status_map = {
                0x00: 'SUCCESS',
                0x01: 'FAILED',
                0x02: 'CRASHED',
                0x03: 'WATCHDOG',
                0x04: 'SECURITY_FAIL',
                0x05: 'HARDWARE_ERROR',
                0x06: 'SOFTWARE_ERROR',
                0x07: 'BOOT_TIMEOUT',
                0x08: 'VERIFICATION_FAIL'
            }
            info['last_boot_status_name'] = boot_status_map.get(info['last_boot_status'], f'UNKNOWN (0x{info["last_boot_status"]:08X})')
            
            if info['boot_timestamp'] > 0:
                try:
                    info['boot_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                time.localtime(info['boot_timestamp']))
                except (ValueError, OverflowError):
                    info['boot_timestamp_human'] = "Invalid timestamp"
        else:
            info['error'] = f"Boot data too small ({len(data)} bytes), need at least 128 bytes"
                
    except Exception as e:
        info['boot_parse_error'] = str(e)
        info['error'] = f"Boot parse error: {e}"
        
    return info

def parse_loader_footer(data, verbose=False):
    """Parse loader footer information"""
    info = {}
    
    try:
        if len(data) >= 256:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['loader_version'] = struct.unpack('<I', data[8:12])[0]
            info['loader_timestamp'] = struct.unpack('<I', data[12:16])[0]
            info['loader_checksum'] = struct.unpack('<I', data[16:20])[0]
            info['loader_size'] = struct.unpack('<I', data[20:24])[0]
            info['entry_point'] = struct.unpack('<I', data[24:28])[0]
            info['load_address'] = struct.unpack('<I', data[28:32])[0]
            
            # Architecture information
            arch_map = {
                0x00: 'ARM32',
                0x01: 'ARM64', 
                0x02: 'x86',
                0x03: 'x64',
                0x04: 'MIPS',
                0x05: 'RISCV32',
                0x06: 'RISCV64',
                0x07: 'POWERPC',
                0x08: 'POWERPC64',
                0x09: 'SPARC',
                0x0A: 'SPARC64',
                0x0B: 'SH4',
                0x0C: 'ALPHA',
                0x0D: 'UNKNOWN'
            }
            info['architecture'] = struct.unpack('<I', data[32:36])[0]
            info['architecture_name'] = arch_map.get(info['architecture'], f'UNKNOWN (0x{info["architecture"]:08X})')
            
            # Endianness
            info['endianness'] = struct.unpack('<I', data[36:40])[0]
            endian_map = {
                0x00: 'LITTLE',
                0x01: 'BIG',
                0x02: 'BI_ENDIAN'
            }
            info['endianness_name'] = endian_map.get(info['endianness'], f'UNKNOWN (0x{info["endianness"]:08X})')
            
            if info['loader_timestamp'] > 0:
                try:
                    info['loader_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                  time.localtime(info['loader_timestamp']))
                except (ValueError, OverflowError):
                    info['loader_timestamp_human'] = "Invalid timestamp"
                    
            # Loader flags
            if len(data) >= 256:
                info['loader_flags'] = struct.unpack('<I', data[40:44])[0]
                info['loader_flags_parsed'] = parse_loader_flags(info['loader_flags'])
        else:
            info['error'] = f"Loader data too small ({len(data)} bytes), need at least 256 bytes"
                
    except Exception as e:
        info['loader_parse_error'] = str(e)
        info['error'] = f"Loader parse error: {e}"
        
    return info

def parse_debug_footer(data, verbose=False):
    """Parse debug footer with diagnostic information"""
    info = {}
    
    try:
        if len(data) >= 512:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['debug_version'] = struct.unpack('<I', data[8:12])[0]
            info['debug_timestamp'] = struct.unpack('<I', data[12:16])[0]
            
            # Debug counters
            info['exception_count'] = struct.unpack('<I', data[16:20])[0]
            info['watchdog_resets'] = struct.unpack('<I', data[20:24])[0]
            info['memory_errors'] = struct.unpack('<I', data[24:28])[0]
            info['io_errors'] = struct.unpack('<I', data[28:32])[0]
            info['cache_errors'] = struct.unpack('<I', data[32:36])[0]
            info['bus_errors'] = struct.unpack('<I', data[36:40])[0]
            
            # Last error information
            info['last_error_code'] = struct.unpack('<I', data[40:44])[0]
            info['last_error_address'] = struct.unpack('<I', data[44:48])[0]
            info['last_error_timestamp'] = struct.unpack('<I', data[48:52])[0]
            info['last_error_thread'] = struct.unpack('<I', data[52:56])[0]
            
            # Debug flags
            info['debug_flags'] = struct.unpack('<I', data[56:60])[0]
            info['debug_flags_parsed'] = parse_debug_flags(info['debug_flags'])
            
            # Error description (if available)
            if len(data) >= 512:
                error_desc_start = 60
                error_desc_end = min(128, len(data))
                error_desc = data[error_desc_start:error_desc_end]
                # Find null terminator
                null_pos = error_desc.find(b'\x00')
                if null_pos != -1:
                    error_desc = error_desc[:null_pos]
                info['last_error_description'] = error_desc.decode('ascii', errors='ignore').rstrip('\x00')
            
            if info['debug_timestamp'] > 0:
                try:
                    info['debug_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                 time.localtime(info['debug_timestamp']))
                except (ValueError, OverflowError):
                    info['debug_timestamp_human'] = "Invalid timestamp"
                    
            if info['last_error_timestamp'] > 0:
                try:
                    info['last_error_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                      time.localtime(info['last_error_timestamp']))
                except (ValueError, OverflowError):
                    info['last_error_timestamp_human'] = "Invalid timestamp"
        else:
            info['error'] = f"Debug data too small ({len(data)} bytes), need at least 512 bytes"
                
    except Exception as e:
        info['debug_parse_error'] = str(e)
        info['error'] = f"Debug parse error: {e}"
        
    return info

def parse_audit_footer(data, verbose=False):
    """Parse audit footer with security events"""
    info = {}
    
    try:
        if len(data) >= 1024:
            info['magic'] = data[0:8].decode('ascii', errors='ignore').rstrip('\x00')
            info['audit_version'] = struct.unpack('<I', data[8:12])[0]
            info['audit_timestamp'] = struct.unpack('<I', data[12:16])[0]
            
            # Security event counters
            info['auth_failures'] = struct.unpack('<I', data[16:20])[0]
            info['access_denied'] = struct.unpack('<I', data[20:24])[0]
            info['integrity_failures'] = struct.unpack('<I', data[24:28])[0]
            info['tamper_events'] = struct.unpack('<I', data[28:32])[0]
            info['key_usage'] = struct.unpack('<I', data[32:36])[0]
            info['certificate_validations'] = struct.unpack('<I', data[36:40])[0]
            
            # Last security event
            info['last_security_event'] = struct.unpack('<I', data[40:44])[0]
            info['last_event_timestamp'] = struct.unpack('<I', data[44:48])[0]
            info['last_event_severity'] = struct.unpack('<I', data[48:52])[0]
            
            # Last event details
            event_details_start = 52
            event_details_end = min(128, len(data))
            event_details = data[event_details_start:event_details_end]
            null_pos = event_details.find(b'\x00')
            if null_pos != -1:
                event_details = event_details[:null_pos]
            info['last_event_details'] = event_details.decode('ascii', errors='ignore').rstrip('\x00')
            
            # Security state
            info['security_state'] = struct.unpack('<I', data[128:132])[0]
            security_state_map = {
                0x00: 'SECURE',
                0x01: 'WARNING',
                0x02: 'COMPROMISED',
                0x03: 'TAMPERED',
                0x04: 'LOCKED',
                0x05: 'RECOVERY',
                0x06: 'MAINTENANCE',
                0x07: 'TEST',
                0x08: 'DEVELOPMENT'
            }
            info['security_state_name'] = security_state_map.get(info['security_state'], f'UNKNOWN (0x{info["security_state"]:08X})')
            
            # Security flags
            if len(data) >= 136:
                info['security_flags'] = struct.unpack('<I', data[132:136])[0]
                info['security_flags_parsed'] = parse_security_flags(info['security_flags'])
            
            if info['audit_timestamp'] > 0:
                try:
                    info['audit_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                 time.localtime(info['audit_timestamp']))
                except (ValueError, OverflowError):
                    info['audit_timestamp_human'] = "Invalid timestamp"
                    
            if info['last_event_timestamp'] > 0:
                try:
                    info['last_event_timestamp_human'] = time.strftime('%Y-%m-%d %H:%M:%S', 
                                                                      time.localtime(info['last_event_timestamp']))
                except (ValueError, OverflowError):
                    info['last_event_timestamp_human'] = "Invalid timestamp"
        else:
            info['error'] = f"Audit data too small ({len(data)} bytes), need at least 1024 bytes"
                
    except Exception as e:
        info['audit_parse_error'] = str(e)
        info['error'] = f"Audit parse error: {e}"
        
    return info

def parse_all_footers(data, verbose=False):
    """Parse all footer types from combined data"""
    info = {}
    
    # Try to parse as each type and see which one fits best
    parsers = [
        ('STANDARD', parse_standard_footer),
        ('EXTENDED', parse_extended_footer),
        ('SECURITY', parse_security_footer),
        ('BOOT', parse_boot_footer),
        ('LOADER', parse_loader_footer),
        ('DEBUG', parse_debug_footer),
        ('AUDIT', parse_audit_footer)
    ]
    
    best_match = None
    best_score = 0
    
    for name, parser in parsers:
        try:
            result = parser(data, verbose)
            score = calculate_footer_match_score(result)
            if score > best_score:
                best_score = score
                best_match = (name, result)
        except Exception as e:
            continue
    
    if best_match:
        info['detected_type'] = best_match[0]
        info['match_confidence'] = best_score
        info.update(best_match[1])
    else:
        info['detected_type'] = 'UNKNOWN'
        info['match_confidence'] = 0
        info['error'] = 'Could not detect footer type'
        
    return info

# =============================================================================
# SUPPORTING FUNCTIONS FOR FOOTER ANALYSIS
# =============================================================================

def parse_footer_flags(flags):
    """Parse footer flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'VALIDATED',
        0x00000002: 'SIGNED',
        0x00000004: 'ENCRYPTED',
        0x00000008: 'COMPRESSED',
        0x00000010: 'DEBUG_ENABLED',
        0x00000020: 'PRODUCTION',
        0x00000040: 'DEVELOPMENT',
        0x00000080: 'TEST_BUILD',
        0x00000100: 'SECURE_BOOT',
        0x00000200: 'TRUSTZONE',
        0x00000400: 'ENCRYPTED_STORAGE',
        0x00000800: 'REMOTE_ATTESTATION',
        0x00001000: 'FIPS_COMPLIANT',
        0x00002000: 'CC_EAL_CERTIFIED'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def parse_loader_flags(flags):
    """Parse loader flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'RELOCATABLE',
        0x00000002: 'PIC',
        0x00000004: 'COMPRESSED',
        0x00000008: 'ENCRYPTED',
        0x00000010: 'SIGNED',
        0x00000020: 'VERIFIED',
        0x00000040: 'TRUSTED',
        0x00000080: 'SECURE',
        0x00000100: 'DEBUG_SYMBOLS',
        0x00000200: 'STRIPPED',
        0x00000400: 'SHARED_LIBRARY',
        0x00000800: 'EXECUTABLE',
        0x00001000: 'KERNEL_MODULE'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def parse_debug_flags(flags):
    """Parse debug flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'LOG_ENABLED',
        0x00000002: 'TRACE_ENABLED',
        0x00000004: 'PROFILING',
        0x00000008: 'MEMORY_DEBUG',
        0x00000010: 'ASSERT_ENABLED',
        0x00000020: 'BREAK_ON_ERROR',
        0x00000040: 'METRICS_ENABLED',
        0x00000080: 'STACK_PROTECTION',
        0x00000100: 'HEAP_DEBUG',
        0x00000200: 'THREAD_DEBUG',
        0x00000400: 'IPC_DEBUG',
        0x00000800: 'FS_DEBUG'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def parse_security_flags(flags):
    """Parse security flags into human-readable format"""
    flag_descriptions = []
    
    flag_definitions = {
        0x00000001: 'SECURE_BOOT_ENABLED',
        0x00000002: 'TRUSTZONE_ENABLED',
        0x00000004: 'ENCRYPTION_ENABLED',
        0x00000008: 'INTEGRITY_CHECKING',
        0x00000010: 'ANTI_ROLLBACK',
        0x00000020: 'TAMPER_DETECTION',
        0x00000040: 'SECURE_DEBUG_DISABLED',
        0x00000080: 'SECURE_STORAGE',
        0x00000100: 'KEY_PROTECTION',
        0x00000200: 'CERTIFICATE_CHAIN',
        0x00000400: 'REVOCATION_CHECKING',
        0x00000800: 'SECURE_UPDATE',
        0x00001000: 'FIREWALL_ENABLED',
        0x00002000: 'MPU_ENABLED'
    }
    
    for flag, description in flag_definitions.items():
        if flags & flag:
            flag_descriptions.append(description)
            
    return flag_descriptions

def calculate_footer_match_score(footer_info):
    """Calculate how well the parsed data matches expected footer structure"""
    score = 0
    
    # Check for magic signature
    if 'magic' in footer_info and footer_info['magic']:
        magic = footer_info['magic']
        if any(sig in magic.upper() for sig in ['QSLCL', 'BOOT', 'SECURE', 'DEBUG', 'AUDIT', 'LOADER']):
            score += 50
        elif len(magic) >= 4 and all(32 <= ord(c) < 127 for c in magic):
            score += 20
    
    # Check for valid timestamps
    timestamp_keys = ['timestamp', 'boot_timestamp', 'debug_timestamp', 'audit_timestamp', 'loader_timestamp']
    for key in timestamp_keys:
        if key in footer_info:
            timestamp = footer_info[key]
            if isinstance(timestamp, int):
                if 946684800 < timestamp < 2000000000:  # Between 2000 and 2033
                    score += 20
                elif timestamp > 0:
                    score += 5
    
    # Check for valid version numbers
    version_keys = ['version', 'security_version', 'boot_version', 'debug_version', 'audit_version', 'loader_version']
    for key in version_keys:
        if key in footer_info:
            version = footer_info[key]
            if isinstance(version, int) and 0 < version < 0xFFFF:
                score += 15
    
    # Check for valid sizes
    size_keys = ['data_size', 'loader_size']
    for key in size_keys:
        if key in footer_info:
            size = footer_info[key]
            if isinstance(size, int) and 0 < size < 0x1000000:
                score += 15
    
    # Deduct for errors
    error_keys = [key for key in footer_info.keys() if key.endswith('_error') or key == 'error']
    if error_keys:
        score -= 30
    
    return max(0, score)

def validate_footer_integrity(data, footer_type, info):
    """Validate footer integrity and checksums"""
    validation = {}
    
    try:
        # Calculate CRC32 of the data
        calculated_crc = zlib.crc32(data) & 0xFFFFFFFF
        
        # Check if footer has embedded checksum
        checksum_keys = ['checksum', 'loader_checksum']
        for key in checksum_keys:
            if key in info:
                embedded_crc = info[key]
                validation[f'{key}_match'] = (calculated_crc == embedded_crc)
                validation['calculated_crc'] = f"0x{calculated_crc:08X}"
                validation[f'embedded_{key}'] = f"0x{embedded_crc:08X}"
                break
        else:
            validation['calculated_crc'] = f"0x{calculated_crc:08X}"
        
        # Validate magic signature
        if 'magic' in info and info['magic']:
            expected_magics = {
                'STANDARD': ['QSLCL'],
                'EXTENDED': ['QSLCL', 'EXTENDED'],
                'SECURITY': ['SECURE', 'SECURITY', 'CRYPTO'],
                'BOOT': ['BOOT', 'BOOTROM'],
                'LOADER': ['LOADER', 'LDR', 'BOOTLOADER'],
                'DEBUG': ['DEBUG', 'DIAG', 'LOG'],
                'AUDIT': ['AUDIT', 'SECLOG', 'EVENT']
            }
            
            expected_list = expected_magics.get(footer_type, [])
            magic_valid = False
            for expected in expected_list:
                if expected in info['magic'].upper():
                    magic_valid = True
                    break
            
            if expected_list:
                validation['magic_valid'] = magic_valid
                if not magic_valid:
                    validation['magic_expected'] = expected_list
                    validation['magic_found'] = info['magic']
            else:
                validation['magic_valid'] = len(info['magic']) > 0
        
        # Validate timestamps
        timestamp_keys = ['timestamp', 'boot_timestamp', 'debug_timestamp', 
                         'audit_timestamp', 'loader_timestamp', 'last_error_timestamp']
        for key in timestamp_keys:
            if key in info:
                timestamp = info[key]
                if isinstance(timestamp, int):
                    current_time = time.time()
                    # Check if timestamp is reasonable (not too far in past or future)
                    is_valid = (946684800 < timestamp < current_time + 86400 * 365)  # Between 2000 and 1 year in future
                    validation[f'{key}_valid'] = is_valid
        
        # Validate sizes
        size_keys = ['data_size', 'loader_size']
        for key in size_keys:
            if key in info:
                size = info[key]
                if isinstance(size, int):
                    # Check if size is reasonable
                    is_valid = (0 < size < 0x10000000)  # Up to 256MB
                    validation[f'{key}_valid'] = is_valid
        
        # Calculate overall validity
        valid_flags = [v for k, v in validation.items() if isinstance(v, bool) and v]
        invalid_flags = [v for k, v in validation.items() if isinstance(v, bool) and not v]
        
        if valid_flags or invalid_flags:
            validation['overall_valid'] = len(invalid_flags) == 0
        else:
            validation['overall_valid'] = True  # No specific validations to fail
        
    except Exception as e:
        validation['validation_error'] = str(e)
        validation['overall_valid'] = False
    
    return validation

def display_structured_footer(info, footer_type):
    """Display structured footer information"""
    print(f"\n[*] STRUCTURED FOOTER INFORMATION:")
    
    # Basic information
    if 'magic' in info:
        print(f"    Magic: {info['magic']}")
    if 'version' in info:
        print(f"    Version: 0x{info['version']:08X} ({info['version']})")
    elif 'security_version' in info:
        print(f"    Version: 0x{info['security_version']:08X} ({info['security_version']})")
    elif 'boot_version' in info:
        print(f"    Version: 0x{info['boot_version']:08X} ({info['boot_version']})")
    elif 'debug_version' in info:
        print(f"    Version: 0x{info['debug_version']:08X} ({info['debug_version']})")
    elif 'audit_version' in info:
        print(f"    Version: 0x{info['audit_version']:08X} ({info['audit_version']})")
    elif 'loader_version' in info:
        print(f"    Version: 0x{info['loader_version']:08X} ({info['loader_version']})")
    
    # Timestamps
    timestamp_keys = ['timestamp_human', 'boot_timestamp_human', 'debug_timestamp_human',
                     'audit_timestamp_human', 'loader_timestamp_human', 'last_error_timestamp_human']
    for key in timestamp_keys:
        if key in info:
            label = key.replace('_human', '').replace('_', ' ').title()
            print(f"    {label}: {info[key]}")
    
    # Type-specific information
    if footer_type == 'SECURITY':
        if 'crypto_algo_name' in info:
            print(f"    Crypto Algorithm: {info['crypto_algo_name']}")
        if 'hash_type_name' in info:
            print(f"    Hash Type: {info['hash_type_name']}")
        if 'signature_type_name' in info:
            print(f"    Signature Type: {info['signature_type_name']}")
        if 'signature' in info:
            sig_preview = info['signature'][:16] + "..." if len(info['signature']) > 16 else info['signature']
            print(f"    Signature: {sig_preview}")
    
    elif footer_type == 'BOOT':
        if 'boot_source_name' in info:
            print(f"    Boot Source: {info['boot_source_name']}")
        if 'boot_reason_name' in info:
            print(f"    Boot Reason: {info['boot_reason_name']}")
        if 'boot_counter' in info:
            print(f"    Boot Count: {info['boot_counter']}")
        if 'last_boot_status_name' in info:
            print(f"    Last Boot Status: {info['last_boot_status_name']}")
    
    elif footer_type == 'LOADER':
        if 'architecture_name' in info:
            print(f"    Architecture: {info['architecture_name']}")
        if 'endianness_name' in info:
            print(f"    Endianness: {info['endianness_name']}")
        if 'entry_point' in info:
            print(f"    Entry Point: 0x{info['entry_point']:08X}")
        if 'load_address' in info:
            print(f"    Load Address: 0x{info['load_address']:08X}")
        if 'loader_size' in info:
            print(f"    Loader Size: 0x{info['loader_size']:08X} ({info['loader_size']} bytes)")
    
    elif footer_type == 'DEBUG':
        if 'exception_count' in info:
            print(f"    Exception Count: {info['exception_count']}")
        if 'watchdog_resets' in info:
            print(f"    Watchdog Resets: {info['watchdog_resets']}")
        if 'last_error_code' in info:
            print(f"    Last Error Code: 0x{info['last_error_code']:08X}")
        if 'last_error_description' in info:
            print(f"    Last Error: {info['last_error_description']}")
    
    elif footer_type == 'AUDIT':
        if 'security_state_name' in info:
            print(f"    Security State: {info['security_state_name']}")
        if 'auth_failures' in info:
            print(f"    Authentication Failures: {info['auth_failures']}")
        if 'tamper_events' in info:
            print(f"    Tamper Events: {info['tamper_events']}")
        if 'integrity_failures' in info:
            print(f"    Integrity Failures: {info['integrity_failures']}")
        if 'last_event_details' in info:
            print(f"    Last Event: {info['last_event_details']}")
    
    # Show flags if present
    flag_keys = ['flags_parsed', 'loader_flags_parsed', 'debug_flags_parsed', 
                'security_flags_parsed']
    for key in flag_keys:
        if key in info and info[key]:
            label = key.replace('_parsed', '').replace('_', ' ').title()
            print(f"    {label}: {', '.join(info[key])}")
    
    # Show detected type for ALL
    if footer_type == 'ALL' and 'detected_type' in info:
        print(f"    Detected Type: {info['detected_type']}")
        if 'match_confidence' in info:
            print(f"    Confidence: {info['match_confidence']}/100")
    
    # Show any errors
    for key in list(info.keys()):
        if key.endswith('_error') or key == 'error':
            print(f"    [!] {key}: {info[key]}")

def display_extended_footer_info(info, footer_type):
    """Display extended footer information"""
    print(f"\n[*] EXTENDED FOOTER INFORMATION:")
    
    # Display all fields except raw data and errors (handled separately)
    for key in sorted(info.keys()):
        if key in ['raw_data', 'validation', 'flags_parsed', 'loader_flags_parsed', 
                  'debug_flags_parsed', 'security_flags_parsed']:
            continue
        
        # Skip error fields (already displayed)
        if key.endswith('_error') or key == 'error':
            continue
        
        value = info[key]
        if isinstance(value, int):
            # Format as hex and decimal
            if key in ['timestamp', 'boot_timestamp', 'debug_timestamp', 
                      'audit_timestamp', 'loader_timestamp', 'last_error_timestamp']:
                # Timestamps shown differently
                continue
            else:
                print(f"    {key:30}: 0x{value:08X} ({value})")
        elif isinstance(value, list):
            if value:
                print(f"    {key:30}: {', '.join(str(v) for v in value)}")
        elif isinstance(value, dict):
            # Skip nested dicts
            continue
        elif isinstance(value, str) and len(value) > 0:
            if key.endswith('_human'):
                # Already displayed in structured view
                continue
            elif len(value) <= 80:
                print(f"    {key:30}: {value}")
            else:
                print(f"    {key:30}: {value[:77]}...")

def display_crc_info(data, info):
    """Display CRC and checksum information"""
    print(f"\n[*] CRC AND CHECKSUM INFORMATION:")
    
    calculated_crc = zlib.crc32(data) & 0xFFFFFFFF
    print(f"    Calculated CRC32: 0x{calculated_crc:08X}")
    
    # Check all possible checksum fields
    checksum_fields = ['checksum', 'loader_checksum']
    for field in checksum_fields:
        if field in info:
            embedded_crc = info[field]
            match = "✓" if calculated_crc == embedded_crc else "✗"
            print(f"    Embedded {field}: 0x{embedded_crc:08X} {match}")
            if calculated_crc != embedded_crc:
                print(f"    [!] {field.upper()} MISMATCH - Data may be corrupted!")
            break
    else:
        print(f"    No embedded checksum found in footer")

def display_footer_metadata(info):
    """Display footer metadata"""
    print(f"\n[*] FOOTER METADATA:")
    
    # Count fields by type
    int_fields = sum(1 for v in info.values() if isinstance(v, int))
    str_fields = sum(1 for v in info.values() if isinstance(v, str))
    list_fields = sum(1 for v in info.values() if isinstance(v, list))
    dict_fields = sum(1 for v in info.values() if isinstance(v, dict))
    other_fields = len(info) - (int_fields + str_fields + list_fields + dict_fields)
    
    print(f"    Total fields: {len(info)}")
    if int_fields > 0:
        print(f"    Integer fields: {int_fields}")
    if str_fields > 0:
        print(f"    String fields: {str_fields}")
    if list_fields > 0:
        print(f"    List fields: {list_fields}")
    if dict_fields > 0:
        print(f"    Dictionary fields: {dict_fields}")
    if other_fields > 0:
        print(f"    Other fields: {other_fields}")
    
    # Show parse errors if any
    error_fields = [k for k in info.keys() if k.endswith('_error') or k == 'error']
    if error_fields:
        print(f"    Parse errors: {len(error_fields)}")
        for error_field in error_fields:
            print(f"      - {error_field}: {info[error_field]}")

def display_validation_results(validation):
    """Display validation results"""
    print(f"\n[*] VALIDATION RESULTS:")
    
    for key, value in sorted(validation.items()):
        if key == 'validation_error':
            print(f"    [!] Validation Error: {value}")
        elif isinstance(value, bool):
            status = "PASS" if value else "FAIL"
            icon = "✓" if value else "✗"
            print(f"    {icon} {key:30}: {status}")
        elif key not in ['overall_valid']:
            print(f"    {key:30}: {value}")
    
    if 'overall_valid' in validation:
        overall_status = "VALID" if validation['overall_valid'] else "INVALID"
        overall_icon = "✓" if validation['overall_valid'] else "✗"
        print(f"\n    {overall_icon} OVERALL VALIDATION: {overall_status}")

def assess_footer_security(info, footer_type):
    """Assess footer security posture"""
    assessments = []
    
    if footer_type == "SECURITY":
        if 'crypto_algo_name' in info:
            algo = info['crypto_algo_name']
            if 'AES-128' in algo or 'RSA-2048' in algo:
                assessments.append("🟡 Cryptographic algorithm may be weak (consider upgrading)")
            elif 'AES-256' in algo or 'RSA-4096' in algo or 'ECDSA' in algo:
                assessments.append("🟢 Strong cryptographic algorithm")
            elif 'UNKNOWN' in algo:
                assessments.append("🔴 Unknown cryptographic algorithm - SECURITY RISK")
            elif 'DES' in algo or 'RC4' in algo or 'MD5' in algo:
                assessments.append("🔴 Weak/deprecated cryptographic algorithm - SECURITY RISK")
        
        if 'hash' in info:
            hash_len = len(info['hash'])
            if hash_len == 64:  # SHA256
                assessments.append("🟢 Strong hash algorithm (SHA-256)")
            elif hash_len == 96:  # SHA384
                assessments.append("🟢 Strong hash algorithm (SHA-384)")
            elif hash_len == 128:  # SHA512
                assessments.append("🟢 Strong hash algorithm (SHA-512)")
            elif hash_len == 32:  # MD5 (weak)
                assessments.append("🔴 Weak hash algorithm (MD5) - SECURITY RISK")
            elif hash_len == 40:  # SHA1 (weak)
                assessments.append("🔴 Weak hash algorithm (SHA-1) - SECURITY RISK")
            else:
                assessments.append(f"🟡 Unusual hash length: {hash_len} chars")
    
    elif footer_type == "BOOT":
        if 'boot_source_name' in info and 'CRASH' in info['boot_source_name']:
            assessments.append("🔴 Last boot was due to crash - investigate logs")
        if 'last_boot_status_name' in info and info['last_boot_status_name'] != 'SUCCESS':
            assessments.append(f"🟡 Previous boot had issues: {info['last_boot_status_name']}")
        if 'boot_counter' in info:
            if info['boot_counter'] > 10000:
                assessments.append("🟡 High boot count (possible wear on storage)")
            elif info['boot_counter'] < 10:
                assessments.append("🟢 Low boot count (fresh device)")
        
        # Check for unusual boot reasons
        unusual_reasons = ['SECURITY_VIOLATION', 'HARDWARE_FAILURE', 'WATCHDOG_TIMEOUT']
        if 'boot_reason_name' in info and any(reason in info['boot_reason_name'] for reason in unusual_reasons):
            assessments.append(f"🔴 Unusual boot reason: {info['boot_reason_name']}")
    
    elif footer_type == "AUDIT":
        if 'security_state_name' in info:
            state = info['security_state_name']
            if state in ['COMPROMISED', 'TAMPERED']:
                assessments.append("🔴 SECURITY COMPROMISE DETECTED - IMMEDIATE ACTION REQUIRED")
            elif state == 'WARNING':
                assessments.append("🟡 Security warnings present - review audit logs")
            elif state == 'SECURE':
                assessments.append("🟢 Security state: SECURE")
            elif state == 'LOCKED':
                assessments.append("🟡 Device is locked - may need recovery")
        
        if 'tamper_events' in info and info['tamper_events'] > 0:
            assessments.append(f"🔴 {info['tamper_events']} tamper event(s) detected")
        
        if 'auth_failures' in info:
            if info['auth_failures'] > 50:
                assessments.append(f"🔴 Excessive authentication failures ({info['auth_failures']}) - possible attack")
            elif info['auth_failures'] > 10:
                assessments.append(f"🟡 Elevated authentication failures ({info['auth_failures']})")
            elif info['auth_failures'] > 0:
                assessments.append(f"🟡 {info['auth_failures']} authentication failure(s)")
        
        if 'integrity_failures' in info and info['integrity_failures'] > 0:
            assessments.append(f"🔴 {info['integrity_failures']} integrity failure(s) - system may be compromised")
    
    elif footer_type == "LOADER":
        if 'loader_flags_parsed' in info:
            flags = info['loader_flags_parsed']
            if 'SIGNED' not in flags and 'VERIFIED' not in flags:
                assessments.append("🔴 Loader is not signed or verified - SECURITY RISK")
            if 'ENCRYPTED' not in flags:
                assessments.append("🟡 Loader is not encrypted - consider enabling")
            if 'SECURE' in flags:
                assessments.append("🟢 Loader has secure flag enabled")
            if 'TRUSTED' in flags:
                assessments.append("🟢 Loader has trusted flag enabled")
    
    # General checks for any footer type
    if 'validation' in info:
        validation = info['validation']
        if 'crc_match' in validation and not validation['crc_match']:
            assessments.append("🔴 Checksum validation failed - data may be corrupted")
        if 'checksum_match' in validation and not validation['checksum_match']:
            assessments.append("🔴 Checksum validation failed - data may be corrupted")
        if 'overall_valid' in validation and not validation['overall_valid']:
            assessments.append("🔴 Overall validation failed - footer integrity compromised")
    
    # Check for parse errors
    error_keys = [k for k in info.keys() if k.endswith('_error') or k == 'error']
    if error_keys:
        assessments.append("🔴 Parse errors detected - footer may be malformed")
    
    if not assessments:
        assessments.append("🟢 No obvious security issues detected")
    
    return assessments