def cmd_oem(args=None):
    """
    Fully implemented OEM command with advanced features:
    - Bootloader unlocking/locking with memory region scanning
    - Device-specific OEM operations
    - Secure boot configuration
    - Warranty bit management
    - Device provisioning and customization
    - QSLCLPAR command integration for OEM operations
    """
    if not args:
        print("[!] OEM: No arguments provided")
        return

    devs = scan_all()
    if not devs:
        print("[!] No device connected.")
        return

    dev = devs[0]
    auto_loader_if_needed(args, dev)

    subcommand = getattr(args, 'oem_subcommand', '').lower()
    oem_args = getattr(args, 'oem_args', [])
    force = getattr(args, 'force', False)
    verbose = getattr(args, 'verbose', False)

    if not subcommand:
        print("[!] OEM: No subcommand specified")
        print_oem_help()
        return

    print(f"[*] OEM command: {subcommand} {oem_args}")

    # =========================================================================
    # 1. CHECK QSLCLPAR OEM COMMAND AVAILABILITY
    # =========================================================================
    if "OEM" not in QSLCLPAR_DB:
        print("[!] OEM command not available in QSLCLPAR database")
        print("[!] Ensure qslcl.bin contains OEM command implementation")
        return

    oem_command = QSLCLPAR_DB["OEM"]
    print(f"[+] OEM command found in QSLCLPAR (opcode: 0x{oem_command['opcode']:02X})")

    # =========================================================================
    # 2. SUBCOMMAND DISPATCH WITH MEMORY REGION SCANNING
    # =========================================================================
    try:
        if subcommand in ['unlock', 'unlock-bootloader']:
            oem_unlock(dev, oem_args, force, verbose)
            
        elif subcommand in ['lock', 'lock-bootloader']:
            oem_lock(dev, oem_args, force, verbose)
            
        elif subcommand in ['warranty', 'warranty-bit']:
            oem_warranty(dev, oem_args, force, verbose)
            
        elif subcommand in ['secureboot', 'secure-boot']:
            oem_secureboot(dev, oem_args, force, verbose)
            
        elif subcommand in ['provision', 'provisioning']:
            oem_provision(dev, oem_args, force, verbose)
            
        elif subcommand in ['customize', 'customization']:
            oem_customize(dev, oem_args, force, verbose)
            
        elif subcommand in ['info', 'device-info']:
            oem_info(dev, oem_args, verbose)
            
        elif subcommand in ['config', 'configuration']:
            oem_config(dev, oem_args, force, verbose)
            
        elif subcommand in ['key', 'keys', 'signing-keys']:
            oem_keys(dev, oem_args, force, verbose)
            
        elif subcommand in ['debug', 'debugging']:
            oem_debug(dev, oem_args, force, verbose)
            
        elif subcommand in ['help', '?']:
            print_oem_help()
            
        else:
            print(f"[!] Unknown OEM subcommand: {subcommand}")
            print_oem_help()
            
    except Exception as e:
        print(f"[!] OEM operation failed: {e}")
        if verbose:
            import traceback
            traceback.print_exc()

# =============================================================================
# OEM SUBCOMMAND IMPLEMENTATIONS WITH MEMORY SCANNING
# =============================================================================

def oem_unlock(dev, args, force=False, verbose=False):
    """Unlock bootloader with memory region scanning"""
    print("[*] Initiating bootloader unlock procedure...")
    
    # Scan for bootloader lock regions
    print("[*] Scanning for bootloader lock regions...")
    lock_regions = scan_bootloader_lock_regions(dev, verbose)
    
    if not lock_regions:
        print("[!] No bootloader lock regions found")
        print("[*] Trying standard unlock procedure...")
    else:
        print(f"[+] Found {len(lock_regions)} lock region(s):")
        for region in lock_regions:
            print(f"    - 0x{region['address']:08X}: {region['description']}")
    
    # Safety warnings
    if not force:
        print("\n[!] ⚠️  BOOTLOADER UNLOCK WARNINGS:")
        print("[!] ⚠️  - Will ERASE ALL USER DATA")
        print("[!] ⚠️  - Voids device WARRANTY")
        print("[!] ⚠️  - Security protections will be REDUCED")
        print("[!] ⚠️  - May make device INELIGIBLE for updates")
        print("[!] ⚠️  - Operation is IRREVERSIBLE on some devices")
        
        response = input("\n    Type 'UNLOCK' to proceed: ")
        if response != 'UNLOCK':
            print("[*] Unlock cancelled")
            return
    
    # Additional confirmation for destructive operation
    print("[!] FINAL CONFIRMATION: All user data will be erased!")
    response = input("    Type 'ERASE' to confirm: ")
    if response != 'ERASE':
        print("[*] Unlock cancelled")
        return
    
    print("[*] Executing bootloader unlock...")
    
    try:
        # Build OEM unlock command
        unlock_payload = struct.pack("<B", 0x10)  # OEM_UNLOCK command
        unlock_payload += struct.pack("<I", 0x01)  # Unlock flag
        
        # Add lock region information if found
        if lock_regions:
            unlock_payload += struct.pack("<B", len(lock_regions))
            for region in lock_regions:
                unlock_payload += struct.pack("<I", region['address'])
                unlock_payload += struct.pack("<I", region['expected_value'])
        else:
            unlock_payload += struct.pack("<B", 0)  # No regions
        
        # Execute via QSLCLPAR
        resp = qslcl_dispatch(dev, "OEM", unlock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Bootloader unlock command accepted")
                
                # Verify unlock by scanning regions again
                print("[*] Verifying unlock status...")
                if verify_unlock_status(dev, lock_regions, verbose):
                    print("[+] ✅ Bootloader successfully unlocked!")
                    print("[+] Device will now reboot and erase user data...")
                else:
                    print("[!] ⚠️  Unlock may not have completed fully")
                    
            else:
                print(f"[!] Unlock failed: {status}")
        else:
            print("[!] No response from unlock command")
            
    except Exception as e:
        print(f"[!] Unlock procedure error: {e}")

def oem_lock(dev, args, force=False, verbose=False):
    """Lock bootloader with memory region verification"""
    print("[*] Initiating bootloader lock procedure...")
    
    # Scan current lock status
    print("[*] Scanning current bootloader status...")
    lock_regions = scan_bootloader_lock_regions(dev, verbose)
    current_status = get_bootloader_lock_status(dev, lock_regions)
    
    print(f"[+] Current bootloader status: {current_status}")
    
    if current_status == "LOCKED":
        print("[!] Bootloader is already locked")
        return
    
    # Safety warnings for locking
    if not force:
        print("\n[!] BOOTLOADER LOCK WARNINGS:")
        print("[!] - Device will verify system integrity on boot")
        print("[!] - Only signed firmware will be allowed")
        print("[!] - Custom recoveries may be blocked")
        print("[!] - May require factory reset on some devices")
        
        response = input("\n    Type 'LOCK' to proceed: ")
        if response != 'LOCK':
            print("[*] Lock cancelled")
            return
    
    print("[*] Executing bootloader lock...")
    
    try:
        # Build OEM lock command
        lock_payload = struct.pack("<B", 0x11)  # OEM_LOCK command
        lock_payload += struct.pack("<I", 0x00)  # Lock flag
        
        # Add verification data
        if lock_regions:
            lock_payload += struct.pack("<B", len(lock_regions))
            for region in lock_regions:
                lock_payload += struct.pack("<I", region['address'])
                lock_payload += struct.pack("<I", region['lock_value'])
        else:
            lock_payload += struct.pack("<B", 0)
        
        # Execute via QSLCLPAR
        resp = qslcl_dispatch(dev, "OEM", lock_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print("[+] Bootloader lock command accepted")
                
                # Verify lock status
                print("[*] Verifying lock status...")
                if verify_lock_status(dev, lock_regions, verbose):
                    print("[+] ✅ Bootloader successfully locked!")
                    print("[+] Security protections are now active")
                else:
                    print("[!] ⚠️  Lock may not have completed fully")
                    
            else:
                print(f"[!] Lock failed: {status}")
        else:
            print("[!] No response from lock command")
            
    except Exception as e:
        print(f"[!] Lock procedure error: {e}")

def oem_warranty(dev, args, force=False, verbose=False):
    """Manage warranty bit status"""
    if args and args[0] in ['set', 'clear']:
        operation = args[0]
        print(f"[*] Managing warranty bit: {operation}")
        
        if not force:
            print("[!] WARRANTY BIT WARNING:")
            print("[!] Modifying warranty bit may void device warranty")
            print("[!] This operation is typically irreversible")
            
            response = input("    Type 'WARRANTY' to proceed: ")
            if response != 'WARRANTY':
                print("[*] Operation cancelled")
                return
        
        # Build warranty command
        warranty_payload = struct.pack("<B", 0x20)  # OEM_WARRANTY command
        if operation == "set":
            warranty_payload += struct.pack("<I", 0x01)  # Set warranty bit
        else:
            warranty_payload += struct.pack("<I", 0x00)  # Clear warranty bit
        
        resp = qslcl_dispatch(dev, "OEM", warranty_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Warranty bit {operation} successful")
            else:
                print(f"[!] Warranty bit operation failed: {status}")
        else:
            print("[!] No response from warranty command")
    else:
        # Query warranty status
        print("[*] Querying warranty bit status...")
        warranty_payload = struct.pack("<B", 0x20)  # OEM_WARRANTY command
        warranty_payload += struct.pack("<I", 0xFF)  # Query flag
        
        resp = qslcl_dispatch(dev, "OEM", warranty_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                warranty_data = status["extra"]
                if len(warranty_data) >= 4:
                    warranty_bit = struct.unpack("<I", warranty_data[:4])[0]
                    status_str = "SET" if warranty_bit else "CLEAR"
                    print(f"[+] Warranty bit status: {status_str} (0x{warranty_bit:08X})")
                else:
                    print("[+] Warranty bit query successful")
            else:
                print(f"[!] Warranty query failed: {status}")

def oem_secureboot(dev, args, force=False, verbose=False):
    """Manage secure boot configuration"""
    if args and args[0] in ['enable', 'disable']:
        operation = args[0]
        print(f"[*] Configuring secure boot: {operation}")
        
        if not force:
            print("[!] SECURE BOOT WARNING:")
            print("[!] Secure boot prevents unsigned code execution")
            print("[!] Disabling may reduce security")
            print("[!] Enabling may block custom firmware")
            
            response = input("    Type 'SECURE' to proceed: ")
            if response != 'SECURE':
                print("[*] Operation cancelled")
                return
        
        # Build secureboot command
        secureboot_payload = struct.pack("<B", 0x30)  # OEM_SECUREBOOT command
        if operation == "enable":
            secureboot_payload += struct.pack("<I", 0x01)
        else:
            secureboot_payload += struct.pack("<I", 0x00)
        
        resp = qslcl_dispatch(dev, "OEM", secureboot_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Secure boot {operation} successful")
            else:
                print(f"[!] Secure boot operation failed: {status}")
        else:
            print("[!] No response from secureboot command")
    else:
        # Query secure boot status
        print("[*] Querying secure boot status...")
        secureboot_payload = struct.pack("<B", 0x30)
        secureboot_payload += struct.pack("<I", 0xFF)  # Query flag
        
        resp = qslcl_dispatch(dev, "OEM", secureboot_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                sb_data = status["extra"]
                if len(sb_data) >= 4:
                    sb_status = struct.unpack("<I", sb_data[:4])[0]
                    status_str = "ENABLED" if sb_status else "DISABLED"
                    print(f"[+] Secure boot status: {status_str}")
                else:
                    print("[+] Secure boot query successful")

def oem_provision(dev, args, force=False, verbose=False):
    """Device provisioning operations"""
    print("[*] Executing OEM provisioning...")
    
    provision_type = "DEFAULT"
    if args:
        provision_type = args[0].upper()
    
    if not force and provision_type in ["FACTORY", "CLEAN"]:
        print("[!] FACTORY PROVISIONING WARNING:")
        print("[!] This will reset device to factory state")
        print("[!] All data and settings will be lost")
        
        response = input("    Type 'PROVISION' to proceed: ")
        if response != 'PROVISION':
            print("[*] Provisioning cancelled")
            return
    
    # Build provisioning command
    provision_payload = struct.pack("<B", 0x40)  # OEM_PROVISION command
    provision_payload += provision_type.encode('ascii').ljust(16, b'\x00')
    
    resp = qslcl_dispatch(dev, "OEM", provision_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] Provisioning completed successfully")
        else:
            print(f"[!] Provisioning failed: {status}")

def oem_customize(dev, args, force=False, verbose=False):
    """Device customization operations"""
    print("[*] Executing OEM customization...")
    
    if not args:
        print("[!] Specify customization parameters")
        return
    
    # Build customization command
    customize_payload = struct.pack("<B", 0x50)  # OEM_CUSTOMIZE command
    
    # Add customization parameters
    for arg in args:
        customize_payload += arg.encode('ascii').ljust(32, b'\x00')
    
    resp = qslcl_dispatch(dev, "OEM", customize_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] Customization completed successfully")
        else:
            print(f"[!] Customization failed: {status}")

def oem_info(dev, args, verbose=False):
    """Query OEM device information"""
    print("[*] Querying OEM device information...")
    
    info_payload = struct.pack("<B", 0x60)  # OEM_INFO command
    
    resp = qslcl_dispatch(dev, "OEM", info_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            info_data = parse_oem_info(status["extra"])
            display_oem_info(info_data)
        else:
            print(f"[!] Info query failed: {status}")

def oem_config(dev, args, force=False, verbose=False):
    """OEM configuration management"""
    if not args:
        print("[!] Specify configuration operation")
        return
    
    operation = args[0].lower()
    
    if operation == "get" and len(args) > 1:
        config_key = args[1]
        print(f"[*] Getting OEM configuration: {config_key}")
        
        config_payload = struct.pack("<B", 0x70)  # OEM_CONFIG command
        config_payload += struct.pack("<B", 0x01)  # GET operation
        config_payload += config_key.encode('ascii').ljust(32, b'\x00')
        
        resp = qslcl_dispatch(dev, "OEM", config_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Configuration {config_key}: {status['extra'].decode('ascii', errors='ignore')}")
    
    elif operation == "set" and len(args) > 2:
        config_key = args[1]
        config_value = args[2]
        print(f"[*] Setting OEM configuration: {config_key} = {config_value}")
        
        if not force:
            response = input("    Confirm configuration change? (y/N): ")
            if response.lower() not in ('y', 'yes'):
                return
        
        config_payload = struct.pack("<B", 0x70)
        config_payload += struct.pack("<B", 0x02)  # SET operation
        config_payload += config_key.encode('ascii').ljust(32, b'\x00')
        config_payload += config_value.encode('ascii').ljust(32, b'\x00')
        
        resp = qslcl_dispatch(dev, "OEM", config_payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status["severity"] == "SUCCESS":
                print(f"[+] Configuration {config_key} set successfully")

def oem_keys(dev, args, force=False, verbose=False):
    """Manage OEM signing keys"""
    print("[*] Managing OEM signing keys...")
    
    operation = "LIST"
    if args:
        operation = args[0].upper()
    
    keys_payload = struct.pack("<B", 0x80)  # OEM_KEYS command
    keys_payload += operation.encode('ascii').ljust(16, b'\x00')
    
    resp = qslcl_dispatch(dev, "OEM", keys_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] Key operation completed successfully")
        else:
            print(f"[!] Key operation failed: {status}")

def oem_debug(dev, args, force=False, verbose=False):
    """OEM debugging operations"""
    print("[*] Executing OEM debugging...")
    
    debug_cmd = "STATUS"
    if args:
        debug_cmd = args[0].upper()
    
    debug_payload = struct.pack("<B", 0x90)  # OEM_DEBUG command
    debug_payload += debug_cmd.encode('ascii').ljust(16, b'\x00')
    
    resp = qslcl_dispatch(dev, "OEM", debug_payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status["severity"] == "SUCCESS":
            print("[+] Debug operation completed")
            if verbose and status["extra"]:
                print(f"    Debug output: {status['extra'].decode('ascii', errors='ignore')}")
        else:
            print(f"[!] Debug operation failed: {status}")

# =============================================================================
# MEMORY REGION SCANNING FUNCTIONS
# =============================================================================

def scan_bootloader_lock_regions(dev, verbose=False):
    """Scan memory for bootloader lock regions"""
    lock_regions = []
    
    # Common bootloader lock region addresses
    common_lock_addresses = [
        0x00021000,  # Qualcomm PBL lock region
        0x0006F000,  # Samsung bootloader lock
        0x00070000,  # Generic bootloader lock
        0x00080000,  # MediaTek preloader lock
        0x00100000,  # Common bootloader area
        0x0F000000,  # EMMC boot partition
        0x10000000,  # UFS boot partition
        0x41E00000,  # Huawei bootloader lock
        0x87E00000,  # Xiaomi bootloader lock
    ]
    
    if verbose:
        print("[*] Scanning known bootloader lock regions...")
    
    for address in common_lock_addresses:
        try:
            # Read potential lock region
            read_payload = struct.pack("<II", address, 16)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    lock_data = status["extra"]
                    
                    # Check for common lock patterns
                    if is_lock_region(lock_data, address):
                        region_info = {
                            'address': address,
                            'data': lock_data.hex(),
                            'expected_value': 0x00000000,  # Unlocked state
                            'lock_value': 0x00000001,     # Locked state
                            'description': identify_lock_region(lock_data, address)
                        }
                        lock_regions.append(region_info)
                        
                        if verbose:
                            print(f"    Found lock region at 0x{address:08X}: {region_info['description']}")
            
        except Exception as e:
            if verbose:
                print(f"    Scan failed at 0x{address:08X}: {e}")
    
    return lock_regions

def is_lock_region(data, address):
    """Determine if memory region contains lock data"""
    if len(data) < 4:
        return False
    
    # Check for common lock patterns
    patterns = [
        b'\x00\x00\x00\x00',  # Unlocked
        b'\x01\x00\x00\x00',  # Locked
        b'LOCK',              # Text pattern
        b'UNLK',              # Text pattern
        b'\xEE\xEE\xEE\xEE',  # Erased pattern
        b'\xFF\xFF\xFF\xFF',  # Default pattern
    ]
    
    for pattern in patterns:
        if data[:len(pattern)] == pattern:
            return True
    
    # Check for non-zero, non-0xFF values (likely lock data)
    if data != b'\x00' * len(data) and data != b'\xFF' * len(data):
        return True
    
    return False

def identify_lock_region(data, address):
    """Identify the type of lock region"""
    if len(data) >= 4:
        value = struct.unpack("<I", data[:4])[0]
        
        if value == 0x00000000:
            return "Bootloader Unlocked"
        elif value == 0x00000001:
            return "Bootloader Locked"
        elif value == 0xEEEEEEEE:
            return "Erased Lock Region"
        elif data[:4] == b'LOCK':
            return "Lock Flag (Text)"
        elif data[:4] == b'UNLK':
            return "Unlock Flag (Text)"
    
    # Generic identification based on address
    if address == 0x00021000:
        return "Qualcomm PBL Lock"
    elif address == 0x0006F000:
        return "Samsung Bootloader Lock"
    elif address == 0x00080000:
        return "MediaTek Preloader Lock"
    elif 0x0F000000 <= address < 0x10000000:
        return "EMMC Boot Partition Lock"
    else:
        return "Unknown Lock Region"

def get_bootloader_lock_status(dev, lock_regions):
    """Get current bootloader lock status"""
    if not lock_regions:
        return "UNKNOWN"
    
    locked_count = 0
    unlocked_count = 0
    
    for region in lock_regions:
        try:
            read_payload = struct.pack("<II", region['address'], 4)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    current_value = struct.unpack("<I", status["extra"][:4])[0]
                    if current_value == region['lock_value']:
                        locked_count += 1
                    elif current_value == region['expected_value']:
                        unlocked_count += 1
        except:
            pass
    
    if locked_count > unlocked_count:
        return "LOCKED"
    elif unlocked_count > locked_count:
        return "UNLOCKED"
    else:
        return "MIXED"

def verify_unlock_status(dev, lock_regions, verbose=False):
    """Verify that bootloader is actually unlocked"""
    if not lock_regions:
        return True  # Can't verify, assume success
    
    print("[*] Verifying unlock status by scanning lock regions...")
    
    unlocked_regions = 0
    for region in lock_regions:
        try:
            read_payload = struct.pack("<II", region['address'], 4)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    current_value = struct.unpack("<I", status["extra"][:4])[0]
                    if current_value == region['expected_value']:  # Unlocked state
                        unlocked_regions += 1
                        if verbose:
                            print(f"    ✅ Region 0x{region['address']:08X} is unlocked")
                    else:
                        if verbose:
                            print(f"    ❌ Region 0x{region['address']:08X} is still locked")
        except Exception as e:
            if verbose:
                print(f"    ⚠️  Verification failed for 0x{region['address']:08X}: {e}")
    
    success_ratio = unlocked_regions / len(lock_regions) if lock_regions else 1.0
    return success_ratio >= 0.5  # At least half of regions should be unlocked

def verify_lock_status(dev, lock_regions, verbose=False):
    """Verify that bootloader is actually locked"""
    if not lock_regions:
        return True  # Can't verify, assume success
    
    print("[*] Verifying lock status by scanning lock regions...")
    
    locked_regions = 0
    for region in lock_regions:
        try:
            read_payload = struct.pack("<II", region['address'], 4)
            resp = qslcl_dispatch(dev, "READ", read_payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status["severity"] == "SUCCESS" and status["extra"]:
                    current_value = struct.unpack("<I", status["extra"][:4])[0]
                    if current_value == region['lock_value']:  # Locked state
                        locked_regions += 1
                        if verbose:
                            print(f"    ✅ Region 0x{region['address']:08X} is locked")
                    else:
                        if verbose:
                            print(f"    ❌ Region 0x{region['address']:08X} is still unlocked")
        except Exception as e:
            if verbose:
                print(f"    ⚠️  Verification failed for 0x{region['address']:08X}: {e}")
    
    success_ratio = locked_regions / len(lock_regions) if lock_regions else 1.0
    return success_ratio >= 0.5  # At least half of regions should be locked

def parse_oem_info(info_data):
    """Parse OEM information data"""
    info = {
        'device_model': 'Unknown',
        'hardware_revision': 'Unknown',
        'bootloader_version': 'Unknown',
        'baseband_version': 'Unknown',
        'serial_number': 'Unknown',
        'oem_features': []
    }
    
    try:
        if len(info_data) >= 256:
            # Parse structured OEM info
            info['device_model'] = info_data[0:32].decode('ascii', errors='ignore').rstrip('\x00')
            info['hardware_revision'] = info_data[32:48].decode('ascii', errors='ignore').rstrip('\x00')
            info['bootloader_version'] = info_data[48:80].decode('ascii', errors='ignore').rstrip('\x00')
            info['baseband_version'] = info_data[80:112].decode('ascii', errors='ignore').rstrip('\x00')
            info['serial_number'] = info_data[112:144].decode('ascii', errors='ignore').rstrip('\x00')
            
            # Parse features bitmap
            if len(info_data) >= 148:
                features_bitmap = struct.unpack("<I", info_data[144:148])[0]
                if features_bitmap & 0x01:
                    info['oem_features'].append('BOOTLOADER_UNLOCK')
                if features_bitmap & 0x02:
                    info['oem_features'].append('SECURE_BOOT')
                if features_bitmap & 0x04:
                    info['oem_features'].append('OEM_CUSTOMIZATION')
                if features_bitmap & 0x08:
                    info['oem_features'].append('DEBUG_ACCESS')
    except:
        pass
    
    return info

def display_oem_info(info):
    """Display OEM information"""
    print(f"\n[+] OEM Device Information:")
    print(f"    Model: {info['device_model']}")
    print(f"    Hardware: {info['hardware_revision']}")
    print(f"    Bootloader: {info['bootloader_version']}")
    print(f"    Baseband: {info['baseband_version']}")
    print(f"    Serial: {info['serial_number']}")
    
    if info['oem_features']:
        print(f"    Features: {', '.join(info['oem_features'])}")

def print_oem_help():
    """Display OEM command help"""
    print("""
OEM Command Usage:
  oem unlock                    - Unlock bootloader (ERASES DATA!)
  oem lock                      - Lock bootloader
  oem warranty [set|clear]      - Manage warranty bit
  oem secureboot [enable|disable] - Configure secure boot
  oem provision [type]          - Device provisioning
  oem customize <params>        - Device customization
  oem info                      - Show OEM device information
  oem config get <key>          - Get OEM configuration
  oem config set <key> <value>  - Set OEM configuration
  oem keys [operation]          - Manage signing keys
  oem debug [command]           - OEM debugging operations

Bootloader Operations:
  - unlock: Scans memory for lock regions and unlocks bootloader
  - lock: Verifies and locks bootloader with security checks
  - Both operations include memory region scanning and verification

Safety Warnings:
  ⚠️  Bootloader unlock ERASES ALL USER DATA
  ⚠️  Warranty bit changes may VOID WARRANTY  
  ⚠️  Secure boot changes affect SYSTEM SECURITY
  ⚠️  Provisioning may FACTORY RESET device

Memory Region Scanning:
  - Automatically scans for bootloader lock regions
  - Verifies unlock/lock status by reading memory
  - Supports multiple device architectures
  - Provides visual verification status

Examples:
  qslcl oem unlock                    # Unlock bootloader
  qslcl oem lock                      # Lock bootloader  
  qslcl oem warranty                  # Check warranty bit
  qslcl oem secureboot enable         # Enable secure boot
  qslcl oem info                      # Show device info
  qslcl oem debug STATUS              # Debug status check
    """)

# =============================================================================
# OEM-SPECIFIC ARGUMENT EXTENSIONS
# =============================================================================

def add_oem_arguments(parser):
    """Add OEM-specific arguments to argument parser"""
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Verbose output with memory scanning details")
    return parser