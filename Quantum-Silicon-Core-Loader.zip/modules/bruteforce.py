def cmd_bruteforce(args):
    """
    Advanced BRUTEFORCE command handler for comprehensive system exploration
    Supports multiple brute-force strategies, patterns, and intelligent scanning
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse BRUTEFORCE subcommand or use legacy pattern mode
    if hasattr(args, 'bruteforce_subcommand') and args.bruteforce_subcommand:
        return handle_advanced_bruteforce(dev, args)
    else:
        return handle_legacy_bruteforce(dev, args)

def handle_advanced_bruteforce(dev, args):
    """
    Handle advanced brute-force operations with multiple strategies
    """
    subcmd = args.bruteforce_subcommand.upper()
    
    if subcmd == "LIST":
        return list_bruteforce_strategies(dev)
    elif subcmd == "SCAN":
        return scan_system_vectors(dev, args)
    elif subcmd == "PATTERN":
        return pattern_bruteforce(dev, args)
    elif subcmd == "FUZZ":
        return fuzz_bruteforce(dev, args)
    elif subcmd == "DICTIONARY":
        return dictionary_bruteforce(dev, args)
    elif subcmd == "REPLAY":
        return replay_bruteforce(dev, args)
    elif subcmd == "ANALYZE":
        return analyze_bruteforce_results(dev, args)
    elif subcmd == "CONTINUE":
        return continue_bruteforce_session(dev, args)
    else:
        return handle_bruteforce_operation(dev, subcmd, args)

def list_bruteforce_strategies(dev):
    """
    List all available brute-force strategies and commands
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE BRUTEFORCE STRATEGIES")
    print("="*60)
    
    # Check for bruteforce-related commands in all modules
    bf_commands = []
    
    # QSLCLPAR commands
    print("\n[QSLCLPAR] Bruteforce Commands:")
    par_bf = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "BRUTEFORCE", "SCAN", "FUZZ", "PATTERN", "EXPLORE", "PROBE"
    ])]
    for cmd in par_bf:
        print(f"  • {cmd}")
        bf_commands.append(cmd)
    
    # QSLCLEND opcodes
    print("\n[QSLCLEND] Bruteforce Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        if any(x in entry_name.upper() for x in ["BRUTE", "SCAN", "FUZZ", "PROBE"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name}")
            bf_commands.append(f"ENGINE_0x{opcode:02X}")
    
    print("\n[*] Available Strategies:")
    print("  • PATTERN    - Numeric/hex pattern scanning")
    print("  • FUZZ       - Intelligent fuzzing with mutation")
    print("  • DICTIONARY - Dictionary-based attacks")
    print("  • REPLAY     - Response replay attacks")
    print("  • SCAN       - System vector scanning")
    print("  • ANALYZE    - Result analysis and correlation")
    
    print("\n[*] Common Target Areas:")
    print("  • Memory addresses and offsets")
    print("  • Command opcodes and parameters")
    print("  • Security tokens and keys")
    print("  • Configuration values")
    print("  • Protocol fields and flags")
    
    print("="*60)
    return True

def handle_legacy_bruteforce(dev, args):
    """
    Handle legacy pattern-based brute-force (original functionality)
    """
    # Optional: enable RAWMODE
    if args.rawmode:
        print("[*] Enabling RAWMODE (0xFF)…")
        qslcl_dispatch(dev, "RAWMODE", b"\xFF")
        time.sleep(0.3)

    # Parse range
    pattern = args.pattern.lower()
    
    try:
        if "-" in pattern:
            a, b = pattern.split("-")
            start = int(a, 0)
            end   = int(b, 0)
        else:
            start = end = int(pattern, 0)
    except:
        return print("[!] Invalid pattern, use: 0x00-0xFFFF")

    print(f"[*] Bruteforce range: {hex(start)} → {hex(end)}")
    print(f"[*] Total values: {end - start + 1:,}")

    # Advanced pattern analysis
    analyze_pattern_complexity(start, end)
    
    # Work queue
    q = Queue()
    for val in range(start, end + 1):
        q.put(val)

    hits = []
    errors = 0
    done = 0
    total = end - start + 1
    lock = threading.Lock()
    start_time = time.time()

    # Progress tracking
    progress_stats = {
        'start_time': start_time,
        'last_update': start_time,
        'last_count': 0,
        'rates': []
    }

    def worker(worker_id):
        nonlocal done, errors
        worker_hits = []
        worker_errors = 0
        
        while True:
            try:
                val = q.get_nowait()
            except:
                # Worker finished, report results
                with lock:
                    hits.extend(worker_hits)
                    errors += worker_errors
                return

            # Build payload based on value size
            if val <= 0xFFFF:
                payload = struct.pack("<H", val)  # 16-bit
            elif val <= 0xFFFFFFFF:
                payload = struct.pack("<I", val)  # 32-bit
            else:
                payload = struct.pack("<Q", val)  # 64-bit

            # Try multiple brute-force strategies
            response_data = try_bruteforce_strategies(dev, val, payload, worker_id)
            
            with lock:
                done += 1
                current_time = time.time()
                
                # Update progress with rate calculation
                if current_time - progress_stats['last_update'] >= 1.0:  # Update every second
                    elapsed = current_time - progress_stats['last_update']
                    count_diff = done - progress_stats['last_count']
                    rate = count_diff / elapsed if elapsed > 0 else 0
                    progress_stats['rates'].append(rate)
                    progress_stats['last_update'] = current_time
                    progress_stats['last_count'] = done
                    
                    avg_rate = sum(progress_stats['rates'][-10:]) / min(len(progress_stats['rates']), 10)  # 10-second average
                    eta = (total - done) / avg_rate if avg_rate > 0 else 0
                    
                    pct = (done * 100.0) / total
                    print(f"\r[*] Progress: {done}/{total} ({pct:5.1f}%) | Rate: {avg_rate:5.1f}/s | ETA: {format_time(eta)} | Hits: {len(hits)} | Errors: {errors}", end="")
                
                # Process response
                if response_data:
                    resp, origin, strategy = response_data
                    status = decode_runtime_result(resp)
                    
                    sev = status.get("severity", "")
                    name = status.get("name", "")
                    extra = status.get("extra", b"")

                    # Enhanced hit detection
                    hit_confidence = calculate_hit_confidence(sev, name, extra, val)
                    
                    if hit_confidence > 0:
                        with lock:
                            prefix = "[+]" if hit_confidence >= 0.8 else "[~]" if hit_confidence >= 0.5 else "[?]"
                            print(f"\n{prefix} HIT: 0x{val:08X} (conf: {hit_confidence:.2f}) via {strategy} → {name}")
                            
                            hit_info = {
                                'value': val,
                                'status': status,
                                'origin': origin,
                                'strategy': strategy,
                                'confidence': hit_confidence,
                                'timestamp': time.time(),
                                'extra_data': extra
                            }
                            hits.append(hit_info)
                            worker_hits.append(hit_info)
                else:
                    worker_errors += 1

            q.task_done()

    # Run threads
    threads = args.threads
    print(f"[*] Launching {threads} threads…")
    print(f"[*] Using {threads} concurrent workers")

    ths = []
    for i in range(threads):
        t = threading.Thread(target=worker, daemon=True, args=(i,))
        t.start()
        ths.append(t)

    # Monitor thread for user interrupts and statistics
    def monitor_thread():
        while any(t.is_alive() for t in ths):
            time.sleep(2)
            # Could add real-time statistics display here

    monitor = threading.Thread(target=monitor_thread, daemon=True)
    monitor.start()

    # Wait for completion
    try:
        q.join()
    except KeyboardInterrupt:
        print(f"\n[!] Bruteforce interrupted by user after {done} attempts")
        print("[*] Finalizing...")
    
    total_time = time.time() - start_time
    print(f"\n[✓] Bruteforce complete. Time: {format_time(total_time)}")

    # Analysis and reporting
    return analyze_and_report_bruteforce(hits, errors, total, total_time, args)

def try_bruteforce_strategies(dev, value, payload, worker_id):
    """
    Try multiple brute-force strategies for a given value
    """
    strategies = [
        try_direct_bruteforce,
        try_idx_bruteforce,
        try_engine_bruteforce,
        try_vm5_bruteforce,
        try_pattern_bruteforce
    ]
    
    for strategy in strategies:
        result = strategy(dev, value, payload, worker_id)
        if result:
            resp, origin = result
            if resp:
                return resp, origin, strategy.__name__
    
    return None

def try_direct_bruteforce(dev, value, payload, worker_id):
    """Direct BRUTEFORCE command"""
    return qslclidx_or_dispatch(dev, "BRUTEFORCE", payload)

def try_idx_bruteforce(dev, value, payload, worker_id):
    """IDX-based brute-force (common index: 0x30)"""
    # Try common bruteforce indices
    bf_indices = [0x30, 0x31, 0x32, 0x40, 0x41]
    
    for idx in bf_indices:
        if idx in QSLCLIDX_DB:
            entry = QSLCLIDX_DB[idx]
            if isinstance(entry, dict):
                pkt = b"QSLCLIDX" + struct.pack("<I", idx) + payload
                resp = qslcl_dispatch(dev, "IDX", pkt)
                if resp:
                    return resp, f"IDX_0x{idx:02X}"
    return None

def try_engine_bruteforce(dev, value, payload, worker_id):
    """ENGINE opcode brute-force"""
    # Common bruteforce opcodes
    bf_opcodes = [0xB0, 0xB1, 0xB2, 0xC0, 0xC1]
    
    for opcode in bf_opcodes:
        if opcode in QSLCLEND_DB:
            entry = QSLCLEND_DB[opcode]
            entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
            pkt = b"QSLCLEND" + entry_data + payload
            resp = qslcl_dispatch(dev, "ENGINE", pkt)
            if resp:
                return resp, f"ENGINE_0x{opcode:02X}"
    return None

def try_vm5_bruteforce(dev, value, payload, worker_id):
    """VM5 microservice brute-force"""
    vm5_services = ["BRUTEFORCE", "SCAN", "PROBE", "EXPLORE"]
    
    for service in vm5_services:
        if service in QSLCLVM5_DB:
            raw = QSLCLVM5_DB[service]["raw"]
            pkt = b"QSLCLVM5" + raw + payload
            resp = qslcl_dispatch(dev, "NANO", pkt)
            if resp:
                return resp, f"VM5_{service}"
    return None

def try_pattern_bruteforce(dev, value, payload, worker_id):
    """Pattern-based brute-force with value transformation"""
    # Try different value representations
    patterns = [
        payload,  # Original
        struct.pack(">I", value),  # Big-endian
        payload + b"\x00" * 4,  # Padded
        struct.pack("<I", value ^ 0xFFFFFFFF),  # Inverted
    ]
    
    for pattern in patterns:
        resp = qslcl_dispatch(dev, "BRUTEFORCE", pattern)
        if resp:
            return resp, "PATTERN"
    return None

def calculate_hit_confidence(severity, name, extra_data, value):
    """
    Calculate confidence score for a brute-force hit
    """
    confidence = 0.0
    
    # Severity-based scoring
    if severity == "SUCCESS":
        confidence += 0.7
    elif severity == "WARNING":
        confidence += 0.4
    elif severity == "ERROR":
        confidence += 0.1
    
    # Name-based scoring
    positive_indicators = ["OK", "SUCCESS", "FOUND", "MATCH", "VALID", "UNLOCKED"]
    negative_indicators = ["FAIL", "ERROR", "INVALID", "REJECTED", "DENIED"]
    
    name_upper = name.upper()
    for indicator in positive_indicators:
        if indicator in name_upper:
            confidence += 0.2
    for indicator in negative_indicators:
        if indicator in name_upper:
            confidence -= 0.1
    
    # Extra data analysis
    if extra_data:
        # Non-zero/non-empty response data
        if extra_data != b"\x00" * len(extra_data):
            confidence += 0.1
        
        # Structured data might indicate success
        if len(extra_data) >= 4:
            first_word = struct.unpack("<I", extra_data[:4])[0]
            if first_word != 0 and first_word != 0xFFFFFFFF:
                confidence += 0.1
    
    # Value pattern analysis (common magic values)
    magic_values = {
        0x00000000: -0.1,  # Often means null/no result
        0xFFFFFFFF: -0.1,  # Often means error
        0xDEADBEEF: 0.3,   # Debug marker
        0xC0DEC0DE: 0.3,   # Code marker
        0x12345678: 0.2,   # Test pattern
        0xAAAAAAAA: 0.1,   # Pattern
        0x55555555: 0.1,   # Pattern
    }
    
    if value in magic_values:
        confidence += magic_values[value]
    
    return max(0.0, min(1.0, confidence))

def analyze_pattern_complexity(start, end):
    """
    Analyze the complexity and characteristics of the brute-force pattern
    """
    total_values = end - start + 1
    print(f"[*] Pattern Analysis:")
    print(f"    Range size: {total_values:,} values")
    print(f"    Memory required: {(total_values * 4) / 1024 / 1024:.2f} MB (est.)")
    
    # Estimate time based on typical rates
    estimated_time = total_values / 1000  # Conservative 1000 attempts/sec
    if estimated_time > 60:
        print(f"    Estimated time: {estimated_time/60:.1f} minutes")
    else:
        print(f"    Estimated time: {estimated_time:.1f} seconds")
    
    # Check for common patterns
    if start == 0x0000 and end == 0xFFFF:
        print("    Pattern: Full 16-bit range")
    elif start == 0x00000000 and end == 0xFFFFFFFF:
        print("    Pattern: Full 32-bit range (VERY LARGE)")
        print("    [!] This range contains 4,294,967,296 values")
        print("    [!] Consider using a smaller range or --strategy smart")
    
    # Check for alignment
    if (start % 4 == 0) and (end % 4 == 3):
        print("    Alignment: 32-bit aligned")
    elif (start % 2 == 0) and (end % 2 == 1):
        print("    Alignment: 16-bit aligned")

def format_time(seconds):
    """Format time in human-readable format"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds/60:.1f}m"
    else:
        return f"{seconds/3600:.1f}h"

def analyze_and_report_bruteforce(hits, errors, total, total_time, args):
    """
    Analyze brute-force results and generate comprehensive report
    """
    print(f"\n{'='*60}")
    print("[*] BRUTEFORCE ANALYSIS REPORT")
    print('='*60)
    
    # Basic statistics
    success_rate = (len(hits) / total * 100) if total > 0 else 0
    error_rate = (errors / total * 100) if total > 0 else 0
    avg_speed = total / total_time if total_time > 0 else 0
    
    print(f"Total attempts: {total:,}")
    print(f"Total hits: {len(hits)} ({success_rate:.2f}%)")
    print(f"Total errors: {errors} ({error_rate:.2f}%)")
    print(f"Average speed: {avg_speed:.1f} attempts/second")
    print(f"Total time: {format_time(total_time)}")
    
    # Hit analysis
    if hits:
        print(f"\n[*] HIT ANALYSIS:")
        
        # Group by confidence
        high_confidence = [h for h in hits if h['confidence'] >= 0.7]
        medium_confidence = [h for h in hits if 0.4 <= h['confidence'] < 0.7]
        low_confidence = [h for h in hits if h['confidence'] < 0.4]
        
        print(f"    High confidence: {len(high_confidence)} hits")
        print(f"    Medium confidence: {len(medium_confidence)} hits")
        print(f"    Low confidence: {len(low_confidence)} hits")
        
        # Strategy effectiveness
        strategies = {}
        for hit in hits:
            strategy = hit['strategy']
            strategies[strategy] = strategies.get(strategy, 0) + 1
        
        print(f"\n[*] STRATEGY EFFECTIVENESS:")
        for strategy, count in sorted(strategies.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / len(hits)) * 100
            print(f"    {strategy}: {count} hits ({percentage:.1f}%)")
        
        # Value patterns in hits
        print(f"\n[*] VALUE PATTERNS:")
        hex_hits = [f"0x{hit['value']:08X}" for hit in high_confidence[:10]]  # Top 10 high-confidence hits
        if hex_hits:
            print(f"    High-confidence values: {', '.join(hex_hits)}")
    
    # Save detailed report
    return save_bruteforce_report(hits, errors, total, total_time, args)

def save_bruteforce_report(hits, errors, total, total_time, args):
    """
    Save comprehensive brute-force report
    """
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    base_filename = args.output if args.output else f"bruteforce_report_{timestamp}"
    
    # Save hits to text file
    txt_filename = f"{base_filename}.txt"
    with open(txt_filename, "w") as f:
        f.write(f"Bruteforce Report - {timestamp}\n")
        f.write("=" * 50 + "\n")
        f.write(f"Range: {args.pattern}\n")
        f.write(f"Total attempts: {total}\n")
        f.write(f"Total hits: {len(hits)}\n")
        f.write(f"Total errors: {errors}\n")
        f.write(f"Total time: {format_time(total_time)}\n\n")
        
        f.write("HITS:\n")
        f.write("-" * 50 + "\n")
        for hit in sorted(hits, key=lambda x: x['confidence'], reverse=True):
            f.write(f"0x{hit['value']:08X} | Conf: {hit['confidence']:.2f} | {hit['strategy']} | {hit['status']['name']}\n")
            if hit['extra_data']:
                f.write(f"      Extra: {hit['extra_data'].hex()}\n")
    
    # Save structured data (JSON)
    json_filename = f"{base_filename}.json"
    try:
        import json
        report_data = {
            'timestamp': timestamp,
            'parameters': {
                'pattern': args.pattern,
                'threads': args.threads,
                'rawmode': getattr(args, 'rawmode', False)
            },
            'statistics': {
                'total_attempts': total,
                'total_hits': len(hits),
                'total_errors': errors,
                'total_time': total_time,
                'success_rate': (len(hits) / total * 100) if total > 0 else 0
            },
            'hits': [
                {
                    'value': hit['value'],
                    'value_hex': f"0x{hit['value']:08X}",
                    'confidence': hit['confidence'],
                    'strategy': hit['strategy'],
                    'status': hit['status'],
                    'timestamp': hit['timestamp'],
                    'extra_data_hex': hit['extra_data'].hex() if hit['extra_data'] else ""
                }
                for hit in hits
            ]
        }
        
        with open(json_filename, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        print(f"[+] Detailed report saved to: {txt_filename}")
        print(f"[+] Structured data saved to: {json_filename}")
        
    except Exception as e:
        print(f"[!] Could not save JSON report: {e}")
        print(f"[+] Basic report saved to: {txt_filename}")
    
    return len(hits) > 0

def scan_system_vectors(dev, args):
    """
    Scan common system vectors and entry points
    """
    print("[*] Scanning common system vectors...")
    
    scan_results = {}
    
    # Common vector ranges to scan
    vector_ranges = [
        (0x00000000, 0x0000FFFF, "Interrupt Vectors"),
        (0x80000000, 0x8000FFFF, "Kernel Entry Points"),
        (0x40000000, 0x4000FFFF, "MMIO Regions"),
        (0x10000000, 0x1000FFFF, "Bootloader Entry Points"),
        (0xC0000000, 0xC000FFFF, "TrustZone Entry Points")
    ]
    
    for start, end, description in vector_ranges:
        print(f"\n[*] Scanning {description} (0x{start:08X}-0x{end:08X})...")
        
        # Sample scanning (for demonstration - would need full implementation)
        sample_points = [start, start + 0x1000, start + 0x8000, end]
        hits_in_range = 0
        
        for point in sample_points:
            payload = struct.pack("<I", point)
            resp = qslcl_dispatch(dev, "BRUTEFORCE", payload)
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") in ["SUCCESS", "WARNING"]:
                    hits_in_range += 1
        
        scan_results[description] = hits_in_range
        print(f"    Found {hits_in_range} potential vectors")
    
    return True

def pattern_bruteforce(dev, args):
    """
    Advanced pattern-based brute-force with intelligent patterns
    """
    if not hasattr(args, 'bruteforce_args') or not args.bruteforce_args:
        return print("[!] PATTERN requires pattern type (magic, sequence, aligned, etc.)")
    
    pattern_type = args.bruteforce_args[0].upper()
    
    print(f"[*] Starting {pattern_type} pattern brute-force...")
    
    # Generate patterns based on type
    if pattern_type == "MAGIC":
        values = generate_magic_values()
    elif pattern_type == "SEQUENCE":
        values = generate_sequence_patterns()
    elif pattern_type == "ALIGNED":
        values = generate_aligned_patterns()
    elif pattern_type == "COMMON":
        values = generate_common_values()
    else:
        return print(f"[!] Unknown pattern type: {pattern_type}")
    
    print(f"[*] Generated {len(values)} pattern values")
    
    # Execute brute-force with generated patterns
    # (Implementation would be similar to handle_legacy_bruteforce but with custom values)
    
    return True

def generate_magic_values():
    """Generate common magic values for brute-force"""
    magic_values = [
        # Common magic values
        0x00000000, 0xFFFFFFFF, 0xDEADBEEF, 0xC0DEC0DE, 0xCAFEBABE,
        0xBAADF00D, 0x8BADF00D, 0xABADBABE, 0xABADCAFE, 0xB16B00B5,
        0x0D15EA5E, 0x1BADB002, 0xDEADDEAD, 0xFACEB00C, 0xFACEFEED,
        # Power of two values
        0x00000001, 0x00000002, 0x00000004, 0x00000008, 0x00000010,
        0x00000020, 0x00000040, 0x00000080, 0x00000100, 0x00000200,
        # Common offsets
        0x00001000, 0x00002000, 0x00004000, 0x00008000, 0x00010000,
        # ASCII patterns
        0x41414141, 0x42424242, 0x43434343, 0x44444444, 0x45454545,
        0x12345678, 0x87654321, 0x11223344, 0x44332211, 0xAABBCCDD
    ]
    
    return magic_values

def fuzz_bruteforce(dev, args):
    """Intelligent fuzzing with mutation"""
    print("[*] Intelligent fuzzing not yet implemented")
    return False

def dictionary_bruteforce(dev, args):
    """Dictionary-based brute-force"""
    print("[*] Dictionary attack not yet implemented")
    return False

def replay_bruteforce(dev, args):
    """Response replay attacks"""
    print("[*] Replay attacks not yet implemented")
    return False

def analyze_bruteforce_results(dev, args):
    """Analyze previous brute-force results"""
    print("[*] Result analysis not yet implemented")
    return False

def continue_bruteforce_session(dev, args):
    """Continue previous brute-force session"""
    print("[*] Session continuation not yet implemented")
    return False

def handle_bruteforce_operation(dev, operation, args):
    """Handle other brute-force operations"""
    print(f"[*] Advanced brute-force operation '{operation}' not yet implemented")
    return False

# Update the argument parser in main() function
def update_bruteforce_parser(sub):
    """
    Update the BRUTEFORCE command parser with new subcommands
    """
    bruteforce_parser = sub.add_parser("bruteforce", help="Advanced brute-force and system exploration")
    bruteforce_parser.add_argument("bruteforce_subcommand", nargs="?", help="Bruteforce subcommand (list, scan, pattern, fuzz, dictionary, replay, analyze, continue)")
    bruteforce_parser.add_argument("pattern", nargs="?", help="Legacy pattern (e.g., 0x00-0xFFFF)")
    bruteforce_parser.add_argument("--threads", type=int, default=8, help="Number of threads")
    bruteforce_parser.add_argument("--rawmode", action="store_true", help="Enable raw mode")
    bruteforce_parser.add_argument("--output", help="Output filename")
    bruteforce_parser.add_argument("--strategy", choices=["basic", "smart", "aggressive"], default="basic", help="Bruteforce strategy")
    bruteforce_parser.add_argument("bruteforce_args", nargs="*", help="Additional arguments")
    bruteforce_parser.set_defaults(func=cmd_bruteforce)