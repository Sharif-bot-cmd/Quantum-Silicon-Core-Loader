def cmd_rawmode(args):
    """
    Advanced RAWMODE command handler for low-level device access and privilege escalation
    Supports multiple raw modes with detailed configuration and monitoring
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse RAWMODE subcommand
    if not hasattr(args, 'rawmode_subcommand') or not args.rawmode_subcommand:
        return print("[!] RAWMODE command requires subcommand (list, set, status, unlock, lock, etc.)")
    
    subcmd = args.rawmode_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_rawmodes(dev)
    elif subcmd == "SET":
        return set_rawmode(dev, args)
    elif subcmd == "STATUS":
        return get_rawmode_status(dev)
    elif subcmd == "UNLOCK":
        return unlock_rawmode(dev, args)
    elif subcmd == "LOCK":
        return lock_rawmode(dev, args)
    elif subcmd == "CONFIGURE":
        return configure_rawmode(dev, args)
    elif subcmd == "ESCALATE":
        return escalate_privileges(dev, args)
    elif subcmd == "MONITOR":
        return monitor_rawmode_activity(dev, args)
    elif subcmd == "AUDIT":
        return audit_rawmode_access(dev, args)
    elif subcmd == "RESET":
        return reset_rawmode(dev, args)
    else:
        return handle_rawmode_operation(dev, subcmd, args)

def list_available_rawmodes(dev):
    """
    List all available RAWMODE commands and supported modes
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL RAWMODE COMMANDS AND MODES")
    print("="*60)
    
    rawmode_found = []
    
    # Check QSLCLPAR for RAWMODE commands
    print("\n[QSLCLPAR] RawMode Commands:")
    par_rawmodes = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in [
        "RAWMODE", "RAW_ACCESS", "PRIVILEGE", "UNLOCK", "ESCALATE", 
        "SUPERVISOR", "KERNEL", "SECURE", "DEBUG"
    ])]
    for rawmode_cmd in par_rawmodes:
        print(f"  • {rawmode_cmd}")
        rawmode_found.append(rawmode_cmd)
    
    # Check QSLCLEND for rawmode-related opcodes
    print("\n[QSLCLEND] RawMode Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["RAWMODE", "RAW", "PRIVILEGE", "UNLOCK"]) or any(x in entry_str for x in ["RAW", "PRIV"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            rawmode_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for rawmode microservices
    print("\n[QSLCLVM5] RawMode Microservices:")
    vm5_rawmodes = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["RAWMODE", "RAW_ACCESS"])]
    for rawmode_cmd in vm5_rawmodes:
        print(f"  • {rawmode_cmd}")
        rawmode_found.append(f"VM5_{rawmode_cmd}")
    
    # Check QSLCLIDX for rawmode indices
    print("\n[QSLCLIDX] RawMode Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["RAWMODE", "RAW_ACCESS"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                rawmode_found.append(f"IDX_{name}")
    
    if not rawmode_found:
        print("  No rawmode commands found in loader")
    else:
        print(f"\n[*] Total rawmode commands found: {len(rawmode_found)}")
    
    print("\n[*] Supported Raw Modes:")
    print("  • UNRESTRICTED (0xFF) - Full system access, no restrictions")
    print("  • HYPERVISOR   (0xE0) - Virtualization-level access")
    print("  • KERNEL       (0xC0) - Kernel-level privilege escalation") 
    print("  • SUPERVISOR   (0xA0) - Supervisor mode access")
    print("  • META         (0xA1) - Meta/engineering mode")
    print("  • DIAGNOSTIC   (0x10) - Diagnostic and debug access")
    print("  • DEVELOPER    (0x42) - Developer/debugging mode")
    print("  • SECURE       (0x5A) - Secure mode with auditing")
    print("  • SAFE         (0x01) - Safe mode with restrictions")
    print("  • LOCKED       (0x00) - Fully locked, no raw access")
    
    print("\n[*] Raw Mode Features:")
    print("  • Memory mapping bypass")
    print("  • Register direct access") 
    print("  • Hardware interrupt control")
    print("  • DMA engine access")
    print("  • Secure monitor calls")
    print("  • TrustZone boundary crossing")
    print("  • MMU configuration access")
    print("  • Cache control operations")
    
    print("="*60)
    
    return True

def set_rawmode(dev, args):
    """
    Set device to specific raw mode with configuration options
    """
    if not hasattr(args, 'rawmode_args') or not args.rawmode_args:
        return print("[!] RAWMODE SET requires mode specification")
    
    mode_arg = args.rawmode_args[0].lower()
    
    # Extended mode mapping with detailed descriptions
    mode_map = {
        # Unrestricted access modes
        "unrestricted":  (0xFF, "Full system access without restrictions"),
        "full":          (0xFF, "Full system access without restrictions"),
        "hypervisor":    (0xE0, "Virtualization-level hypervisor access"),
        "hyper":         (0xE0, "Virtualization-level hypervisor access"),
        
        # Kernel and system modes
        "kernel":        (0xC0, "Kernel-level privilege escalation"),
        "supervisor":    (0xA0, "Supervisor mode system access"),
        "system":        (0xA0, "System-level privileged access"),
        
        # Engineering and diagnostic modes
        "meta":          (0xA1, "Meta/engineering mode access"),
        "engineering":   (0xA1, "Engineering-level access"),
        "diagnostic":    (0x10, "Diagnostic and debugging access"),
        "debug":         (0x10, "Debugging and troubleshooting access"),
        
        # Development modes
        "developer":     (0x42, "Developer mode with enhanced access"),
        "development":   (0x42, "Development environment access"),
        
        # Security modes
        "secure":        (0x5A, "Secure mode with full auditing"),
        "audited":       (0x5A, "Audited secure access mode"),
        "safe":          (0x01, "Safe mode with restrictions"),
        "restricted":    (0x01, "Restricted safe access"),
        
        # Lock modes
        "locked":        (0x00, "Fully locked, no raw access"),
        "normal":        (0x00, "Normal operational mode"),
        "user":          (0x00, "Standard user mode access"),
    }
    
    # Parse mode value
    if mode_arg.startswith("0x"):
        mode_val = int(mode_arg, 16)
        mode_name = f"Custom Mode 0x{mode_val:02X}"
        mode_desc = "User-defined custom raw mode"
    elif mode_arg.isdigit():
        mode_val = int(mode_arg)
        mode_name = f"Custom Mode {mode_val}"
        mode_desc = "User-defined custom raw mode"
    else:
        if mode_arg not in mode_map:
            print(f"[!] Unknown mode: {mode_arg}")
            print("[*] Available modes: " + ", ".join(mode_map.keys()))
            return False
        mode_val, mode_desc = mode_map[mode_arg]
        mode_name = mode_arg.upper()
    
    # Get additional configuration parameters
    config_flags = 0x00
    timeout = 0
    access_level = 0xFF
    
    if hasattr(args, 'rawmode_args') and len(args.rawmode_args) > 1:
        for param in args.rawmode_args[1:]:
            if param.startswith("flags="):
                try:
                    flags_str = param.split('=')[1]
                    if flags_str.startswith("0x"):
                        config_flags = int(flags_str, 16)
                    else:
                        config_flags = int(flags_str)
                except:
                    print(f"[!] Invalid flags: {param}")
            elif param.startswith("timeout="):
                try:
                    timeout = int(param.split('=')[1])
                except:
                    print(f"[!] Invalid timeout: {param}")
            elif param.startswith("access="):
                try:
                    access_str = param.split('=')[1]
                    if access_str.startswith("0x"):
                        access_level = int(access_str, 16)
                    else:
                        access_level = int(access_str)
                except:
                    print(f"[!] Invalid access level: {param}")
    
    print(f"[*] Setting Raw Mode: {mode_name} (0x{mode_val:02X})")
    print(f"    Description: {mode_desc}")
    
    if config_flags != 0x00:
        print(f"    Configuration Flags: 0x{config_flags:02X}")
    if timeout > 0:
        print(f"    Timeout: {timeout} seconds")
    if access_level != 0xFF:
        print(f"    Access Level: 0x{access_level:02X}")
    
    # Safety warning for high-privilege modes
    if mode_val >= 0xC0:  # Kernel and above
        print("\n[!] WARNING: High-privilege raw mode selected!")
        print("[!] This may bypass security mechanisms and void warranties!")
        confirm = input("!! CONFIRM HIGH-PRIVILEGE MODE (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Raw mode change cancelled")
            return False
    
    # Build advanced payload
    payload = struct.pack("<BBBI", mode_val, config_flags, access_level, timeout)
    
    # Execute raw mode change
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE", payload)
    result = _decode_and_show_advanced(resp, "RAWMODE", mode_val, origin=origin)
    
    if result:
        # Verify mode change
        time.sleep(0.5)
        verify_rawmode_change(dev, mode_val)
    
    return result

def _decode_and_show_advanced(resp, operation, value, origin="UNKNOWN"):
    """
    Enhanced response decoder with detailed analysis
    """
    if not resp:
        print(f"[!] {operation} 0x{value:02X}: No response from device")
        return False
    
    result = decode_runtime_result(resp)
    severity = result.get("severity", "UNKNOWN")
    name = result.get("name", "UNKNOWN")
    extra = result.get("extra", b"")
    
    # Color-coded output based on severity
    color_codes = {
        "SUCCESS": "\033[92m",  # Green
        "WARNING": "\033[93m",  # Yellow  
        "ERROR": "\033[91m",    # Red
        "CRITICAL": "\033[95m", # Magenta
    }
    
    color = color_codes.get(severity, "\033[0m")
    reset = "\033[0m"
    
    print(f"{color}[{severity}] {operation} 0x{value:02X} via {origin}: {name}{reset}")
    
    # Analyze extra data for additional information
    if extra:
        if len(extra) >= 4:
            # Try to interpret as mode status
            current_mode = extra[0]
            previous_mode = extra[1] if len(extra) > 1 else 0
            flags = extra[2] if len(extra) > 2 else 0
            access_level = extra[3] if len(extra) > 3 else 0
            
            print(f"    Current Mode: 0x{current_mode:02X}")
            if previous_mode != 0:
                print(f"    Previous Mode: 0x{previous_mode:02X}")
            if flags != 0:
                print(f"    Status Flags: 0x{flags:02X}")
            if access_level != 0:
                print(f"    Access Level: 0x{access_level:02X}")
        
        if len(extra) > 4:
            # Show raw extra data
            print(f"    Additional Data: {extra[4:].hex()}")
    
    return severity == "SUCCESS"

def verify_rawmode_change(dev, expected_mode):
    """
    Verify that raw mode change was successful
    """
    print("[*] Verifying raw mode change...")
    
    # Try to get current raw mode status
    resp = qslcl_dispatch(dev, "RAWMODE", b"STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if extra and len(extra) > 0:
                current_mode = extra[0]
                if current_mode == expected_mode:
                    print(f"[✓] Raw mode verified: 0x{current_mode:02X}")
                    return True
                else:
                    print(f"[!] Raw mode mismatch: expected 0x{expected_mode:02X}, got 0x{current_mode:02X}")
                    return False
    
    print("[~] Raw mode verification unavailable")
    return True  # Assume success if verification not available

def get_rawmode_status(dev):
    """
    Get detailed raw mode status and capabilities
    """
    print("[*] Retrieving raw mode status...")
    
    status_info = {}
    
    # Get basic raw mode status
    resp = qslcl_dispatch(dev, "RAWMODE", b"STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 4:
                status_info["current_mode"] = extra[0]
                status_info["max_mode"] = extra[1]
                status_info["capabilities"] = extra[2]
                status_info["restrictions"] = extra[3]
                
                print("\n[*] Raw Mode Status:")
                print(f"    Current Mode: 0x{status_info['current_mode']:02X} ({get_mode_description(status_info['current_mode'])})")
                print(f"    Maximum Mode: 0x{status_info['max_mode']:02X} ({get_mode_description(status_info['max_mode'])})")
                print(f"    Capabilities: 0x{status_info['capabilities']:02X}")
                print(f"    Restrictions: 0x{status_info['restrictions']:02X}")
                
                # Decode capabilities
                capabilities = decode_capabilities(status_info['capabilities'])
                if capabilities:
                    print(f"    Available Features: {', '.join(capabilities)}")
                
                # Decode restrictions
                restrictions = decode_restrictions(status_info['restrictions'])
                if restrictions:
                    print(f"    Active Restrictions: {', '.join(restrictions)}")
    
    # Get security status
    print("\n[*] Security Status:")
    security_status = get_rawmode_security_status(dev)
    status_info["security"] = security_status
    
    # Get access log if available
    print("\n[*] Access History:")
    access_log = get_rawmode_access_log(dev)
    status_info["access_log"] = access_log
    
    return status_info

def get_mode_description(mode_value):
    """
    Get human-readable description for mode value
    """
    mode_descriptions = {
        0x00: "Locked/Normal",
        0x01: "Safe/Restricted", 
        0x10: "Diagnostic/Debug",
        0x42: "Developer",
        0x5A: "Secure/Audited",
        0xA0: "Supervisor/System",
        0xA1: "Meta/Engineering",
        0xC0: "Kernel",
        0xE0: "Hypervisor",
        0xFF: "Unrestricted/Full"
    }
    return mode_descriptions.get(mode_value, f"Unknown (0x{mode_value:02X})")

def decode_capabilities(capabilities_byte):
    """
    Decode capabilities from byte flags
    """
    capabilities = []
    flags = {
        0x01: "Memory Access",
        0x02: "Register Access", 
        0x04: "Interrupt Control",
        0x08: "DMA Access",
        0x10: "Secure Monitor",
        0x20: "TrustZone Access",
        0x40: "MMU Control",
        0x80: "Cache Control"
    }
    
    for flag, description in flags.items():
        if capabilities_byte & flag:
            capabilities.append(description)
    
    return capabilities

def decode_restrictions(restrictions_byte):
    """
    Decode restrictions from byte flags
    """
    restrictions = []
    flags = {
        0x01: "Memory Write Protected",
        0x02: "Register Write Protected",
        0x04: "Critical Regions Locked",
        0x08: "DMA Restricted", 
        0x10: "Secure Monitor Locked",
        0x20: "TrustZone Locked",
        0x40: "MMU Protected",
        0x80: "Cache Operations Restricted"
    }
    
    for flag, description in flags.items():
        if restrictions_byte & flag:
            restrictions.append(description)
    
    return restrictions

def get_rawmode_security_status(dev):
    """
    Get security-related status information
    """
    security_info = {}
    
    # Try to get security status
    resp = qslcl_dispatch(dev, "RAWMODE", b"SECURITY_STATUS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 4:
                security_info["authentication"] = extra[0]
                security_info["integrity"] = extra[1]
                security_info["audit_level"] = extra[2]
                security_info["violations"] = extra[3]
                
                print(f"    Authentication: {'Required' if security_info['authentication'] else 'None'}")
                print(f"    Integrity Check: {'Enabled' if security_info['integrity'] else 'Disabled'}")
                print(f"    Audit Level: {security_info['audit_level']}")
                print(f"    Security Violations: {security_info['violations']}")
    
    return security_info

def get_rawmode_access_log(dev):
    """
    Get raw mode access history log
    """
    # Try to get access log
    resp = qslcl_dispatch(dev, "RAWMODE", b"ACCESS_LOG\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if extra:
                # Parse access log entries (each 8 bytes: mode(1) + timestamp(4) + duration(2) + result(1))
                entry_size = 8
                num_entries = len(extra) // entry_size
                
                print(f"    Found {num_entries} access log entries")
                
                for i in range(min(num_entries, 5)):  # Show last 5 entries
                    entry = extra[i*entry_size:(i+1)*entry_size]
                    if len(entry) >= 8:
                        mode = entry[0]
                        timestamp = struct.unpack("<I", entry[1:5])[0]
                        duration = struct.unpack("<H", entry[5:7])[0]
                        result = entry[7]
                        
                        time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))
                        result_str = "SUCCESS" if result == 1 else "FAILED" if result == 0 else "UNKNOWN"
                        
                        print(f"      {time_str} - Mode 0x{mode:02X} - {duration}s - {result_str}")
                
                if num_entries > 5:
                    print(f"      ... and {num_entries - 5} more entries")
                
                return num_entries
    
    print("    No access log available")
    return 0

def unlock_rawmode(dev, args):
    """
    Unlock raw mode with authentication if required
    """
    print("[*] Attempting to unlock raw mode...")
    
    unlock_method = "DEFAULT"
    auth_data = b""
    
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        unlock_method = args.rawmode_args[0].upper()
        if len(args.rawmode_args) > 1:
            auth_data = args.rawmode_args[1].encode()
    
    print(f"    Method: {unlock_method}")
    
    # Build unlock payload
    payload = unlock_method.encode() + b"\x00" + auth_data
    
    # Execute unlock
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE_UNLOCK", payload)
    result = _decode_and_show_advanced(resp, "RAWMODE_UNLOCK", 0, origin=origin)
    
    if result:
        print("[✓] Raw mode unlocked successfully")
        # Show new capabilities
        get_rawmode_status(dev)
    
    return result

def lock_rawmode(dev, args):
    """
    Lock raw mode and restore normal operation
    """
    print("[*] Locking raw mode...")
    
    lock_level = "FULL"
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        lock_level = args.rawmode_args[0].upper()
    
    print(f"    Lock Level: {lock_level}")
    
    payload = lock_level.encode() + b"\x00"
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE_LOCK", payload)
    result = _decode_and_show_advanced(resp, "RAWMODE_LOCK", 0, origin=origin)
    
    if result:
        print("[✓] Raw mode locked successfully")
    
    return result

def configure_rawmode(dev, args):
    """
    Configure raw mode parameters and settings
    """
    if not hasattr(args, 'rawmode_args') or not args.rawmode_args:
        return print_rawmode_config_help()
    
    config_action = args.rawmode_args[0].upper()
    
    if config_action == "AUDIT":
        return configure_audit_settings(dev, args)
    elif config_action == "TIMEOUT":
        return configure_timeout_settings(dev, args)
    elif config_action == "ACCESS":
        return configure_access_controls(dev, args)
    elif config_action == "SECURITY":
        return configure_security_settings(dev, args)
    else:
        return handle_configuration_action(dev, config_action, args)

def configure_audit_settings(dev, args):
    """
    Configure audit and logging settings
    """
    audit_level = "STANDARD"
    if hasattr(args, 'rawmode_args') and len(args.rawmode_args) > 1:
        audit_level = args.rawmode_args[1].upper()
    
    print(f"[*] Configuring audit level: {audit_level}")
    
    payload = audit_level.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "RAWMODE_CONFIG", b"AUDIT\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Audit settings configured")
            return True
        else:
            print(f"[!] Audit configuration failed: {status}")
            return False
    
    print("[!] Audit configuration not available")
    return False

def escalate_privileges(dev, args):
    """
    Escalate privileges to higher raw mode levels
    """
    print("[*] Attempting privilege escalation...")
    
    target_level = "KERNEL"
    escalation_method = "STANDARD"
    
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        target_level = args.rawmode_args[0].upper()
        if len(args.rawmode_args) > 1:
            escalation_method = args.rawmode_args[1].upper()
    
    print(f"    Target Level: {target_level}")
    print(f"    Method: {escalation_method}")
    
    # Safety confirmation for privilege escalation
    print("\n[!] WARNING: Privilege escalation may bypass security mechanisms!")
    confirm = input("!! CONFIRM PRIVILEGE ESCALATION (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Privilege escalation cancelled")
        return False
    
    payload = target_level.encode() + b"\x00" + escalation_method.encode() + b"\x00"
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE_ESCALATE", payload)
    result = _decode_and_show_advanced(resp, "PRIVILEGE_ESCALATION", 0, origin=origin)
    
    if result:
        print("[✓] Privileges escalated successfully")
        get_rawmode_status(dev)
    
    return result

def monitor_rawmode_activity(dev, args):
    """
    Monitor raw mode activity in real-time
    """
    duration = 30
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        try:
            duration = int(args.rawmode_args[0])
        except:
            pass
    
    print(f"[*] Starting raw mode activity monitoring for {duration} seconds...")
    print("[*] Press Ctrl+C to stop early\n")
    
    start_time = time.time()
    end_time = start_time + duration
    
    try:
        while time.time() < end_time:
            elapsed = time.time() - start_time
            
            # Get current status
            resp = qslcl_dispatch(dev, "RAWMODE", b"STATUS\x00")
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    extra = status.get("extra", b"")
                    if len(extra) > 0:
                        current_mode = extra[0]
                        mode_name = get_mode_description(current_mode)
                        print(f"[{elapsed:5.1f}s] Current Mode: 0x{current_mode:02X} ({mode_name})")
            
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring stopped by user")
    
    print("[*] Raw mode monitoring completed")
    return True

def audit_rawmode_access(dev, args):
    """
    Perform security audit of raw mode access
    """
    print("[*] Performing raw mode security audit...")
    
    audit_type = "FULL"
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        audit_type = args.rawmode_args[0].upper()
    
    print(f"    Audit Type: {audit_type}")
    
    payload = audit_type.encode() + b"\x00"
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE_AUDIT", payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            print("[✓] Security audit completed successfully")
            
            if extra:
                # Parse audit results
                try:
                    audit_results = extra.decode('utf-8', errors='ignore')
                    print(f"    Audit Results: {audit_results}")
                except:
                    print(f"    Raw Audit Data: {extra.hex()}")
            
            return True
        else:
            print(f"[!] Security audit failed: {status}")
            return False
    
    print("[!] Security audit not available")
    return False

def reset_rawmode(dev, args):
    """
    Reset raw mode to default state
    """
    print("[*] Resetting raw mode to default state...")
    
    reset_type = "SOFT"
    if hasattr(args, 'rawmode_args') and args.rawmode_args:
        reset_type = args.rawmode_args[0].upper()
    
    print(f"    Reset Type: {reset_type}")
    
    payload = reset_type.encode() + b"\x00"
    resp, origin = qslclidx_or_dispatch(dev, "RAWMODE_RESET", payload)
    result = _decode_and_show_advanced(resp, "RAWMODE_RESET", 0, origin=origin)
    
    if result:
        print("[✓] Raw mode reset successfully")
        get_rawmode_status(dev)
    
    return result

def handle_rawmode_operation(dev, operation, args):
    """
    Handle other raw mode operations
    """
    print(f"[*] Executing raw mode operation: {operation}")
    
    # Build operation parameters
    params = build_rawmode_params(operation, args)
    
    # Try different operation strategies
    strategies = [
        try_direct_rawmode_operation,
        try_par_rawmode_command,
        try_end_rawmode_opcode,
        try_vm5_rawmode_service,
        try_idx_rawmode_command,
    ]
    
    for strategy in strategies:
        success = strategy(dev, operation, params)
        if success is not None:
            return success
    
    print(f"[!] Failed to execute raw mode operation: {operation}")
    return False

def build_rawmode_params(operation, args):
    """
    Build parameters for raw mode operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'rawmode_args'):
        for arg in args.rawmode_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

# Strategy implementations
def try_direct_rawmode_operation(dev, operation, params):
    resp = qslcl_dispatch(dev, "RAWMODE", operation.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {operation} executed successfully")
        return True
    return None

def try_par_rawmode_command(dev, operation, params):
    if operation in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, operation, params)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLPAR")
            return True
    return None

def try_end_rawmode_opcode(dev, operation, params):
    opcode = sum(operation.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLEND opcode 0x{opcode:02X}")
            return True
    return None

def try_vm5_rawmode_service(dev, operation, params):
    if operation in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[operation]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLVM5")
            return True
    return None

def try_idx_rawmode_command(dev, operation, params):
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == operation:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
            resp = qslcl_dispatch(dev, "IDX", pkt)
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {operation} executed via QSLCLIDX {name}")
                return True
    return None

# Placeholder functions for configuration actions
def print_rawmode_config_help():
    print("[*] Raw mode configuration commands:")
    print("  configure audit <level>       - Configure audit settings")
    print("  configure timeout <seconds>   - Set operation timeout")
    print("  configure access <level>      - Configure access controls")
    print("  configure security <settings> - Configure security settings")
    return False

def configure_timeout_settings(dev, args):
    print("[*] Timeout configuration not yet implemented")
    return False

def configure_access_controls(dev, args):
    print("[*] Access control configuration not yet implemented")
    return False

def configure_security_settings(dev, args):
    print("[*] Security settings configuration not yet implemented")
    return False

def handle_configuration_action(dev, action, args):
    print(f"[*] Configuration action '{action}' not yet implemented")
    return False

# Update the argument parser in main() function
def update_rawmode_parser(sub):
    """
    Update the RAWMODE command parser with new subcommands
    """
    rawmode_parser = sub.add_parser("rawmode", help="Raw mode access and privilege escalation commands")
    rawmode_parser.add_argument("rawmode_subcommand", help="Rawmode subcommand (list, set, status, unlock, lock, configure, escalate, monitor, audit, reset)")
    rawmode_parser.add_argument("rawmode_args", nargs="*", help="Additional arguments for rawmode command")
    rawmode_parser.set_defaults(func=cmd_rawmode)
