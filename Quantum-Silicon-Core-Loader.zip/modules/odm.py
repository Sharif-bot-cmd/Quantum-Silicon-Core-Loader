def cmd_odm(args):
    """
    Advanced ODM command handler for factory-level operations
    Supports: ENABLE, DISABLE, TEST, DIAG, META, and other ODM commands
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse ODM subcommand
    if not hasattr(args, 'odm_subcommand') or not args.odm_subcommand:
        return print("[!] ODM command requires subcommand (enable, disable, test, diag, etc.)")
    
    subcmd = args.odm_subcommand.upper()
    
    # Handle different ODM command categories
    if subcmd in ["ENABLE", "DISABLE"]:
        return handle_odm_enable_disable(dev, subcmd, args)
    elif subcmd == "TEST":
        return handle_odm_test(dev, args)
    elif subcmd in ["DIAG", "META", "ENGINEERING"]:
        return handle_odm_diagnostic_mode(dev, subcmd, args)
    elif subcmd in ["FRP", "FACTORY_RESET"]:
        return handle_odm_frp(dev, subcmd, args)
    elif subcmd in ["CALIBRATE", "CALIBRATION"]:
        return handle_odm_calibration(dev, args)
    else:
        return handle_generic_odm(dev, subcmd, args)

def handle_odm_enable_disable(dev, operation, args):
    """
    Handle ODM ENABLE/DISABLE commands for various features
    """
    if not hasattr(args, 'odm_args') or not args.odm_args:
        return print("[!] ENABLE/DISABLE requires feature argument")
    
    feature = args.odm_args[0].upper()
    
    print(f"[*] ODM {operation} {feature}...")
    
    # Map common features to their handlers
    feature_handlers = {
        # Diagnostic Modes
        "DIAG": lambda: enable_disable_diag_mode(dev, operation),
        "META": lambda: enable_disable_meta_mode(dev, operation),
        "ENGINEERING": lambda: enable_disable_engineering_mode(dev, operation),
        "QPST": lambda: enable_disable_qpst_mode(dev, operation),
        "DEBUG": lambda: enable_disable_debug_mode(dev, operation),
        
        # Hardware Interfaces
        "JTAG": lambda: enable_disable_jtag(dev, operation),
        "USB_DEBUG": lambda: enable_disable_usb_debug(dev, operation),
        "ADB": lambda: enable_disable_adb(dev, operation),
        "FASTBOOT": lambda: enable_disable_fastboot(dev, operation),
        
        # Security Features
        "SECURE_BOOT": lambda: enable_disable_secure_boot(dev, operation),
        "VERIFIED_BOOT": lambda: enable_disable_verified_boot(dev, operation),
        "OEM_LOCK": lambda: enable_disable_oem_lock(dev, operation),
        
        # System Features
        "TEST_SIGNING": lambda: enable_disable_test_signing(dev, operation),
        "ENG_ROOT": lambda: enable_disable_eng_root(dev, operation),
        "LOG_VERBOSE": lambda: enable_disable_verbose_logging(dev, operation),
    }
    
    if feature in feature_handlers:
        return feature_handlers[feature]()
    else:
        # Try generic enable/disable
        return generic_odm_enable_disable(dev, operation, feature, args)

def enable_disable_diag_mode(dev, operation):
    """Enable/disable Qualcomm diagnostic mode"""
    print(f"[*] {operation} Qualcomm DIAG mode...")
    
    # Try direct ODM command first
    cmd_name = f"DIAG_{operation}"
    if try_odm_command(dev, cmd_name):
        return True
    
    # Try SOC-specific methods
    soc_type = detect_soc_type(dev)
    
    if soc_type == "QUALCOMM":
        # Qualcomm DIAG mode via NV items or port config
        return configure_qualcomm_diag(dev, operation)
    elif soc_type == "MTK":
        # MediaTek META mode
        return configure_mtk_meta_mode(dev, operation)
    else:
        # Generic diagnostic enable
        return generic_diagnostic_enable(dev, operation)

def enable_disable_meta_mode(dev, operation):
    """Enable/disable MediaTek META mode"""
    print(f"[*] {operation} MediaTek META mode...")
    
    cmd_name = f"META_{operation}"
    if try_odm_command(dev, cmd_name):
        return True
    
    # MediaTek specific META mode configuration
    if operation == "ENABLE":
        # Send META mode trigger
        payload = b"META\x00" + b"\x01\x00\x00\x00"
    else:
        payload = b"META\x00" + b"\x00\x00\x00\x00"
    
    resp = qslcl_dispatch(dev, "ODM", payload)
    status = decode_runtime_result(resp)
    print(f"[*] META mode {operation}: {status}")
    return status.get("severity") == "SUCCESS"

def enable_disable_engineering_mode(dev, operation):
    """Enable/disable engineering/debug mode"""
    print(f"[*] {operation} engineering mode...")
    
    cmd_name = f"ENGINEERING_{operation}"
    if try_odm_command(dev, cmd_name):
        return True
    
    # Common engineering mode flags
    engineering_flags = {
        "ENABLE": [
            (0x100000, b"eng_root\x00"),
            (0x100100, b"debug_enable\x00"),
            (0x100200, b"\x01\x00\x00\x00"),  # Binary enable flag
        ],
        "DISABLE": [
            (0x100000, b"user_build\x00"),
            (0x100100, b"debug_disable\x00"),
            (0x100200, b"\x00\x00\x00\x00"),  # Binary disable flag
        ]
    }
    
    success = False
    for addr, flag_data in engineering_flags.get(operation, []):
        if write_odm_config(dev, addr, flag_data):
            success = True
    
    return success

def enable_disable_jtag(dev, operation):
    """Enable/disable JTAG debugging interface"""
    print(f"[*] {operation} JTAG interface...")
    
    cmd_name = f"JTAG_{operation}"
    if try_odm_command(dev, cmd_name):
        return True
    
    # JTAG configuration addresses vary by SOC
    soc_type = detect_soc_type(dev)
    jtag_configs = {
        "QUALCOMM": {
            "ENABLE": [(0x000A2000, b"\x01"), (0x000A2004, b"\x01")],
            "DISABLE": [(0x000A2000, b"\x00"), (0x000A2004, b"\x00")]
        },
        "MTK": {
            "ENABLE": [(0x10007000, b"\x01"), (0x10007004, b"\x01")],
            "DISABLE": [(0x10007000, b"\x00"), (0x10007004, b"\x00")]
        },
        "EXYNOS": {
            "ENABLE": [(0x10000000, b"\x01")],
            "DISABLE": [(0x10000000, b"\x00")]
        }
    }
    
    configs = jtag_configs.get(soc_type, jtag_configs["QUALCOMM"])
    success_count = 0
    
    for addr, value in configs.get(operation, []):
        if write_odm_config(dev, addr, value):
            success_count += 1
    
    return success_count > 0

def enable_disable_usb_debug(dev, operation):
    """Enable/disable USB debugging"""
    print(f"[*] {operation} USB debugging...")
    
    cmd_name = f"USB_DEBUG_{operation}"
    if try_odm_command(dev, cmd_name):
        return True
    
    # Common USB debugging configurations
    usb_configs = {
        "ENABLE": [
            (0x00050000, b"adb_enable\x00"),
            (0x00050010, b"\x01\x00\x00\x00"),  # ADB enable flag
            (0x00050020, b"debugging\x00"),
        ],
        "DISABLE": [
            (0x00050000, b"adb_disable\x00"),
            (0x00050010, b"\x00\x00\x00\x00"),  # ADB disable flag
            (0x00050020, b"production\x00"),
        ]
    }
    
    success_count = 0
    for addr, config_data in usb_configs.get(operation, []):
        if write_odm_config(dev, addr, config_data):
            success_count += 1
    
    return success_count > 0

def handle_odm_test(dev, args):
    """
    Handle ODM TEST commands for hardware validation
    """
    if not hasattr(args, 'odm_args') or not args.odm_args:
        return run_comprehensive_odm_test(dev)
    
    test_type = args.odm_args[0].upper()
    
    test_handlers = {
        "DISPLAY": run_display_test,
        "TOUCH": run_touch_test,
        "AUDIO": run_audio_test,
        "SENSOR": run_sensor_test,
        "CAMERA": run_camera_test,
        "BUTTON": run_button_test,
        "LED": run_led_test,
        "VIBRATION": run_vibration_test,
        "MEMORY": run_memory_test,
        "STORAGE": run_storage_test,
        "BATTERY": run_battery_test,
        "ALL": run_comprehensive_odm_test,
    }
    
    if test_type in test_handlers:
        return test_handlers[test_type](dev)
    else:
        return generic_odm_test(dev, test_type)

def run_display_test(dev):
    """Run display hardware test"""
    print("[*] Running display test...")
    
    if try_odm_command(dev, "TEST_DISPLAY"):
        return True
    
    # Display test patterns
    test_patterns = [
        b"DISPLAY_TEST_RED",
        b"DISPLAY_TEST_GREEN", 
        b"DISPLAY_TEST_BLUE",
        b"DISPLAY_TEST_WHITE",
        b"DISPLAY_TEST_BLACK",
        b"DISPLAY_TEST_GRADIENT",
    ]
    
    success_count = 0
    for pattern in test_patterns:
        resp = qslcl_dispatch(dev, "ODM", b"TEST_DISPLAY\x00" + pattern)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            success_count += 1
        time.sleep(0.5)  # Brief pause between patterns
    
    print(f"[*] Display test completed: {success_count}/{len(test_patterns)} patterns passed")
    return success_count == len(test_patterns)

def run_sensor_test(dev):
    """Run sensor calibration and test"""
    print("[*] Running sensor test...")
    
    if try_odm_command(dev, "TEST_SENSOR"):
        return True
    
    sensors_to_test = [
        "ACCELEROMETER",
        "GYROSCOPE", 
        "MAGNETOMETER",
        "PROXIMITY",
        "LIGHT",
        "PRESSURE",
        "HUMIDITY",
    ]
    
    success_count = 0
    for sensor in sensors_to_test:
        resp = qslcl_dispatch(dev, "ODM", b"TEST_SENSOR\x00" + sensor.encode())
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {sensor}: OK")
            success_count += 1
        else:
            print(f"[!] {sensor}: FAILED")
    
    print(f"[*] Sensor test completed: {success_count}/{len(sensors_to_test)} sensors passed")
    return success_count > 0

def run_comprehensive_odm_test(dev):
    """Run comprehensive hardware test suite"""
    print("[*] Starting comprehensive ODM test suite...")
    
    test_results = {}
    
    # Run individual tests
    test_results["display"] = run_display_test(dev)
    test_results["touch"] = run_touch_test(dev) 
    test_results["audio"] = run_audio_test(dev)
    test_results["sensor"] = run_sensor_test(dev)
    test_results["camera"] = run_camera_test(dev)
    test_results["memory"] = run_memory_test(dev)
    
    # Print summary
    print("\n" + "="*50)
    print("[*] ODM TEST SUMMARY")
    print("="*50)
    for test_name, passed in test_results.items():
        status = "PASS" if passed else "FAIL"
        print(f"  {test_name.upper():<12}: {status}")
    
    total_passed = sum(test_results.values())
    total_tests = len(test_results)
    
    print(f"  {'TOTAL':<12}: {total_passed}/{total_tests}")
    print("="*50)
    
    return total_passed == total_tests

def handle_odm_diagnostic_mode(dev, mode, args):
    """
    Handle ODM diagnostic mode commands
    """
    print(f"[*] Configuring {mode} diagnostic mode...")
    
    if try_odm_command(dev, f"{mode}_MODE"):
        return True
    
    # Configure diagnostic mode based on SOC type
    soc_type = detect_soc_type(dev)
    
    if soc_type == "QUALCOMM":
        return configure_qualcomm_diagnostic(dev, mode)
    elif soc_type == "MTK":
        return configure_mtk_diagnostic(dev, mode)
    else:
        return configure_generic_diagnostic(dev, mode)

def handle_odm_frp(dev, subcmd, args):
    """
    Handle ODM FRP (Factory Reset Protection) commands
    """
    print(f"[*] Handling FRP {subcmd}...")
    
    if try_odm_command(dev, f"FRP_{subcmd}"):
        return True
    
    # FRP bypass methods
    if subcmd == "FRP":
        return bypass_frp_protection(dev)
    elif subcmd == "FACTORY_RESET":
        return perform_factory_reset(dev)
    
    return False

def bypass_frp_protection(dev):
    """Bypass Factory Reset Protection"""
    print("[*] Attempting FRP bypass...")
    
    # Common FRP partition areas
    frp_partitions = ["frp", "misc", "persist", "devinfo"]
    
    for partition in frp_partitions:
        try:
            addr, size = resolve_partition(partition)
            # Clear FRP data
            payload = struct.pack("<Q I", addr, 512)
            resp = qslcl_dispatch(dev, "WRITE", payload + b"\x00" * 512)
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] Cleared FRP data from {partition}")
                return True
        except:
            continue
    
    return False

def handle_odm_calibration(dev, args):
    """
    Handle ODM calibration commands
    """
    print("[*] Running sensor calibration...")
    
    if not hasattr(args, 'odm_args') or not args.odm_args:
        return run_comprehensive_calibration(dev)
    
    sensor = args.odm_args[0].upper()
    
    calibration_handlers = {
        "TOUCH": calibrate_touch,
        "GYRO": calibrate_gyro,
        "COMPASS": calibrate_compass,
        "CAMERA": calibrate_camera,
        "BATTERY": calibrate_battery,
        "ALL": run_comprehensive_calibration,
    }
    
    if sensor in calibration_handlers:
        return calibration_handlers[sensor](dev)
    else:
        return generic_calibration(dev, sensor)

def calibrate_touch(dev):
    """Calibrate touchscreen"""
    print("[*] Starting touchscreen calibration...")
    
    if try_odm_command(dev, "CALIBRATE_TOUCH"):
        return True
    
    # Touch calibration sequence
    calibration_points = [
        (0.1, 0.1),   # Top-left
        (0.9, 0.1),   # Top-right  
        (0.1, 0.9),   # Bottom-left
        (0.9, 0.9),   # Bottom-right
        (0.5, 0.5),   # Center
    ]
    
    success_count = 0
    for x, y in calibration_points:
        point_data = struct.pack("<ff", x, y)
        resp = qslcl_dispatch(dev, "ODM", b"CALIBRATE_TOUCH\x00" + point_data)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            success_count += 1
        time.sleep(0.5)
    
    return success_count == len(calibration_points)

# Helper functions
def try_odm_command(dev, command):
    """Try to execute ODM command through available handlers"""
    # Try QSLCLPAR first
    if command in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, command, b"")
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] ODM {command} via QSLCLPAR")
            return True
    
    # Try QSLCLEND opcode
    opcode = sum(command.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        pkt = b"QSLCLEND" + entry
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] ODM {command} via QSLCLEND")
            return True
    
    return False

def write_odm_config(dev, address, data):
    """Write ODM configuration data to specific address"""
    payload = struct.pack("<Q", address) + data
    resp = qslcl_dispatch(dev, "WRITE", payload)
    status = decode_runtime_result(resp)
    return status.get("severity") == "SUCCESS"

def handle_generic_odm(dev, subcmd, args):
    """
    Handle generic ODM commands
    """
    print(f"[*] Executing ODM command: {subcmd}")
    
    # Build payload from additional arguments
    payload = b""
    if hasattr(args, 'odm_args'):
        for arg in args.odm_args:
            try:
                if arg.startswith("0x"):
                    payload += struct.pack("<I", int(arg, 16))
                else:
                    payload += struct.pack("<I", int(arg))
            except:
                payload += arg.encode() + b"\x00"
    
    # Try ODM-specific dispatch first
    resp = qslcl_dispatch(dev, "ODM", subcmd.encode() + b"\x00" + payload)
    status = decode_runtime_result(resp)
    
    if status.get("severity") != "SUCCESS":
        # Fallback to generic command
        resp = qslcl_dispatch(dev, subcmd, payload)
        status = decode_runtime_result(resp)
    
    print(f"[*] ODM {subcmd} Result: {status}")
    return status.get("severity") == "SUCCESS"

# Placeholder functions for other test types
def run_touch_test(dev): 
    print("[*] Running touch test...")
    return try_odm_command(dev, "TEST_TOUCH")

def run_audio_test(dev):
    print("[*] Running audio test...") 
    return try_odm_command(dev, "TEST_AUDIO")

def run_camera_test(dev):
    print("[*] Running camera test...")
    return try_odm_command(dev, "TEST_CAMERA")

def run_button_test(dev):
    print("[*] Running button test...")
    return try_odm_command(dev, "TEST_BUTTON")

def run_led_test(dev):
    print("[*] Running LED test...")
    return try_odm_command(dev, "TEST_LED")

def run_vibration_test(dev):
    print("[*] Running vibration test...")
    return try_odm_command(dev, "TEST_VIBRATION")

def run_memory_test(dev):
    print("[*] Running memory test...")
    return try_odm_command(dev, "TEST_MEMORY")

def run_storage_test(dev):
    print("[*] Running storage test...")
    return try_odm_command(dev, "TEST_STORAGE")

def run_battery_test(dev):
    print("[*] Running battery test...")
    return try_odm_command(dev, "TEST_BATTERY")

def run_comprehensive_calibration(dev):
    print("[*] Running comprehensive calibration...")
    return try_odm_command(dev, "CALIBRATE_ALL")

def generic_odm_test(dev, test_type):
    print(f"[*] Running generic {test_type} test...")
    return try_odm_command(dev, f"TEST_{test_type}")

def generic_calibration(dev, sensor):
    print(f"[*] Running generic {sensor} calibration...")
    return try_odm_command(dev, f"CALIBRATE_{sensor}")

def configure_qualcomm_diag(dev, operation):
    print(f"[*] Configuring Qualcomm DIAG mode: {operation}")
    return try_odm_command(dev, f"DIAG_{operation}")

def configure_mtk_meta_mode(dev, operation):
    print(f"[*] Configuring MediaTek META mode: {operation}")
    return try_odm_command(dev, f"META_{operation}")

def generic_diagnostic_enable(dev, operation):
    print(f"[*] Generic diagnostic {operation}")
    return try_odm_command(dev, f"DIAG_{operation}")

def configure_qualcomm_diagnostic(dev, mode):
    print(f"[*] Configuring Qualcomm {mode} diagnostic")
    return try_odm_command(dev, f"{mode}_MODE")

def configure_mtk_diagnostic(dev, mode):
    print(f"[*] Configuring MediaTek {mode} diagnostic") 
    return try_odm_command(dev, f"{mode}_MODE")

def configure_generic_diagnostic(dev, mode):
    print(f"[*] Configuring generic {mode} diagnostic")
    return try_odm_command(dev, f"{mode}_MODE")

def perform_factory_reset(dev):
    print("[*] Performing factory reset...")
    return try_odm_command(dev, "FACTORY_RESET")

def generic_odm_enable_disable(dev, operation, feature, args):
    print(f"[*] Generic ODM {operation} for {feature}")
    return try_odm_command(dev, f"{feature}_{operation}")