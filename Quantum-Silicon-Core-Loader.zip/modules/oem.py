def cmd_oem(args):
    """
    Advanced OEM command handler with intelligent lock/unlock detection
    Supports: UNLOCK, LOCK, and other OEM commands
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse OEM subcommand
    if not hasattr(args, 'oem_subcommand') or not args.oem_subcommand:
        return print("[!] OEM command requires subcommand (unlock, lock, etc.)")
    
    subcmd = args.oem_subcommand.upper()
    
    if subcmd in ["UNLOCK", "LOCK"]:
        return handle_bootloader_lock_unlock(dev, subcmd, args)
    else:
        # Handle other OEM commands
        return handle_generic_oem(dev, subcmd, args)

def handle_bootloader_lock_unlock(dev, operation, args):
    """
    Intelligent bootloader lock/unlock detection across SOC platforms
    """
    print(f"[*] Starting {operation} procedure...")
    
    # Step 1: Try direct OEM command first
    if try_direct_oem_command(dev, operation):
        return True
    
    # Step 2: Auto-detect lock regions and apply changes
    return auto_detect_and_modify_lock_state(dev, operation, args)

def try_direct_oem_command(dev, operation):
    """
    Try using direct OEM UNLOCK/LOCK commands if available in loader
    """
    cmd_name = operation.upper()
    
    # Priority 1: QSLCLPAR direct command
    if cmd_name in QSLCLPAR_DB:
        print(f"[*] Using QSLCLPAR {cmd_name} command")
        resp = qslcl_dispatch(dev, cmd_name, b"")
        status = decode_runtime_result(resp)
        print(f"[*] {cmd_name} Result: {status}")
        return status.get("severity") == "SUCCESS"
    
    # Priority 2: QSLCLEND opcode
    opcode_map = {"UNLOCK": 0xD0, "LOCK": 0xD1}
    if operation in opcode_map and opcode_map[operation] in QSLCLEND_DB:
        print(f"[*] Using QSLCLEND opcode for {operation}")
        entry = QSLCLEND_DB[opcode_map[operation]]
        pkt = b"QSLCLEND" + entry
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        print(f"[*] {operation} Result: {status}")
        return status.get("severity") == "SUCCESS"
    
    # Priority 3: VM5 microservice
    if cmd_name in QSLCLVM5_DB:
        print(f"[*] Using QSLCLVM5 {cmd_name} microservice")
        raw = QSLCLVM5_DB[cmd_name]["raw"]
        pkt = b"QSLCLVM5" + raw
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        print(f"[*] {operation} Result: {status}")
        return status.get("severity") == "SUCCESS"
    
    return False

def auto_detect_and_modify_lock_state(dev, operation, args):
    """
    Auto-detect lock regions and modify bootloader lock state
    """
    print("[*] Auto-detecting lock regions...")
    
    # Step 1: Detect SOC type and get lock region patterns
    soc_type = detect_soc_type(dev)
    lock_patterns = get_lock_patterns_for_soc(soc_type)
    
    # Step 2: Scan memory for lock flags
    lock_regions = scan_for_lock_regions(dev, lock_patterns)
    
    if not lock_regions:
        print("[!] No lock regions detected. Device may not support this operation.")
        return False
    
    print(f"[*] Found {len(lock_regions)} potential lock region(s)")
    
    # Step 3: Verify and modify lock state
    success_count = 0
    for region in lock_regions:
        if modify_lock_region(dev, region, operation):
            success_count += 1
    
    # Step 4: Verify changes
    if success_count > 0:
        print(f"[*] Verifying {operation} operation...")
        if verify_lock_state(dev, operation, lock_regions):
            print(f"[✓] {operation} completed successfully")
            return True
        else:
            print(f"[!] {operation} verification failed")
            return False
    else:
        print(f"[!] {operation} failed on all regions")
        return False

def detect_soc_type(dev):
    """
    Detect SOC type to determine lock region patterns
    """
    # Try to get device info first
    resp = qslcl_dispatch(dev, "GETINFO", b"")
    if resp:
        info = parse_device_info(resp)
        for key, value in info.items():
            if "qualcomm" in value.lower() or "qcom" in value.lower():
                return "QUALCOMM"
            elif "mediatek" in value.lower() or "mt" in value.lower():
                return "MTK"
            elif "samsung" in value.lower() or "exynos" in value.lower():
                return "EXYNOS"
            elif "hisilicon" in value.lower() or "kirin" in value.lower():
                return "HISILICON"
            elif "unisoc" in value.lower() or "sprd" in value.lower():
                return "UNISOC"
    
    # Fallback to transport detection
    handle, serial_mode = open_transport(dev)
    dtype = detect_device_type(handle)
    
    type_map = {
        "QUALCOMM": "QUALCOMM", 
        "MTK": "MTK",
        "APPLE_DFU": "APPLE",
        "GENERIC": "UNKNOWN"
    }
    
    return type_map.get(dtype, "UNKNOWN")

def get_lock_patterns_for_soc(soc_type):
    """
    Return lock region search patterns for different SOC types
    """
    patterns = {
        "QUALCOMM": [
            # Common Qualcomm lock flag locations
            {"start": 0x00086000, "end": 0x00087000, "pattern": b"bootlock|unlock", "mask": 0xFFFF},
            {"start": 0x0006F000, "end": 0x00070000, "pattern": b"locked", "mask": 0xFFFF},
            {"start": 0x00100000, "end": 0x00110000, "pattern": b"verifiedboot", "mask": 0xFFFF},
            # Android Verified Boot (AVB) areas
            {"start": 0x00700000, "end": 0x00800000, "pattern": b"avb", "mask": 0xFFFF},
        ],
        "MTK": [
            # MediaTek lock regions
            {"start": 0x00011C00, "end": 0x00011E00, "pattern": b"bootmode", "mask": 0xFFFF},
            {"start": 0x00012000, "end": 0x00012200, "pattern": b"security", "mask": 0xFFFF},
            {"start": 0x0010A000, "end": 0x0010B000, "pattern": b"lockstate", "mask": 0xFFFF},
            # MTK preloader areas
            {"start": 0x00001000, "end": 0x00002000, "pattern": b"PL", "mask": 0xFFFF},
        ],
        "EXYNOS": [
            # Samsung Exynos lock areas
            {"start": 0x04000000, "end": 0x04001000, "pattern": b"boot_cfg", "mask": 0xFFFF},
            {"start": 0x05000000, "end": 0x05001000, "pattern": b"sec_boot", "mask": 0xFFFF},
        ],
        "HISILICON": [
            # HiSilicon Kirin lock regions
            {"start": 0x0000E000, "end": 0x0000F000, "pattern": b"fastboot", "mask": 0xFFFF},
            {"start": 0x00100000, "end": 0x00110000, "pattern": b"boot_verify", "mask": 0xFFFF},
        ],
        "UNISOC": [
            # Unisoc/Spreadtrum lock areas
            {"start": 0x00005000, "end": 0x00006000, "pattern": b"spl", "mask": 0xFFFF},
            {"start": 0x00080000, "end": 0x00081000, "pattern": b"bootctrl", "mask": 0xFFFF},
        ],
        "UNKNOWN": [
            # Generic search patterns for unknown SOC
            {"start": 0x00000000, "end": 0x00200000, "pattern": b"lock", "mask": 0xFFFF},
            {"start": 0x00600000, "end": 0x00800000, "pattern": b"boot", "mask": 0xFFFF},
            {"start": 0x04000000, "end": 0x04100000, "pattern": b"security", "mask": 0xFFFF},
            {"start": 0x08000000, "end": 0x08100000, "pattern": b"verified", "mask": 0xFFFF},
        ]
    }
    
    return patterns.get(soc_type, patterns["UNKNOWN"])

def scan_for_lock_regions(dev, patterns):
    """
    Scan memory for bootloader lock regions using provided patterns
    """
    regions_found = []
    sector_size = get_sector_size(dev)
    
    for pattern_info in patterns:
        start_addr = pattern_info["start"]
        end_addr = pattern_info["end"]
        search_pattern = pattern_info["pattern"]
        mask = pattern_info.get("mask", 0xFFFF)
        
        print(f"[*] Scanning region 0x{start_addr:08X}-0x{end_addr:08X} for '{search_pattern}'")
        
        # Read memory region
        read_size = end_addr - start_addr
        if read_size > 1024 * 1024:  # Limit to 1MB chunks
            read_size = 1024 * 1024
        
        payload = struct.pack("<Q I", start_addr, read_size)
        resp, origin = qslclidx_or_dispatch(dev, "READ", payload)
        
        if not resp:
            continue
            
        status = decode_runtime_result(resp)
        if status.get("severity") != "SUCCESS":
            continue
            
        data = status.get("extra", b"")
        if not data:
            continue
        
        # Search for pattern in data
        pattern_bytes = search_pattern if isinstance(search_pattern, bytes) else search_pattern.encode()
        
        # Simple pattern matching
        pos = 0
        while pos < len(data):
            found_pos = data.find(pattern_bytes, pos)
            if found_pos == -1:
                break
                
            # Found potential lock region
            region_addr = start_addr + found_pos
            regions_found.append({
                "address": region_addr & ~(sector_size - 1),  # Align to sector
                "size": sector_size,
                "pattern": search_pattern,
                "context": data[max(0, found_pos-16):min(len(data), found_pos+32)],
                "soc_type": "detected"
            })
            
            pos = found_pos + 1
    
    # Also check known partition areas
    partition_regions = check_partition_lock_areas(dev)
    regions_found.extend(partition_regions)
    
    return regions_found

def check_partition_lock_areas(dev):
    """
    Check common partition areas for lock flags
    """
    lock_partitions = []
    common_lock_partitions = [
        "bootconfig", "devinfo", "misc", "param", "frp", "persist", "protect_f", "protect_s"
    ]
    
    parts = load_partitions(dev)
    for part in parts:
        part_name = part["name"].lower()
        if any(lock_part in part_name for lock_part in common_lock_partitions):
            # Read first sector of partition to check for lock flags
            payload = struct.pack("<Q I", part["offset"], 512)
            resp, origin = qslclidx_or_dispatch(dev, "READ", payload)
            
            if resp:
                status = decode_runtime_result(resp)
                if status.get("severity") == "SUCCESS":
                    data = status.get("extra", b"")
                    if data and (b"lock" in data.lower() or b"unlock" in data.lower()):
                        lock_partitions.append({
                            "address": part["offset"],
                            "size": 512,
                            "pattern": "partition_lock",
                            "context": f"Partition: {part_name}",
                            "soc_type": "partition"
                        })
    
    return lock_partitions

def modify_lock_region(dev, region, operation):
    """
    Modify a lock region based on the requested operation
    """
    address = region["address"]
    size = region["size"]
    
    print(f"[*] Modifying lock region at 0x{address:08X} for {operation}")
    
    # Read current content
    payload = struct.pack("<Q I", address, size)
    resp, origin = qslclidx_or_dispatch(dev, "READ", payload)
    
    if not resp:
        return False
        
    status = decode_runtime_result(resp)
    if status.get("severity") != "SUCCESS":
        return False
        
    current_data = status.get("extra", b"")
    if not current_data:
        return False
    
    # Modify data based on operation
    modified_data = apply_lock_modification(current_data, operation, region)
    
    if modified_data == current_data:
        print(f"[!] No changes needed for region 0x{address:08X}")
        return True  # Already in desired state
    
    # Write modified data back
    write_payload = struct.pack("<Q", address) + modified_data
    resp, origin = qslclidx_or_dispatch(dev, "WRITE", write_payload)
    
    if not resp:
        return False
        
    status = decode_runtime_result(resp)
    success = status.get("severity") == "SUCCESS"
    
    if success:
        print(f"[✓] Successfully modified region 0x{address:08X}")
    else:
        print(f"[!] Failed to modify region 0x{address:08X}: {status}")
    
    return success

def apply_lock_modification(data, operation, region):
    """
    Apply lock/unlock modifications to the data
    """
    modified = bytearray(data)
    pattern = region["pattern"]
    
    if operation == "UNLOCK":
        # Common unlock patterns
        replacements = [
            (b"locked", b"unlock"),
            (b"LOCKED", b"UNLOCK"),
            (b"\x01", b"\x00"),  # Binary flags
            (b"\xFF", b"\x00"),
            (b"enable", b"disabl"),
            (b"ENABLE", b"DISABL"),
        ]
    else:  # LOCK
        # Common lock patterns
        replacements = [
            (b"unlock", b"locked"),
            (b"UNLOCK", b"LOCKED"),
            (b"\x00", b"\x01"),  # Binary flags
            (b"disabl", b"enable"),
            (b"DISABL", b"ENABLE"),
        ]
    
    for old, new in replacements:
        if old in modified:
            pos = 0
            while pos < len(modified):
                found = modified.find(old, pos)
                if found == -1:
                    break
                modified[found:found+len(old)] = new.ljust(len(old), b'\x00')[:len(old)]
                pos = found + len(old)
    
    return bytes(modified)

def verify_lock_state(dev, operation, regions):
    """
    Verify that lock state was successfully changed
    """
    print(f"[*] Verifying {operation} state...")
    
    # Try direct verification first
    if operation == "UNLOCK":
        verify_cmd = "VERIFY_UNLOCK"
    else:
        verify_cmd = "VERIFY_LOCK"
    
    # Check if verify command exists
    if verify_cmd in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, verify_cmd, b"")
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            return True
    
    # Fallback: re-scan regions to verify changes
    success_count = 0
    for region in regions[:3]:  # Check first 3 regions
        payload = struct.pack("<Q I", region["address"], region["size"])
        resp, origin = qslclidx_or_dispatch(dev, "READ", payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                data = status.get("extra", b"")
                if operation == "UNLOCK" and (b"unlock" in data.lower() or b"\x00" in data[0:4]):
                    success_count += 1
                elif operation == "LOCK" and (b"lock" in data.lower() or b"\x01" in data[0:4]):
                    success_count += 1
    
    return success_count > 0

def handle_generic_oem(dev, subcmd, args):
    """
    Handle generic OEM commands
    """
    print(f"[*] Executing OEM command: {subcmd}")
    
    # Build payload from additional arguments
    payload = b""
    if hasattr(args, 'oem_args'):
        for arg in args.oem_args:
            try:
                # Try to parse as hex first
                if arg.startswith("0x"):
                    payload += struct.pack("<I", int(arg, 16))
                else:
                    # Try as decimal
                    payload += struct.pack("<I", int(arg))
            except:
                # Treat as string
                payload += arg.encode() + b"\x00"
    
    resp = qslcl_dispatch(dev, "OEM", subcmd.encode() + b"\x00" + payload)
    status = decode_runtime_result(resp)
    print(f"[*] OEM {subcmd} Result: {status}")
    
    return status.get("severity") == "SUCCESS"

def update_oem_parser(sub):
    """
    Update the OEM command parser with new subcommands
    """
    oem_parser = sub.add_parser("oem", help="OEM commands (unlock, lock, etc.)")
    oem_parser.add_argument("oem_subcommand", help="OEM subcommand (unlock, lock, etc.)")
    oem_parser.add_argument("oem_args", nargs="*", help="Additional arguments for OEM command")
    oem_parser.set_defaults(func=cmd_oem)