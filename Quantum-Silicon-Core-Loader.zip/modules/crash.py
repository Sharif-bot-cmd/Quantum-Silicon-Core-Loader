def cmd_crash(args):
    """
    Advanced CRASH command handler for controlled system crash simulation
    Supports various crash types and fault injection methods
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse CRASH subcommand
    if not hasattr(args, 'crash_subcommand') or not args.crash_subcommand:
        return print("[!] CRASH command requires subcommand (list, preloader, kernel, watchdog, etc.)")
    
    subcmd = args.crash_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_crash_types(dev)
    else:
        return trigger_controlled_crash(dev, subcmd, args)

def list_available_crash_types(dev):
    """
    List all available CRASH commands from QSLCL loader
    """
    print("\n" + "="*50)
    print("[*] AVAILABLE QSLCL CRASH COMMANDS")
    print("="*50)
    
    crash_found = []
    
    # Check QSLCLPAR for CRASH commands
    print("\n[QSLCLPAR] Crash Commands:")
    par_crashes = [cmd for cmd in QSLCLPAR_DB.keys() if "CRASH" in cmd.upper()]
    for crash_cmd in par_crashes:
        print(f"  • {crash_cmd}")
        crash_found.append(crash_cmd)
    
    # Check QSLCLEND for crash-related opcodes
    print("\n[QSLCLEND] Crash Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        if isinstance(entry, dict) and "CRASH" in str(entry.get('name', '')).upper():
            print(f"  • Opcode 0x{opcode:02X}: {entry.get('name', 'UNKNOWN')}")
            crash_found.append(f"ENGINE_0x{opcode:02X}")
        elif isinstance(entry, bytes) and len(entry) > 0:
            # Check if opcode name suggests crash functionality
            opcode_name = f"OP_{opcode:02X}"
            if opcode in [0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xDE, 0xAD, 0xBE, 0xEF]:
                print(f"  • Suspicious Opcode 0x{opcode:02X}: Potential crash function")
                crash_found.append(f"SUSPECT_0x{opcode:02X}")
    
    # Check QSLCLVM5 for crash microservices
    print("\n[QSLCLVM5] Crash Microservices:")
    vm5_crashes = [cmd for cmd in QSLCLVM5_DB.keys() if "CRASH" in cmd.upper()]
    for crash_cmd in vm5_crashes:
        print(f"  • {crash_cmd}")
        crash_found.append(f"VM5_{crash_cmd}")
    
    # Check QSLCLIDX for crash indices
    print("\n[QSLCLIDX] Crash Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and "CRASH" in str(entry.get('name', '')).upper():
            print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
            crash_found.append(f"IDX_{name}")
    
    if not crash_found:
        print("  No crash commands found in loader")
    else:
        print(f"\n[*] Total crash commands found: {len(crash_found)}")
    
    print("\n[*] Common Crash Types Available:")
    print("  • PRELOADER  - Simulate preloader/bootrom crash")
    print("  • KERNEL     - Trigger kernel panic/oops")
    print("  • WATCHDOG   - Trigger watchdog timeout")
    print("  • MEMORY     - Memory corruption crash")
    print("  • NULL_PTR   - Null pointer dereference")
    print("  • STACK      - Stack overflow corruption")
    print("  • DIV_ZERO   - Division by zero fault")
    print("  • UNDEF_INST - Undefined instruction")
    print("  • HARD_FAULT - Hard fault escalation")
    print("  • SECURITY   - Security violation crash")
    
    print("="*50)
    
    return True

def trigger_controlled_crash(dev, crash_type, args):
    """
    Trigger controlled system crash with specified type
    """
    print(f"[!] WARNING: Attempting to trigger {crash_type} crash")
    print("[!] This may cause device instability or require physical reset!")
    
    # Safety confirmation for destructive crashes
    if crash_type not in ["SOFT", "TEST", "DUMMY"]:
        confirm = input("!! CONFIRM CRASH OPERATION (type 'YES' to continue): ").strip().upper()
        if confirm != "YES":
            print("[*] Crash operation cancelled")
            return False
    
    print(f"[*] Preparing {crash_type} crash injection...")
    
    # Build crash parameters
    crash_params = build_crash_parameters(crash_type, args)
    
    # Try different crash triggering strategies
    strategies = [
        try_direct_crash_command,
        try_par_crash_command,
        try_end_crash_opcode,
        try_vm5_crash_service,
        try_idx_crash_command,
        try_generic_crash_injection
    ]
    
    for strategy in strategies:
        success = strategy(dev, crash_type, crash_params)
        if success is not None:
            if success:
                monitor_crash_aftermath(dev, crash_type)
            return success
    
    print(f"[!] Failed to trigger {crash_type} crash")
    return False

def build_crash_parameters(crash_type, args):
    """
    Build appropriate parameters for different crash types
    """
    params = bytearray()
    
    # Add crash type identifier
    type_hash = sum(crash_type.encode()) & 0xFFFF
    params.extend(struct.pack("<H", type_hash))
    
    # Add severity level (default: 0x01 = MEDIUM)
    severity = 0x01
    if hasattr(args, 'crash_args') and args.crash_args:
        try:
            if args.crash_args[0].startswith("0x"):
                severity = int(args.crash_args[0], 16) & 0xFF
            else:
                severity = int(args.crash_args[0]) & 0xFF
        except:
            pass
    
    params.extend(struct.pack("<B", severity))
    
    # Add crash-specific parameters
    if crash_type == "PRELOADER":
        # Preloader crash: address, corruption pattern
        params.extend(struct.pack("<I", 0x100000))  # Typical preloader base
        params.extend(b"DEADBEEF")  # Corruption signature
        
    elif crash_type == "KERNEL":
        # Kernel panic: oops type, register state
        params.extend(struct.pack("<I", 0x0000000D))  # Oops type
        params.extend(b"\x00" * 16)  # Simulated register dump
        
    elif crash_type == "WATCHDOG":
        # Watchdog trigger: timeout value, reset type
        params.extend(struct.pack("<I", 1000))  # 1000ms timeout
        params.extend(b"\x01")  # Hard reset
        
    elif crash_type == "MEMORY":
        # Memory corruption: target address, corruption pattern
        target_addr = 0x80000000
        if hasattr(args, 'crash_args') and len(args.crash_args) > 1:
            try:
                if args.crash_args[1].startswith("0x"):
                    target_addr = int(args.crash_args[1], 16)
            except:
                pass
        params.extend(struct.pack("<Q", target_addr))
        params.extend(b"CORRUPTED_MEMORY\x00")
        
    elif crash_type == "NULL_PTR":
        # Null pointer: access type, fault address
        params.extend(struct.pack("<B", 0x01))  # Read access
        params.extend(struct.pack("<Q", 0x00000000))  # NULL address
        
    elif crash_type == "STACK":
        # Stack overflow: stack base, overflow size
        params.extend(struct.pack("<Q", 0x80000000))  # Stack base
        params.extend(struct.pack("<I", 0x1000))  # Overflow by 4KB
        
    elif crash_type == "DIV_ZERO":
        # Division by zero: dividend, divisor
        params.extend(struct.pack("<I", 0x12345678))  # Dividend
        params.extend(struct.pack("<I", 0x00000000))  # Divisor (zero)
        
    elif crash_type == "UNDEF_INST":
        # Undefined instruction: opcode bytes
        params.extend(b"\xDE\xAD\xC0\xDE")  # Undefined instruction pattern
        
    elif crash_type == "HARD_FAULT":
        # Hard fault: fault type, status register
        params.extend(struct.pack("<I", 0x00000002))  # Hard fault type
        params.extend(struct.pack("<I", 0x40000000))  # HFSR value
        
    elif crash_type == "SECURITY":
        # Security violation: violation type, severity
        params.extend(struct.pack("<B", 0x03))  # Privilege escalation attempt
        params.extend(struct.pack("<I", 0xDEADBEEF))  # Security token
        
    else:
        # Generic crash: random pattern
        params.extend(os.urandom(8))
    
    # Add timestamp for crash identification
    timestamp = int(time.time())
    params.extend(struct.pack("<I", timestamp))
    
    return bytes(params)

def try_direct_crash_command(dev, crash_type, params):
    """
    Try direct CRASH command dispatch
    """
    resp = qslcl_dispatch(dev, "CRASH", crash_type.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {crash_type} crash triggered successfully via direct CRASH command")
        return True
    
    return None

def try_par_crash_command(dev, crash_type, params):
    """
    Try QSLCLPAR crash commands
    """
    # Check for exact match
    if crash_type in QSLCLPAR_DB:
        print(f"[*] Using QSLCLPAR crash command: {crash_type}")
        resp = qslcl_dispatch(dev, crash_type, params)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {crash_type} crash triggered successfully via QSLCLPAR")
            return True
        else:
            print(f"[!] QSLCLPAR crash '{crash_type}' failed: {status}")
            return False
    
    # Check for CRASH_ prefixed commands
    crash_prefixed = f"CRASH_{crash_type}"
    if crash_prefixed in QSLCLPAR_DB:
        print(f"[*] Using QSLCLPAR crash command: {crash_prefixed}")
        resp = qslcl_dispatch(dev, crash_prefixed, params)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {crash_type} crash triggered successfully via QSLCLPAR {crash_prefixed}")
            return True
        else:
            print(f"[!] QSLCLPAR crash '{crash_prefixed}' failed: {status}")
            return False
    
    return None

def try_end_crash_opcode(dev, crash_type, params):
    """
    Try QSLCLEND crash opcodes
    """
    # Calculate opcode from crash type
    crash_opcode = sum(crash_type.encode()) & 0xFF
    
    if crash_opcode in QSLCLEND_DB:
        print(f"[*] Using QSLCLEND crash opcode 0x{crash_opcode:02X} for '{crash_type}'")
        entry = QSLCLEND_DB[crash_opcode]
        if isinstance(entry, dict):
            entry_data = entry.get("raw", b"")
        else:
            entry_data = entry
        
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {crash_type} crash triggered successfully via QSLCLEND opcode 0x{crash_opcode:02X}")
            return True
        else:
            print(f"[!] QSLCLEND crash opcode 0x{crash_opcode:02X} failed: {status}")
            return False
    
    # Try common crash opcodes
    common_crash_opcodes = {
        "PRELOADER": 0xC0,
        "KERNEL": 0xC1,
        "WATCHDOG": 0xC2,
        "MEMORY": 0xC3,
        "NULL_PTR": 0xC4,
        "STACK": 0xC5,
        "DIV_ZERO": 0xC6,
        "UNDEF_INST": 0xC7,
        "HARD_FAULT": 0xC8,
        "SECURITY": 0xC9,
        "GENERIC": 0xCA,
    }
    
    if crash_type in common_crash_opcodes:
        opcode = common_crash_opcodes[crash_type]
        if opcode in QSLCLEND_DB:
            print(f"[*] Using common QSLCLEND crash opcode 0x{opcode:02X} for '{crash_type}'")
            entry = QSLCLEND_DB[opcode]
            if isinstance(entry, dict):
                entry_data = entry.get("raw", b"")
            else:
                entry_data = entry
            
            pkt = b"QSLCLEND" + entry_data + params
            resp = qslcl_dispatch(dev, "ENGINE", pkt)
            status = decode_runtime_result(resp)
            
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {crash_type} crash triggered successfully via common QSLCLEND opcode 0x{opcode:02X}")
                return True
            else:
                print(f"[!] Common QSLCLEND crash opcode 0x{opcode:02X} failed: {status}")
                return False
    
    return None

def try_vm5_crash_service(dev, crash_type, params):
    """
    Try QSLCLVM5 crash microservices
    """
    # Check for exact match
    if crash_type in QSLCLVM5_DB:
        print(f"[*] Using QSLCLVM5 crash microservice: {crash_type}")
        raw = QSLCLVM5_DB[crash_type]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {crash_type} crash triggered successfully via QSLCLVM5")
            return True
        else:
            print(f"[!] QSLCLVM5 crash '{crash_type}' failed: {status}")
            return False
    
    # Check for CRASH_ prefixed VM5 services
    crash_prefixed = f"CRASH_{crash_type}"
    if crash_prefixed in QSLCLVM5_DB:
        print(f"[*] Using QSLCLVM5 crash microservice: {crash_prefixed}")
        raw = QSLCLVM5_DB[crash_prefixed]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {crash_type} crash triggered successfully via QSLCLVM5 {crash_prefixed}")
            return True
        else:
            print(f"[!] QSLCLVM5 crash '{crash_prefixed}' failed: {status}")
            return False
    
    return None

def try_idx_crash_command(dev, crash_type, params):
    """
    Try QSLCLIDX crash commands
    """
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if crash_type.upper() == entry_name.upper() or f"CRASH_{crash_type}".upper() == entry_name.upper():
                idx = entry.get('idx', 0)
                print(f"[*] Using QSLCLIDX crash command: {name} (idx: 0x{idx:02X})")
                
                pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
                resp = qslcl_dispatch(dev, "IDX", pkt)
                status = decode_runtime_result(resp)
                
                if status.get("severity") == "SUCCESS":
                    print(f"[✓] {crash_type} crash triggered successfully via QSLCLIDX {name}")
                    return True
                else:
                    print(f"[!] QSLCLIDX crash '{name}' failed: {status}")
                    return False
    
    return None

def try_generic_crash_injection(dev, crash_type, params):
    """
    Final fallback: try generic crash injection
    """
    print(f"[*] Trying generic crash injection for '{crash_type}'")
    
    # Try the crash type as a direct command
    resp = qslcl_dispatch(dev, crash_type, params)
    status = decode_runtime_result(resp)
    
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {crash_type} crash triggered successfully via generic injection")
        return True
    else:
        print(f"[!] Generic crash injection for '{crash_type}' failed: {status}")
        return False

def monitor_crash_aftermath(dev, crash_type):
    """
    Monitor device state after crash attempt
    """
    print(f"[*] Monitoring crash aftermath for {crash_type}...")
    
    # Wait a moment for crash to manifest
    time.sleep(2)
    
    # Try to communicate with device
    print("[*] Checking device responsiveness...")
    
    try:
        # Try simple ping to check if device is alive
        resp = qslcl_dispatch(dev, "PING", b"")
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print("[~] Device appears to have survived the crash attempt")
                return "SURVIVED"
            else:
                print("[~] Device responded with error after crash attempt")
                return "ERROR_RESPONSE"
    except:
        pass
    
    # If we get here, device is likely unresponsive
    print("[!] Device appears unresponsive after crash attempt")
    
    # Try to detect if device rebooted
    print("[*] Checking for device reboot...")
    time.sleep(5)
    
    try:
        # Scan for devices again
        new_devs = scan_all()
        if new_devs:
            print("[~] Device detected after crash - may have rebooted")
            return "REBOOTED"
        else:
            print("[!] No devices detected - device may be in crash state")
            return "CRASHED"
    except:
        print("[!] Unable to determine device state")
        return "UNKNOWN"

def cmd_crash_test(args):
    """
    Safe crash test command for validation
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    print("[*] Running safe crash test...")
    
    # Use TEST or DUMMY crash type for safe testing
    resp = qslcl_dispatch(dev, "CRASH", b"TEST\x00")
    status = decode_runtime_result(resp)
    
    if status.get("severity") == "SUCCESS":
        print("[✓] Safe crash test completed successfully")
        return True
    else:
        print(f"[!] Safe crash test failed: {status}")
        return False

def update_crash_parser(sub):
    """
    Update the CRASH command parser with new subcommands
    """
    crash_parser = sub.add_parser("crash", help="Controlled crash simulation commands")
    crash_parser.add_argument("crash_subcommand", help="Crash subcommand (list, test, or crash type)")
    crash_parser.add_argument("crash_args", nargs="*", help="Additional arguments for crash command")
    crash_parser.set_defaults(func=cmd_crash)

    test_parser = sub.add_parser("crash-test", help="Safe crash functionality test")
    test_parser.set_defaults(func=cmd_crash_test)