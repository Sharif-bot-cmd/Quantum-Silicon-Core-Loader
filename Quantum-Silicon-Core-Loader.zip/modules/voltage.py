def cmd_voltage(args):
    """
    Advanced VOLTAGE command handler for power management and voltage control
    Supports voltage reading, regulation, and power domain control
    """
    devs = scan_all()
    if not devs:
        return print("[!] No device connected.")
    
    dev = devs[0]
    auto_loader_if_needed(args, dev)
    
    # Parse VOLTAGE subcommand
    if not hasattr(args, 'voltage_subcommand') or not args.voltage_subcommand:
        return print("[!] VOLTAGE command requires subcommand (list, read, set, domains, etc.)")
    
    subcmd = args.voltage_subcommand.upper()
    
    if subcmd == "LIST":
        return list_available_voltage_commands(dev)
    elif subcmd == "READ":
        return read_voltage_values(dev, args)
    elif subcmd == "SET":
        return set_voltage_values(dev, args)
    elif subcmd == "DOMAINS":
        return list_power_domains(dev)
    elif subcmd == "MONITOR":
        return monitor_voltage_continuous(dev, args)
    elif subcmd == "CALIBRATE":
        return calibrate_voltage_sensors(dev, args)
    elif subcmd == "PROFILE":
        return manage_power_profiles(dev, args)
    else:
        return handle_voltage_operation(dev, subcmd, args)

def list_available_voltage_commands(dev):
    """
    List all available VOLTAGE commands from QSLCL loader
    """
    print("\n" + "="*60)
    print("[*] AVAILABLE QSLCL VOLTAGE & POWER COMMANDS")
    print("="*60)
    
    voltage_found = []
    
    # Check QSLCLPAR for VOLTAGE commands
    print("\n[QSLCLPAR] Voltage Commands:")
    par_voltage = [cmd for cmd in QSLCLPAR_DB.keys() if any(x in cmd.upper() for x in ["VOLTAGE", "POWER", "VDD", "VREG", "PMIC", "BATTERY"])]
    for voltage_cmd in par_voltage:
        print(f"  • {voltage_cmd}")
        voltage_found.append(voltage_cmd)
    
    # Check QSLCLEND for voltage-related opcodes
    print("\n[QSLCLEND] Voltage Opcodes:")
    for opcode, entry in QSLCLEND_DB.items():
        entry_name = entry.get('name', '') if isinstance(entry, dict) else ''
        entry_str = str(entry).upper()
        if any(x in entry_name.upper() for x in ["VOLTAGE", "POWER", "VDD", "PMIC"]) or any(x in entry_str for x in ["VOLT", "PWR", "VDD"]):
            print(f"  • Opcode 0x{opcode:02X}: {entry_name or 'UNKNOWN'}")
            voltage_found.append(f"ENGINE_0x{opcode:02X}")
    
    # Check QSLCLVM5 for voltage microservices
    print("\n[QSLCLVM5] Voltage Microservices:")
    vm5_voltage = [cmd for cmd in QSLCLVM5_DB.keys() if any(x in cmd.upper() for x in ["VOLTAGE", "POWER", "PMIC"])]
    for voltage_cmd in vm5_voltage:
        print(f"  • {voltage_cmd}")
        voltage_found.append(f"VM5_{voltage_cmd}")
    
    # Check QSLCLIDX for voltage indices
    print("\n[QSLCLIDX] Voltage Indices:")
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict):
            entry_name = entry.get('name', '')
            if any(x in entry_name.upper() for x in ["VOLTAGE", "POWER", "PMIC"]):
                print(f"  • {name} (idx: 0x{entry.get('idx', 0):02X})")
                voltage_found.append(f"IDX_{name}")
    
    if not voltage_found:
        print("  No voltage commands found in loader")
    else:
        print(f"\n[*] Total voltage commands found: {len(voltage_found)}")
    
    print("\n[*] Common Voltage Operations Available:")
    print("  • READ         - Read voltage values from various domains")
    print("  • SET          - Set voltage values for specific domains")
    print("  • DOMAINS      - List available power domains")
    print("  • MONITOR      - Continuous voltage monitoring")
    print("  • CALIBRATE    - Calibrate voltage sensors")
    print("  • PROFILE      - Manage power profiles")
    print("  • PMIC         - PMIC register access")
    print("  • BUCK         - Buck converter control")
    print("  • LDO          - LDO regulator control")
    print("  • BANDGAP      - Bandgap reference control")
    
    print("="*60)
    
    return True

def read_voltage_values(dev, args):
    """
    Read voltage values from various power domains
    """
    target_domain = None
    if hasattr(args, 'voltage_args') and args.voltage_args:
        target_domain = args.voltage_args[0].upper()
    
    print("[*] Reading voltage values...")
    
    # Get available power domains
    domains = get_power_domains(dev)
    
    readings = {}
    
    if target_domain and target_domain in domains:
        # Read specific domain
        voltage = read_single_voltage(dev, target_domain)
        if voltage is not None:
            readings[target_domain] = voltage
            print(f"  [✓] {target_domain}: {voltage:.3f}V")
        else:
            print(f"  [!] Failed to read {target_domain}")
    else:
        # Read all domains
        for domain in domains:
            voltage = read_single_voltage(dev, domain)
            if voltage is not None:
                readings[domain] = voltage
                print(f"  [✓] {domain}: {voltage:.3f}V")
            else:
                print(f"  [!] Failed to read {domain}")
    
    # Display summary
    if readings:
        print(f"\n[*] Voltage Summary ({len(readings)} domains):")
        for domain, voltage in sorted(readings.items()):
            status = "NORMAL" if is_voltage_normal(domain, voltage) else "WARNING"
            print(f"  • {domain}: {voltage:.3f}V [{status}]")
    
    return len(readings) > 0

def read_single_voltage(dev, domain):
    """
    Read voltage from a specific power domain
    """
    # Try direct voltage read command
    payload = domain.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "VOLTAGE", b"READ\x00" + payload)
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 4:
                # Voltage in millivolts (common format)
                voltage_mv = struct.unpack("<I", extra[:4])[0]
                return voltage_mv / 1000.0  # Convert to volts
    
    # Try domain-specific command
    resp = qslcl_dispatch(dev, f"VOLTAGE_{domain}", b"")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            if len(extra) >= 4:
                voltage_mv = struct.unpack("<I", extra[:4])[0]
                return voltage_mv / 1000.0
    
    return None

def get_power_domains(dev):
    """
    Get list of available power domains
    """
    # Common power domains across SOCs
    common_domains = [
        "VDD_CPU", "VDD_GPU", "VDD_DDR", "VDD_CORE", "VDD_MEM", 
        "VDD_IO", "VDD_AON", "VDD_RF", "VDD_MODEM", "VDD_PLL",
        "VDD_USB", "VDD_SRAM", "VDD_ANALOG", "VDD_DIGITAL", "VDD_Q6",
        "BATTERY", "VREG_S1", "VREG_S2", "VREG_S3", "VREG_S4",
        "VDD_APC0", "VDD_APC1", "VDD_GFX", "VDD_MX", "VDD_CX"
    ]
    
    # Try to get domains from device
    resp = qslcl_dispatch(dev, "VOLTAGE", b"DOMAINS\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            try:
                # Parse domain list from response
                domain_list = extra.decode('utf-8', errors='ignore').split('\x00')
                return [d.strip() for d in domain_list if d.strip()]
            except:
                pass
    
    return common_domains

def is_voltage_normal(domain, voltage):
    """
    Check if voltage is within normal range for the domain
    """
    # Typical voltage ranges for common domains (in volts)
    voltage_ranges = {
        "VDD_CPU": (0.8, 1.4),
        "VDD_GPU": (0.8, 1.2),
        "VDD_DDR": (1.1, 1.4),
        "VDD_CORE": (0.9, 1.1),
        "VDD_IO": (1.8, 3.3),
        "VDD_MEM": (1.1, 1.4),
        "BATTERY": (3.0, 4.4),
        "VDD_RF": (2.7, 3.3),
        "VDD_PLL": (1.2, 1.4),
    }
    
    if domain in voltage_ranges:
        min_v, max_v = voltage_ranges[domain]
        return min_v <= voltage <= max_v
    
    return True  # Unknown domain, assume normal

def set_voltage_values(dev, args):
    """
    Set voltage values for specific power domains
    """
    if not hasattr(args, 'voltage_args') or len(args.voltage_args) < 2:
        return print("[!] SET requires domain and voltage (e.g., VDD_CPU 1.2)")
    
    domain = args.voltage_args[0].upper()
    voltage_str = args.voltage_args[1]
    
    try:
        if 'mv' in voltage_str.lower():
            voltage_mv = int(voltage_str.lower().replace('mv', '').strip())
        else:
            voltage = float(voltage_str)
            voltage_mv = int(voltage * 1000)  # Convert to millivolts
    except ValueError:
        return print("[!] Invalid voltage value")
    
    print(f"[!] WARNING: Setting {domain} to {voltage_mv}mV")
    print("[!] This may cause device instability or damage!")
    
    confirm = input("!! CONFIRM VOLTAGE CHANGE (type 'YES' to continue): ").strip().upper()
    if confirm != "YES":
        print("[*] Voltage change cancelled")
        return False
    
    # Execute voltage set
    success = set_single_voltage(dev, domain, voltage_mv)
    
    if success:
        # Verify the change
        new_voltage = read_single_voltage(dev, domain)
        if new_voltage is not None:
            print(f"[✓] {domain} set to {new_voltage:.3f}V")
        else:
            print(f"[✓] {domain} voltage change executed (verification failed)")
    
    return success

def set_single_voltage(dev, domain, voltage_mv):
    """
    Set voltage for a specific power domain
    """
    # Build voltage set payload
    payload = domain.encode() + b"\x00" + struct.pack("<I", voltage_mv)
    
    # Try direct voltage set command
    resp = qslcl_dispatch(dev, "VOLTAGE", b"SET\x00" + payload)
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {domain} voltage set to {voltage_mv}mV via VOLTAGE SET")
            return True
    
    # Try domain-specific set command
    resp = qslcl_dispatch(dev, f"SET_{domain}", struct.pack("<I", voltage_mv))
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {domain} voltage set to {voltage_mv}mV via domain command")
            return True
    
    # Try PMIC register write for advanced users
    if try_pmic_voltage_set(dev, domain, voltage_mv):
        return True
    
    print(f"[!] Failed to set {domain} voltage")
    return False

def try_pmic_voltage_set(dev, domain, voltage_mv):
    """
    Try PMIC register-based voltage setting (advanced)
    """
    # Map domains to common PMIC registers
    pmic_registers = {
        "VDD_CPU": (0x1400, 0x1401),  # S1 voltage control
        "VDD_GPU": (0x1500, 0x1501),  # S2 voltage control  
        "VDD_DDR": (0x1600, 0x1601),  # S3 voltage control
        "VDD_CORE": (0x1700, 0x1701), # S4 voltage control
    }
    
    if domain in pmic_registers:
        vsen_reg, vctl_reg = pmic_registers[domain]
        
        # Convert voltage to PMIC register value (typical formula)
        # This varies by PMIC - using approximate formula for common PMICs
        if voltage_mv < 800: voltage_mv = 800
        if voltage_mv > 1400: voltage_mv = 1400
        
        # Approximate conversion (exact formula depends on PMIC)
        reg_value = ((voltage_mv - 800) // 10) & 0x7F
        
        # Write to PMIC register
        payload = struct.pack("<HH", vctl_reg, reg_value)
        resp = qslcl_dispatch(dev, "PMIC_WRITE", payload)
        
        if resp:
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {domain} set to {voltage_mv}mV via PMIC register 0x{vctl_reg:04X}")
                return True
    
    return False

def list_power_domains(dev):
    """
    List all available power domains with current voltages
    """
    print("[*] Scanning power domains...")
    
    domains = get_power_domains(dev)
    
    print(f"\n[*] Found {len(domains)} power domains:")
    print("-" * 50)
    
    for domain in domains:
        voltage = read_single_voltage(dev, domain)
        if voltage is not None:
            status = "NORMAL" if is_voltage_normal(domain, voltage) else "WARNING"
            print(f"  • {domain:<15} : {voltage:6.3f}V [{status}]")
        else:
            print(f"  • {domain:<15} : UNREADABLE")
    
    return True

def monitor_voltage_continuous(dev, args):
    """
    Continuous voltage monitoring with real-time display
    """
    duration = 30  # Default 30 seconds
    interval = 1   # Default 1 second intervals
    
    if hasattr(args, 'voltage_args'):
        if len(args.voltage_args) > 0:
            try:
                duration = int(args.voltage_args[0])
            except:
                pass
        if len(args.voltage_args) > 1:
            try:
                interval = float(args.voltage_args[1])
            except:
                pass
    
    target_domains = []
    if hasattr(args, 'voltage_args') and len(args.voltage_args) > 2:
        target_domains = [d.upper() for d in args.voltage_args[2:]]
    
    domains = get_power_domains(dev)
    if target_domains:
        domains = [d for d in domains if d in target_domains]
    
    print(f"[*] Starting voltage monitoring for {duration} seconds...")
    print("[*] Press Ctrl+C to stop early")
    
    start_time = time.time()
    end_time = start_time + duration
    
    try:
        while time.time() < end_time:
            elapsed = time.time() - start_time
            print(f"\n[*] Time: {elapsed:5.1f}s")
            print("-" * 40)
            
            for domain in domains:
                voltage = read_single_voltage(dev, domain)
                if voltage is not None:
                    status = "✓" if is_voltage_normal(domain, voltage) else "!"
                    print(f"  {status} {domain:<15} : {voltage:6.3f}V")
                else:
                    print(f"  ? {domain:<15} : ---.--V")
            
            time.sleep(interval)
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring stopped by user")
    
    print("[*] Voltage monitoring completed")
    return True

def calibrate_voltage_sensors(dev, args):
    """
    Calibrate voltage sensors and ADCs
    """
    print("[*] Starting voltage sensor calibration...")
    
    calibration_type = "AUTO"
    if hasattr(args, 'voltage_args') and args.voltage_args:
        calibration_type = args.voltage_args[0].upper()
    
    # Try calibration command
    payload = calibration_type.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "VOLTAGE", b"CALIBRATE\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print("[✓] Voltage calibration completed successfully")
            
            # Read calibration results if available
            extra = status.get("extra", b"")
            if extra:
                try:
                    cal_data = extra.decode('utf-8', errors='ignore')
                    print(f"[*] Calibration data: {cal_data}")
                except:
                    print(f"[*] Calibration data (raw): {extra.hex()}")
            
            return True
        else:
            print(f"[!] Voltage calibration failed: {status}")
            return False
    
    print("[!] No voltage calibration command available")
    return False

def manage_power_profiles(dev, args):
    """
    Manage power profiles and performance states
    """
    if not hasattr(args, 'voltage_args') or not args.voltage_args:
        return list_power_profiles(dev)
    
    action = args.voltage_args[0].upper()
    
    if action == "LIST":
        return list_power_profiles(dev)

    elif action == "SET":
        if len(args.voltage_args) < 2:
            return print("[!] PROFILE SET requires profile name")
        profile = args.voltage_args[1].upper()
        return set_power_profile(dev, profile)

    elif action == "CREATE":
        return create_power_profile(dev, args)

    else:
        # FIXED LINE — fully closed parenthesis
        return handle_power_profile_action(dev, action, args)

def list_power_profiles(dev):
    """
    List available power profiles
    """
    print("[*] Available power profiles:")
    
    common_profiles = [
        "PERFORMANCE", "BALANCED", "POWER_SAVE", "ULTRA_SAVE",
        "GAMING", "BENCHMARK", "THERMAL", "DEFAULT"
    ]
    
    # Try to get profiles from device
    resp = qslcl_dispatch(dev, "VOLTAGE", b"PROFILES\x00")
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            extra = status.get("extra", b"")
            try:
                profiles = extra.decode('utf-8', errors='ignore').split('\x00')
                common_profiles = [p.strip() for p in profiles if p.strip()]
            except:
                pass
    
    for profile in common_profiles:
        print(f"  • {profile}")
    
    return True

def set_power_profile(dev, profile):
    """
    Set active power profile
    """
    print(f"[*] Setting power profile to {profile}...")
    
    payload = profile.encode() + b"\x00"
    resp = qslcl_dispatch(dev, "VOLTAGE", b"PROFILE_SET\x00" + payload)
    
    if resp:
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] Power profile set to {profile}")
            return True
        else:
            print(f"[!] Failed to set power profile: {status}")
            return False
    
    print(f"[!] No power profile support available")
    return False

def handle_voltage_operation(dev, operation, args):
    """
    Handle other voltage operations (PMIC, BUCK, LDO, etc.)
    """
    print(f"[*] Executing voltage operation: {operation}")
    
    # Build operation parameters
    params = build_voltage_operation_params(operation, args)
    
    # Try different operation strategies
    strategies = [
        try_direct_voltage_operation,
        try_par_voltage_command,
        try_end_voltage_opcode,
        try_vm5_voltage_service,
        try_idx_voltage_command,
    ]
    
    for strategy in strategies:
        success = strategy(dev, operation, params)
        if success is not None:
            return success
    
    print(f"[!] Failed to execute voltage operation: {operation}")
    return False

def build_voltage_operation_params(operation, args):
    """
    Build parameters for voltage operations
    """
    params = bytearray()
    
    # Add operation identifier
    op_hash = sum(operation.encode()) & 0xFFFF
    params.extend(struct.pack("<H", op_hash))
    
    # Add parameters from arguments
    if hasattr(args, 'voltage_args'):
        for arg in args.voltage_args:
            try:
                if arg.startswith("0x"):
                    params.extend(struct.pack("<I", int(arg, 16)))
                elif '.' in arg:
                    params.extend(struct.pack("<f", float(arg)))
                else:
                    params.extend(struct.pack("<I", int(arg)))
            except:
                params.extend(arg.encode() + b"\x00")
    
    return bytes(params)

def try_direct_voltage_operation(dev, operation, params):
    """Try direct voltage operation"""
    resp = qslcl_dispatch(dev, "VOLTAGE", operation.encode() + b"\x00" + params)
    status = decode_runtime_result(resp)
    if status.get("severity") == "SUCCESS":
        print(f"[✓] {operation} executed successfully")
        return True
    return None

def try_par_voltage_command(dev, operation, params):
    """Try QSLCLPAR voltage command"""
    if operation in QSLCLPAR_DB:
        resp = qslcl_dispatch(dev, operation, params)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLPAR")
            return True
    return None

def try_end_voltage_opcode(dev, operation, params):
    """Try QSLCLEND voltage opcode"""
    opcode = sum(operation.encode()) & 0xFF
    if opcode in QSLCLEND_DB:
        entry = QSLCLEND_DB[opcode]
        entry_data = entry.get("raw", b"") if isinstance(entry, dict) else entry
        pkt = b"QSLCLEND" + entry_data + params
        resp = qslcl_dispatch(dev, "ENGINE", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLEND opcode 0x{opcode:02X}")
            return True
    return None

def try_vm5_voltage_service(dev, operation, params):
    """Try QSLCLVM5 voltage service"""
    if operation in QSLCLVM5_DB:
        raw = QSLCLVM5_DB[operation]["raw"]
        pkt = b"QSLCLVM5" + raw + params
        resp = qslcl_dispatch(dev, "NANO", pkt)
        status = decode_runtime_result(resp)
        if status.get("severity") == "SUCCESS":
            print(f"[✓] {operation} executed via QSLCLVM5")
            return True
    return None

def try_idx_voltage_command(dev, operation, params):
    """Try QSLCLIDX voltage command"""
    for name, entry in QSLCLIDX_DB.items():
        if isinstance(entry, dict) and entry.get('name', '').upper() == operation:
            idx = entry.get('idx', 0)
            pkt = b"QSLCLIDX" + struct.pack("<I", idx) + params
            resp = qslcl_dispatch(dev, "IDX", pkt)
            status = decode_runtime_result(resp)
            if status.get("severity") == "SUCCESS":
                print(f"[✓] {operation} executed via QSLCLIDX {name}")
                return True
    return None

def create_power_profile(dev, args):
    """Create custom power profile (placeholder)"""
    print("[*] Custom power profile creation not yet implemented")
    return False

def handle_power_profile_action(dev, action, args):
    """Handle other power profile actions"""
    print(f"[*] Power profile action '{action}' not yet implemented")
    return False

def update_voltage_parser(sub):
    """
    Update the VOLTAGE command parser with new subcommands
    """
    voltage_parser = sub.add_parser("voltage", help="Voltage and power management commands")
    voltage_parser.add_argument("voltage_subcommand", help="Voltage subcommand (list, read, set, domains, monitor, calibrate, profile)")
    voltage_parser.add_argument("voltage_args", nargs="*", help="Additional arguments for voltage command")
    voltage_parser.set_defaults(func=cmd_voltage)